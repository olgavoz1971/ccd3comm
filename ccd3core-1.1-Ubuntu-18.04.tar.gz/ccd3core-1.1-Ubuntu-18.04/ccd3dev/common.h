#ifndef COMMON_H_
#define COMMON_H_

#ifdef DEBUG

#define DBG(msg, args...) do { 				\
    printk(KERN_DEBUG "[%s] " msg , __func__ , ##args );\
} while (0)

#else /* !defined(DEBUG) */
#define DBG(msg, args...) do {} while (0)
#endif /* !defined(DEBUG) */


#endif /*COMMON_H_*/
