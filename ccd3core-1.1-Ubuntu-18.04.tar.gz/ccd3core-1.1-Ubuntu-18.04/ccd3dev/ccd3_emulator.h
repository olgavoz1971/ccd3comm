#ifndef _CCD3_EMULATOR_H_
#define _CCD3_EMULATOR_H_

#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/mm.h>


unsigned em_progress(void);
unsigned em_xsiz(void);
unsigned em_ysiz(void);
void em_interpreter(char* cmd, char* reply);
int em_open(void);
int em_close(void);
int em_reset(void);
int* em_buffer(void);
void em_update_timing(void);
void em_vma_fault(int no_pci, struct vm_fault* vmf);

#endif
