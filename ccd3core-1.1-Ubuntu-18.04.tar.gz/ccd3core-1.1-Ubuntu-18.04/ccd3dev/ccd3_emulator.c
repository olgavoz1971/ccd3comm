#include <linux/jiffies.h>
#include <linux/timer.h>
#include <linux/slab.h>
#include "ccd3_emulator.h"

#define MAX_DETECTOR_CNT 4
#define MAX_AMPLIFIER_CNT 4
#define MAX_DETECTOR_MASK 0xF
#define MAX_AMPLIFIER_MASK 0xF

#define cmd_len 7
#define reply_len 32

// only used when emulation hardware
typedef struct {
	char cmd[cmd_len];
	char reply[reply_len];
	bool indexed;
	bool can_cmd;
	bool can_ask;
}ccd3_controller_cmd;

#define STAT_IDX 0
#define SINT_IDX 1
#define TIMR_IDX 2
#define TIMA_IDX 3
#define TIME_IDX 4
#define BREK_IDX 5
#define HOLD_IDX 6
#define XSIZ_IDX 7
#define YSIZ_IDX 8
#define DEAV_IDX 9
#define DEEN_IDX 10
#define RDAV_IDX 11
#define RDEN_IDX 12
#define FPIX_IDX 13

ccd3_controller_cmd controller_cmds[] = {
		{"stat", "4",			false, false, true},
		{"sint", "",			false, true,  false},
		{"timr", "0",			false, true,  true},
		{"tima", "0",			false, false, true},
		{"time", "1443",		false, true,  true},
		{"brek", "",			false, true,  false},
		{"hold", "0",			false, true,  true},
		{"xsiz", "2148",		false, true,  true},
		{"ysiz", "4102",		false, true,  true},
		{"deav", "3",			false, false, true},
		{"deen", "3",			false, true,  true},
		{"rdav", "3",			false, false, true},
		{"rden", "3",			true,  true,  true},
		{"fpix", "400",			false, false, true},
		{"xbin", "1",			false, true,  true},
		{"ybin", "1",			false, true,  true},
		{"xbeg", "1",			false, true,  true},
		{"ybeg", "1",			false, true,  true},
		{"xtot", "2148",		false, true,  true},
		{"ytot", "4102",		false, true,  true},
		{"tsam", "72",			false, true,  true},
		{"tspw", "24",			false, true,  true},
		{"tsol", "4",			false, true,  true},
		{"tstr", "8",			false, true,  true},
		{"tsnd", "6",			false, true,  true},
		{"tppw", "250",			false, true,  true},
		{"tpol", "125",			false, true,  true},
		{"tptr", "40",			false, true,  true},
		{"cdsg", "50000",		false, true,  true},
		{"vbha", "23.000",		true,  true,  true},
		{"vbhb", "2.000",		true,  true,  true},
		{"vbhc", "24.000",		true,  true,  true},
		{"vbla", "-3.500",		true,  true,  true},
		{"vblb", "-2.500",		true,  true,  true},
		{"gain", "1.000",		true,  true,  true},
		{"offs", "500",			true,  true,  true},
		{"zero", "10000",		true,  true,  true},
		{"tmpa", "0.00",		false, false, true},
		{"tmpw", "30.0",		false, false, true},
		{"tmpl", "0.00",		false, false, true},
		{"pres", "0.00e+00",	false, false, true},
		{"read", "0",			false, true,  true},
		{"shut", "1",			false, true,  true},
		{"fres", "",			false, true,  false},
		{"rexp", "1",			false, true,  true},
		{"sdly", "500",			false, true,  true},
		{"vshi", "5.000",		false, true,  true},
		{"vslo", "-5.000",		false, true, true},
		{"vphi", "2.000",		false, true, true},
		{"vplo", "-9.000",		false, true, true},
		{"","",					false, false, false}
};

#define STAT_IDLE			4
#define STAT_INTEGRATING	4100
#define STAT_HOLD			4108
#define STAT_READOUT		8196

long unsigned progress = 0;
long unsigned start_exp = 0;
long unsigned hold_time = 0;
long unsigned hold_exp = 0;
long unsigned hold_start = 0;
long unsigned start_readout = 0;
unsigned amp_cnt = 0;
unsigned detector_cnt = 0;
unsigned stat = STAT_IDLE;
unsigned time = 0;
unsigned pixcnt = 0;
unsigned fpix = 0;

// DMY_BUFSIZE has to be complete pages
#define DMY_BUFSIZE PAGE_SIZE
int* dmy_buffer = NULL;
static struct timer_list my_timer;

// Jk Ubuntu 18.04
//void timer_callback( unsigned long data )
void timer_callback( struct timer_list *data )
{
	del_timer( &my_timer );
	em_update_timing();
}

void em_start_exposure(void)
{
	unsigned xsiz, ysiz, deen, rden, n;

	printk("Emulator starting exposure\n");
	hold_time = 0;
	hold_exp = 0;
	start_exp = jiffies;
	stat = STAT_INTEGRATING;
	sscanf(controller_cmds[TIME_IDX].reply, "%u", &time);
	sscanf(controller_cmds[XSIZ_IDX].reply, "%u", &xsiz);
	sscanf(controller_cmds[YSIZ_IDX].reply, "%u", &ysiz);
	sscanf(controller_cmds[DEEN_IDX].reply, "%u", &deen);
	sscanf(controller_cmds[RDEN_IDX].reply, "%u", &rden);
	sscanf(controller_cmds[FPIX_IDX].reply, "%u", &fpix);

	for(n=detector_cnt=0; n < MAX_DETECTOR_CNT; n++){
		if(deen & 0x1 << n){
			detector_cnt++;
		}
	}

	printk("%d detectors\n", detector_cnt);

	for(n=amp_cnt=0; n < MAX_AMPLIFIER_CNT; n++){
		if(rden & 0x1 << n){
			amp_cnt++;
		}
	}
	printk("%d amplifiers\n", amp_cnt);

	pixcnt = xsiz * ysiz * detector_cnt;
	printk("%d pixels\n", pixcnt);

// Jk Ubuntu 18.04
//	setup_timer( &my_timer, timer_callback, 0 );
        timer_setup( &my_timer, timer_callback, 0 );
	mod_timer( &my_timer, jiffies + msecs_to_jiffies(time) );

}

void em_start_readout(void)
{
	if( stat == STAT_INTEGRATING ){
		start_readout = jiffies;
		stat = STAT_READOUT;
		printk("Emulator starting readout\n");
// Jk Ubuntu 18.04
//		setup_timer( &my_timer, timer_callback, 0 );
                timer_setup( &my_timer, timer_callback, 0 );
		mod_timer( &my_timer, jiffies + msecs_to_jiffies( pixcnt / (detector_cnt * amp_cnt * fpix) ) );
	}
}

void em_end_readout(void){
	printk("Emulator ending readout\n");
	stat = STAT_IDLE;
}

void em_start_hold(void){
	if( hold_start ) return;
	hold_start = jiffies;
	printk("Emulator hold\n");
}

void em_end_hold(void){
	long unsigned now = jiffies;
	if( !hold_start ) return;
	hold_exp = now - hold_start;
	hold_time = hold_time + hold_exp;
	hold_start = 0;
	hold_exp = 0;
	printk("Emulator end hold\n");
}

unsigned em_progress(void){
	em_update_timing();
	return progress;
}

int em_open(void){
	printk("Emulating ccd3 acquisition card\n");

	if( dmy_buffer ){
		printk("Freed dmy_buffer in em_open()\n");
		kfree(dmy_buffer);
	}

	dmy_buffer = kmalloc(DMY_BUFSIZE, GFP_KERNEL);
	if( !dmy_buffer ){
		printk("Failed allocating emulation buffer\n");
	}
	return 0;
}

int em_close(void){
	printk("Emulator close\n");
	if( dmy_buffer ){
		kfree(dmy_buffer);
		dmy_buffer = NULL;
	}
	return 0;
}

int em_reset(void){
	printk("Emulator reset\n");
	hold_time = 0;
	hold_exp = 0;
	hold_start = 0;
	//start_readout = 0;
	//amp_cnt = 0;
	//detector_cnt = 0;
	//time = 0;
	//pixcnt = 0;
	//fpix = 0;
	progress = 0;
	//start_exp = 0;
	//stat = STAT_IDLE;
	del_timer( &my_timer );
	return 0;
}

int* em_buffer(void){
	return dmy_buffer;
}

void em_update_timing(void){
	long unsigned tima;
	long unsigned timr;
	long unsigned now;

	now = jiffies;

	switch (stat) {
	case STAT_READOUT:
		progress = detector_cnt * amp_cnt * fpix * 1000 * (now - start_readout) / HZ;
		if( progress >= pixcnt ){
			progress = pixcnt;
			em_end_readout();
		}
		break;

	case STAT_INTEGRATING:
		if( hold_start ){
			hold_exp = now - hold_start;
		}

		tima = (now - start_exp - hold_exp - hold_time) * 1000 / HZ;
		timr = time - tima;
		if( tima >= time ){
			tima = time;
			timr = 0;
			em_start_readout();
		}
		sprintf(controller_cmds[TIMA_IDX].reply, "%lu", tima);
		sprintf(controller_cmds[TIMR_IDX].reply, "%lu", timr);
		break;
	} // switch
}

void em_vma_fault(int no_pci, struct vm_fault* vmf){
	unsigned n = 0;

	printk("em_wma_fault(), no_pci=%d\n", no_pci);
	switch( no_pci ){
	case 1: // Running counter
		for(n = 0; n < (DMY_BUFSIZE >> 2); n++){
			dmy_buffer[n] = n + (DMY_BUFSIZE >> 2) * vmf->pgoff;
		}
		break;

	case 2: // Grayscale left to right
		for(n = 0; n < (DMY_BUFSIZE >> 2); n++){
			dmy_buffer[n] = (n + (DMY_BUFSIZE >> 2) * vmf->pgoff) % em_xsiz();
		}
		break;

	case 3: // Grayscale right to left
		for(n = 0; n < (DMY_BUFSIZE >> 2); n++){
			dmy_buffer[n] = em_xsiz() - ((n + (DMY_BUFSIZE >> 2) * vmf->pgoff) % em_xsiz());
		}
		break;

	case 4: // Grayscale bottom to top
		for(n = 0; n < (DMY_BUFSIZE >> 2); n++){
			dmy_buffer[n] = n + (DMY_BUFSIZE >> 2) * vmf->pgoff;
		}
		break;

	case 5: // 2 amp, running counter, 1Meg offset in each amp
		for(n = 0; n < (DMY_BUFSIZE >> 2); n++){
			dmy_buffer[n] = 1000000 + (n % 2) * 1000000 + ((n + (DMY_BUFSIZE >> 2) * vmf->pgoff) >> 1);
		}
		break;

	case 6: // 4 amp, running counter, 1Meg offset in each amp
		for(n = 0; n < (DMY_BUFSIZE >> 2); n++){
			dmy_buffer[n] = 1000000 + (n % 4) * 1000000 + ((n + (DMY_BUFSIZE >> 2) * vmf->pgoff) >> 1);
		}
		break;

	case 7: // 100 0 100 0 100 0 100 0
	case 8: // 0 100 200 300 0 100 200 300
	default:
		printk("Invalid no_pci option in emulator mode!\n");
		break;
	}

}

unsigned em_xsiz(void){
	int xsiz = 2148;
	if( 1 != sscanf(controller_cmds[XSIZ_IDX].reply, "%u", &xsiz)){
		printk("Unable to translate \"%s\"\n", controller_cmds[XSIZ_IDX].reply);
	}
	return xsiz;
}

unsigned em_ysiz(void){
	int ysiz = 4102;
	if( 1 != sscanf(controller_cmds[YSIZ_IDX].reply, "%u", &ysiz)){
		printk("Unable to translate \"%s\"\n", controller_cmds[YSIZ_IDX].reply);
	}
	return ysiz;
}

void em_interpreter(char* cmd, char* reply){
	int n = 0;
	int index = 0;
	int cmd_idx = 0;
	char* my_cmd = &cmd[1];
	char parm[256];
	bool is_cmd = cmd[0] == '@';
	bool is_req = cmd[0] == '?';

	while( cmd[strlen(cmd) - 1] == '\n' || cmd[strlen(cmd) - 1] == '\r' ){
		cmd[strlen(cmd) - 1] = '\0';
	}

	for(cmd_idx = 0; strlen(controller_cmds[cmd_idx].cmd); cmd_idx++){
		if( !strncasecmp(controller_cmds[cmd_idx].cmd, my_cmd, strlen(controller_cmds[cmd_idx].cmd))){
			break;
		}
	}

	if( !strlen(controller_cmds[cmd_idx].cmd) || (is_cmd && !controller_cmds[cmd_idx].can_cmd) || (is_req && !controller_cmds[cmd_idx].can_ask) ){
		sprintf(reply, "!Error: (emulator) Request unknown '%s'\n", cmd);
		return;
	} else {

		if( is_cmd ){

			if(!controller_cmds[cmd_idx].indexed || sscanf(my_cmd, "%*s %d %s", &index, parm) != 2){
				index = 0;
				if( strlen(controller_cmds[cmd_idx].reply) ){
					if( sscanf(my_cmd, "%*s %s", parm) != 1 ){
						sprintf(reply, "!Error: failed handling '%s'\n", cmd);
						return;
					} else {
						//printk("parsed non indexed command\n");
						strcpy(controller_cmds[cmd_idx].reply, parm);
					}
				}
			}

		} else if( is_req ){
			sscanf(my_cmd, "%*s %d", &index);
		} else {
			sprintf(reply, "!Error: invalid command '%s'\n", cmd);
			return;
		}

		em_update_timing();

		switch( cmd_idx ){
		case SINT_IDX:
			em_start_exposure();
			break;
		case STAT_IDX:
			sprintf(controller_cmds[STAT_IDX].reply, "%u", stat);
			break;
		case BREK_IDX:
			em_end_readout();
			break;

		case HOLD_IDX:
			if( is_cmd && sscanf(controller_cmds[HOLD_IDX].reply, "%d", &n) == 1){
				if( n ){
					em_start_hold();
				} else {
					em_end_hold();
				}
			}
			break;

		case DEEN_IDX:
			if( is_cmd ){
				if( sscanf(controller_cmds[DEEN_IDX].reply, "%d", &n) == 1){
					if(n > MAX_DETECTOR_MASK){
						sprintf(controller_cmds[DEEN_IDX].reply, "%d", MAX_DETECTOR_MASK);
						sprintf(reply, "!Error: detector index (%d) out of range\n", n);
						return;
					}
				} else {
					sprintf(reply, "!Error: invalid command '%s'\n", cmd);
					return;
				}
			}
			break;

		case RDEN_IDX:
			if( is_cmd ){
				if( sscanf(controller_cmds[RDEN_IDX].reply, "%d", &n) == 1){
					if(n > MAX_AMPLIFIER_MASK){
						sprintf(controller_cmds[RDEN_IDX].reply, "%d", MAX_AMPLIFIER_MASK);
						sprintf(reply, "!Error: amplifier index (%d) out of range\n", n);
						return;
					}
				} else {
					sprintf(reply, "!Error: invalid command '%s'\n", cmd);
					return;
				}
			}
			break;
		} // switch

		if(controller_cmds[cmd_idx].indexed){
			sprintf(reply, "!%s %d %s\n", controller_cmds[cmd_idx].cmd, index, controller_cmds[cmd_idx].reply);
		} else {
			sprintf(reply, "!%s %s\n", controller_cmds[cmd_idx].cmd, controller_cmds[cmd_idx].reply);
		}
	}

}
