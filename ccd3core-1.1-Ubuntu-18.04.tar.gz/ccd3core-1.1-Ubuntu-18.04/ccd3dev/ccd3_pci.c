#include <linux/interrupt.h>
#include <linux/delay.h> 
#include <linux/sched.h>

#include "ccd3_pci.h"
#include "ccd3_reg.h"
#include "ccd3dev.h"
#include "ccd3.h"
#include "ccd3_print.h"

static irqreturn_t interrupt_handler(int irq, void *dev_id);
unsigned long ccd3_status(unsigned long mask);
int read8(int offset, unsigned char* buf);
int write8(int offset, unsigned char buf);
int read32(int offset, unsigned int* buf);
int write32(int offset, unsigned int buf);
void drv_message(char* msg);
void drv_error(char* msg);

struct ccd3_comm_data{
	struct ccd3_queues queues;
	struct ccd3_comm_status status;
	int no_pci;
	int mem_limit;
};

struct ccd3_comm_data comm_data = {
		.status.tx_down = false,
		.status.rx_down = false,
		.no_pci = 0,
		.mem_limit = 0,
};

///////////////////////////////////////////////////////////////////////////////
#define BUF_SIZE (8*1024*1024)
int ccd3_register(int a_no_pci, int a_mem_limit)
{
	int res = 0;
	comm_data.no_pci = a_no_pci;
	comm_data.mem_limit = a_mem_limit;
	
	init_waitqueue_head(&comm_data.queues.rx_wait);
	init_waitqueue_head(&comm_data.queues.tx_wait);

	if( comm_data.no_pci ){
		print(plDebug, "no_pci=%d\n", comm_data.no_pci);
	} else {
		res = pci_register(comm_data.mem_limit);

		comm_data.queues.mem = (int*)pci_mem();
		comm_data.queues.mem_size = pci_mem_size();
		comm_data.queues.mem_write = 0;
	}

	return res;
}


///////////////////////////////////////////////////////////////////////////////

int ccd3_unregister()
{
	return comm_data.no_pci ? 0 : pci_unregister();
}

///////////////////////////////////////////////////////////////////////////////

int ccd3_enable_irq(void)
{
    if( !comm_data.no_pci ){

    	if( pci_enable_irq(interrupt_handler, IRQF_SHARED) ){
    		return -1;
        }
    	write32(REG_COMMAND, REG_CMD_SET + CMD_IEN_MASTER_POS);

    }

    return 0;
}

///////////////////////////////////////////////////////////////////////////////

int ccd3_disable_irq(void)
{
	if( !comm_data.no_pci ){
		// Disable irq on hardware
		write32(REG_COMMAND, REG_CMD_CLR + CMD_IEN_MASTER_POS);

		// Discard irq handler
		pci_disable_irq();
	}
	return 0;
}

///////////////////////////////////////////////////////////////////
// interrupt handler

static irqreturn_t interrupt_handler(int irq, void *dev_id)
{
	unsigned char ch;
	unsigned int sts;
	int ret = IRQ_NONE;

	sts = ccd3_status(STS_MASK_ALL);

	// Handle outgoing ctl
	if( !TX_BUSY(sts) && IEN_TX_BUSY(sts) ){
		if( char_queue_size(comm_data.queues.tx) ){
			ch = char_queue_get(comm_data.queues.tx);
			//print(plDebug, "irq writing %c\n", ch);
			write8(REG_CHAR, ch);
		} else {
			//print(plDebug, "Disabling tx irq\n");
			write32(REG_COMMAND, REG_CMD_CLR + CMD_IEN_TX_BUSY_POS);
			wake_up_interruptible(&comm_data.queues.tx_wait);
		}
		sts = ccd3_status(STS_MASK_ALL);
		comm_data.status.tx_down = 0;
		ret = IRQ_HANDLED;
	} 

	// Handle incomming ctl
	if( RX_CHAR_READY(sts) && IEN_CHAR_READY(sts) ){

		read8(REG_CHAR, &ch);
		//print(plDebug, "irq read \"%c:0x%X\"\n", ch, ch);
		comm_data.status.rx_down = !FRAMING(sts);
		if( !comm_data.status.rx_down ){
			if( !char_queue_isfull(comm_data.queues.rx) ) {
				char_queue_add(comm_data.queues.rx, ch);
			} else {
				comm_data.queues.rx.overflow++;
				print(plError, "RX queue overflow = %d, lost \'%c\'!\n", comm_data.queues.rx.overflow, ch);
			}
		}
		wake_up_interruptible(&comm_data.queues.rx_wait);
		sts = ccd3_status(STS_MASK_ALL);
		ret = IRQ_HANDLED;
	}

	// Handle data timeout irq
	if( RX_TIMEOUT(sts) && IEN_TIMEOUT(sts) ){
		//print(plDebug, "data\n");
		// Clear interrupt
		write32(REG_COMMAND, REG_CMD_SET + CMD_CLEAR_COUNTERS);
		// Read write ptr
		read32(REG_WRITE, &comm_data.queues.mem_write);

	    ret = IRQ_HANDLED;
	}

	return ret;
}

///////////////////////////////////////////////////////////////////////////////

int ccd3_ctlwrite(char* buf, int cnt, bool block)
{
	int idx, res;
	unsigned char *str, *arg;
	char strbuf[256];
	bool local_cmd_handled = false;
	bool error = false;
	buf[cnt] = 0;

	// Parse data stream, process local commands
	str = strstr(&buf[1], DRV_TOKEN);
	
	if( str ) { // if local cmd

		str += strlen(DRV_TOKEN);
		while(str[0] == ' ') str++;
	
		arg = error ? NULL : strstr(str, DRV_PROGRESS);
		if( arg ) { // Handle progress report
			if( comm_data.no_pci ){
				sprintf(strbuf, "%s %d\n", DRV_PROGRESS, em_progress());
			} else {
				read32(REG_WRITE, &comm_data.queues.mem_write);
				sprintf(strbuf, "%s %d\n", DRV_PROGRESS, comm_data.queues.mem_write >> 2);
			}
			local_cmd_handled = true;
		}

		arg = error ? NULL : strstr(str, DRV_RX);
		if( arg ) {
			if( comm_data.no_pci ){
				sprintf(strbuf,"%s %d\n", DRV_RX, 1);
			} else {
				comm_data.status.rx_down = !ccd3_status(FRAMING_MASK);
				sprintf(strbuf,"%s %d\n", DRV_RX, comm_data.status.rx_down ? 0 : 1);
			}
			local_cmd_handled = true;
		}
		
		arg = error ? NULL : strstr(str, DRV_TX);
		if( arg ){
			if( comm_data.no_pci){
				sprintf(strbuf,"%s %d\n", DRV_TX, 1);
			} else {
				// check tx irq
				//ccd3_ctlwrite("\0", 1, block);
				sprintf(strbuf,"%s %d\n", DRV_TX, comm_data.status.tx_down ? 0 : 1);
			}
			local_cmd_handled = true;
		}

		arg = error ? NULL : strstr(str, DRV_REGISTERS);
		if( arg ) {
			if( comm_data.no_pci ){
				sprintf(strbuf, "Sorry no register dump available in \"no_pci\" mode\n");
				error = true;
			} else {
				// Dump pci regs to log
				show_status_reg();
				sprintf(strbuf,"registers dumped in log\n");
			}
			local_cmd_handled = true;	
		}

		arg = error ? NULL : strstr(str, DRV_RESET);
		if( arg ) {
			ccd3_reset();
			sprintf(strbuf,"reset\n");
			local_cmd_handled = true;	
		}
		
		arg = error ? NULL : strstr(str, DRV_MEM);
		if( arg ){
			sprintf(strbuf,"%s %d\n", DRV_MEM, comm_data.no_pci ? 256*1024*1024 : pci_mem_size());
			local_cmd_handled = true;
		}

		if( !local_cmd_handled ){
			sprintf(strbuf, "Unknown driver command: \"%s\"\n", str);
			error = true;
		}

		if( error ){
			drv_error(strbuf);
		} else {
			drv_message(strbuf);
		}
		
		return cnt;
	} // if local cmd
	

	// if emulating
	if( comm_data.no_pci ){

		buf[cnt] = '\0';
		em_interpreter(buf, strbuf);

		for( idx=0; strbuf[idx]; idx++ ){
			if( !char_queue_isfull( comm_data.queues.rx ) ) {
				char_queue_add( comm_data.queues.rx, strbuf[idx]);
			} else {
				comm_data.queues.rx.overflow++;
			}
		}
		idx = cnt;

		wake_up_interruptible(&comm_data.queues.rx_wait);
		return idx;
	}

	//print(plDebug, "Putting on queue\n");
	for(idx=0; idx < cnt; idx++){

		while( char_queue_isfull(comm_data.queues.tx) ) {

			if( block ){
				print(plDebug, "ccd3_ctlwrite() blocked wait, idx=%d, framing=%s, buf=\"%s\"\n", idx, ccd3_status(FRAMING_MASK) ? "true": "false", buf);
				res = wait_event_interruptible_timeout(comm_data.queues.tx_wait, !ccd3_status(TX_BUSY_MASK), msecs_to_jiffies(100) );
				if( !res ){
					//timeout
					print(plError, "ccd3_ctlwrite() timeout\n");
					comm_data.status.tx_down = 1;
					return idx; // discard tx data
				}
			} else {
				if( idx ){
					return idx;
				} else {
					print(plDebug, "ccd3_ctlwrite() non blocked, idx=%d, framing=%s, tx_busy=%s buf=\"%s\"\n", idx, ccd3_status(FRAMING_MASK) ? "true": "false", ccd3_status(TX_BUSY_MASK) ? "true" : "false", buf);
					return -EAGAIN;
				}
			}
		}
		//print(plDebug, "ccd3_ctlwrite() queing \"%c\"\n", buf[idx]);
		char_queue_add(comm_data.queues.tx, buf[idx]);
	}

	//print(plDebug, "Performing tx\n");
	//print(plDebug, "block = %s\n", block ? "true" : "false");

	if( !ccd3_status(IEN_TX_BUSY_MASK) ){
		//print(plDebug, "Enabling tx irq\n");
		write32 (REG_COMMAND, REG_CMD_SET + CMD_IEN_TX_BUSY_POS);
	}

	while(block && char_queue_size(comm_data.queues.tx)){
		//print(plDebug, "waiting for tx irq\n");
		res = wait_event_interruptible_timeout(comm_data.queues.tx_wait, 0, msecs_to_jiffies(200) );
		if( !res ){
			//timeout
			//print(plDebug, "ccd3_ctlwrite() Timeout after enabling tx irq, tx busy = %d \n", (int)ccd3_status(TX_BUSY_MASK));
			comm_data.status.tx_down = 1;
			//print(plError, "ccd3_ctlwrite() - returning with error\n");
			return idx;
		} else {
			//print(plDebug, "ccd3_ctlwrite() tx_wait .. was signaled\n");
		}
	}

	//print(plDebug, "ccd3_ctlwrite() - returning\n");
	return idx;
}

///////////////////////////////////////////////////////////////////////////////

int ccd3_ctlread (char* buf, int len, bool block)
{
	int n, res;

	while( !comm_data.no_pci && char_queue_isempty(comm_data.queues.rx) ){
		print(plDebug, "ccd3_ctlread() rx queue size = %d\n", char_queue_size(comm_data.queues.rx));
		if( !block ){
			printk("drv rx buffer = \"%s\"\n", comm_data.queues.rx.buf);
			printk("drv rx overflow = %d\n", comm_data.queues.rx.overflow);
			printk("drv read = %d\n", comm_data.queues.rx.read);
			printk("drv write = %d\n", comm_data.queues.rx.write);
			return -EAGAIN;
	    }
	    
		if( !ccd3_status(FRAMING_MASK)){
			comm_data.status.rx_down = 1;
		} else {
			res = wait_event_interruptible_timeout(comm_data.queues.rx_wait, char_queue_size(comm_data.queues.rx), msecs_to_jiffies(100));
			if( !res ){
				return 0;
			}
		}
	}
	
	for(n=0; char_queue_size(comm_data.queues.rx) && n < len; n++){
		buf[n] = char_queue_get(comm_data.queues.rx);
	}
		
	return n;
}

///////////////////////////////////////////////////////////////////////////////
struct ccd3_queues* ccd3_getqueues(void){
    return &comm_data.queues;
}

///////////////////////////////////////////////////////////////////////////////
struct ccd3_comm_status* ccd3_getstatus(void){
	return &comm_data.status;
}

///////////////////////////////////////////////////////////////////////////////

void drv_message(char* msg){
	int idx;
	char strbuf[256];
	
	sprintf(strbuf, "%s %s", DRV_ANSWER, msg);
	
	for( idx=0; strbuf[idx]; idx++ ){
		if( !char_queue_isfull( comm_data.queues.rx ) ) {
			char_queue_add( comm_data.queues.rx, strbuf[idx]);
		} else {
			comm_data.queues.rx.overflow++;
		} 
	}
	
	wake_up_interruptible(&comm_data.queues.rx_wait);
}

///////////////////////////////////////////////////////////////////////////////

void drv_error(char* msg){
	int idx;
	char strbuf[256];

	sprintf(strbuf, "%s %s", DRV_ERROR, msg);

	for( idx=0; strbuf[idx]; idx++ ){
		if( !char_queue_isfull( comm_data.queues.rx ) ) {
			char_queue_add( comm_data.queues.rx, strbuf[idx]);
		} else {
			comm_data.queues.rx.overflow++;
		}
	}

	wake_up_interruptible(&comm_data.queues.rx_wait);
}
///////////////////////////////////////////////////////////////////////////////

int read8(int offset, unsigned char* buf)
{
	return pci_read8(CCD3_IO_BAR, offset, buf);
}

///////////////////////////////////////////////////////////////////////////////

int write8(int offset, unsigned char buf)
{
	return pci_write8(CCD3_IO_BAR, offset, buf);
}

///////////////////////////////////////////////////////////////////////////////

int read32(int offset, unsigned int* buf)
{
	return pci_read32(CCD3_IO_BAR, offset, buf);
}

///////////////////////////////////////////////////////////////////////////////

int write32(int offset, unsigned int buf)
{
	return pci_write32(CCD3_IO_BAR, offset, buf);
}

///////////////////////////////////////////////////////////////////////////////

void ccd3_memtest(void)
{
	pci_mem_test();
}

///////////////////////////////////////////////////////////////////////////////
void show_status_reg(void){
	int n;	
	int reg;

	if( comm_data.no_pci){
		print(plError, "No status registers available in emulating mode\n");
		return;
	}
	
	reg = ccd3_status(STS_MASK_ALL);
		
	print(plDebug, "Status = ");
	for(n=0; n < 16;){
		if(reg & (1 << n))print(plDebug, "1");
		else			  print(plDebug, "0");
		if(! (++n % 4) && n != 16) print(plDebug, ":");
	}
	print(plDebug, "\n");
	
	print(plDebug, "Data timeout    = %s\n", RX_TIMEOUT(reg) ?		"1":"0");
	print(plDebug, "Character ready = %s\n", RX_CHAR_READY(reg) ?	"1":"0");
	print(plDebug, "Tx Busy         = %s\n", TX_BUSY(reg) ? 		"1":"0");
	print(plDebug, "Carrier detect  = %s\n", CARRIER_DETECT(reg) ?	"1":"0");
	print(plDebug, "Framing         = %s\n", FRAMING(reg) ?			"1":"0");
	print(plDebug, "Irq enable      = %s\n", IEN_MASTER(reg) ?	    "1":"0");
	print(plDebug, "Tx irq enable   = %s\n", IEN_TX_BUSY(reg) ?     "1":"0");
	print(plDebug, "Rx irq enable   = %s\n", IEN_CHAR_READY(reg) ?  "1":"0");
	read32(REG_WRITE, &n);
	print(plDebug, "Write ptr       = %d\n", n);
}


///////////////////////////////////////////////////////////////////////////////
int ccd3_reset(void)
{
	char ch;
	int n;

	print(plDebug, "Resetting driver\n");

	comm_data.queues.mem_write = 0;
	INIT_QUEUE(comm_data.queues.rx);
	INIT_QUEUE(comm_data.queues.tx);

	if( comm_data.no_pci ){
		return em_reset();
	}

	print(plDebug, "Opening optoring\n");

	// Enable CCD3 pci device
	write8(REG_COMMAND, REG_CMD_CLR + CMD_ENABLE);
	write8(REG_COMMAND, REG_CMD_SET + CMD_ENABLE);

	// Setup registers
	// Set irq timeout value
	write32(REG_TIMEOUT,  TIMEOUT_TRESHOLD);
	
	// Write pointer and mask
	write32(REG_WRITE, 0x0);
	write32(REG_WRITE_MASK, 0xFFFFFFFF);

	// Default cam on fiber
	write32(REG_ADDR, 0x08);

	// Setup required interrupts

	// Disable cts interrupt
	write32(REG_COMMAND, REG_CMD_CLR + CMD_IEN_TX_BUSY_POS);
	// Disable timeout interrupt
	write32(REG_COMMAND, REG_CMD_CLR + CMD_IEN_TIMEOUT_POS);
	// Enable character ready interrupt
	write32(REG_COMMAND, REG_CMD_SET + CMD_IEN_CHAR_READY_POS);
	// Enable master interrupts on hardware
	write32(REG_COMMAND, REG_CMD_SET + CMD_IEN_MASTER_POS);

	// Empty controller buffers
	for(n=0; n < 200; n++){
		read8(REG_CHAR, &ch);
		mdelay(1);
	}

	write8(REG_CHAR, 0);
	mdelay(1);
	comm_data.status.tx_down = ccd3_status(TX_BUSY_MASK);
	return 0;	
}

///////////////////////////////////////////////////////////////////////////////

int ccd3_close(void){
	print(plDebug, "Releasing optoring\n");
	ccd3_disable_irq();
	write8(REG_COMMAND, REG_CMD_CLR + CMD_ENABLE);
	return 0;
}

///////////////////////////////////////////////////////////////////////////////

unsigned long ccd3_status(unsigned long mask)
{
	static unsigned int Status1, Status2, Cnt = 0;
	
	Cnt = 0;
	
	do{		

		if( Cnt++ > MAX_STS_RETRIES ){
			print(plError, "Failed to obtain a stable hardware status!(%4X:%4X)\n", (int)Status1, (int)Status2);
			print(plError, "comm_data.nopci = %d\n", comm_data.no_pci);
			return 0;
		}

		read32(REG_STATUS, &Status1);
		read32(REG_STATUS, &Status2);
				
	} while( mask & 0x003F03FF & (Status1 ^ Status2) );
	
	if( Cnt > 4 )
		print(plDebug, "Queried hardware multiple times to get stable status (%d)\n", Cnt);
	
	return mask & Status1;
}

///////////////////////////////////////////////////////////////////////////////
// EOF
