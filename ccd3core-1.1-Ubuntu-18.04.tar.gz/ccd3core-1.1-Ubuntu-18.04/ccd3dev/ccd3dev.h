#ifndef CCD3DEV_H_
#define CCD3DEV_H_

#define CAM_COMMAND					"@"
#define CAM_QUESTION				"?"
#define CAM_ANSWER					"!"
#define CAM_INTEGRATING				"timr"
#define CAM_ERROR					CAM_ANSWER "ERROR"

#define DRV_TOKEN					"drv"
#define DRV_ERROR					CAM_ANSWER "ERROR"
#define DRV_ANSWER					CAM_ANSWER DRV_TOKEN
#define DRV_COMMAND					CAM_COMMAND DRV_TOKEN
#define DRV_QUESTION				CAM_QUESTION DRV_TOKEN
#define DRV_PROGRESS 				"progress"
#define DRV_RX						"rx"
#define DRV_TX						"tx"
//#define DRV_QUEUE					"txqueue"
#define DRV_REGISTERS				"registers"
#define DRV_RESET					"reset"
#define DRV_MEM						"memory"

#endif /*CCD3DEV_H_*/
