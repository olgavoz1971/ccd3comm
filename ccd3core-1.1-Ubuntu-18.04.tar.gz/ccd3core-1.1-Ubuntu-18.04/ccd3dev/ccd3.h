#ifndef CCD3_H_
#define CCD3_H_

#define DEFAULT_CAM 8

#define PIX_SIZE		4

#endif /*CCD3_H_*/
