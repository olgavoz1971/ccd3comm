#include <linux/kernel.h> 
#include <linux/module.h>
#include <linux/pci.h>
#include <linux/interrupt.h>

#ifndef _PCI_H_
#define _PCI_H_

#define MAX_PCI_REGIONS 6
#define BAR0 0
#define BAR1 1
#define BAR2 2
#define BAR3 3
#define BAR4 4
#define BAR5 5

int pci_register(int mem_limit);
int pci_unregister(void);
int pci_enable_irq(irq_handler_t handler, unsigned long irqflags);
void pci_disable_irq(void);

u64 pci_mem(void);
u64 pci_physical_mem(void);
int pci_mem_size(void);
void pci_mem_test(void);

int pci_write8(int bar, int offset, unsigned char buf);
int pci_read8(int bar, int offset, unsigned char *buf);
int pci_write32(int bar, int offset, unsigned int buf);
int pci_read32(int bar, int offset, unsigned int *buf);

#endif /*_PCI_H_*/
