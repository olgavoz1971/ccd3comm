/*
 *  Copyright (c) 2006 Copenhagen University Astronomical Observatory
 *  All possible rights reserved
 *	Filename:	
 *  Abstract:	
 *  Author:		Jeppe Jønch Andersen (jja@astro.ku.dk)
 *  Revision:
 *  Remarks:
 */
 
#ifndef CCD3_REG_H_
#define CCD3_REG_H_

#define CCD3_PCI_VENDOR_ID 0x1172
#define CCD3_PCI_DEVICE_ID 0x4F52
#define CCD3_DEVICE_NAME "ccd3"

// Register definitions, offset relative to PCI base addr
#define REG_DATA    			0x00
#define REG_STATUS  			0x04
#define REG_COMMAND 			REG_STATUS
#define REG_CHAR    			0x08
#define REG_ADDR    			0x0c
//#define REG_TRESHOLD			0x10
#define REG_TIMEOUT				0x14
#define REG_WRITE				0x20
#define REG_WRITE_MASK			0x24
	
#define REG_CMD_SET 			0x80
#define REG_CMD_CLR 			0x00	

#define CMD_ENABLE				0
#define CMD_CLEAR_COUNTERS		1
#define CMD_IEN_MASTER_POS		3
#define CMD_IEN_CHAR_READY_POS	4
#define CMD_IEN_TX_BUSY_POS		5
//#define CMD_IEN_TRESHOLD_POS	6  /* Don't use	*/
#define CMD_IEN_TIMEOUT_POS		7

typedef enum
{
    CCD3_BAR0  = BAR0,
    CCD3_BAR1  = BAR1,
    CCD3_BAR2  = BAR2,
    CCD3_BAR3  = BAR3,
    CCD3_BAR4  = BAR4,
    CCD3_BAR5  = BAR5,
} CCD3_ADDR;

#define CCD3_MEM_BAR	CCD3_BAR0
#define CCD3_IO_BAR		CCD3_BAR1
	
// Timeout to trigger interrupt
//#define TIMEOUT_TRESHOLD 250
#define TIMEOUT_TRESHOLD 255
// Max retries for stable hw status
#define MAX_STS_RETRIES	 10			

// Status word, bit definitions
#define STS_RX_CHAR_READY_POS	16
#define STS_TX_BUSY_POS			17
//#define STS_NOOP_POS			18	/* Don't use	*/
#define STS_RX_TIMEOUT_POS		19
#define STS_CARRIER_DETECT_POS	20
#define STS_FRAMING_POS			21

// Status word, masks
#define RX_CHAR_READY_MASK	(0x1 << STS_RX_CHAR_READY_POS)
#define IEN_CHAR_READY_MASK	(0x1 << CMD_IEN_CHAR_READY_POS)
#define TX_BUSY_MASK 		(0x1 << STS_TX_BUSY_POS)
#define IEN_TX_BUSY_MASK	(0x1 << CMD_IEN_TX_BUSY_POS)
#define RX_TIMEOUT_MASK		(0x1 << STS_RX_TIMEOUT_POS)
#define IEN_MASTER_MASK		(0x1 << CMD_IEN_MASTER_POS)
#define IEN_TIMEOUT_MASK	(0x1 << CMD_IEN_TIMEOUT_POS)
#define CARRIER_DETECT_MASK (0x1 << STS_CARRIER_DETECT_POS)
#define FRAMING_MASK		(0x1 << STS_FRAMING_POS)
#define RX_IRQ_MASK			(RX_TIMEOUT_MASK | RX_CHAR_READY_MASK)
#define STS_MASK_VALID		0x003F03FF /* 00000000 00111111 00000011 11111111 */
#define STS_MASK_ALL		0xFFFFFFFF	

	
// User macro's for extracting status information
//#define RX_DATA_READY(x)  ((RX_DATA_READY_MASK & x)  >> RX_DATA_READY_POS) /* Number of 32 bit block data ready to be read 				*/
#define RX_TIMEOUT(x)	  ((RX_TIMEOUT_MASK & x)	 >> STS_RX_TIMEOUT_POS)	   /* Flag, set on data timeout									*/
#define IEN_MASTER(x)	  ((IEN_MASTER_MASK & x)     >> CMD_IEN_MASTER_POS)	   /* Master interrupt enabled									*/
#define IEN_TIMEOUT(x)    ((IEN_TIMEOUT_MASK & x)	 >> CMD_IEN_TIMEOUT_POS)   /* Timeout interrupt enabled									*/
#define RX_CHAR_READY(x)  ((RX_CHAR_READY_MASK & x)  >> STS_RX_CHAR_READY_POS) /* Flag, character is ready                    				*/
#define IEN_CHAR_READY(x) ((IEN_CHAR_READY_MASK & x) >> CMD_IEN_CHAR_READY_POS)/* Char ready interrupt enabled								*/
#define TX_BUSY(x)		  ((TX_BUSY_MASK & x)        >> STS_TX_BUSY_POS)       /* Flag, previously transmitted char are not acknowledged	*/
#define IEN_TX_BUSY(x)	  ((IEN_TX_BUSY_MASK & x)	 >> CMD_IEN_TX_BUSY_POS)   /* CTS interrupt enabled										*/
#define CARRIER_DETECT(x) ((CARRIER_DETECT_MASK & x) >> STS_CARRIER_DETECT_POS)/* Flag, carrier is detected if set							*/
#define FRAMING(x)        ((FRAMING_MASK & x)        >> STS_FRAMING_POS)	   /* Flag, if comm is sync'ed									*/

#endif /*CCD3_REG_H_*/
///////////////////////////////////////////////////////////////////////////////
// EOF
