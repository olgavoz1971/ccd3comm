#include <linux/pci.h>
#include <linux/interrupt.h>
#include "pci.h"
#include "ccd3_reg.h"
#include "ccd3_print.h"

///////////////////////////////////////////////////////////////////////////////

// Non-public forward declarations
static int  probe (struct pci_dev *dev, const struct pci_device_id *id);
static void remove(struct pci_dev *dev);

///////////////////////////////////////////////////////////////////////////////

struct pci_resource_info{
	u64 start_addr;
	u64 end_addr;
	unsigned long flags;
};

struct pci_device_data {
	struct pci_dev* pci_card;
	struct pci_device_id* ids;
	struct pci_resource_info resources[MAX_PCI_REGIONS];
	u64 pci_mem;
	u64 pci_physical_mem;
	int pci_mem_size;
	unsigned char pin;
	int mem_limit;
};

static struct pci_device_data device_data;

static struct pci_device_id ids[] ={
	{ PCI_DEVICE(CCD3_PCI_VENDOR_ID, CCD3_PCI_DEVICE_ID) },
	{0,},
};

static struct pci_driver pci_driver_def = {
	.name		= CCD3_DEVICE_NAME,
	.id_table	= ids,
	.probe		= probe,
	.remove		= remove,
};


///////////////////////////////////////////////////////////////////////////////

static int probe (struct pci_dev *pci_dev, const struct pci_device_id *id)
{
	int n;
	u64 start_addr;

	// Is this our device ?
	if( id->vendor != CCD3_PCI_VENDOR_ID || id->device != CCD3_PCI_DEVICE_ID)
	{
		print(plDebug, "Not our device ... backing out\n");
		return -1;
	}
	
	if( pci_dev->vendor != CCD3_PCI_VENDOR_ID || pci_dev->device != CCD3_PCI_DEVICE_ID)
	{
		print(plDebug, "Not our device ... backing out\n");
		return -1;
	}

	if( pci_enable_device(pci_dev) < 0 ) return -2;

	device_data.pci_card = pci_dev;

	memset(device_data.resources, 0, MAX_PCI_REGIONS * sizeof(device_data.resources[0]));

	for(n=0; n < MAX_PCI_REGIONS; n++){		
	
		start_addr = pci_resource_start(device_data.pci_card, n);
	
		if( start_addr ){
			device_data.resources[n].start_addr = start_addr;
			device_data.resources[n].end_addr = pci_resource_end(device_data.pci_card, n);
			device_data.resources[n].flags = pci_resource_flags(device_data.pci_card, n);

			if( device_data.resources[n].flags & IORESOURCE_MEM && device_data.mem_limit ){
				if( device_data.mem_limit <= (device_data.resources[n].end_addr - device_data.resources[n].start_addr + 1)){
					device_data.resources[n].end_addr = device_data.resources[n].start_addr + device_data.mem_limit - 1;
				} else {
					print(plDebug, "CCD3 mem_limit is not less than physical memory size, sticking to physical size\n");
				}
			}

			if      ( device_data.resources[n].flags & IORESOURCE_IO)	print(plDebug, "BAR%d PCI I/O resource @ 0x%4x, size=%u\n", n, (unsigned int)device_data.resources[n].start_addr, (unsigned int)(device_data.resources[n].end_addr - device_data.resources[n].start_addr + 1));
			else if( device_data.resources[n].flags & IORESOURCE_MEM)	print(plDebug, "BAR%d PCI Memory resource @ %p, size=%dMB\n", n, (void*)device_data.resources[n].start_addr, (int)(device_data.resources[n].end_addr - device_data.resources[n].start_addr + 1) >> 20);
			else if( device_data.resources[n].flags & IORESOURCE_IRQ)	print(plDebug, "BAR%d PCI Interrupt\n",n);
			else if( device_data.resources[n].flags & IORESOURCE_DMA)	print(plDebug, "BAR%d PCI DMA resource\n",n);
			else														print(plError, "BAR%d PCI unknown resource\n",n);

			if( device_data.resources[n].flags & IORESOURCE_PREFETCH)	print(plDebug, "Resource is prefetchable\n");
			if( device_data.resources[n].flags & IORESOURCE_READONLY)	print(plDebug, "Resource is readonly\n");

		}
	}
	
	device_data.pci_physical_mem = device_data.resources[CCD3_MEM_BAR].start_addr;
	device_data.pci_mem_size =	device_data.resources[CCD3_MEM_BAR].end_addr -
								device_data.resources[CCD3_MEM_BAR].start_addr;

	print(plDebug, "Requesting memory @ %p, length = %dMB\n", (void*)device_data.resources[CCD3_MEM_BAR].start_addr, (device_data.pci_mem_size + 1) >> 20);
	
	if(!request_mem_region(device_data.resources[CCD3_MEM_BAR].start_addr, device_data.pci_mem_size, CCD3_DEVICE_NAME)){
		print(plError, "Failed requesting memory\n");
		return 1;
	}
	
	device_data.pci_mem = (u64)ioremap_nocache(device_data.resources[CCD3_MEM_BAR].start_addr, device_data.pci_mem_size);

	print(plDebug, "Remapped memory from %p to %p\n", (void*)device_data.resources[CCD3_MEM_BAR].start_addr, (void*)device_data.pci_mem);

	return 0;
}

///////////////////////////////////////////////////////////////////////////////

static void remove(struct pci_dev *dev)
{
	print(plDebug, "remove()\n");
}

///////////////////////////////////////////////////////////////////////////////

int pci_register(int mem_limit)
{
	int res;
	print(plDebug, "Registering pci driver\n");

	device_data.mem_limit = mem_limit;
	res = pci_register_driver(&pci_driver_def);

	if( res != 0 ){
		print(plError, "Failed registering pci driver\n");
		res = -EIO;
	} else if( !device_data.pci_card ){
		print(plError, "No CCD3 hardware found?\n");
		pci_unregister();
		res = -ENODEV;
	}

	return res;
}

///////////////////////////////////////////////////////////////////////////////

int pci_unregister(void)
{
	print(plDebug, "Unregistering pci driver\n");

	iounmap((void*)device_data.pci_mem);
	release_mem_region(device_data.resources[CCD3_MEM_BAR].start_addr, device_data.pci_mem_size);
	pci_unregister_driver(&pci_driver_def);
	return 0;
}

///////////////////////////////////////////////////////////////////////////////

int pci_enable_irq(irq_handler_t handler, unsigned long irqflags){
	int n;
  	n = request_irq(device_data.pci_card->irq, handler, irqflags, pci_driver_def.name, &device_data);

	if( n ){

		print(plError, KERN_INFO "Cannot attach irq %d\n", device_data.pci_card->irq);

		switch( n ){
			case -EINVAL: print(plError, "Invalid arguments\n"); break;
			case -ENOMEM: print(plError, "Not enough memory\n"); break;
			case -EBUSY	: print(plError, "Device is busy\n"); break;
			default	: print(plError, "Unknown error?\n"); break;
		}

		return -1;
	}

	print(plDebug, "Attached irq (%d) on device \"%s\"\n", device_data.pci_card->irq, pci_driver_def.name);
	return 0;
}

///////////////////////////////////////////////////////////////////////////////

void pci_disable_irq(void){
	free_irq(device_data.pci_card->irq, &device_data);
}

///////////////////////////////////////////////////////////////////////////////

u64 pci_mem(void)
{
	return device_data.pci_mem;
}

///////////////////////////////////////////////////////////////////////////////

u64 pci_physical_mem(void)
{
	return device_data.pci_physical_mem;
}

///////////////////////////////////////////////////////////////////////////////

int pci_mem_size(void)
{
	return device_data.pci_mem_size;
}

///////////////////////////////////////////////////////////////////////////////

void pci_mem_test(void)
{
	int n = 0;
	int* p_32 = NULL;
	int tmp;
	int memsize = device_data.resources[CCD3_MEM_BAR].end_addr - device_data.resources[CCD3_MEM_BAR].start_addr;
	bool error = 0;

	print(plDebug, "Testing onboard memory, %dMB @ %p\n", (memsize + 1) >> 20, (void*)device_data.resources[0].start_addr);
	p_32 = (int*)device_data.pci_mem;

	for(n = 0; n < memsize >> 2 ; n++){
		iowrite32(n, &p_32[n]);
	}
	//iowrite32_rep((void*)dev->pci_mem_address, queues.data, memsize >> 2);
	//memcpy_toio((void*)dev->pci_mem_address, queues.data, memsize);
	//memset_io((void*)dev->pci_mem_address, 0xAA, memsize);

	/*print(plDebug, "Verifying ..\n");
	for(n = 0; n < memsize ; n++){
		pci_read8(dev, CCD3_MEM_BAR, n, &tmp);
		if(tmp != n + 10){
			print(plDebug, "Memory test failed @ offset %d\n", n);
			print(plDebug, "Expected 0x%X but found 0x%X\n", n + 10, tmp);
			//return 1;
		}

	}*/
	//print(plDebug, "32bit reads\n");
	//memsize = 64;
	for(n = 0; n < memsize >> 2; n ++){
		//pci_read32(dev, CCD3_MEM_BAR, n, &tmp);
		//tmp = p_32[n];
		tmp = ioread32(&p_32[n]);
		if(tmp != n){
			error++;
			print(plDebug, "Offset 0x%X = 0x%X\n", n, tmp);
		}
	}

	/*print(plDebug, "\n8bit reads\n");
	for(n = 0; n < memsize ; n ++){
		//pci_read8(dev, CCD3_MEM_BAR, n, &tmp8);
		//tmp8 = p_8[n];
		tmp = ioread8(&p_8[n]);
		print(plDebug, "Offset 0x%X = 0x%X\n", n, tmp);
	}*/
	if( error ){
		print(plError, "%d bad memory cells found\n", error);
	} else {
		print(plDebug, "Memory test succeeded\n");
	}
}

///////////////////////////////////////////////////////////////////////////////

int pci_write8(int bar, int offset, unsigned char buf)
{
	outb_p(buf, (device_data.resources[bar].start_addr + offset));
	return 1;
}

///////////////////////////////////////////////////////////////////////////////

int pci_read8(int bar, int offset, unsigned char *buf)
{
	if(!buf){
		print(plError, "No buffer?\n");
		return 0;
	}

	*buf = inb_p((int)(device_data.resources[bar].start_addr + offset));
	return 1;
}

///////////////////////////////////////////////////////////////////////////////

int pci_write32(int bar, int offset, unsigned int buf)
{
	outl_p(buf, (int)(device_data.resources[bar].start_addr + offset));
	return 1;
}

///////////////////////////////////////////////////////////////////////////////

int pci_read32(int bar, int offset, unsigned int *buf)
{
	if(!buf){
		print(plError, "No buffer?\n");
		return 0;
	}

	*buf = inl_p((int)(device_data.resources[bar].start_addr + offset));
	return 1;
}

///////////////////////////////////////////////////////////////////////////////
// EOF
