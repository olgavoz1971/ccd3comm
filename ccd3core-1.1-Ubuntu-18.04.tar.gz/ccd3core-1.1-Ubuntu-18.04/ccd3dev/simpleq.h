#ifndef __SIMPLEQ_
#define __SIMPLEQ_

#include <linux/kernel.h>

#define CHAR_QUEUE_SIZE 200

struct char_q {
    unsigned char write;
    unsigned char read;
    unsigned char overflow;
    char buf[CHAR_QUEUE_SIZE];
};

struct long_q {
    long *buf;
    unsigned long write;
    unsigned long read;
    unsigned long overflow;
};

#define ALLOC_CHAR_QUEUE(x) 	\
    struct char_q x = {			\
	.write = 0,					\
	.read  = 0,					\
	.overflow  = 0,				\
    }


#define ALLOC_LONG_QUEUE(x)		\
    struct long_q x = {			\
	.write = 0,					\
	.read  = 0,					\
	.overflow  = 0,				\
	.buf   = NULL,				\
    }
    
#define INIT_QUEUE(x)			\
    x.write = x.read = x.overflow = 0
   
    
// General queue operations                                                                                                         
#define queue_size(q,s)         	(q.write >= q.read ? q.write - q.read : s - q.read + q.write)                                       
#define queue_isempty(q)        	(q.write == q.read)                                                                                 
#define queue_peek(q)           	q.buf[q.read]                                                                                       

// Char queue operations                                                                                                            
#define char_queue_size(q)      	queue_size(q, CHAR_QUEUE_SIZE)                                                                         
#define char_queue_isempty(q)   	queue_isempty(q)                                                                                    
#define char_queue_peek(q)      	queue_peek(q)                                                                                       
#define char_queue_isfull(q)    	( q.write == (q.read - 1) )                                                                          
#define char_queue_add(q,v)     	q.buf[q.write] = v; char_queue_write_inc(q)                                                                       
#define char_queue_get(q)       	char_queue_peek(q); char_queue_read_inc(q)                                                                        
#define char_queue_inc(q,y)     	q.y++; q.y = q.y % CHAR_QUEUE_SIZE
//#define char_queue_inc(q,y)     	q.y++
#define char_queue_read_inc(q)  	char_queue_inc(q,read)                                                                              
#define char_queue_write_inc(q) 	char_queue_inc(q,write)                                                                             
                                                                                                                                                                                                                                                                        
// Long queue operations                                                                                                            
#define long_queue_size(q)      	queue_size(q,BUF_SIZE)                                                                              
#define long_queue_isempty(q)   	queue_isempty(q)                                                                                    
#define long_queue_peek(q)      	queue_peek(q)                                                                                       
#define long_queue_isfull(q)    	( (q.write == (q.read - 1)) || (!q.read && q.write == (BUF_SIZE-1)) )                               
#define long_queue_add(q,v)     	q.buf[q.write] = v; long_queue_write_inc(q)                                                         
#define long_queue_get(q)       	long_queue_peek(q);long_queue_read_inc(q)                                                           

#define long_queue_inc_with(q,y,n)   	q.y = (n+q.y) % BUF_SIZE                                                                              
#define long_queue_inc(q,y)				long_queue_inc_with(q,y,1)
#define long_queue_read_inc(q)  		long_queue_inc(q,read)                                                                              
#define long_queue_write_inc(q) 		long_queue_inc(q,write)   
#define long_queue_read_inc_with(q,n)	long_queue_inc_with(q,read,n)
#define long_queue_write_inc_with(q,n)	long_queue_inc_with(q,write,n)  


#endif
