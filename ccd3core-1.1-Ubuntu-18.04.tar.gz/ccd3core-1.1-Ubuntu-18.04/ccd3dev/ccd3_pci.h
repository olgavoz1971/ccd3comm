#include <linux/kernel.h> 
#include <linux/module.h>
#include <linux/pci.h>
#include <linux/wait.h>
#include "ccd3_emulator.h"
#include "simpleq.h"
#include "pci.h"

#ifndef _CCD3_PCI_H_
#define _CCD3_PCI_H_

struct ccd3_queues {
	unsigned int* mem;
    unsigned int mem_write;
    unsigned int mem_size;
    struct char_q tx;
    struct char_q rx;
    wait_queue_head_t rx_wait;
    wait_queue_head_t tx_wait;
};

struct ccd3_comm_status{
	bool tx_down;
	bool rx_down;
};


int ccd3_register(int a_no_pci, int a_mem_limit);
int ccd3_unregister(void);

int ccd3_enable_irq(void);
int ccd3_disable_irq(void);
int ccd3_reset(void);
int ccd3_close(void);

int ccd3_ctlread(char* buf, int len, bool block);
int ccd3_ctlwrite(char* buf, int len, bool block);

void ccd3_memtest(void);
struct ccd3_queues* ccd3_getqueues(void);
struct ccd3_comm_status* ccd3_getstatus(void);

void show_status_reg(void);

#endif /*CCD3_PCI_H_*/
