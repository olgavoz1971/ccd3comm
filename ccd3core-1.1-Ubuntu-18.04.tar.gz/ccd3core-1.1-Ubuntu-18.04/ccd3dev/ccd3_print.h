/*
 *  Copyright (c) 2006 Copenhagen University Astronomical Observatory
 *  All possible rights reserved
 *	Filename:
 *  Abstract:
 *  Author:		Jeppe Jønch Andersen (jja@nbi.ku.dk)
 *  Revision:
 *  Remarks:
 */

#ifndef CCD3_PRINT_H_
#define CCD3_PRINT_H_

typedef enum {
	plSilent = 0,
	plError  = 1,
	plNormal = 2,
	plDebug  = 3,
}module_print_level;

// Printing function
void print(module_print_level level, char* msg, ...);
void set_print_level(module_print_level level);

#endif /* CCD3_PRINT_H_ */
