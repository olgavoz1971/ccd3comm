/*
 *  Copyright (c) 2006 Copenhagen University Astronomical Observatory
 *  All possible rights reserved
 *	Filename:
 *  Abstract:
 *  Author:		Jeppe Jønch Andersen (jja@nbi.ku.dk)
 *  Revision:
 *  Remarks:
 */
#include <linux/kernel.h>
#include "ccd3_print.h"

module_print_level print_level = plNormal;

void print(module_print_level level, char* msg, ...){
	char fmt_msg[128] = "";
	va_list ap;
	va_start(ap, msg);
	vsnprintf(fmt_msg, 128, msg, ap);
	va_end (ap);

	if( level <= print_level ){
		printk(fmt_msg);
	}
}

void set_print_level(module_print_level level){
	print_level = level;
}
