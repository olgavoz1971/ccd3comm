
#include <linux/kernel.h> 
#include <linux/module.h>
#include <linux/init.h>
#include <linux/version.h>
#include <linux/errno.h>
#include <linux/fs.h>
#include <linux/mm.h>
#include <linux/sched.h>
#include <asm/uaccess.h>
#include <asm/io.h>
#include <linux/vmalloc.h>
#include <linux/mman.h>
#include <linux/slab.h>
#include <linux/cdev.h>
#include <linux/poll.h>
#include <linux/rmap.h>

#include "ccd3.h"
#include "ccd3_pci.h"
#include "ccd3dev.h"
#include "simpleq.h"
#include "ccd3_print.h"

#define DRIVER_DATA_NAME	"ccd3"
#define DRIVER_CTL_NAME		"ccd3ctl"

#define CHAR_BUF_SIZE 256
#define CASE1 1
#define CASE2 2

static int no_pci = 0;
module_param(no_pci, int, S_IRUGO);

static int mem_limit = 0;
module_param(mem_limit, int, S_IRUGO);

static int print_level = plNormal;
module_param(print_level, int, S_IRUGO);

struct ccd3_driver_data {
    struct cdev dat_dev;
    struct cdev ctl_dev;
    struct class * data_class;
    struct class * ctl_class;
    atomic_t ccd3_available;
};

static struct ccd3_driver_data driver_data = {
	.data_class = NULL,
	.ctl_class = NULL,
    .ccd3_available = ATOMIC_INIT(1),
};

unsigned long virt_addr;

#ifndef VMALLOC_VMADDR
	#define VMALLOC_VMADDR(x) ((unsigned long)(x))
#endif

static void vma_open(struct vm_area_struct *vma);
static void vma_close(struct vm_area_struct *vma);
// Jk for Ubuntu 18.04
//static int  vma_fault(struct vm_area_struct* vma, struct vm_fault* vmf);
static vm_fault_t  vma_fault(struct vm_fault* vmf);

//static struct page *vma_nopage(struct vm_area_struct *vma, unsigned long address, int *type);

// CCD3 device functions
static int			ccd3_open	(struct inode *inode, struct file *file);
static int			ccd3_release(struct inode *inode, struct file *file);
static ssize_t		ccd3_read	(struct file *file, char *buf, size_t count, loff_t *ppos);
static ssize_t 		ccd3_write	(struct file *file, const char *buf, size_t count, loff_t *ppos);
static int			ccd3_mmap	(struct file * filp, struct vm_area_struct * vma);
//static int		ccd3_ioctl	(struct inode *inode, struct file *file, unsigned int cmd, unsigned long arg);

// CCD3CTL device functions
static int			ccd3ctl_open   (struct inode *inode, struct file *file);
static int			ccd3ctl_release(struct inode *inode, struct file *file);
static ssize_t		ccd3ctl_read   (struct file *file, char *buf, size_t count, loff_t *ppos);
static ssize_t		ccd3ctl_write  (struct file *file, const char *buf, size_t count, loff_t *ppos);
//static int		ccd3ctl_mmap   (struct file *file, struct vm_area_struct * vma);
static unsigned int	ccd3ctl_poll   (struct file *file, poll_table *wait);
//static int 			ccd3ctl_fsync (struct file *file, loff_t, loff_t, int datasync);
//static int		ccd3ctl_ioctl  (struct inode *inode, struct file *file, unsigned int cmd, unsigned long arg);

// Module functions
static int  __init ccd3_init_module(void);
static void ccd3_cleanup_module(void);

// Virtual memory operations
static struct vm_operations_struct remap_vm_ops = {
    .open  = vma_open,
    .close = vma_close,
    .fault = vma_fault
};

// define which file operations are supported on /dev/ccd3
struct file_operations ccd3_fops = {
	.owner		=	THIS_MODULE,
	//.llseek	=	NULL,
	.read		=	ccd3_read,
	.write		=	ccd3_write,
	//.readdir	=	NULL,
	//.poll		=	NULL,
	//.ioctl		ccd3_ioctl,
	.mmap		=	ccd3_mmap,
	.open		=	ccd3_open,
	//.flush	=	NULL,
	.release	=	ccd3_release,
	//.fsync	=	NULL,
	//.fasync	=	NULL,
	//.lock		=	NULL,
};

// define which file operations are supported on /dev/ccd3ctl
struct file_operations ccd3ctl_fops = {
	.owner		=	THIS_MODULE,
	//.llseek	=	NULL,
	.read		=	ccd3ctl_read,
	.write		=	ccd3ctl_write,

	//.readdir	=	NULL,
	.poll		=	ccd3ctl_poll,
	//.ioctl		ccd3ctl_ioctl,
	//.mmap		=	ccd3ctl_mmap,
	.open		=	ccd3ctl_open,
	//.flush	=	NULL,
	.release	=	ccd3ctl_release,
	//.fsync	=	ccd3ctl_fsync,
	//.fasync	=	NULL,
	//.lock		=	NULL,
};

///////////////////////////// CCD3 ////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////
// open function - called when the "file" /dev/ccd3 is opened in userspace
static int ccd3_open (struct inode *inode, struct file *file) {
	print(plDebug, "ccd3_open()\n");
	if( no_pci ){
		return em_open();
	}
	return 0;
}

///////////////////////////////////////////////////////////////////////////////
// close function - called when the "file" /dev/ccd3 is closed in userspace  
static int ccd3_release (struct inode *inode, struct file *file) {
	print(plDebug, "ccd3_release()\n");

	if( no_pci ){
		return em_close();
	}
	return 0;
}

///////////////////////////////////////////////////////////////////////////////
// read function called when from /dev/ccd3 is read
static ssize_t ccd3_read (struct file *file, char *buf, size_t count, loff_t *ppos) {
	
	long avail_bytes, read_bytes=0, avail_pix, read_pix=0, err=0;

	if( no_pci ){

		avail_bytes = em_progress() << 2;
		avail_bytes = avail_bytes > (*ppos) ? avail_bytes - (*ppos) : 0;
		avail_bytes = min((long)count, avail_bytes);
		avail_bytes = min(avail_bytes, (long)PAGE_SIZE);
		avail_pix = avail_bytes >> 2;

		if( !em_buffer() ){
			print(plError, "No em_buffer() allocated!\n");
		} else {

			for(read_pix = 0; read_pix < avail_pix; read_pix++){
				em_buffer()[read_pix] = read_pix + ((*ppos) >> 2);
			}
			read_bytes = read_pix << 2;
			err = copy_to_user(buf, em_buffer(), read_bytes);

			if( err ) {
				print(plError, "read(): failed copy_to_user() while emulating\n");
				print(plError, "ppos        = %lu\n", (long)*ppos);
				print(plError, "read_bytes  = %lu\n", read_bytes);
				return -EFAULT;
			}
		}

	} else {

		avail_bytes = ccd3_getqueues()->mem_write;
		avail_bytes = avail_bytes > (*ppos) ? avail_bytes - (*ppos) : 0;
		avail_bytes = min((long)count, avail_bytes);
		read_bytes  = avail_bytes;
		
		err = copy_to_user(buf, &ccd3_getqueues()->mem[(*ppos) >> 2], avail_bytes);
	
		if( err ) {
			print(plError, "read(): failed copy_to_user()\n");
			print(plError, "ppos        = %lu\n", (long)*ppos);
			print(plError, "read_bytes  = %lu\n", read_bytes);
			print(plError, "src address = 0x%p\n", &ccd3_getqueues()->mem[(long)ppos]);
			print(plError, "avail_bytes = %lu\n", avail_bytes);
			print(plError, "write ptr   = %d\n", ccd3_getqueues()->mem_write);
			return -EFAULT;
		}
	}

	*ppos += read_bytes;
	return read_bytes;
}

///////////////////////////////////////////////////////////////////////////////
// write function called when to /dev/ccd3 is written
static ssize_t ccd3_write (struct file *file, const char *buf, size_t count, loff_t *ppos) {
	int err;

	err = copy_from_user(&ccd3_getqueues()->mem[(*ppos) >> 2], buf, count);

	if( err ) {
		print(plError, "write(): failed copy_from_user()\n");
		print(plError, "ppos        = %lu\n", (long)*ppos);
		print(plError, "src address = 0x%p\n", &ccd3_getqueues()->mem[(long)ppos]);
		print(plError, "write ptr   = %d\n", ccd3_getqueues()->mem_write);
		return -EFAULT;
	}

	ccd3_getqueues()->mem_write += count;
	*ppos += count;
	return count;
}

///////////////////////////////////////////////////////////////////////////////
// mmap file
static int ccd3_mmap(struct file * file, struct vm_area_struct * vma) {
	int ret = 0;
	//struct ccd3_driver_data* my_driver_data = file->private_data;


	print(plDebug, "vma->vm_start = 0x%lX\n", vma->vm_start);
	print(plDebug, "vma->vm_end   = 0x%lX\n", vma->vm_end);
	print(plDebug, "size          = %ld MB\n",(vma->vm_end - vma->vm_start) / (1024*1024));

	//vma->vm_flags |= VM_RESERVED;
	//vma->vm_flags |= VM_LOCKED;

	if( no_pci ){
		vma->vm_ops = &remap_vm_ops;
		vma_open(vma);
	} else {
		ret = remap_pfn_range(vma, vma->vm_start, ((long)pci_physical_mem()) >> PAGE_SHIFT, vma->vm_end - vma->vm_start, vma->vm_page_prot/*PAGE_SHARED*/);
	}

	if( ret ){
		print(plError, "mmap failed\n");
		return -EAGAIN;
	}

	return 0;
}

static void vma_open(struct vm_area_struct *vma)
{
	print(plDebug, "vma_open()\n");
}

static void vma_close(struct vm_area_struct *vma)
{
	print(plDebug, "vma_close()\n");
}

// Jk for Ubuntu 18.04 changed type
//static int vma_fault(struct vm_area_struct* vma, struct vm_fault* vmf){
static vm_fault_t vma_fault(struct vm_fault* vmf){

	static struct page* pageptr = NULL;
	int res = VM_FAULT_NOPAGE;

	print(plDebug, "vma_fault()\n");
	print(plDebug, "vmf->pgoff = %lu\n", vmf->pgoff);

	if( no_pci  ){
		if( pageptr ){
			print(plDebug, "vmf->page count = %d\n", page_count(pageptr));
			print(plDebug, "Trying put_page() on page=0x%lX\n", (unsigned long)pageptr);
			put_page(pageptr);
			print(plDebug, "Finished put_page()\n");
			print(plDebug, "vmf->page count = %d\n", page_count(pageptr));
		} else {
			print(plDebug, "page pointer empty!\n");
		}

		em_vma_fault(no_pci, vmf);

		pageptr = virt_to_page(((unsigned long)em_buffer()));
		print(plDebug, "pageptr = 0x%lX\n", (unsigned long)pageptr);
		print(plDebug, "page count = %d\n", page_count(pageptr));
		print(plDebug, "address = 0x%lX\n", (unsigned long)page_to_phys(pageptr));
		get_page(pageptr);
		print(plDebug, "new page count = %d\n", page_count(pageptr));
		vmf->page = pageptr;
		res = 0;

    } else {
    	print(plError, "vma_fault() .. while not emulating - this is bad!\n");
    }
	print(plError, "vma_fault() exit\n");
    return res;
}

///////////////////////////// CCD3CTL /////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////
// open function - called when the "file" /dev/ccd3 is opened in userspace

static int ccd3ctl_open (struct inode *inode, struct file *file) {

	print(plNormal, "Opening CCD3 device\n");
	
    if ( !atomic_dec_and_test (&driver_data.ccd3_available)) {
        atomic_inc(&driver_data.ccd3_available);
        return -EBUSY; /* already open */
    }

	if( ccd3_reset() ){
		print(plError, "Failed to reset device??\n");
		return -EIO;
	}

	if( 0 > ccd3_enable_irq() ){
		print(plError, "Failed to enable interrupts\n");
		return -EIO;
	}

	file->private_data = &driver_data;

	return 0;
}

///////////////////////////////////////////////////////////////////////////////
// close function - called when the "file" /dev/ccd3 is closed in userspace  
static int ccd3ctl_release (struct inode *inode, struct file *file) {

	struct ccd3_driver_data* my_driver_data = file->private_data;
	print(plNormal, "Closing CCD3 device\n");
	ccd3_close();
	atomic_inc(&my_driver_data->ccd3_available);

	return 0;
}

/*static int ccd3ctl_fsync (struct file *file, loff_t, loff_t, int datasync){
	print(plDebug, "fsync()\n");
	return -1;
}*/

///////////////////////////////////////////////////////////////////////////////
// read function called when from /dev/ccd3 is read

static ssize_t ccd3ctl_read (struct file *file, char *buf, size_t count, loff_t *ppos){ 

	//struct ccd3_driver_data* my_driver_data = file->private_data;
	static char tmpbuf[CHAR_BUF_SIZE];
	int len, err;
	
	len = ccd3_ctlread(tmpbuf, min((int)count, CHAR_BUF_SIZE), !(file->f_flags & O_NONBLOCK));
	
	if( len < 0 ){
		print(plDebug, "ccd3ctl_read() returning %d\n", len);
	    return len;//-EFAULT;
	}
		
	err = copy_to_user(buf, tmpbuf, len);

	if ( err ){
		print(plError, "Could not remap memory into user space\n");
		return -EFAULT;
	}
	tmpbuf[len] = 0;

	print(plDebug, "ccd3ctl_read() len=%d, count=%d, \"%s\"\n", len, count, tmpbuf);

	return len;
}

///////////////////////////////////////////////////////////////////////////////
// write function called when to /dev/ccd3 is written

static ssize_t ccd3ctl_write (struct file *file, const char *buf, size_t count, loff_t *ppos) {
	int realcount;
	char tmpbuf[CHAR_BUF_SIZE];
	//struct ccd3_driver_data* my_driver_data = file->private_data;

	realcount = min(CHAR_BUF_SIZE, (int)count);

	if( 0 != copy_from_user(tmpbuf, buf, realcount)){
		return -EFAULT;
	}
	tmpbuf[realcount] = 0;
	
	print(plDebug, "ccd3ctl_write() len=%d, \"%s\"\n", realcount, tmpbuf);
	return ccd3_ctlwrite(tmpbuf, realcount, !(file->f_flags & O_NONBLOCK));

}

///////////////////////////////////////////////////////////////////////////////
// ioctl - I/O control
/*static int ccd3ctl_ioctl(struct inode *inode, struct file *file, unsigned int cmd, unsigned long arg) {
	int retval = 0;
	print(plDebug, "ccd3ctl_ioctl\n");
	switch ( cmd ) {
		case CASE1:// for writing data to arg 
			//if (copy_from_user(&data, (int *)arg, sizeof(int))) return -EFAULT;
			break;
			
		case CASE2:// for reading data from arg 
			//if (copy_to_user((int *)arg, &data, sizeof(int))) return -EFAULT;
			break;
			
		default:
			retval = -EINVAL;
	}
	
	return retval;
}*/

///////////////////////////////////////////////////////////////////////////////
// mmap file
/*static int ccd3ctl_mmap(struct file * filp, struct vm_area_struct * vma) {
	int ret = 1;
	print(plDebug, "ccd3ctl_mmap\n");

	ret = remap_pfn_range(vma,  vma->vm_start, virt_to_phys((void*)((unsigned long)driver.buf)) >> PAGE_SHIFT, vma->vm_end-vma->vm_start, PAGE_SHARED);

	return ret ? -EAGAIN : 0;
}*/

static unsigned int ccd3ctl_poll(struct file * file, poll_table *wait) {
	unsigned int mask = 0;
	print(plDebug, "ccd3ctl_poll()\n");

	print(plDebug, "ccd3ctl_poll(), rx queue size = %d\n", char_queue_size(ccd3_getqueues()->rx));

	poll_wait(file, &ccd3_getqueues()->rx_wait, wait);

	if( !char_queue_isempty(ccd3_getqueues()->rx)){
		mask |= POLLIN | POLLRDNORM;
	}
		
	poll_wait(file, &ccd3_getqueues()->tx_wait, wait);

	if( /*!char_queue_isfull(ccd3_getqueues()->tx) && */!ccd3_getstatus()->tx_down ){
		mask |= POLLOUT | POLLWRNORM;
	}

	print(plDebug, "ccd3ctl_poll() =");
	if( mask & POLLIN) 		print(plDebug, " POLLIN");
	if( mask & POLLRDNORM)	print(plDebug, " POLLRDNORM");
	if( mask & POLLOUT)		print(plDebug, " POLLOUT");
	if( mask & POLLWRNORM)	print(plDebug, " POLLWRNORM");
	if( mask & POLLHUP)		print(plDebug, " POLLHUP");
	if( mask & POLLERR)		print(plDebug, " POLLERR");
	if( mask & POLLNVAL)	print(plDebug, " POLLNVAL");
	print(plDebug, "\n");

	return mask;
}	

///////////////////////////////////////////////////////////////////////////////
// initialize module
static int __init ccd3_init_module (void) {
	int i;

	set_print_level(print_level);
	print(plNormal, "CCD3 kernel module initializing..\n");

	i = ccd3_register(no_pci, mem_limit);

	if( i < 0 ){
		print(plError, "Failed registering CCD3 device\n");
		return i;//- EIO;
	}
	
	print(plDebug, "CCD3 device found\n");
	
	// Get device number
	cdev_init(&driver_data.dat_dev, &ccd3_fops);
	cdev_init(&driver_data.ctl_dev, &ccd3ctl_fops);

	i = alloc_chrdev_region(&driver_data.dat_dev.dev, 0, 1, DRIVER_DATA_NAME);
	if (i != 0){
		print(plError, "Could not register device region\n");
		ccd3_cleanup_module();
		return - EIO;
	}

	i = alloc_chrdev_region(&driver_data.ctl_dev.dev, 0, 1, DRIVER_CTL_NAME);
	if (i != 0){
		print(plError, "Could not register device region\n");
		ccd3_cleanup_module();
		return - EIO;
	}

	print(plDebug, "Registering CCD3 device\n");
	
	driver_data.dat_dev.owner = ccd3_fops.owner;
	kobject_set_name(&driver_data.dat_dev.kobj, "%s%d", DRIVER_DATA_NAME, 0);
	i = cdev_add(&driver_data.dat_dev, driver_data.dat_dev.dev, 1);
	
	driver_data.ctl_dev.owner = ccd3ctl_fops.owner;
	kobject_set_name(&driver_data.ctl_dev.kobj, "%s%d", DRIVER_CTL_NAME, 0);
	i = cdev_add(&driver_data.ctl_dev, driver_data.ctl_dev.dev, 1);
	
	switch(i){
		case 0: 
			print(plDebug, "Device registered successfully\n");
			print(plDebug, "dev numbers: %d %d\n", MAJOR(driver_data.dat_dev.dev), MINOR(driver_data.dat_dev.dev));
			print(plDebug, "ctl numbers: %d %d\n", MAJOR(driver_data.ctl_dev.dev), MINOR(driver_data.ctl_dev.dev));
			break;
		case -EINVAL:
			print(plError, "Failed registering device with error -EINVAL\n");
			ccd3_cleanup_module();
			return -EIO;
		case -EBUSY:
			print(plError, "Failed registering device with error -EBUSY\n");
			ccd3_cleanup_module();
			return -EIO;
		default:
			print(plError, "Failed registering device with unknown error (%d)\n", i);
			ccd3_cleanup_module();
			return -EIO;
	}
	
	driver_data.data_class = class_create(THIS_MODULE, DRIVER_DATA_NAME);
	driver_data.ctl_class = class_create(THIS_MODULE, DRIVER_CTL_NAME);

	device_create(driver_data.data_class, NULL, driver_data.dat_dev.dev, "%s", "ccd3");
	device_create(driver_data.ctl_class, NULL, driver_data.ctl_dev.dev, "%s", "ccd3ctl");

	return 0;
}

///////////////////////////////////////////////////////////////////////////////
// close and cleanup module
static void ccd3_cleanup_module (void) {

	print(plNormal, "CCD3 kernel module unloading..\n");

	device_destroy(driver_data.data_class, driver_data.dat_dev.dev);
	device_destroy(driver_data.ctl_class, driver_data.ctl_dev.dev);

	class_destroy(driver_data.data_class);
	class_destroy(driver_data.ctl_class);

    ccd3_unregister();

	cdev_del(&driver_data.dat_dev);
	cdev_del(&driver_data.ctl_dev);

	unregister_chrdev_region(driver_data.dat_dev.dev, 1);
	unregister_chrdev_region(driver_data.ctl_dev.dev, 1);

}

///////////////////////////////////////////////////////////////////////////////

module_init(ccd3_init_module);
module_exit(ccd3_cleanup_module);

///////////////////////////////////////////////////////////////////////////////

MODULE_AUTHOR("jja@nbi.ku.dk");
MODULE_LICENSE("GPL");
MODULE_DESCRIPTION("CCD3 Data Acquisition Device");

///////////////////////////////////////////////////////////////////////////////
// EOF
