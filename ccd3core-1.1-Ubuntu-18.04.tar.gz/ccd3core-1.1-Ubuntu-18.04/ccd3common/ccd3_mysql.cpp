#include <stdarg.h>
#include "ccd3_mysql.h"

cCCD3mysql::cCCD3mysql(char* database, char* user, char* password, char* server)
{
	res = NULL;
	row = NULL;

	conn = mysql_init(NULL);
	
	if( !mysql_real_connect(conn, server, user, password, database, 0, NULL, 0) ){
		throw EMYSQL("MySQL: \"%s\"", mysql_error(conn));
	}
}

cCCD3mysql::~cCCD3mysql()
{
	mysql_close(conn);
}


void cCCD3mysql::query(const char* sql_str,...)
{
	char query_str[1024];
	va_list arg;
	
	va_start (arg, sql_str);
	vsprintf (query_str, sql_str, arg);
	va_end (arg);

	if( mysql_query(conn, query_str) ) {
		throw EMYSQL("MySQL Query: \"%s\"", errorstr());
	}
}

int cCCD3mysql::get_result(void){

	if( res ){
		throw EMYSQL("query already in progress");
	}

	res = mysql_store_result(conn);
	return get_row_cnt();
}

int cCCD3mysql::get_affected(void){

	return mysql_affected_rows(conn);
}

void cCCD3mysql::close_result(void){

	if( res ){
		mysql_free_result(res);
	}

	if( row ){
		row = NULL;
	}

	res = NULL;
}

char** cCCD3mysql::get_row(void)
{
	row = mysql_fetch_row(res);
	return row;
}

int cCCD3mysql::get_row_cnt(void)
{
	return mysql_num_rows(res);
}

int cCCD3mysql::get_field_cnt(void){
	return mysql_num_fields(res);
}

const char* cCCD3mysql::errorstr()
{
	return mysql_error(conn);
}
