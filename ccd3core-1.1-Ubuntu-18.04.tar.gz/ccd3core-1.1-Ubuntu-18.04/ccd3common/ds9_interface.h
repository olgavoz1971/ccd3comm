/*
 * ds9_interface.h
 *
 *  Created on: Apr 12, 2011
 *      Author: root
 */

#ifndef DS9_INTERFACE_H_
#define DS9_INTERFACE_H_

#include <common_exception.h>
#include "xpa_interface.h"

class ds9_comm {
protected:
	bool remote;
	xpa_interface* my_xpa;

public:
	ds9_comm(bool a_remote);
	~ds9_comm(void);
	xpa_interface* xpa(void) { return my_xpa; };
	// image calculations
	unsigned long  GetPos(void);
    unsigned long  GetData(unsigned long* buf, int width, int height);
    unsigned long* GetDataAtPos(unsigned long* buf, int x, int y, int width, int height);
    char* GetStr(char* buf, int width, int height);
    char* GetStrAtPos(char* buf, int x, int y, int width, int height);
    unsigned long Examine(unsigned long* matrice, int width, int height);
    typedef common_exception e_ds9_comm;
};

#endif /* DS9_INTERFACE_H_ */
