
#include <fitsio.h>

char buf[256];

const char* get_error_string(int code)
{
	switch( code ){
		case SAME_FILE         		: return "input and output files are the same";
		case TOO_MANY_FILES    		: return "tried to open too many FITS files at once";
 		case FILE_NOT_OPENED   		: return "could not open the named file";
 		case FILE_NOT_CREATED  		: return "could not create the named file";
 		case WRITE_ERROR       		: return "error writing to FITS file";
 		case END_OF_FILE       		: return "tried to move past end of file";
 		case READ_ERROR        		: return "error reading from FITS file";
 		case FILE_NOT_CLOSED   		: return "could not close the file";
 		case ARRAY_TOO_BIG     		: return "array dimensions exceed internal limit";
 		case READONLY_FILE     		: return "Cannot write to readonly file";
 		case MEMORY_ALLOCATION 		: return "Could not allocate memory";
 		case BAD_FILEPTR       		: return "invalid fitsfile pointer";
 		case NULL_INPUT_PTR    		: return "NULL input pointer to routine";
 		case SEEK_ERROR        		: return "error seeking position in file";
		case BAD_URL_PREFIX    		: return "invalid URL prefix on file name";
		case TOO_MANY_DRIVERS  		: return "tried to register too many IO drivers";
		case DRIVER_INIT_FAILED		: return "driver initialization failed";
		case NO_MATCHING_DRIVER		: return "matching driver is not registered";
		case URL_PARSE_ERROR   		: return "failed to parse input file URL";
		case RANGE_PARSE_ERROR 		: return "parse error in range list";

		case SHARED_BADARG     		: return "bad argument in shared memory driver";
		case SHARED_NULPTR     		: return "null pointer passed as an argument";
		case SHARED_TABFULL    		: return "no more free shared memory handles";
		case SHARED_NOTINIT    		: return "shared memory driver is not initialized";
		case SHARED_IPCERR     		: return "IPC error returned by a system call";
		case SHARED_NOMEM      		: return "no memory in shared memory driver";
		case SHARED_AGAIN      		: return "resource deadlock would occur";
		case SHARED_NOFILE     		: return "attempt to open/create lock file failed";
		case SHARED_NORESIZE   		: return "shared memory block cannot be resized at the moment";

		case HEADER_NOT_EMPTY  		: return "header already contains keywords";
 		case KEY_NO_EXIST      		: return "keyword not found in header";
		case KEY_OUT_BOUNDS    		: return "keyword record number is out of bounds";
		case VALUE_UNDEFINED   		: return "keyword value field is blank";
		case NO_QUOTE          		: return "string is missing the closing quote";
		case BAD_INDEX_KEY     		: return "illegal indexed keyword name (e.g. 'TFORM1000')";
		case BAD_KEYCHAR       		: return "illegal character in keyword name or card";
		case BAD_ORDER         		: return "required keywords out of order";
		case NOT_POS_INT       		: return "keyword value is not a positive integer";
 		case NO_END            		: return "couldn't find END keyword";
		case BAD_BITPIX        		: return "illegal BITPIX keyword value";
		case BAD_NAXIS         		: return "illegal NAXIS keyword value";
		case BAD_NAXES         		: return "illegal NAXISn keyword value";
		case BAD_PCOUNT        		: return "illegal PCOUNT keyword value";
		case BAD_GCOUNT        		: return "illegal GCOUNT keyword value";
		case BAD_TFIELDS       		: return "illegal TFIELDS keyword value";
		case NEG_WIDTH         		: return "negative table row size";
		case NEG_ROWS          		: return "negative number of rows in table";
		case COL_NOT_FOUND     		: return "column with this name not found in table";
		case BAD_SIMPLE        		: return "illegal value of SIMPLE keyword";
		case NO_SIMPLE         		: return "Primary array doesn't start with SIMPLE";
		case NO_BITPIX         		: return "Second keyword not BITPIX";
		case NO_NAXIS          		: return "Third keyword not NAXIS";
		case NO_NAXES          		: return "Couldn't find all the NAXISn keywords";
		case NO_XTENSION       		: return "HDU doesn't start with XTENSION keyword";
		case NOT_ATABLE        		: return "the CHDU is not an ASCII table extension";
		case NOT_BTABLE        		: return "the CHDU is not a binary table extension";
		case NO_PCOUNT         		: return "couldn't find PCOUNT keyword";
		case NO_GCOUNT         		: return "couldn't find GCOUNT keyword";
		case NO_TFIELDS        		: return "couldn't find TFIELDS keyword";
		case NO_TBCOL          		: return "couldn't find TBCOLn keyword";
		case NO_TFORM          		: return "couldn't find TFORMn keyword";
		case NOT_IMAGE         		: return "the CHDU is not an IMAGE extension";
		case BAD_TBCOL         		: return "TBCOLn keyword value < 0 or > rowlength";
		case NOT_TABLE         		: return "the CHDU is not a table";
		case COL_TOO_WIDE      		: return "column is too wide to fit in table";
		case COL_NOT_UNIQUE    		: return "more than 1 column name matches template";
		case BAD_ROW_WIDTH     		: return "sum of column widths not = NAXIS1";
		case UNKNOWN_EXT       		: return "unrecognizable FITS extension type";
		case UNKNOWN_REC       		: return "unknown record; 1st keyword not SIMPLE or XTENSION";
		case END_JUNK          		: return "END keyword is not blank";
		case BAD_HEADER_FILL   		: return "Header fill area contains non-blank chars";
		case BAD_DATA_FILL     		: return "Illegal data fill bytes (not zero or blank)";
		case BAD_TFORM         		: return "illegal TFORM format code";
		case BAD_TFORM_DTYPE   		: return "unrecognizable TFORM data type code";
		case BAD_TDIM          		: return "illegal TDIMn keyword value";
		case BAD_HEAP_PTR      		: return "invalid BINTABLE heap pointer is out of range";

		case BAD_HDU_NUM       		: return "HDU number < 1";
		case BAD_COL_NUM       		: return "column number < 1 or > tfields";
		case NEG_FILE_POS      		: return "tried to move to negative byte location in file";
		case NEG_BYTES         		: return "tried to read or write negative number of bytes";
		case BAD_ROW_NUM       		: return "illegal starting row number in table";
		case BAD_ELEM_NUM      		: return "illegal starting element number in vector";
		case NOT_ASCII_COL     		: return "this is not an ASCII string column";
		case NOT_LOGICAL_COL   		: return "this is not a logical data type column";
		case BAD_ATABLE_FORMAT 		: return "ASCII table column has wrong format";
		case BAD_BTABLE_FORMAT 		: return "Binary table column has wrong format";
		case NO_NULL           		: return "null value has not been defined";
		case NOT_VARI_LEN      		: return "this is not a variable length column";
		case BAD_DIMEN         		: return "illegal number of dimensions in array";
		case BAD_PIX_NUM       		: return "first pixel number greater than last pixel";
		case ZERO_SCALE        		: return "illegal BSCALE or TSCALn keyword = 0";
		case NEG_AXIS          		: return "illegal axis length < 1";

		case NOT_GROUP_TABLE       	:
		case HDU_ALREADY_MEMBER    	:
		case MEMBER_NOT_FOUND      	:
		case GROUP_NOT_FOUND       	:
		case BAD_GROUP_ID          	:
		case TOO_MANY_HDUS_TRACKED 	:
		case HDU_ALREADY_TRACKED   	:
		case BAD_OPTION            	:
		case IDENTICAL_POINTERS    	:
		case BAD_GROUP_ATTACH      	:
		case BAD_GROUP_DETACH      	: return "Grouping function error";

		case NGP_NO_MEMORY			: return "malloc failed";
		case NGP_READ_ERR			: return "read error from file";
		case NGP_NUL_PTR			: return "null pointer passed as an argument. Passing null pointer as a name of template file raises this error";
		case NGP_EMPTY_CURLINE		: return "line read seems to be empty (used internally)";
		case NGP_UNREAD_QUEUE_FULL	: return "cannot unread more then 1 line (or single line twice)";
		case NGP_INC_NESTING		: return "too deep include file nesting (infinite loop, template includes itself ?)";
		case NGP_ERR_FOPEN			: return "fopen() failed, cannot open template file";
		case NGP_EOF				: return "end of file encountered and not expected";
		case NGP_BAD_ARG			: return "bad arguments passed. Usually means internal parser error. Should not happen";
		case NGP_TOKEN_NOT_EXPECT	: return "token not expected here";

		case BAD_I2C           		: return "bad int to formatted string conversion";
		case BAD_F2C           		: return "bad float to formatted string conversion";
		case BAD_INTKEY        		: return "can't interpret keyword value as integer";
		case BAD_LOGICALKEY    		: return "can't interpret keyword value as logical";
		case BAD_FLOATKEY     		: return "can't interpret keyword value as float";
		case BAD_DOUBLEKEY    		: return "can't interpret keyword value as double";
		case BAD_C2I         		: return "bad formatted string to int conversion";
		case BAD_C2F         		: return "bad formatted string to float conversion";
		case BAD_C2D          		: return "bad formatted string to double conversion";
		case BAD_DATATYPE      		: return "illegal datatype code value";
		case BAD_DECIM         		: return "bad number of decimal places specified";
		case NUM_OVERFLOW      		: return "overflow during data type conversion";
		case DATA_COMPRESSION_ERR   : return "error compressing image";
		case DATA_DECOMPRESSION_ERR : return "error uncompressing image";

		case BAD_DATE           	: return "error in date or time conversion";

		case PARSE_SYNTAX_ERR   	: return "syntax error in parser expression";
		case PARSE_BAD_TYPE     	: return "expression did not evaluate to desired type";
		case PARSE_LRG_VECTOR   	: return "vector result too large to return in array";
		case PARSE_NO_OUTPUT    	: return "data parser failed not sent an out column";
		case PARSE_BAD_COL     		: return "bad data encounter while parsing column";
		case PARSE_BAD_OUTPUT   	: return "Output file not of proper type";

		case ANGLE_TOO_BIG      	: return "celestial angle too large for projection";
		case BAD_WCS_VAL      		: return "bad celestial coordinate or pixel value";
		case WCS_ERROR          	: return "error in celestial coordinate calculation";
		case BAD_WCS_PROJ       	: return "unsupported type of celestial projection";
		case NO_WCS_KEY				: return "celestial coordinate keywords not found";
		case APPROX_WCS_KEY			: return "approximate wcs keyword values were returned";
		default						: sprintf(buf, "Unknown error (%d)?", code);
									  return buf;
	}
}
