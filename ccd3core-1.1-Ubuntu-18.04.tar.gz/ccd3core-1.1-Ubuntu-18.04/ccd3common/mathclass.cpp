#include "mathclass.h"
#include <string.h>
#include <stdio.h>

mathclass::mathclass()
{
}

mathclass::~mathclass()
{
}

#define CHAR_BUF_SIZE 256
mathParser::mathParser(char* str)
{
	// split into expressions
/*	char* first;
	char* next;
	char* last;
	char buf[CHAR_BUF_SIZE];
	
	child_count = 0;
	
	first = strchr(str, '(');
	if( first ) {
		next = strchr(first, '(');
		
		if( next ){
		}
		
		if( first ){
			
			last = strrchr(str, ')');
			if( !last ) throw emathClass("Matching paranthesis not found!");
		
			strncpy(buf, first, last-first);			
			child_count++;
			childs = new mathParser(buf);
		}
	}*/
	arg_cnt = 0;
	memset(ops, e_nop, MAX_CHILDS -1);
}

mathParser::~mathParser(void)
{
}

void mathParser::parse(char* str){
	// Search for operators outside paranthesis
	int op_idx;
	int dl_idx;
	int arg_idx;
	float val;
	char arg1[CHAR_BUF_SIZE];
	
	op_idx = strcspn(str, operator_string);
	dl_idx = strcspn(str, delim_string);
	
	if( op_idx < dl_idx ) {
		// operands first
		strncpy(arg1, str, op_idx);	// TBD check zero termination
		// add to childs array
		args[arg_cnt++] = new mathParser(arg1);
		
		parse(&str[op_idx+1]); // recurse to next arg
		
		// args array has been filled
		// Handle resulting args array
		for(arg_idx = 0; arg_idx < arg_cnt; arg_idx++){
			switch(ops[arg_idx]){
				case e_sum:
				case e_sub:
				case e_mul:
				case e_div:
				case e_shiftup:
				case e_shiftdown:
				case e_nop: break;
				default	: throw emathClass("Internal error found!");
			}
		}
				
	} else if( dl_idx < op_idx) {
		// delimiters first, see if multiple args or recursion are needed
		// "(expr) op (expr)" or "((expr op expr) op (expr op expr))"
		op_idx = strcspn(&str[dl_idx+1], delim_string);
		switch(str[dl_idx+1+op_idx]){
			case '(' :	// Find matching ')' character
				
				break;
			case ')' :	
				args[arg_cnt++] = new mathParser(&str[dl_idx+1]);
				break;
			default  : throw emathClass("Syntax error: \"%s\"", str);			
		}	
		
	} else {
		// eval args
		for(arg_idx = 0; arg_idx < e_argcnt; arg_idx++) {
			if( !strcasecmp(str, ArgStrings[arg_idx]) ){
				break;
			}  
		}
		
		if( arg_idx == e_argcnt){
			throw emathClass("Unknown argument found: \"%s\n", str);
		}
		
		// Arg found in ArgStrings[arg_idx];
		switch( arg_idx ){
			case	e_img:
			case	e_rms:
			case	e_avg:
			case	e_fft:
			case	e_sqr:
			case	e_sqrsum:
			case	e_sdev:
			case	e_cent:
			case	e_hole:
			case	e_subset:
			case	e_log2:
			case	e_log10:
			case	e_pwr:
			case	e_exp:
			case	e_abs:
			case	e_argcnt:
			default:
				if( 1 != sscanf(str, "%f", &val)){
					throw emathClass("Syntax error: \"%s\"", str);
				} 
				// Resulting constant in val
				break;
		} 
	}
}

