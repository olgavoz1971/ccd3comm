#include <errno.h>
#include <stdarg.h>
#include <limits.h>
#include <time.h>

#include "ccd3_log.h"

#define IS_PRINTABLE(x) (x >= 32 && x <= 126)

#define TRIM_END(x)										\
	while(!IS_PRINTABLE(x[strlen(x)-1]) && strlen(x)) {	\
		x[strlen(x)-1] = '\0';							\
	}

cCCD3log* cCCD3log::me = NULL;

ccd3Verbosity& operator++(ccd3Verbosity& d, int)
{
	int tmp = d;
	return d = static_cast<ccd3Verbosity> (++tmp);
}

cCCD3log::cCCD3log(void)
{
	print_verbosity = DEFAULT_VERBOSITY;
	log_verbosity = DEFAULT_VERBOSITY;
	max_size = -1;
	LogType = ltNOTSET;
	if( me ){
		print_verbosity = me->print_verbosity;
		log_verbosity = me->log_verbosity;
		delete me;
	}
	me = this;
}

cCCD3log::cCCD3log(const char* a_filename)
{
	strcpy(debug_str, "");
	print_verbosity = DEFAULT_VERBOSITY;
	log_verbosity = DEFAULT_VERBOSITY;
	max_size = -1;

	LogType = ltFile;
	if( me ){
		print_verbosity = me->print_verbosity;
		log_verbosity = me->log_verbosity;
		delete me;
	}
	me = this;
	strcpy(Filename, a_filename);
	File = fopen(Filename, "a");
	
	if( !File ){
		throw ECCD3LOG("Failed to open logfile", errno);
	}	
}

cCCD3log::cCCD3log(const char* ident, int facility)
{
	strcpy(debug_str, "");
	print_verbosity = DEFAULT_VERBOSITY;
	log_verbosity = DEFAULT_VERBOSITY;

	LogType = ltSyslog;
	if( me ){
		print_verbosity = me->print_verbosity;
		log_verbosity = me->log_verbosity;
		delete me;
	}
	me = this;
	File = NULL;
	
	openlog(ident, LOG_PID, facility);
}

cCCD3log::cCCD3log(const char* ident, char* str_facility)
{
	strcpy(debug_str, "");
	print_verbosity = DEFAULT_VERBOSITY;
	log_verbosity = DEFAULT_VERBOSITY;

	int i_facility = -1;
	LogType = ltSyslog;
	if( me ){
		print_verbosity = me->print_verbosity;
		log_verbosity = me->log_verbosity;
		delete me;
	}
	me = this;
	File = NULL;
	
	for(int n=0; n < LOG_FACILITY_CNT; n++){
		if( !strcasecmp(LOG_FACILITIES[n].str_facility, str_facility) ){
			i_facility = LOG_FACILITIES[n].int_facility;
			break;
		}
	}
	
	if( i_facility == -1 )
		throw ECCD3LOG("Unknown log facility (\"%s\")", str_facility );
	
	Facility = i_facility;
	openlog(ident, LOG_PID, Facility);
}

cCCD3log::~cCCD3log()
{
	me = NULL;
	
	if( File ){
		fclose(File);
	}
	
	if( LogType == ltSyslog ){
		closelog();
	}
}

cCCD3log* cCCD3log::instance(void)
{
	if( !me ){
		new cCCD3log();
	}

	return me;
}

void cCCD3log::insert_debug_str(const char* new_debug_str){
#ifdef DEBUG
	strcpy(debug_str, new_debug_str);
#endif
}

void cCCD3log::check_filesize(void)
{
	long fsize;
	if( LogType != ltFile ) return;
	if( max_size == -1 ) return;
	fsize = ftell (File);
	if( fsize > max_size ){
		throw ECCD3LOG("Size of log file has exceeded specified maximum of %d", max_size);
	}
}

void cCCD3log::log(int Severity, const char* message, ...)
{
	time_t t;
	struct tm *tmp;
	char msg_buf[1024] = "";
	char tim_buf[128] = "";
	va_list arg;

	if( LogType == ltNOTSET ){
		return;
	}

	va_start (arg, message);	
	vsprintf(msg_buf, message, arg);
	va_end (arg);

	TRIM_END(msg_buf);

	if( strlen(msg_buf) ){
		if( LogType == ltFile ){
			// TBD handle severity ??
			t = time(NULL);
			tmp= localtime(&t);
			
			strftime(tim_buf, sizeof(tim_buf), LOG_TIMEFORMAT, tmp);		
			fprintf(File, "%s %s\n", tim_buf, msg_buf);
			fflush(File);
			
		} else 	if( LogType == ltSyslog){
			syslog(LOG_MAKEPRI(Facility, Severity), "%s", msg_buf);
		} else {
			throw ECCD3LOG("Unknown log type? (%d)", LogType);
		}
	}
	
}

void cCCD3log::log(const char* message, ...)
{
	char buf[4096];
	va_list arg;
	va_start (arg, message);
	vsprintf(buf, message, arg);
	va_end (arg);

	log( LOG_INFO, buf);
	
}

void cCCD3log::print(ccd3Verbosity Levels, const char* Str, ...)
{
	char buf[4096];
	va_list arg;
	int severity;
	ccd3Verbosity log_level;
	ccd3Verbosity print_level;

	if( !Str ) return;
	if( !strlen(Str) ) return;

	log_level = LOG_LEVEL(Levels);
	print_level = PRINT_LEVEL(Levels);

	switch(log_level){
		case ccAlways : severity = LOG_ERR;  break;
		case ccFatal  : severity = LOG_ERR;  break;
		case ccError  : severity = LOG_ERR;  break;
		case ccNormal : severity = LOG_INFO;   break;
		case ccDebug  : severity = LOG_DEBUG;  break;
		default		  : severity = LOG_DEBUG;  break;
	}


	FILE* output = ( print_level == ccError || print_level == ccFatal ) ? stderr : stdout;

	strcpy(buf, log_level == ccDebug && strlen(debug_str) ? debug_str : "");

	va_start (arg, Str);
	vsprintf(&buf[strlen(buf)], Str, arg);
	va_end (arg);

	if( log_level <= log_verbosity ){
		LOGMSG(severity, buf);
	}

	if( print_level <= print_verbosity ){
		fprintf(output, "%s", buf);
		fflush(output);	// commit
	}

}

bool cCCD3log::set_verbosity(ccd3Verbosity new_verb, ccd3Verbosity* dst)
{
	if( new_verb >= ccAlways && new_verb <= ccDebug ){
		*dst = new_verb;
		return true;
	}

	return false;
}

bool cCCD3log::set_verbosity(char* new_verb, ccd3Verbosity* dst)
{
	ccd3Verbosity verb;
	int int_verb;

	for(verb = ccAlways; verb <= ccDebug; verb ++){
		if( !strcasecmp(new_verb, VERBOSITY_STRINGS[verb]) ){
			return set_verbosity(verb, dst);
		}
	}

	if(1 == sscanf(new_verb, "%d", &int_verb)){
		verb = (ccd3Verbosity)int_verb;
		return set_verbosity(verb, dst);
	}

	return false;
}

bool cCCD3log::set_print_verbosity(ccd3Verbosity new_verb)
{
	return set_verbosity(new_verb, &print_verbosity);
}

bool cCCD3log::set_print_verbosity(char* new_verb)
{
	return set_verbosity(new_verb, &print_verbosity);
}

bool cCCD3log::set_log_verbosity(ccd3Verbosity new_verb)
{
	return set_verbosity(new_verb, &log_verbosity);
}

bool cCCD3log::set_log_verbosity(char* new_verb)
{
	return set_verbosity(new_verb, &log_verbosity);
}

