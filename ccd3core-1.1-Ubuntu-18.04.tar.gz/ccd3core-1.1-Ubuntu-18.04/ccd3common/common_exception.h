/*
 *  Copyright (c) 2006 Copenhagen University Astronomical Observatory
 *  All possible rights reserved
 *	Filename:	
 *  Abstract:	
 *  Author:		Jeppe Jønch Andersen (jja@astro.ku.dk)
 *  Revision:
 *  Remarks:
 */
 
#ifndef _COMMON_EXCEPTION_H_
#define _COMMON_EXCEPTION_H_

#include <execinfo.h>
#include <stdio.h>
#include <exception>

using namespace std;

#define TRACE_COUNT 			25	/* Maximum depth of call stack			*/
#define ERROR_STR_LENGTH	   256	/* Maximum length of an error message	*/

/* Common base class for exceptions, provides easy interface and stack trace */

class common_exception : public exception
{
	protected:
		char errstr[ERROR_STR_LENGTH];
	    void* array[TRACE_COUNT];
    	char** symbols;
	    int	nSize;
		void preparetrace();
			
	public:
    	common_exception(const char *fmt, ...);
	    common_exception(void);
    	common_exception(int err);
    	common_exception(const char *str, int err);
		~common_exception() throw();
		char* what(void);
		char* trace(int level);	
		char* trace_name(int level);
		int size(void){ return nSize; };
};

#endif /* _COMMON_EXCEPTION_H_ */

///////////////////////////////////////////////////////////////////////////////
// EOF
