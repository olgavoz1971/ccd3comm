#ifndef MATHCLASS_H_
#define MATHCLASS_H_

#include "common_exception.h"

typedef enum {
	e_sum,
	e_sub,
	e_mul,
	e_div,
	e_shiftup,
	e_shiftdown,
	e_nop
} TOperator;

const char operator_strings[][6] = {
	"+",
	"-",
	"*",
	"/",
	">",
	"<"
};

const char operator_string[] = "+-*/><";
const char delim_string[] = "()";

typedef enum {
	e_img = 0,
	e_rms,
	e_avg,
	e_fft,
	e_sqr,
	e_sqrsum,
	e_sdev,
	e_cent,
	e_hole,
	e_subset,
	e_log2,
	e_log10,
	e_pwr,
	e_exp,
	e_abs,
	e_argcnt
} TArgs;

const char ArgStrings[][7] = {
	"image",
	"rms",
	"avg",
	"fft",
	"sqr",
	"sqrsum",
	"sdev",
	"cent",
	"hole",
	"subset",
	"log2",
	"log10",
	"pwr",
	"exp",
	"abs"
};

/*

eval image(0) + image(1)
eval fft(image(0))
eval image(0) / image(1)
eval rms(image(0) - image(1)) - (image(2) - image(3))
eval sqr(image(0))
eval sqrsum(image(0))
eval sdev(image(0))
eval cent(image(0))
eval hole(image(0))
eval subset(image(0), x, y, w, h)

*/


class mathclass
{
public:
	mathclass();
	virtual ~mathclass();
};


#define MAX_ARG_LEN 32
#define MAX_CHILDS	8

// Type of data returned by this class
typedef enum {
	dtUnknown,
	dtScalar,
	dtVector,
} TDataType;

class mathParser{
protected:
	mathParser* args[MAX_CHILDS];
	TOperator	ops[MAX_CHILDS-1];
	int arg_cnt;
	TDataType data_type;
public:
	mathParser(char* str);
	virtual ~mathParser(void);
	void parse(char* str);
	// Exception classes
	typedef common_exception emathClass;
	
};

#endif /*MATHCLASS_H_*/
