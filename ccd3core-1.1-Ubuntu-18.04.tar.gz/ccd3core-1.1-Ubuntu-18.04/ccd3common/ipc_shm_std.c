
#include "ipc_shm_std.h"

//#ifdef __KERNEL__
//    #include "kpstdlib.h"
//#else
    #include <stdio.h>
    #include <stdlib.h>
//#endif

// ------------------------------------------------------------

#define SHMMAX_FILE "/proc/sys/kernel/shmmax"
#define SHMMNI_FILE "/proc/sys/kernel/shmmni"

#define ERR_STR_LEN 40
const char SHM_ERRORS[SHM_COUNT][ERR_STR_LEN] ={
	{"Operation completed succesfully"},
	"An unspecified failure occurred",
	"Failed to determine maximum page size",
	"Failed to read maximum page size",
	"Failed to read system page size",
	"Failed to set system page size",
	"Unable to get shm key",
	"Failed to deallocate shared memory",
	"Failed to allocate kernel memory"
}; 


// ------------------------------------------------------------

sharedmem_result shm_alloc(h_sharedmem* Handle, int size, int FailExists)
{
	FILE *f;
	int res;
	*Handle = (h_sharedmem)malloc(sizeof(sharedmem));

	if(!*Handle)
		return SHM_FAIL_MEM_ALLOC;
	
	if( !(f = fopen(SHMMAX_FILE, "r")) )
		return SHM_FAIL_MAX_PAGE_SIZE;

	res = fscanf(f, "%d", &(*Handle)->maxpagesize);
	fclose(f);
	
	if( 1 != res )
		return SHM_FAIL_MAX_PAGE_READ;
	
	if( !(f = fopen(SHMMNI_FILE, "r")) ) 
		return SHM_FAIL_SYS_PAGE_SIZE;
	
	res = fscanf(f, "%d", &(*Handle)->pagesize);
	fclose(f);
	
	if( 1 != res )
		return SHM_FAIL_SYS_PAGE_SIZE;
		
	// Make size a multiple of PAGE_SIZE
	(**Handle).realsize = size + /*(**Handle).pagesize -*/ (size % (**Handle).pagesize);

	// Check page size agains system max
	while( (**Handle).realsize > (**Handle).maxpagesize ){
		
		if( !(f = fopen(SHMMAX_FILE, "w")) )
			return SHM_FAIL_SET_SYS_PAGE_SIZE;
			
		(**Handle).maxpagesize =  (**Handle).maxpagesize ? (**Handle).maxpagesize * 2 : INITIAL_PAGE_SIZE;
		fprintf(f ,"%d", (**Handle).maxpagesize);
		fclose(f);
	}	

	(**Handle).key = ftok("/", size);
	if( (**Handle).key == -1) 
		return SHM_FAIL_SHM_KEY;
				
	(**Handle).shmid = 	shmget((**Handle).key, (**Handle).realsize, IPC_PERM | IPC_CREAT | (FailExists ? IPC_EXCL : 0));
	if( (**Handle).shmid < 0 ) return SHM_FAILURE;
				
	(**Handle).page = shmat((**Handle).shmid, NULL, 0);		
	if( (**Handle).page == (void*)-1 ) return SHM_FAILURE;

	// Mark segment for removal when last attached process have detached		
	if( shmctl((**Handle).shmid, IPC_RMID, 0) < 0 ){
		return SHM_FAILURE;
	}

	return SHM_SUCCESS;
}

// ------------------------------------------------------------

sharedmem_result shm_free(h_sharedmem Handle)
{
	if( shmdt(Handle->page) < 0 ){
		return SHM_FAIL_DEALLOCATE;
	}
	
	free(Handle);	
	return SHM_SUCCESS;
}

// ------------------------------------------------------------

sharedmem_result shm_getmem(h_sharedmem Handle, void** Mem)
{
	*Mem = Handle->page;
	return SHM_SUCCESS;
}

// ------------------------------------------------------------

sharedmem_result shm_getid(h_sharedmem Handle, int* shmid)        
{ 
	*shmid = Handle->shmid;
	return SHM_SUCCESS; 
}

// ------------------------------------------------------------

char* shm_geterr(sharedmem_result result)
{
	return (char*)SHM_ERRORS[result];
}

// ------------------------------------------------------------
// EOF
