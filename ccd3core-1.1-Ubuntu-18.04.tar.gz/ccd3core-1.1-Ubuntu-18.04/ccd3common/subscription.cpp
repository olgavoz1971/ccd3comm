
#include "subscription.h"
#include <stdio.h>

const char SUBSCRIPTION_WILDCARD[] = "*";

///////////////////////////////////////////////////////////////////////////////
// Constructor
SubscriptionQueue::SubscriptionQueue(int queue_size, int callback_size)
{
	size = queue_size;
	Queue = new pSubscriptionElement[size];
	for(DWORD msg_idx = 0; msg_idx < size; msg_idx++){
		Queue[msg_idx] = new SubscriptionElement(callback_size);
	}
}

///////////////////////////////////////////////////////////////////////////////
// Destructor
SubscriptionQueue::~SubscriptionQueue()
{
	// delete objects
	while(size--){
		delete Queue[size];
	}
	// delete object list
	delete[] Queue;
}

///////////////////////////////////////////////////////////////////////////////
// Request that the callback method is called when a response specified in
// buf is received. Callback may be omitted and thus polling of the result
// is required. The request is identified by the return value
HSUBSCRIPTION SubscriptionQueue::Subscribe(const char* cmd, SubscriptionCallback* Callback, void* UserData, DWORD Mode)
{
	DWORD msg_idx;
	DWORD callback_idx;
	// Search existing message
	for(msg_idx=0; msg_idx < size; msg_idx++){
		
		if( !strcmp(Queue[msg_idx]->Command, cmd) ){
			// If message is already defined... add callback to existing
			for(callback_idx=0; callback_idx < Queue[callback_idx]->MaxCallbackCount; callback_idx++){

				// If same callback has already been defined on this message
				// update associated parameters
				if( Queue[msg_idx]->CallbackQueue[callback_idx] == Callback){
					Queue[msg_idx]->Mode[callback_idx] = Mode; 				// Update mode
					Queue[msg_idx]->User[callback_idx] = UserData;			// Update user data
					return MAKE_SUBSCRIPTION_HANDLE(msg_idx, callback_idx);	// return existing handle
				}

				// If vacant position found
				if( !Queue[msg_idx]->CallbackQueue[callback_idx] ){
					Queue[msg_idx]->CallbackQueue[callback_idx] = Callback;
					Queue[msg_idx]->Mode[callback_idx] = Mode;
					Queue[msg_idx]->User[callback_idx] = UserData;
					Queue[msg_idx]->CallbackCount++;
					return MAKE_SUBSCRIPTION_HANDLE(msg_idx, callback_idx);
				}
			}

			if( callback_idx >= Queue[msg_idx]->MaxCallbackCount )
				throw ESubscriptionQueue("Callback queue on message \"%s\" is full!", cmd);
		} // if ( !strcmp( ...
	} // for(msg_idx=0 ...

	// Search for vacant spot for new message
	for(msg_idx=0; msg_idx < size; msg_idx++){

		if( !strlen(Queue[msg_idx]->Command )){
			// otherwise create a new callback	
			strcpy(Queue[msg_idx]->Command, cmd);
			Queue[msg_idx]->CallbackQueue[0] = Callback;
			Queue[msg_idx]->Mode[0] = Mode;
			Queue[msg_idx]->User[0] = UserData;
			Queue[msg_idx]->CallbackCount = Callback ? 1:0;
			if( !Callback ){
				printf("Subscribe on \"%s\" without callback\n", cmd);
			}
//			printf("Subscribing to \"%s\"\n", cmd);
			return MAKE_SUBSCRIPTION_HANDLE(msg_idx, 0);
		}
	}
	
	Show();
	throw ESubscriptionQueue("Subscription queue is full!");	// No vacant position available
	return -1;
}

///////////////////////////////////////////////////////////////////////////////
// Cancels a previously subscribed command
void SubscriptionQueue::Unsubscribe(HSUBSCRIPTION hSubscription)
{
	DWORD msg_idx = GET_SUBSCRIPTION_INDEX(hSubscription);
	DWORD callback_idx = GET_CALLBACK_INDEX(hSubscription);
	
	if(!strlen(Queue[msg_idx]->Command)) throw ESubscriptionQueue("Item was not found in subscription queue!");

	Queue[msg_idx]->CallbackQueue[callback_idx] = NULL;
	Queue[msg_idx]->Mode[callback_idx] = 0;
	Queue[msg_idx]->CallbackCount--;
	//printf("Unsubscribing \"%s\" CallbackCount=%lu\n", Queue[msg_idx]->Command, Queue[msg_idx]->CallbackCount);
	
	
	// If no more subscriptions on this queue
	if( !Queue[msg_idx]->CallbackCount ){
		//printf("Removing last instance of \"%s\"\n", Queue[msg_idx]->Command);
		strcpy(Queue[msg_idx]->Command, "");
		Queue[msg_idx]->Clear();
	}
}	

///////////////////////////////////////////////////////////////////////////////
// Registers a default callback handler for unspecified events
void SubscriptionQueue::SubscribeDefault(SubscriptionCallback Callback, void* UserData, DWORD Mode)
{
	DefaultHandler.CallbackQueue[0] = Callback;	
	DefaultHandler.User[0] = UserData;
	DefaultHandler.Mode[0] = Mode;
}

///////////////////////////////////////////////////////////////////////////////
//

HSUBSCRIPTION SubscriptionQueue::SubscribeAll(SubscriptionCallback Callback, void* UserData)
{
	return Subscribe(SUBSCRIPTION_WILDCARD, Callback, UserData, SM_ALWAYS);
}

///////////////////////////////////////////////////////////////////////////////
// 
void SubscriptionQueue::HandleEvent(char* Event)
{
	DWORD msg_idx;
	DWORD callback_idx;
	char data[MAX_EVENT_LENGTH];
	pSubscriptionCallback Callback;
	char* arg;
	bool wildcard = false;
	bool msg_found = false;

	if( strlen(Event) > MAX_EVENT_LENGTH ){
		throw ESubscriptionQueue("Can't handle events longer than %d characters", MAX_EVENT_LENGTH);
	}

	strcpy(data, Event);

	for(msg_idx=0; msg_idx < size; msg_idx++){			
		// is this command defined at all ?
		if(!strlen(Queue[msg_idx]->Command)) continue;

		wildcard = !strcmp(Queue[msg_idx]->Command, SUBSCRIPTION_WILDCARD);

		if( !wildcard && strncasecmp(Queue[msg_idx]->Command, data, strlen(Queue[msg_idx]->Command))){
			continue;
		}
		// Token was found.. save response
		arg = strchr(data, ' ');		// Find first space in !NNNN ARG1 ARG2 ARG3
		if( arg ) { 			// No arguments ??

			while (arg[0] == ' ') arg++; 			// Remove leading spaces
			while (arg[strlen(arg)-1] == ' ') {		// Remove trailing spaces
				arg[strlen(arg)-1] = '\0';
			}
			strcpy(Queue[msg_idx]->Response, arg);

		} else {
			strcpy(Queue[msg_idx]->Response, "");
		}


		// Check callbacks
		for(callback_idx=0; callback_idx < Queue[msg_idx]->MaxCallbackCount; callback_idx++){

			if( Queue[msg_idx]->CallbackQueue[callback_idx] == NULL) continue;
				
			if( !wildcard )
				msg_found = true;
			// Execute subscription callback
			Callback = Queue[msg_idx]->CallbackQueue[callback_idx];
			Callback(MAKE_SUBSCRIPTION_HANDLE(msg_idx, callback_idx), data, Queue[msg_idx]->User[callback_idx]);
			
			if( Queue[msg_idx]->CallbackCount && Queue[msg_idx]->Mode[callback_idx] ){
			
				if( !--Queue[msg_idx]->Mode[callback_idx] ){
					// Remove subscription
					Unsubscribe(MAKE_SUBSCRIPTION_HANDLE(msg_idx, callback_idx));
				}
			}
		}			
		// Don't back out .. there may still be unprocessed wildcards
	}
	
	if( !msg_found ){
		// Handle unexpected data
		Callback = DefaultHandler.CallbackQueue[0];
		if( Callback ){
			try {
				Callback(MAKE_SUBSCRIPTION_HANDLE(0, 0), data, DefaultHandler.User[0]);
			} catch(...){
				throw ESubscriptionQueue("Default callback function made a poohh: \"%s\"", data);
			}
		}
	}
	
	return;	
}

///////////////////////////////////////////////////////////////////////////////
//
char* SubscriptionQueue::GetCommand(HSUBSCRIPTION hSubscription)
{
	DWORD msg_idx = GET_SUBSCRIPTION_INDEX(hSubscription);
	if( msg_idx >= size) throw ESubscriptionQueue("Invalid parameter");
	return Queue[msg_idx]->Command;
}
///////////////////////////////////////////////////////////////////////////////
//
char* SubscriptionQueue::GetResponse(HSUBSCRIPTION hSubscription)
{
	DWORD msg_idx = GET_SUBSCRIPTION_INDEX(hSubscription);
	return Queue[msg_idx]->Response;
}

///////////////////////////////////////////////////////////////////////////////
//
void SubscriptionQueue::Show(void){
    DWORD msg_idx, callback_idx;
    printf("Subscription queues:\n");
    for(msg_idx = 0; msg_idx < size; msg_idx++){
    		
		if(!strlen(Queue[msg_idx]->Command)) continue;
		printf("\tMessage[%lu]: %s\n", msg_idx, Queue[msg_idx]->Command);
		printf("\t\tCount: %lu\n", Queue[msg_idx]->CallbackCount);
		for(callback_idx=0; callback_idx < Queue[msg_idx]->MaxCallbackCount; callback_idx++){
		    if( !Queue[msg_idx]->CallbackQueue[callback_idx] ) continue;
		    printf("\t\t\tCallback: %p:%lu\n", Queue[msg_idx]->CallbackQueue[callback_idx], Queue[msg_idx]->Mode[callback_idx]);
		}
		
    }
}

///////////////////////////////////////////////////////////////////////////////
//EOF

