/*
 *  Copyright (c) 2006 Copenhagen University Astronomical Observatory
 *  Filename:	cFifo.cpp
 *  Abstract:	A simple untyped fifo class
 *  Author:	Jeppe Jønch Andersen (jja@@astro.ku.dk)
 *  Revision:
 */

#include "fifo.h"

///////////////////////////////////////////////////////////////////////////////
// Constructor
cFifo::cFifo(int spc, int esz){
	space = spc+1;
	element_size = esz;	
	buf = new BYTE[space * element_size];
	clear();
}

///////////////////////////////////////////////////////////////////////////////
// Destructor
cFifo::~cFifo(void)
{
	if( buf ){
		delete[] buf;
		buf = NULL;
	}
}

///////////////////////////////////////////////////////////////////////////////
// Put cnt elements from data into queue. Returns the number elements which
// was succesfully stored
int cFifo::put(void* data, int cnt)
{
	BYTE* src = (BYTE*)data;
	int n;

	for(n=0; n < cnt && !isfull(); n++){
		memcpy(&buf[element_size * write], &src[element_size * n], element_size);	
		write++;
		write = write % space;
	}
	
	return n;
}

///////////////////////////////////////////////////////////////////////////////
// Return cnt elements from queue. The element(s) is written to data 
// and data is returned
void* cFifo::get(void* userbuf, int cnt)
{
	BYTE* dst = (BYTE*)userbuf;
	
	if(cnt > size()) throw eFifo("Queue underflow");
	
	for(int n=0; n < cnt; n++){
		if( dst ){
			memcpy(&dst[element_size * n], &buf[element_size * read], element_size);
		}
		//memset(&buf[element_size * read], 0, element_size);
		read++;
		read = read % space;
	}
	
	return dst;
}

///////////////////////////////////////////////////////////////////////////////
// Returns the entire unfragmented buffer in cbuf
// The caller has to ensure that sufficient space is allocated in cbuf
void* cFifo::getbuf(void* cbuf)
{
	BYTE* dst = (BYTE*)cbuf;
	
	if( write > read ){
		memcpy(dst, &buf[read * element_size], (write - read) * element_size);
	}else{
		memcpy(dst, &buf[read * element_size], (space - read) * element_size);
		memcpy(&dst[(space-read) * element_size], buf, write * element_size);
	}
	
	clear();
	return cbuf;
}

///////////////////////////////////////////////////////////////////////////////
// Returns the number of elements in the queue
int cFifo::size(void)
{
	return (write >= read ? write - read : write + space - read);
}

///////////////////////////////////////////////////////////////////////////////
// Returns the number of vacant elements in the queue
int cFifo::free(void)
{
	return space - size();
}

///////////////////////////////////////////////////////////////////////////////
// Returns the index of the value pointed to by data
int cFifo::indexof(void* data)
{
	void* res = NULL;
	int idx = -1;
	if( write >= read){
		res = memchr(&buf[read],*(char*)data, write-read);
		if( res )
			idx = (BYTE*)res - (BYTE*)&buf[read];
	} else {
		res = memchr(&buf[read],*(char*)data, space - read);
		if( res ){
			idx = (BYTE*)res - (BYTE*)&buf[read];
		} else {
			res = memchr(buf, *(char*)data, write);
			if( res ){
				idx = (BYTE*)res - (BYTE*)buf + space - read;
			}
		}		
	}
			

/*	for(int n=0; n < size(); n++){
		//if(!bcmp(&buf[((n+read) % space) * element_size], data, element_size)){
		if(buf[((n+read) % space) * element_size] ==  *(char*)data){
			return n;
		}		 
	}*/
	return idx;
}

///////////////////////////////////////////////////////////////////////////////
// Returns cnt data from offset without removal
void* cFifo::peek(void* data, int cnt, int offset)
{
	BYTE* dst = (BYTE*)data;
	
	if( write >= (read + offset + cnt) ){
		memcpy(dst, &buf[(read + offset) * element_size], cnt * element_size);
	} else {
		memcpy(dst, &buf[(read + offset) * element_size], (space - read) * element_size);
		memcpy(&dst[(space-read) * element_size], buf, (cnt - space + read) * element_size);
	}
	
	return dst;	
}

///////////////////////////////////////////////////////////////////////////////
// EOF
