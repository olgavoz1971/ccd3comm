#ifndef IPC_SHM_STD_H_
#define IPC_SHM_STD_H_

#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>

// ------------------------------------------------------------
//#if !defined(__KERNEL__)
//using namespace std;
//#endif

// ------------------------------------------------------------

typedef enum {
	SHM_SUCCESS = 0,			/* Operation completed succesfully 			*/
	SHM_FAILURE,				/* An unspecified failure occurred			*/
	SHM_FAIL_MAX_PAGE_SIZE,		/* Failed to determine maximum page size	*/
	SHM_FAIL_MAX_PAGE_READ,		/* Failed to read maximum page size			*/
	SHM_FAIL_SYS_PAGE_SIZE,		/* Failed to read system page size 			*/
	SHM_FAIL_SET_SYS_PAGE_SIZE,	/* Failed to set system page size			*/
	SHM_FAIL_SHM_KEY,			/* Unable to get shm key					*/
	SHM_FAIL_DEALLOCATE,		/* Failed to deallocate shared memory		*/
	SHM_FAIL_MEM_ALLOC,			/* Failed to allocate local memory			*/
	SHM_COUNT
} sharedmem_result;

#define PERM_UREAD      0400
#define PERM_UWRITE     0200
#define PERM_GREAD      0040
#define PERM_GWRITE     0020
#define PERM_OREAD      0004
#define PERM_OWRITE     0002

#define INITIAL_PAGE_SIZE 0x400000	/* 4 megs */

#define IPC_PERM (	PERM_UREAD | PERM_UWRITE | PERM_GREAD | \
					PERM_GWRITE | PERM_OREAD | PERM_OWRITE)

typedef struct {
	key_t  key;
	int    shmid;
    void*  page;
    int	   realsize;
    int	   maxpagesize;
    int	   pagesize;	
} sharedmem;
typedef sharedmem *h_sharedmem;

// ------------------------------------------------------------

sharedmem_result shm_alloc(h_sharedmem* Handle, int size, int FailExists);
sharedmem_result shm_free(h_sharedmem Handle);
sharedmem_result shm_getmem(h_sharedmem Handle, void** Mem);
sharedmem_result shm_getid(h_sharedmem Handle, int* shmid);        
char* shm_geterr(sharedmem_result result);

#endif /*IPC_SHM_STD_H_*/
// ------------------------------------------------------------
// EOF
