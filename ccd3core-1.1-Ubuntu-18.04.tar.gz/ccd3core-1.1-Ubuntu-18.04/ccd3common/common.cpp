#include <stdio.h>
#include <assert.h>
#include <unistd.h>
#include <string.h>
#include "common.h"


bool file_exists(const char* filename)
{
	FILE* file;
	file = fopen(filename, "r");
	
	if( file ){
		fclose(file);
		return true;
	}
	
	return false;
}

bool file_exists(const char* path, const char* filename){
	char tmp[MAX_PATH];
	sprintf(tmp, "%s%s", path, filename);
	return file_exists(tmp);
}

char* find_configfile(char* filename, int argc, char** argv, char* prefix){
	// filename  = [modulename].conf or [modulename].cfg or .[modulename]
	// search order:
	// 	/etc/[prefix]
	// 	/etc/[modulename]
	//	/etc/default
	// 	~/
	// 	current dir
	// 	binary dir

	char module_name[256];
	char module_path[256];
	char filename1[256];
	char filename2[256];
	char filename3[256];
	char *c_ptr;

	if( filename && strlen(filename)){
		if( file_exists(filename) ) return filename;
	}

	c_ptr = strrchr(argv[0], '/');
	if( !c_ptr ){
		strcpy(module_path, "./");
		strcpy(module_name, argv[0]);
	} else {
		strcpy(module_path, argv[0]);
		c_ptr = strrchr(module_path, '/');
		c_ptr[0] = '\0';
		strcpy(module_name, &c_ptr[1]);
	}

	sprintf(filename1, "%s.conf", module_name);
	sprintf(filename2, "%s.cfg", module_name);
	sprintf(filename3, ".%s", module_name);

	// Search /etc/[prefix]
	if( prefix ){
		sprintf(filename, "/etc/%s/%s", prefix, filename1);
		if( file_exists(filename) ) return filename;

		sprintf(filename, "/etc/%s/%s", prefix, filename2);
		if( file_exists(filename) ) return filename;

		sprintf(filename, "/etc/%s/%s", prefix, filename3);
		if( file_exists(filename) ) return filename;
	}

	// Search /etc/[module_name]
	sprintf(filename, "/etc/%s/%s", module_name, filename1);
	if( file_exists(filename) ) return filename;

	sprintf(filename, "/etc/%s/%s", module_name, filename2);
	if( file_exists(filename) ) return filename;

	sprintf(filename, "/etc/%s/%s", module_name, filename3);
	if( file_exists(filename) ) return filename;

	// Search /etc/default
	sprintf(filename, "/etc/defmodule_name, ault/%s", filename1);
	if( file_exists(filename) ) return filename;

	sprintf(filename, "/etc/default/%s", filename2);
	if( file_exists(filename) ) return filename;

	sprintf(filename, "/etc/default/%s", filename3);
	if( file_exists(filename) ) return filename;


	// Search home dir
	sprintf(filename, "~/%s", filename1);
	if( file_exists(filename) ) return filename;

	sprintf(filename, "~/%s", filename2);
	if( file_exists(filename) ) return filename;

	sprintf(filename, "~/%s", filename3);
	if( file_exists(filename) ) return filename;

	// Search current dir
	strcpy(filename, filename1);
	if( file_exists(filename) ) return filename;

	strcpy(filename, filename2);
	if( file_exists(filename) ) return filename;

	strcpy(filename, filename3);
	if( file_exists(filename) ) return filename;


	// Search binary dir
	sprintf(filename, "%s/%s", module_path, filename1);
	if( file_exists(filename) ) return filename;

	sprintf(filename, "%s/%s", module_path, filename2);
	if( file_exists(filename) ) return filename;

	sprintf(filename, "%s/%s", module_path, filename3);
	if( file_exists(filename) ) return filename;

	strcpy(filename, "");
	return NULL;
}
