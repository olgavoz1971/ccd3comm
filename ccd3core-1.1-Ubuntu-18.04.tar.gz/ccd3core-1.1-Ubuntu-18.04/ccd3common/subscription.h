#ifndef SUBSCRIPTION_H_
#define SUBSCRIPTION_H_

#include <string.h>
#include "common_exception.h"

#define MAX_EVENT_LENGTH	64			/* maximum length of a total subscription str	*/
#define SM_ALWAYS		 0 				/* infinite subscription 						*/

#define MAKE_SUBSCRIPTION_HANDLE(S_IDX, C_IDX)	((HSUBSCRIPTION)((S_IDX << 16) + C_IDX))
#define GET_SUBSCRIPTION_INDEX(HANDLE)			((DWORD)(HANDLE >> 16))
#define GET_CALLBACK_INDEX(HANDLE)				((DWORD)(HANDLE & 0xFFFF))
#define INVALID_SUBSCRIPTION_HANDLE				((HSUBSCRIPTION)0xFFFFFFFF)

#define BZERO(buf) memset((buf), 0, sizeof(*buf) * MaxCallbackCount)

typedef unsigned long DWORD;
typedef DWORD HSUBSCRIPTION;
typedef void (SubscriptionCallback)(HSUBSCRIPTION hSubscription, char* data, void* User);
typedef SubscriptionCallback* pSubscriptionCallback;

typedef struct SubscriptionElement {
	char Command[MAX_EVENT_LENGTH];
	char Response[MAX_EVENT_LENGTH];

	pSubscriptionCallback* CallbackQueue;
	DWORD* Mode;
	void** User;

	DWORD CallbackCount;
	DWORD MaxCallbackCount;

	void Clear(void){
		BZERO(CallbackQueue);
		BZERO(Mode);
		BZERO(User);
	};

	SubscriptionElement(void)
	{
		MaxCallbackCount = 1;
		CallbackCount = 0;
		CallbackQueue = new pSubscriptionCallback[MaxCallbackCount];
		Mode = new DWORD[MaxCallbackCount];
		User = new void*[MaxCallbackCount];
		strcpy(Command, "");
		strcpy(Response,""); 		
		Clear();
	};

	SubscriptionElement(DWORD UserMaxCallback)
	{
		MaxCallbackCount = 10;//UserMaxCallback;
		CallbackCount = 0;
		CallbackQueue = new pSubscriptionCallback[MaxCallbackCount];
		Mode = new DWORD[MaxCallbackCount];
		User = new void*[MaxCallbackCount];
		strcpy(Command, "");
		strcpy(Response,""); 		
		Clear();
	};
	
	~SubscriptionElement(void)
	{
		delete[] User;
		User = NULL;
		delete[] Mode;
		Mode = NULL;
		delete[] CallbackQueue;
		CallbackQueue = NULL;
	};

} *pSubscriptionElement;

typedef common_exception ESubscriptionQueue;	

class SubscriptionQueue
{
protected:
	pSubscriptionElement* Queue;
	SubscriptionElement DefaultHandler;
	DWORD size;
public:
	SubscriptionQueue(int queue_size, int callback_size);
	virtual ~SubscriptionQueue();
	void HandleEvent(char* Event);
    void SubscribeDefault(SubscriptionCallback Callback, void* UserData, DWORD Mode);
    HSUBSCRIPTION SubscribeAll(SubscriptionCallback Callback, void* UserData);
    HSUBSCRIPTION Subscribe(const char* cmd, SubscriptionCallback Callback = NULL, void* UserData = NULL, DWORD Mode = SM_ALWAYS);	
    void Unsubscribe(HSUBSCRIPTION hSubscription);
    char* GetCommand(HSUBSCRIPTION hSubscription);
    char* GetResponse(HSUBSCRIPTION hSubscription);
    void  Show(void);
};

#endif /*SUBSCRIPTION_H_*/
