/*
 *  Copyright (c) 2006 Copenhagen University Astronomical Observatory
 *  All possible rights reserved
 *	Filename:	
 *  Abstract:	
 *  Author:		Jeppe Jønch Andersen (jja@astro.ku.dk)
 *  Revision:
 *  Remarks:
 */
 
#include "ipc_shm.h"

// ------------------------------------------------------------
						
TIpc::TIpc (int a_size, bool a_FailExists){

	sharedmem_result Result;
	mem_size = a_size;
	Result = shm_alloc(&Handle, mem_size, a_FailExists);
	
	if( Result != SHM_SUCCESS )
		throw EIpc( shm_geterr(Result) );	
}

// ------------------------------------------------------------

TIpc::~TIpc (){
	sharedmem_result Result;
	Result = shm_free(Handle);
	
	if( Result != SHM_SUCCESS )
		throw EIpc( shm_geterr(Result) );
}

// ------------------------------------------------------------

void* TIpc::getmem(void){
	sharedmem_result Result;
	void* tmp;
	Result = shm_getmem(Handle, &tmp);
	
	if( Result != SHM_SUCCESS )
		throw EIpc( shm_geterr(Result) );
		
	return tmp;
}

// ------------------------------------------------------------

int TIpc::getid(void){ 
	sharedmem_result Result;
	int tmp;
	Result = shm_getid(Handle, &tmp);
	
	if( Result != SHM_SUCCESS )
		throw EIpc( shm_geterr(Result) );
		
	return tmp; 
}        

///////////////////////////////////////////////////////////////////////////////
// EOF
