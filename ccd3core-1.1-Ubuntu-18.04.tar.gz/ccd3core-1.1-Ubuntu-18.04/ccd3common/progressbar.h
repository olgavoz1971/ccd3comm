#ifndef PROGRESSBAR_CLASS_H_
#define PROGRESSBAR_CLASS_H_

class progressbar_class
{
protected:
	int call_cnt;
	int last_progress;
	char* text;
	char buf[256];
	char progressbuf[51];

public:
	progressbar_class(char* label);
	virtual ~progressbar_class();
	char* get_text(int progress, bool active = true);
	//void set_label(char* new_label){ text = new_label; };
	void clear(void);
};

#endif /*PROGRESSBAR_CLASS_H_*/
