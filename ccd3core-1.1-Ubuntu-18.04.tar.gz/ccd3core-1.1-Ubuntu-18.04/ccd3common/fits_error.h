#ifndef FITS_ERROR_H_
#define FITS_ERROR_H_

char* get_error_string(int code);

#endif /*FITS_ERROR_H_*/
