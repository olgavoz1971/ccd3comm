/*
 *  Copyright (c) 2006 Copenhagen University Astronomical Observatory
 *  All possible rights reserved
 *	Filename:	vt100.h	
 *  Abstract:	A very simple vt100 implementation
 *  Author:		Jeppe Jønch Andersen (jja@astro.ku.dk)
 *  Revision:
 *  Remarks:
 */
 
#ifndef _VT100_
#define _VT100_

#define ESC		0x1B
#define ESC_STR "\x1B"


const char* enable_ansi(bool mode, char* areturnnull = (char*)"");
const char* reset_terminal(void);
const char* clrscr(void);
const char* clrscrup(void);
const char* clrscrdown(void);
const char* clrline(void);
const char* clrlineleft(void);
const char* clrlineright(void);
const char* gotoxy(int x, int y);
const char* backspace(void);
const char* startofline(void);
//const char* cursorpos(void);
const char* cursorup(int n=1);
const char* cursordown(int n=1);
const char* cursorleft(int n=1);
const char* cursorright(int n=1);
const char* parse(const char* fmt, ...);

#endif

///////////////////////////////////////////////////////////////////////////////
// EOF
