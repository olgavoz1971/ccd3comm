#ifndef XPA_INTERFACE_H_
#define XPA_INTERFACE_H_

#include <xpa.h>
#include "common_exception.h"

#define MAX_XPA_IDENTIFIER 32
#define MAX_XPA_COMM_LEN   128

class xpa_interface
{
protected:
	XPA xpa;
	char id[MAX_XPA_IDENTIFIER]; 	
public:
	xpa_interface(const char* xpa_id = NULL);
	virtual ~xpa_interface();
	//void  set_id(const char* xpa_id);
	//void  set(const char* param, char* mode = NULL);
	int set(const char* fmt, ...);
	int get(char** buf, size_t size, const char* fmt,...);
	typedef common_exception xpa_exception;
};

#endif /*XPA_INTERFACE_H_*/
