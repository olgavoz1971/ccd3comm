/*
 *  Copyright (c) 2006 Copenhagen University Astronomical Observatory
 *  All possible rights reserved
 *	Filename:	
 *  Abstract:	
 *  Author:		Jeppe Jønch Andersen (jja@astro.ku.dk)
 *  Revision:
 *  Remarks:
 */
 
#ifndef __IPC_SHM__
#define __IPC_SHM__

#include <exception>
#include "ipc_shm_std.h"
#include "common_exception.h"

using namespace std;

class TIpc {
    protected:
    		h_sharedmem Handle;
    		int mem_size;
    public:
    	// Exception class
        class EIpc : public common_exception {
			public:
		        EIpc(char* Msg):common_exception(Msg){};
		        EIpc(void):common_exception(){};
		        EIpc(int err):common_exception(err){};
        };
        void* getmem(void);
        int   getid(void);
        int	  size(void){ return mem_size; };
        TIpc (int a_size, bool a_FailExists);
        virtual ~TIpc ();
};

#endif

///////////////////////////////////////////////////////////////////////////////
// EOF
