#ifndef CCD3_LOG_H_
#define CCD3_LOG_H_

#include <stdio.h>
#include <string.h>
#include <syslog.h>
#include <limits.h>
#include "common_exception.h"

typedef enum {
	ccAlways = 0,
	ccFatal  = 1,
	ccError  = 2,
	ccNormal = 3,
	ccDebug  = 4,
	ccDont   = 10,
} ccd3Verbosity;

const ccd3Verbosity DEFAULT_VERBOSITY = ccNormal;

ccd3Verbosity& operator++(ccd3Verbosity& d, int);

const char VERBOSITY_STRINGS[][7] = {
	"always",
	"fatal",
	"error",
	"normal",
	"debug",
};

#define MAKE_FLAG(print_verbosity, log_verbosity) (ccd3Verbosity)(print_verbosity | (log_verbosity << 8))
#define PRINT_LEVEL(LEVELS) (ccd3Verbosity)(LEVELS & 0xFF)
#define LOG_LEVEL(LEVELS) (ccd3Verbosity)(LEVELS >> 8)

#define L_ALWAYS MAKE_FLAG(ccAlways, ccAlways)
#define L_FATAL  MAKE_FLAG(ccFatal,  ccFatal)
#define L_ERROR  MAKE_FLAG(ccError,  ccError)
#define L_NORMAL MAKE_FLAG(ccNormal, ccNormal)
#define L_DEBUG  MAKE_FLAG(ccDebug,  ccDebug)
#define L_DBGNRM MAKE_FLAG(ccDebug,  ccNormal)


#define LOG cCCD3log::instance()
#define LOGMSG LOG->log
#define PRINT LOG->print


#define LOG_TIMEFORMAT "%b %d %H:%M:%S"

typedef enum {
	ltNOTSET = 0,
	ltFile,
	ltSyslog
} ccd3LogType;

typedef struct {
	char str_facility[32];
	unsigned int_facility;
} ccd3LogFacility;

const ccd3LogFacility LOG_FACILITIES[]={
	{"LOG_USER", LOG_USER},
	{"LOG_LOCAL1", LOG_LOCAL1},
	{"LOG_LOCAL2", LOG_LOCAL2},
	{"LOG_LOCAL3", LOG_LOCAL3},
	{"LOG_LOCAL4", LOG_LOCAL4},
	{"LOG_LOCAL5", LOG_LOCAL5},
	{"LOG_LOCAL6", LOG_LOCAL6},
	{"LOG_LOCAL7", LOG_LOCAL7}
};

const int LOG_FACILITY_CNT = 8;

class cCCD3log
{
protected:
	ccd3LogType LogType;
	char Filename[PATH_MAX];
	char debug_str[256];
	FILE* File;
	int Facility;
	int max_size;

	static cCCD3log* me;
    ccd3Verbosity print_verbosity;
    ccd3Verbosity log_verbosity;
    virtual bool set_verbosity(ccd3Verbosity new_verb, ccd3Verbosity* dst);
    virtual bool set_verbosity(char* new_verb, ccd3Verbosity* dst);
    virtual void check_filesize(void);
public:
	/* Name of file, including full path, if file logging are used	*/
	cCCD3log(const char* a_filename);
	
	/*	ident are prepended to all messages.
	 * 
	 * 	facility may be any of the posix defined:
	 * 		LOG_USER
	 * 		LOG_LOCAL0
	 * 		LOG_LOCAL1
	 * 		LOG_LOCAL2
	 * 		LOG_LOCAL3
	 * 		LOG_LOCAL4
	 * 		LOG_LOCAL5
	 * 		LOG_LOCAL6
	 * 		LOG_LOCAL7 
	 */
	cCCD3log(void);
	cCCD3log(const char* ident, int facility);
	cCCD3log(const char* ident, char* facility);
	virtual ~cCCD3log();

	/* Possible values of Severity includes
	 * 	LOG_EMERG	A panic condition
	 * 	LOG_ALERT	A condition that should be corrected immediately, such os a corrupted system database
	 * 	LOG_ERR		Errors
	 * 	LOG_WARNING	Warning messages
	 * 	LOG_NOTICE	Conditions that are not error conditions, but that may require special handling
	 * 	LOG_INFO	Informational messages
	 * 	LOG_DEBUG	Messages that contain information normally of use only when debugging a program
	 */
	static cCCD3log* instance(void);
	void set_max_filesize(int a_max_size){ max_size = a_max_size; };
	void insert_debug_str(const char* new_debug_str);
	void log(int Severity, const char* message, ...);
	void log(const char* message, ...);
    void print(ccd3Verbosity Levels, const char* Str, ...);
    bool set_print_verbosity(ccd3Verbosity new_verb);
    bool set_print_verbosity(char* new_verb);
    bool set_log_verbosity(ccd3Verbosity new_verb);
    bool set_log_verbosity(char* new_verb);
    ccd3Verbosity get_print_verbosity(void) { return print_verbosity; };
    ccd3Verbosity get_log_verbosity(void) { return log_verbosity; };
    bool set_verbosity(ccd3Verbosity new_verb) { return set_log_verbosity(new_verb) && set_print_verbosity(new_verb);};
	
	typedef common_exception ECCD3LOG;
};

#endif /*CCD3_LOG_H_*/
