//---------------------------------------------------------------------------

#ifndef inifilesH
#define inifilesH

#include <stdio.h>
#include "common_exception.h"


#define MAX_FILENAME_LENGTH FILENAME_MAX	/* max number of characters in a filename				*/
#define MAX_LINE_LENGTH 	255				/* max number of characters on a line in config file	*/
#define MAX_LINE_CNT 		1024			/* max 1024 lines in a config file						*/
#define MAX_KEY_LEN 		32				/* max length of key name 								*/
#define MAX_VAL_LEN			128				/* max length of value									*/

class TIniFile{
	typedef common_exception EIniFile; 
  private:
    char  FFileName[MAX_FILENAME_LENGTH];
    FILE* FFile;
  protected:
    int   FFileReferenceCount;
    bool  FCreate;
    FILE* GetFile(void);
    int   GetSection(char* Section);
    int   GetNextSection(char* Section);
    int   GetKey(const char* Section, const char* Key);
    void  DismissFile(void);
    char* Trim(char* Line);
    int   FileSize(void);
    int   FilePosition(void);
    int   GetLineNo(void);
    bool  Eof(void);
    void  SetFilePosition(int Position);
    void  EraseLines(int Start, int End);
    void  InsertLine(int Position, char* Data);
    void  GotoLine(int LineNo);    
  public:
    TIniFile(char* FileName, bool Create = false);
    virtual ~TIniFile(void);
    virtual void    EraseSection     (const char* Section);
    virtual int     SectionExists    (const char* Section);
    virtual void    ReadSections     (char** Strings);
    virtual void    ReadSectionKeys  (const char* Section, char Strings[][MAX_KEY_LEN]);
    virtual void    ReadSectionValues(const char* Section, char Strings[][MAX_VAL_LEN]);
    virtual void    DeleteKey        (const char* Section, const char* Ident);
    virtual bool    ValueExists      (const char* Section, const char* Ident);

    virtual char*   ReadString  (const char* Section, const char* Ident, const char* Default, char* ValStr);
    virtual bool    ReadBool    (const char* Section, const char* Ident, bool    Default);
    //virtual TTime48 ReadDateTime(const char* Section, const char* Ident, TTime48 Default);
    virtual double  ReadFloat   (const char* Section, const char* Ident, double  Default);
    virtual int     ReadInteger (const char* Section, const char* Ident, int     Default);

    virtual void    WriteString  (const char* Section, const char* Ident, char*   Value);
    virtual void    WriteBool    (const char* Section, const char* Ident, bool    Value);
    //virtual void    WriteDateTime(const char* Section, const char* Ident, TTime48 Value);
    virtual void    WriteFloat   (const char* Section, const char* Ident, double  Value);
    virtual void    WriteInteger (const char* Section, const char* Ident, int     Value);
};

//---------------------------------------------------------------------------
#endif
