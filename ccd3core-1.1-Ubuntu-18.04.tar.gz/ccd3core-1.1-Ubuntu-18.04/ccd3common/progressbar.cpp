#include <stdio.h>
#include <string.h>
#include "common.h"
#include "progressbar.h"

const char marker[] ="\\|/-";
const char marker_cnt = strlen(marker);

progressbar_class::progressbar_class(char* label)
{
	call_cnt = 0;
	last_progress = 0;
	text = label;
	sprintf(buf, "%-14s [%50s]   0%%", text, " ");
}

progressbar_class::~progressbar_class()
{
}

char* progressbar_class::get_text(int progress, bool active)
{
	int n;
	
	progress = progress < 100 ? progress : 100;

	for(n=0; n < progress >> 1; n++){
		progressbuf[n] = '=';
	}

	progressbuf[progress >> 1] = active ? marker[call_cnt++ % marker_cnt] : ' ';

	for(n=1 + (progress >> 1); n <= 50; n++){
		progressbuf[n] = ' ';
	}

	progressbuf[50] = NULL;

	sprintf(buf, "%-14s [%50s] %3d%%", text, progressbuf, progress);

	return buf;
}

void progressbar_class::clear(void){
	call_cnt = 0; 
	last_progress = 0; 
	sprintf(buf, "%-14s [%50s]   0%%", text, " ");
}
