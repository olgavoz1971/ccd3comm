//---------------------------------------------------------------------------

#include <string.h>
#include <errno.h>
#include "inifiles.h"


//---------------------------------------------------------------------------

TIniFile::TIniFile(char* FileName, bool Create)
{
	strcpy(FFileName, FileName);
	FFileReferenceCount = 0;
	FFile = NULL;
	FCreate = Create;
	GetFile();
}

//---------------------------------------------------------------------------

TIniFile::~TIniFile(void)
{
	DismissFile();
}

//---------------------------------------------------------------------------

FILE* TIniFile::GetFile(void)
{ 
	 
	if( !FFile ){
		
		FFile = fopen(FFileName, "r+");
		
		if( !FFile ){
			if( FCreate ){
				FFile = fopen(FFileName, "w+");  // File did not exists, creating a new
			}/* else {
				FFile = fopen("/dev/null", "r+"); // Open null file
			}*/
		}

		if( !FFile ){
			// Failed creating .ini file
			//perror("Failed opening config file");
			throw EIniFile("Failed opening configuration file: %s", FFileName);
		}
		
	}
  
	FFileReferenceCount++;
	return FFile;
}

//---------------------------------------------------------------------------

void TIniFile::DismissFile(void)
{
	if( !--FFileReferenceCount ){
		fclose(FFile);
		FFile = NULL;
	}
}

//---------------------------------------------------------------------------

char* TIniFile::Trim(char* Line)
{
	// Remove trailing spaces and nl's
	for(int n = strlen(Line)-1; Line[n] == ' ' || Line[n] == '\n'; Line[n--] = 0); 
  
	while(Line[0] == ' ')
		memmove(Line, &Line[1], strlen(Line));
  
	return Line;
}

//---------------------------------------------------------------------------

int TIniFile::FileSize(void)
{
	int Pos, Size;
	
	FILE* File = GetFile();
	fflush( File );
	Pos = FilePosition();
	fseek(File, 0, SEEK_END);
	Size = FilePosition();
	SetFilePosition(Pos);
	
	DismissFile();
	return Size;
}

//---------------------------------------------------------------------------

int TIniFile::FilePosition(void)
{
	FILE* File = GetFile();
	int pos = ftell(File);
	DismissFile();

	return pos;
}

//---------------------------------------------------------------------------

void TIniFile::SetFilePosition(int Position)
{
	FILE* File = GetFile();
	fseek(File, Position, SEEK_SET);
	DismissFile();
}

//---------------------------------------------------------------------------

void TIniFile::GotoLine(int LineNo)
{
	char Buf[MAX_LINE_LENGTH];
	//char* res;
	FILE* File = GetFile();

	SetFilePosition(0); // Goto start

	for(int n=0; n < LineNo; n++){
		/*res = */fgets(Buf, MAX_LINE_LENGTH, File);
	}
  
	DismissFile();
}

//---------------------------------------------------------------------------

bool TIniFile::Eof(void)
{  
	return FilePosition() >= FileSize();
}

//---------------------------------------------------------------------------

void TIniFile::EraseLines(int Start, int End)
{
	char* Lines[MAX_LINE_CNT];
	char  Buf[MAX_LINE_LENGTH];
	//char* res;
	int LineCnt = 0;
	FILE* File = GetFile();

	SetFilePosition(0);								// Move pointer to start

	for(LineCnt=0; !Eof(); LineCnt++){
		/*res = */fgets(Buf, MAX_LINE_LENGTH, File);			// Read a line into tmp buffer
		Lines[LineCnt] = new char[strlen(Buf)+1];		// Allocate memory for storage
		strcpy(Lines[LineCnt], Buf);				// Copy line from buffer to storage
	}

	fclose(File);									// Close file
	// suspected to reset file permissions ??
	//remove(FFileName);							// Delete file
	File = FFile = fopen(FFileName,"w+");			// Create new file

	for(int n=0; n < LineCnt;n++){
		if(n < Start || n > End)fputs(Lines[n], File);
		delete[] Lines[n];
		Lines[n] = NULL; 
	}

	DismissFile();

/*  char* Buf;
  size_t Size;
  FILE* File = GetFile();
  SetFilePosition(0);                    // Move pointer to start
  Buf = new char[FileSize()+1];
  Size = fread(Buf,1,FileSize(),File);   // Read entire file into buffer
  Buf[Size] = 0;
  fclose(File);	      			 // Close file
  remove(FFileName);  			 // Delete file
  File = FFile = fopen(FFileName,"wt+"); // Create new file
  fwrite(Buf,1,Start,File);
  fwrite(&Buf[End],1,Size-End,File);
  delete[] Buf;
  fflush(File);
  SetFilePosition(Start);
  DismissFile();*/
}

//---------------------------------------------------------------------------

void TIniFile::InsertLine(int Position, char* Line)
{
	char* Buf;
	size_t Size = FileSize();
	FILE* File = GetFile();

	Position = Position < 0 ? FilePosition() : Position; // If no position is given, we insert at current

	SetFilePosition(0);						// Go to start of file
	Size = FileSize();
	Buf = new char[Size+1];					// Allocate buffer memory
	Size = fread(Buf, 1, Size, File);		// Read entire file into buffer
	Buf[Size] = 0;
	fclose(File);							// Close and delete file
	remove(FFileName);
	File = FFile = fopen(FFileName,"w+");	// Create new empty file
	fwrite(Buf, 1, Position, File);			// Write original file content up to Postion
	fputs(Line, File);						// Write new data to file
	fputs("\n", File);						// 
	fwrite(&Buf[Position], 1, strlen(Buf) - Position, File); // Write remaining original data to file
	SetFilePosition(Position + strlen(Line)+1);
  
	delete[] Buf;							// delete buffer memory
	fflush(File);
	DismissFile();
}

//---------------------------------------------------------------------------

void TIniFile::EraseSection(const char* Section)
{
	char Dummy[MAX_LINE_LENGTH];
	int StartLn,EndLn;
	StartLn = GetSection((char*)Section);
	if(StartLn >= 0){ // Section exists
		EndLn = GetNextSection(Dummy)-1; // End = start of next section, area between start and end should be deleted
		EraseLines(StartLn, EndLn);
	}
}

//---------------------------------------------------------------------------

int TIniFile::GetLineNo(void)
{
	FILE* File = GetFile();

	int LineCnt = 0;
	int StartPos = FilePosition();
	GotoLine(0);

	for(int n=0; n < StartPos; n++){
		if(fgetc(File) == '\n')
			LineCnt++;
	}

	DismissFile();
	return LineCnt;
}

//---------------------------------------------------------------------------

int TIniFile::GetNextSection(char * Section){
	char Buf[MAX_LINE_LENGTH] = "\0";
	//char *res;
	int  LineCnt;
	FILE* File = GetFile();
  
	for(LineCnt = GetLineNo(); !Eof() && sscanf(Buf, "[%s",Section) != 1; LineCnt++){
		//ConfigFileGetLine(File, Buf);
		/*res = */fgets(Buf, MAX_LINE_LENGTH, File);
	}
  
	if(!Eof())
		Section[strlen(Section)] = 0; // Remove trailing ']' character
	
	DismissFile();

	return Eof() ? -1 : LineCnt;
}

//---------------------------------------------------------------------------

int TIniFile::GetSection(char* Section)
{
	int LineCnt;
	FILE* File = GetFile();

	char Line[MAX_LINE_LENGTH] = "\0";
	char NextSection[MAX_LINE_LENGTH] = "\0";
	
	SetFilePosition(0);
  
	for(LineCnt=0; !Eof() && strcasecmp(Section, NextSection); LineCnt++){
		
		if( fgets(Line, MAX_LINE_LENGTH, File) ){
			if(sscanf(Line, "[%s",NextSection) == 1){ // If a section was found
				NextSection[strlen(NextSection)-1] = 0;    // Remove trailing ']' character
			}
		}
	}

	DismissFile();
	return strcasecmp(Section, NextSection) ? -1 : LineCnt;
}

//---------------------------------------------------------------------------

int TIniFile::GetKey(const char* Section, const char* Key)
{
	char  Line  [MAX_LINE_LENGTH];
	char  KeyStr[MAX_LINE_LENGTH];
//  char  ValStr[MAX_LINE_LENGTH];
	bool  KeyFound = false, SectionFound=false;
	char* Delimiter;
	//char* res;
	int   LineCnt;
	FILE* File = GetFile();

	LineCnt = GetSection((char*)Section);
	GotoLine(LineCnt); // Start at top of section

	while( LineCnt >= 0 && !KeyFound && !SectionFound && !Eof() )
	{
		/*res =*/ fgets(Line, MAX_LINE_LENGTH, File);
		LineCnt ++;
		if((Delimiter = strchr(Line,'=')) != NULL){
			Delimiter[0] = 0;
			Delimiter++;
			strcpy(KeyStr,Trim(Line));
			//strcpy(ValStr,Trim(Delimiter));
			if( !strcasecmp(KeyStr, Key) ){
				KeyFound = true; // Key is found
				LineCnt--;
			}
	  
		} else if (Line[0]=='[') {      
			SectionFound = true; // Next section found
		} else {
      		// Error
		}
	}
  
	DismissFile();
	return KeyFound ? LineCnt : -1;
}

//---------------------------------------------------------------------------

int TIniFile::SectionExists(const char* Section)
{
	return GetSection((char*)Section) >= 0;
}

//---------------------------------------------------------------------------

void TIniFile::ReadSections(char** Strings)
{
	int n;
	SetFilePosition(0);
	for(n=0; GetNextSection(Strings[n++]) >= 0;);
	strcpy(Strings[n], "");

}

//---------------------------------------------------------------------------

void TIniFile::ReadSectionKeys(const char* Section, char Strings[][MAX_KEY_LEN])
{
  char Line  [MAX_LINE_LENGTH]="";
  char KeyStr[MAX_LINE_LENGTH];
  char * Comment;
  FILE* File = GetFile();
  int n;
  bool NextSectionFound=false;
  // Empty Strings

  if(!SectionExists(Section))
	  return;

  for(n=0; !feof(File) && !NextSectionFound;){

	if(fgets(Line, MAX_LINE_LENGTH, File)){
		NextSectionFound = (Line[0] == '[');

		Comment = strstr(Line, "//");
		if( Comment )
			*Comment = '\0';

		if(!NextSectionFound && sscanf(Line, "%s =", KeyStr) >= 1){
			strcpy(Strings[n++],KeyStr);
		}
	}
  }
  strcpy(Strings[n], "");
  DismissFile();
}

//---------------------------------------------------------------------------

void TIniFile::ReadSectionValues(const char* Section, char Strings[][MAX_VAL_LEN])
{
	  char Line  [MAX_LINE_LENGTH]="";
	  char KeyStr[MAX_LINE_LENGTH];
	  char ValStr[MAX_LINE_LENGTH];
	  int n;
	  char * Comment;
	  FILE* File = GetFile();
	  bool NextSectionFound=false;
	  // Empty Strings
	  for(n=0; strlen(Strings[n]) ; strcpy(Strings[n++],"") );

	  if(!SectionExists(Section))
		  return;

	  for(n=0;!feof(File) && !NextSectionFound;){

		if(fgets(Line, MAX_LINE_LENGTH, File)){
			NextSectionFound = (Line[0] == '[');

			Comment = strstr(Line, "//");
			if( Comment )
				*Comment = '\0';//NULL;

			if(!NextSectionFound && sscanf(Line, "%s = %s", KeyStr, ValStr) == 2){
				strcpy(Strings[n], strstr(Line, ValStr));
				// Remove trailing \n characters
				while(Strings[n][strlen(Strings[n])-1] == '\n'){
					Strings[n][strlen(Strings[n])-1] = '\0';//NULL;
				}
				n++;
			}
		}
	  }
	  strcpy(Strings[n], "");
	  DismissFile();
}

//---------------------------------------------------------------------------

void TIniFile::DeleteKey(const char* Section, const char* Ident)
{
	int KeyLine;
	GetFile();
	KeyLine = GetKey(Section, Ident);
  
	if(KeyLine >= 0) 
		EraseLines(KeyLine, KeyLine);
  	
	DismissFile();
}

//---------------------------------------------------------------------------

bool TIniFile::ValueExists(const char* Section, const char* Ident)
{
	return GetKey(Section, Ident) != -1;
}

//---------------------------------------------------------------------------

char* TIniFile::ReadString(const char* Section, const char* Ident, const char* Default, char* ValStr)
{
	char  Line  [MAX_LINE_LENGTH];
	//char  KeyStr[MAX_LINE_LENGTH];
	char  buf[255];
	char  default_buf[255];
	char* Delimiter;
	char* Comment;
	int   LineNo;
  
	FILE* File = GetFile();

	// Introduced temp "default" buffer to make valgrind and strcpy() happy
	// when, ValStr and Default are the same

	strcpy(default_buf, Default);

	if((LineNo = GetKey(Section, Ident)) != -1){
  
		GotoLine(LineNo);
  
		if( fgets(Line, MAX_LINE_LENGTH, File) != 0 ){
			if((Delimiter = strchr(Line,'=')) != NULL){
				strcpy(ValStr, Trim(++Delimiter));
				Comment = strstr(ValStr, "//");
				if( Comment ){
					*Comment = '\0';
				}
			} else {
				sprintf(buf,"Invalid line, failed to read \"%s\" from section \"%s\", returning default value = \"%s\"", Ident, Section, Default);
				// TBD do something to buf
				strcpy(ValStr, default_buf);
			}
		} else {
			sprintf(buf,"Failed to read line, failed to read \"%s\" from section \"%s\", returning default value = \"%s\"",Ident,Section,Default);
			// TBD do something to buf
			strcpy(ValStr, default_buf);
		}
	} else {
		sprintf(buf, "Key not found, failed to read \"%s\" from section \"%s\", returning default value = \"%s\"",Ident,Section,Default);
		// TBD do something to buf
		strcpy(ValStr, default_buf);
	}

	DismissFile();
	return ValStr;
}

//---------------------------------------------------------------------------

bool TIniFile::ReadBool(const char* Section, const char* Ident, bool Default)
{
	char Val[MAX_LINE_LENGTH];
	
	ReadString(Section, Ident, Default ? "1" : "0", Val);
	
	if( !strcmp(Val, "0") )
		return false;
	if( !strcmp(Val, "1") )
		return true;
	if( !strcasecmp(Val, "false") )
		return false;
	if( !strcasecmp(Val, "true") )
		return true;
	if( !strcasecmp(Val, "yes") )
		return true;
	if( !strcasecmp(Val, "no") )
		return false;
	if( !strcasecmp(Val, "on") )
		return true;
	if( !strcasecmp(Val, "off") )
		return false;
	
	return Default;
}

//---------------------------------------------------------------------------

/*TTime48 TIniFile::ReadDateTime(const char* Section, const char* Ident, TTime48 Default)
{
  double Tmp;
  Tmp = ReadFloat(Section,Ident,TTime482Secs(Default));
  return Secs2TTime48(Tmp);
}*/

//---------------------------------------------------------------------------

double TIniFile::ReadFloat(const char* Section, const char* Ident, double Default)
{
	char Tmp[MAX_LINE_LENGTH];
	double Val;
  
	ReadString(Section, Ident, "", Tmp);
  
	if(sscanf(Tmp,"%lf",&Val) != 1) 
		return Default;
  	
	return Val;
}

//---------------------------------------------------------------------------

int TIniFile::ReadInteger(const char* Section, const char* Ident, int Default)
{
	char Tmp[MAX_LINE_LENGTH];
	int Val;
  
	ReadString(Section, Ident, "", Tmp);
  
	if( !strncasecmp(Tmp, "0x", 2) ){
		if( sscanf(Tmp, "%X", &Val) != 1 )
			return Default;
	} else if( sscanf(Tmp, "%d", &Val) != 1 )
		return Default;
  
	return Val;
}

//---------------------------------------------------------------------------

void TIniFile::WriteString(const char* Section, const char* Ident, char* Value)
{
	char Buf[MAX_LINE_LENGTH];
	GetFile();
  
	if(GetKey(Section, Ident) == -1){ // String does not exists
    
		if(GetSection((char*)Section) == -1){ // Section does not exists
			sprintf(Buf,"%s%s%s", "[", Section, "]");
			InsertLine(FileSize(), Buf);
		}
    
	} else { // String exists an file pointer is positioned just before the actual line
		DeleteKey(Section, Ident);  // Delete key line
	}
  
	sprintf(Buf,"%s = %s", Ident, Value);
	InsertLine(-1, Buf);
	DismissFile();
} 

//---------------------------------------------------------------------------

void TIniFile::WriteBool(const char* Section, const char* Ident, bool Value)
{
	WriteString(Section, Ident, Value ? (char*)"True" : (char*)"False");
}

//---------------------------------------------------------------------------

/*void TIniFile::WriteDateTime(const char* Section, const char* Ident, TTime48 Value)
{  
  WriteFloat(Section,Ident,TTime482Secs(Value));
}*/

//---------------------------------------------------------------------------

void TIniFile::WriteFloat(const char* Section, const char* Ident, double Value)
{
	char Tmp[MAX_LINE_LENGTH];
	sprintf(Tmp,"%lf", Value);
	WriteString(Section, Ident, Tmp);
}

//---------------------------------------------------------------------------

void TIniFile::WriteInteger(const char* Section, const char* Ident, int Value)
{
	char Tmp[MAX_LINE_LENGTH];
	 sprintf(Tmp, "%d", Value);
	WriteString(Section, Ident, Tmp);
}

//---------------------------------------------------------------------------
