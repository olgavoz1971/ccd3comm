#ifndef CCD3_IVY_H_
#define CCD3_IVY_H_

//#include <Ivy/ivysocket.h>
#include <pthread.h>
#include <stdarg.h>
#include <Ivy/ivy.h>
#include <Ivy/ivyloop.h>
#include <stddef.h>

#define IVY_MSG_SIZE 256

// ivy encapsulation class
class cCCD3ivy
{
protected:
	char bus[256];
	char my_name[256];
	char startmsg[256];
	void* user_data;
	pthread_t thread;
	IvyApplicationCallback app_callback;
	IvyDieCallback die_callback;
	virtual void SendAnonymous(const char* fmt, ...);
public:
	cCCD3ivy(char* aname, char* abus, IvyApplicationCallback a_app_callback = NULL, IvyDieCallback a_die_callback = NULL, void* a_user_data = NULL);
	virtual ~cCCD3ivy();
	virtual MsgRcvPtr Subscribe(MsgCallback cb, void* data, const char* msg, ...);
	virtual void Unsubscribe(MsgRcvPtr id);
	virtual void Send(const char* fmt, ...);
	virtual bool Run(char* ivy_start_msg);
	virtual void Stop(void);
	virtual char* Name(void){ return my_name; };
};

#endif /*CCD3_IVY_H_*/
