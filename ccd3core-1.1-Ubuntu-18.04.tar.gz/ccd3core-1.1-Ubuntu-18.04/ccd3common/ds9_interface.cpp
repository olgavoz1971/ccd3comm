/*
 * ds9_interface.cpp
 *
 *  Created on: Apr 12, 2011
 *      Author: root
 */

#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
#include <ccd3_log.h>
#include "ds9_interface.h"

#define DS9_WAITTIME 200		/* 200 ms	*/
#define MAX_DS9_WAITTIME 4000	/* 4000 ms	*/

///////////////////////////////////////////////////////////////////////////////
//
ds9_comm::ds9_comm(bool a_remote){
	char* tmp;
	char* res[2];
	int Result;
	pid_t pid = 0;

	remote = a_remote;

	if( setenv("XPA_METHOD", "local", 1) ){
		throw e_ds9_comm("Failed setting environement for process");
	}

	my_xpa = new xpa_interface("ds9");

	if( !remote ){
		// Wait for DS9
		for(int n=0; !(Result = xpa()->get(res, 2, "version")); n++){
			if( !pid && n >= 2 ){
				// no ds9 found, launching new

				if ((pid = fork()) == 0) {
					execl("/bin/sh", "sh", "-c", "ds9 -xpa", (char *)0);
					_exit(127);
				} else if( pid == -1 ){
					PRINT(L_ERROR, "Failed starting DS9\n");
					throw e_ds9_comm("Failed starting DS9");
				}
				n=0;
			}

			if( n > (MAX_DS9_WAITTIME/DS9_WAITTIME) ){
				if( remote ){
					throw e_ds9_comm("Communication could not be established with remote DS9!");
				} else {
					throw e_ds9_comm("DS9 was launched, but no communication could be established!");
				}
			}
			usleep(DS9_WAITTIME * 1000);
		}
		tmp = strchr(res[Result-1], '\n');
		*tmp++ = 0;
		PRINT(L_DEBUG, "Communication established with %s\n", res[Result-1]);
		free(res[0]);
	}
}

///////////////////////////////////////////////////////////////////////////////
//
ds9_comm::~ds9_comm(void){

	if( !remote ){
		xpa()->set("exit");
	}

	delete my_xpa;
	my_xpa = NULL;
}

///////////////////////////////////////////////////////////////////////////////
unsigned long ds9_comm::Examine(unsigned long* matrice, int width, int height)
{
	unsigned long pos;

	pos = GetData(matrice, width, height);

	return pos;
}

///////////////////////////////////////////////////////////////////////////////
//
unsigned long ds9_comm::GetData(unsigned long* buf, int width, int height)
{
	unsigned long pos;

	pos = GetPos();
	GetDataAtPos(buf, pos >> 16, pos & 0xFFFF, width, height);

	return pos;
}

///////////////////////////////////////////////////////////////////////////////
//
#define SIZE_OF_32BIT_NUMBER_STRING 10
unsigned long* ds9_comm::GetDataAtPos(unsigned long* buf, int x_center, int y_center, int xwidth, int yheight)
{

	char* tmp;
	char* ptr;

	tmp = new char[xwidth * yheight * (SIZE_OF_32BIT_NUMBER_STRING  + 2)];
	ptr = GetStrAtPos(tmp, x_center, y_center, xwidth, yheight);

	for(int n=0; n < xwidth * yheight; n++){
		if( 1 != sscanf(ptr, "%lu", &buf[n])){
			PRINT(L_ERROR, "Failed parsing DS9 data: %s\n", ptr);
			return NULL;
		}
		ptr = strstr(ptr, "\n") + 1;
	}
	*ptr = '\0';
	PRINT(L_NORMAL, "DS9 str = \n%s\n", tmp);
	delete[] tmp;

	return buf;
}

///////////////////////////////////////////////////////////////////////////////
#define MAX_DS9_HEIGHT 55
#define MAX_DS9_WIDTH  55

unsigned long  ds9_comm::GetPos(void){
	char cmd_buf[256];
	char *buf;
	float tmp_x, tmp_y;
	int int_x, int_y;
	unsigned long pos;

	sprintf(cmd_buf, "imexam coordinate image");
	PRINT(L_NORMAL, "Use the mouse to select the center of the area of interest\n");
	xpa()->get(&buf, 1, cmd_buf);

	if(2 != sscanf(buf, "%f %f", &tmp_x, &tmp_y)){
		PRINT(L_ERROR, "Unknown data returned from ds9 (%s)?\n", buf);
	}

	free(buf);

	int_x = tmp_x;
	int_y = tmp_y;
	pos = (int_x << 16) | int_y;
	return pos;
}

char* ds9_comm::GetStr(char* buf, int width, int height)
{
	unsigned long res;

	if(width > MAX_DS9_WIDTH || height > MAX_DS9_HEIGHT){
		PRINT(L_ERROR, "Maximum size of area is %d,%d\n", MAX_DS9_WIDTH, MAX_DS9_HEIGHT);
		return NULL;
	}

	res = GetPos();

	return GetStrAtPos(buf, res >> 16, 0xFFFF & res, width, height);
}

///////////////////////////////////////////////////////////////////////////////

char* ds9_comm::GetStrAtPos(char* buf, int x, int y, int width, int height)
{
	char cmd_buf[256];
	char *xpa_buf;

	sprintf(cmd_buf, "data physical %d %d %d %d yes", x, y, width, height);
	xpa()->get(&xpa_buf, 1, cmd_buf);

	strcpy(buf, xpa_buf);

	free(xpa_buf);

	return buf;
}

///////////////////////////////////////////////////////////////////////////////
// EOF

