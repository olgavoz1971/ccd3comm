/*
 * cFilo.cpp
 *
 *  Created on: Feb 23, 2010
 *      Author: jja
 */

#include "filo.h"

cFilo::cFilo(int spc, int esz) :cFifo(spc, esz) {
	// TODO Auto-generated constructor stub

}

cFilo::~cFilo() {
}

void* cFilo::get(void* userbuf, int cnt)
{
	BYTE* dst = (BYTE*)userbuf;

	if(cnt > size()) throw eFifo("Queue underflow");

	for(int n=0; n < cnt; n++){
		if( dst ){
			write = write ? write -1 : space-1;
			memcpy(&dst[element_size * n], &buf[element_size * write], element_size);
		}
		memset(&buf[element_size * write], 0, element_size);
	}

	return dst;
}

// Get cnt elements starting from offset in queue, without removal
void* cFilo::peek(void* data, int cnt, int offset)
{
	int tmp_write = write;
	BYTE* dst = (BYTE*)data;

	if(cnt > size()) throw eFifo("Queue underflow");

	for(int n=0; n < cnt; n++){
		if( dst ){
			tmp_write = tmp_write ? tmp_write -1 : space-1;
			memcpy(&dst[element_size * n], &buf[element_size * tmp_write], element_size);
		}
	}
	return dst;
}
