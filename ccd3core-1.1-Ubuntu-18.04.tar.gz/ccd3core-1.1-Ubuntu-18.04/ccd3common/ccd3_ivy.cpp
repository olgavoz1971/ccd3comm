#include "ccd3_ivy.h"
#include <stdio.h>
#include <string.h>
#include <Ivy/ivychannel.h>
#include <pthread.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <netdb.h>
#include <common_exception.h>
#include <Ivy/timer.h>

using namespace std;

void* ivy_thread(cCCD3ivy* parent);

cCCD3ivy::cCCD3ivy(char* a_name, char* a_bus, IvyApplicationCallback a_app_callback, IvyDieCallback a_die_callback, void* a_user_data)
{
	strcpy(my_name, a_name);
	app_callback = a_app_callback;
	die_callback = a_die_callback;
	user_data = a_user_data;

	if( a_bus ) {
		strcpy(bus, a_bus);
	} else {
		// use local net broadcast
		strcpy(bus, "255.255.255.255");
	}
			
}

cCCD3ivy::~cCCD3ivy()
{
	Stop();
}

void cCCD3ivy::SendAnonymous(const char* fmt, ...)
{
	char tmp[IVY_MSG_SIZE];
	va_list arg;

	va_start (arg, fmt);
	vsprintf (tmp, fmt, arg);
	va_end (arg);

	try {
		//printf("Sending ivy msg = \"%s\"\n", tmp);
		IvySendMsg("%s", tmp);
	}catch( ... ){
		printf("\n*** error sending ivy message ***\n\n");
	}
}

void cCCD3ivy::Send(const char* fmt, ...)
{
	char tmp[IVY_MSG_SIZE];
	va_list arg;
	
	va_start (arg, fmt);
	vsprintf (tmp, fmt, arg);
	va_end (arg);
	
	SendAnonymous("%s%s%s", my_name, ".", tmp);
}

MsgRcvPtr cCCD3ivy::Subscribe(MsgCallback cb, void* data, const char* msg, ...)
{
	char tmp[IVY_MSG_SIZE];
	va_list arg;

	va_start(arg, msg);
	vsprintf(tmp, msg, arg);
	va_end(arg);
	return IvyBindMsg(cb, data, "%s", tmp);
}

void cCCD3ivy::Unsubscribe(MsgRcvPtr id)
{
	IvyUnbindMsg(id);
}

bool cCCD3ivy::Run(char* ivy_start_msg)
{
	sprintf(startmsg, "%s.%s", my_name, ivy_start_msg);
	
	IvyInit(my_name, startmsg, app_callback, user_data, die_callback, user_data);

	IvyStart(bus);

	if( pthread_create(&thread, NULL, (void*(*)(void*))ivy_thread, this) ){
		printf("Failed to create ivy thread\n");
		return false;
	}

	return true;
}

void IvyTimeout(TimerId id, void *data, unsigned long delta){
	// Dummy function.. needed to make ivy shutdown without waiting for external events
	//printf("IvyTimer()\n");
}

void cCCD3ivy::Stop(void)
{
	IvyStop();
	pthread_join(thread, NULL);
}

void* ivy_thread(cCCD3ivy* parent)
{
	try {
		TimerRepeatAfter(TIMER_LOOP, 200, IvyTimeout, parent);
		IvyMainLoop();
	} catch (common_exception &e){
		printf("\n*** FATAL common error in ivy thread (%s) ***\n\n", e.what());
	} catch(exception &e){
		printf("\n*** FATAL error in ivy thread (%s) ***\n\n", e.what());
	} catch( ... ){
		printf("\n*** FATAL error in ivy thread ***\n\n");
	}
	return NULL;
}
