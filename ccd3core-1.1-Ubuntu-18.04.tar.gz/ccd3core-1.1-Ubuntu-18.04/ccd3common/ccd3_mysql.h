#ifndef CCD3_MYSQL_H_
#define CCD3_MYSQL_H_

#include <mysql/mysql.h>
#include <stdio.h>
#include "common.h"

typedef common_exception EMYSQL;

class cCCD3mysql
{
protected:
	MYSQL* conn;
	MYSQL_RES *res;
	MYSQL_ROW row;
public:
	cCCD3mysql(char* database, char* user=NULL, char* password=NULL, char* server=NULL);
	//cCCD3mysql(char* database, char* user, char* password);
	void query(const char* sql_str,...);
	int get_result(void);
	int get_affected(void);
	void close_result(void);
	char** get_row(void);
	int get_row_cnt(void);
	int get_field_cnt(void);
	const char* errorstr(void);
	virtual ~cCCD3mysql();
};

#endif /*CCD3_MYSQL_H_*/
