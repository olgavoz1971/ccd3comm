/*
 *  Copyright (c) 2006 Copenhagen University Astronomical Observatory
 *  All possible rights reserved
 *	Filename:	vt100.cpp
 *  Abstract:	A very simple vt100 implementation
 *  Author:		Jeppe Jønch Andersen (jja@astro.ku.dk)
 *  Revision:
 *  Remarks:	Only functions which was currently needed, has been implemented
 */
 
 
#include <stdio.h>
#include <stdarg.h>
#include "vt100.h"

static bool AnsiEnable = false;
static char* returnnull = NULL; 

///////////////////////////////////////////////////////////////////////////////
// Disable/Enable ansi codes. If codes are disabled either a NULL pointer
// or a zero length string is returned, depending on the value of areturnnull
const char* enable_ansi(bool mode, char* areturnnull){
	AnsiEnable = mode;
	returnnull = areturnnull;
	if( AnsiEnable ){
		return reset_terminal();
	}
	return returnnull ? NULL : "";
}

///////////////////////////////////////////////////////////////////////////////
// Reset terminal state
const char* reset_terminal(void){
	//return AnsiEnable ? ESC"c" : returnnull ? NULL : "";
	return "";
}

///////////////////////////////////////////////////////////////////////////////
// Return cursor position
const char* cursorpos(void) { 
	return AnsiEnable ? ESC_STR"[6n" : returnnull ? NULL : ""; 
}

///////////////////////////////////////////////////////////////////////////////
// Clear the console
const char* clrscr(void) { 
	return AnsiEnable ? ESC_STR"[2J" : returnnull ? NULL : ""; 
}

///////////////////////////////////////////////////////////////////////////////
// Clear the console from cursor and up
const char* clrscrup(void) { 
	return AnsiEnable ? ESC_STR"[1J" : returnnull ? NULL : "";
}

///////////////////////////////////////////////////////////////////////////////
// Clear the console from cursor and down
const char* clrscrdown(void) { 
	return AnsiEnable ? ESC_STR"[0J" :  returnnull ? NULL : "";
}

///////////////////////////////////////////////////////////////////////////////
// Clear current line
const char* clrline(void) {
	return AnsiEnable ? ESC_STR"[2K" :  returnnull ? NULL : "";
}

///////////////////////////////////////////////////////////////////////////////
// Clear the line from cursor to the left
const char* clrlineleft(void) {
	return AnsiEnable ? ESC_STR"[1K" :  returnnull ? NULL : ""; 
}

///////////////////////////////////////////////////////////////////////////////
// Clear the line from cursor to the right
const char* clrlineright(void) {
	return AnsiEnable ? ESC_STR"[0K" :  returnnull ? NULL : "";
}

///////////////////////////////////////////////////////////////////////////////
// Move cursor to position x,y
const char* gotoxy(int x, int y) { 
	return AnsiEnable ? parse(ESC_STR"[%d;%dH",x,y) :  returnnull ? NULL : "";	
}

///////////////////////////////////////////////////////////////////////////////
// Clear previous character
const char* backspace(void) { 
	return cursorleft(1);//AnsiEnable ? ESC_STR"[D" :  returnnull ? NULL : "";
}

///////////////////////////////////////////////////////////////////////////////
// 
const char* startofline(void) { 
	//return AnsiEnable ? ESC_STR"[1K" :  returnnull ? NULL : "";
	return cursorleft(80);
}

///////////////////////////////////////////////////////////////////////////////
// Move the cursor n lines up, n defaults to 1
const char* cursorup(int n) { 
	return AnsiEnable ? parse(ESC_STR"[%dA",n) :  returnnull ? NULL : "";
}

///////////////////////////////////////////////////////////////////////////////
// Move the cursor n lines down, d default to 1
const char* cursordown(int n) { 
	return AnsiEnable ? parse(ESC_STR"[%dB",n) :  returnnull ? NULL : "";
}

///////////////////////////////////////////////////////////////////////////////
// Move the cursor n positions to the right, n defaults to 1
const char* cursorright(int n)
{
	return AnsiEnable ? parse(ESC_STR"[%dC",n) :  returnnull ? NULL : "";
}

///////////////////////////////////////////////////////////////////////////////
// Move the cursor n positions to the left, n defaults to 1
const char* cursorleft(int n)
{
	return AnsiEnable ? parse(ESC_STR"[%dD",n) :  returnnull ? NULL : "";
}

///////////////////////////////////////////////////////////////////////////////
// return a parsed string specified by fmt and args
// see printf()
const char* parse(const char* fmt, ...){
	static char tmp[256];
	va_list arg;	
	va_start (arg, fmt);
	vsprintf (tmp, fmt, arg);
	va_end (arg);
	
	return (const char*)tmp;
}

///////////////////////////////////////////////////////////////////////////////
// EOF
