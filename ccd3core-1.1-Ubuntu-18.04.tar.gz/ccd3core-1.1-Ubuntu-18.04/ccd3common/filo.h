/*
 * cFilo.h
 *
 *  Created on: Feb 23, 2010
 *      Author: jja
 */

#ifndef CFILO_H_
#define CFILO_H_

#include "fifo.h"

class cFilo: public cFifo {
public:
	cFilo(int spc, int esz = 1);
	virtual ~cFilo();
	void* get(void* data, int cnt=1);
	// Get cnt elements starting from offset in queue, without removal
	void* peek(void* data, int cnt=1, int offset=0);
};

#endif /* CFILO_H_ */
