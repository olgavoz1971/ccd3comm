#include "xpa_interface.h"
#include <stdarg.h>
#include <string.h>

xpa_interface::xpa_interface(const char* xpa_id)
{
	xpa = XPAOpen(NULL);
	
	if( !xpa )
		throw xpa_exception("Could not open XPA");
		
	if( xpa_id )
		strcpy(id, xpa_id);
		
}

xpa_interface::~xpa_interface()
{
	XPAClose(xpa);
}

/*void  xpa_interface::set_id(const char* xpa_id)
{
	strcpy(id, xpa_id);
}*/

int xpa_interface::set(const char* fmt, ...)
{
	char buf[MAX_XPA_COMM_LEN];
	int ret = 0;
	va_list arg;
	va_start (arg, fmt);
	vsprintf(buf, fmt, arg);
	va_end (arg);
	
	ret = XPASet(xpa, id, buf, (char*)"ack = false", NULL, 0, NULL, NULL, 1);
	return ret;
}

int xpa_interface::get(char** buf, size_t size, const char* fmt,...)
{
	char tmp[MAX_XPA_COMM_LEN];
	int ret;
	va_list arg;
	va_start (arg, fmt);
	vsprintf(tmp, fmt, arg);
	va_end (arg);
	
	ret = XPAGet(xpa, id, tmp, NULL, buf, &size, NULL, NULL, 1);
	 
	return ret; 
}


