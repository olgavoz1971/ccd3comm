/*
 *  Copyright (c) 2006 Copenhagen University Astronomical Observatory
 *  All possible rights reserved
 *	Filename:	
 *  Abstract:	
 *  Author:		Jeppe Jønch Andersen (jja@astro.ku.dk)
 *  Revision:
 *  Remarks:
 */
 
#ifndef COMMON_H_
#define COMMON_H_

#include "common_exception.h"

#define FOREVER 1

typedef unsigned int UINT32;
typedef unsigned short UINT16;
typedef int	INT32;
typedef short INT16;
typedef UINT16 WORD;
typedef unsigned char BYTE;

#ifndef BOOL
	typedef bool BOOL;
#endif

bool file_exists(const char* filename);
bool file_exists(const char* path, const char* filename);
char* getlasterr_str(void);
char* find_configfile(char* filename, int argc, char** argv, char* prefix);

#define MAX_PATH 			256		/* maximum length of a complete path 	*/
#define IS_ASCII(x) (x >= 0x9 && x < 0x7E )

#ifdef min
    #undef min
#endif

#define min(x,y) (x < y ? x : y)

#ifdef max
    #undef max
#endif

#define max(x,y) (x > y ? x : y)

#endif /*COMMON_H_*/

///////////////////////////////////////////////////////////////////////////////
// EOF
