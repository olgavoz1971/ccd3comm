/*
 *  Copyright (c) 2006 Copenhagen University Astronomical Observatory
 *	Filename:	cFifo.h 
 *  Abstract:	A simple untyped fifo class
 *  Author:		Jeppe Jønch Andersen (jja@astro.ku.dk)
 *  Revision:
 * 
 * 
 */

#ifndef CFIFO_H_
#define CFIFO_H_

///////////////////////////////////////////////////////////////////////////////

#include <string.h>
#include "common.h"

#define ERROR_TEXT_LENGTH 256

class cFifo
{
	protected:
		BYTE* buf;			/* Allocated buffer space 			*/
		int space;			/* size of allocated space in queue */
		int read;			/* read pointer						*/
		int write;			/* write pointer						*/
		int element_size;
	public:
		// esz = size of an element, spc = size of fifo in terms of elements
		cFifo(int spc, int esz = 1);
		virtual ~cFifo();
		int   get_element_size(void){return element_size;};
		int   put(void* data, int cnt=1);
		//void* allocate_next(void);
		void* get(void* data, int cnt=1);
		// Get cnt elements starting from offset in queue, without removal
		void* peek(void* data, int cnt=1, int offset=0);
		// Get the position in the queue of the value pointed to by data
		// returns -1 if element is not found
		int   indexof(void* data);
		// Returns entire unfragmented buffer
		void* getbuf(void* cbuf);
		int   size(void);
		int   free(void);
		void  clear(void){read=write=0; memset(buf, 0, space * element_size);};
		//bool  isroom(void){return !size();};
		bool  isfull(void){return (size()) >= (space-1);};

		// Exception class
		typedef common_exception eFifo;

};

#endif /*CFIFO_H_*/

///////////////////////////////////////////////////////////////////////////////
// EOF
