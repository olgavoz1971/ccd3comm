/*
 *  Copyright (c) 2006 Copenhagen University Astronomical Observatory
 *  All possible rights reserved
 *	Filename:	
 *  Abstract:	
 *  Author:		Jeppe Jønch Andersen (jja@astro.ku.dk)
 *  Revision:
 *  Remarks:
 */
 
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include <cxxabi.h>

#include "common_exception.h"

void common_exception::preparetrace(){
	nSize = backtrace(array, TRACE_COUNT);
	symbols = backtrace_symbols(array, nSize);
}

common_exception::common_exception(const char *fmt, ...) { 

	preparetrace(); 

	va_list arg;
	
	va_start (arg, fmt);
	vsprintf (errstr, fmt, arg);
	va_end (arg);
	
}

common_exception::common_exception(void) { 
	preparetrace(); 
	sprintf(errstr, "%s", strerror(errno));
}

common_exception::common_exception(int err) { 
	preparetrace(); 
	sprintf(errstr, "%s", strerror(err));
}

common_exception::common_exception(const char *str, int err) {
	preparetrace();
	sprintf(errstr, "%s \"%s\"", str, strerror(err));
}

common_exception::~common_exception() throw() {
	free(symbols);
}

char* common_exception::what(void) {
	return errstr;
}

char* common_exception::trace(int level) {
	return level < nSize ? symbols[level] : NULL;
}

char* common_exception::trace_name(int level){
	int status = -1;
	char* res = NULL;
	char* tmp = strdup(symbols[level]);
	char* start = strchr(tmp, '(') + 1;
	char* end = strchr(start, '+');
	if( end ){
		*end = '\0';
		res = abi::__cxa_demangle( start, NULL, NULL, &status );
	}
	return res ? res : symbols[level];
}

///////////////////////////////////////////////////////////////////////////////
// EOF
