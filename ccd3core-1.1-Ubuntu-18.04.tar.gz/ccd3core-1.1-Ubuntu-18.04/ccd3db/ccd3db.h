/*
 * ccd3db.h
 *
 *  Created on: Nov 23, 2009
 *      Author: jja
 */

#ifndef CCD3DB_H_
#define CCD3DB_H_
#include <ccd3_ivy.h>
#include <ccd3_mysql.h>
#include <inifiles.h>
#include <common_exception.h>
#include <ccd3_log.h>

#define CCD3DBVersionTxt	"v0.1"

#define MAX_DB_FIELDS 127
#define MAX_DB_FIELDNAME_LEN MAX_KEY_LEN

class ccd3db;

struct db_callback_parm{
	ccd3db* parent;
	char dbFieldName[MAX_DB_FIELDNAME_LEN];
	char IvyToken[IVY_MSG_SIZE];
	db_callback_parm(ccd3db* a_parent){ parent = a_parent; };
} ;

class ccd3db {
protected:
	TIniFile   *ini;
	cCCD3mysql *keyword_db;
	cCCD3mysql *status_db;
	cCCD3ivy   *ivy;
	static ccd3db* me;
	char print_verbosity[10];
	char log_verbosity[10];
	bool duplicate_present;
	struct timeval start_time;
	char sts_database[256];
	char sts_user[256];
	char sts_pass[256];
	char sts_host[256];
	char key_database[256];
	char key_user[256];
	char key_pass[256];
	char key_host[256];
	char dbnames[MAX_DB_FIELDS+1][MAX_KEY_LEN];
	bool do_quit;
	bool daemon_mode;
	char peername[256];
	char ivystartmsg[256];
	char ivystopmsg[256];
	char ivymessage[256];
	char ivyvalue[256];
	char ivyresponse[256];
	char ivyready[256];
	char keyword_table[256];
	char status_table[256];
	char config_filename[MAX_PATH];
	void parse_options(int argc, char** argv);
	void init_log(void);
	void daemonize(void);
	void db_reset_status(void);
	void request_updates(void);
	void trigger_callback(IvyClientPtr app, int argc, char** argv);
	void db_callback(IvyClientPtr app, int argc, char** argv, db_callback_parm* parm);
	void ivyapp_callback(IvyClientPtr app, IvyApplicationEvent event);
	void ivydie_callback(IvyClientPtr app, int id);
	friend void trigger_dmy_callback( IvyClientPtr app, void *user_data, int argc, char **argv );
	friend void db_dmy_callback( IvyClientPtr app, void *user_data, int argc, char **argv);
	friend void ivyapp_dmy_callback( IvyClientPtr app, void* user_data, IvyApplicationEvent event);
	friend void ivydie_dmy_callback( IvyClientPtr app, void* user_data, int id);
	friend void signal_handler_dmy(int signum);
	void signal_handler(int signum);
public:
	ccd3db(int argc, char** argv);
	virtual ~ccd3db();
	virtual void run();
	typedef common_exception ECCD3DB;
	typedef ECCD3DB EInvalidArg;
	typedef ECCD3DB EMissingArg;
	typedef ECCD3DB EUnknownArg;
	typedef ECCD3DB EInvalidConfig;

};

#endif /* CCD3DB_H_ */
