	/*
 *  Copyright (c) 2006 Copenhagen University Astronomical Observatory
 *  All possible rights reserved
 *	Filename:	
 *  Abstract:	
 *  Author:		Jeppe Jønch Andersen (jja@astro.ku.dk)
 *  Revision:
 *  Remarks:
 */
 
#include <stdio.h>
#include <stdlib.h>
#include <inifiles.h>
#include <ccd3_log.h>
#include "ccd3db.h"

#ifdef __cplusplus
extern "C" {
#endif

int main (int argc, char** argv) 
{
	//bool do_log = false;
	char* trace=(char*)"";
	try {
		ccd3db dbconn(argc, argv);
		dbconn.run();
	} catch(common_exception &ex) {
		
		//do_log = !dynamic_cast<cCCD3log::ECCD3LOG*>(&ex);
		
		printf("\n*** FATAL - %s ***\n\n", ex.what());
		printf("Stack trace for support personal:\n");
		
		// Don't do logging if the error was raised by the logging system!
		//if( do_log ){
			LOGMSG(LOG_ALERT, "\n*** FATAL error: %s ***\n\n", ex.what());
			LOGMSG(LOG_ALERT, "Stack trace for support personal:\n");
			//}
		
		// Print stack trace
		for(int n=2; trace; n++){
			trace = ex.trace(n);
			printf("\t%s\n",trace ? trace : "");
			//if( do_log )
				LOGMSG(LOG_ALERT, "\t%s\n",trace ? trace : "");
		}
				
		fflush(stdout);
		exit(-1);
		
	}	
}

#ifdef __cplusplus
} // extern "C"
#endif

///////////////////////////////////////////////////////////////////////////////
// EOF
