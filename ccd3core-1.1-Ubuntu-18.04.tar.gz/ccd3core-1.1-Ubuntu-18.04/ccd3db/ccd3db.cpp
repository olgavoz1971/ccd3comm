/*
 * ccd3db.cpp
 *
 *  Created on: Nov 23, 2009
 *      Author: jja
 */

#include <assert.h>
#include <unistd.h>
#include <errno.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <pwd.h>
#include <getopt.h>
#include <signal.h>
#include <sys/time.h>
#include <ccd3_log.h>
#include "ccd3db.h"
#include "buildinfo.h"

#define INI_APP_SECTION				"application"
#define INI_KEY_PIDFILE				"pidfile"
#define INI_KEY_DEFAULT_PIDFILE		"/var/run/ccd3db.pid"
#define INI_KEY_UID					"uid"
#define INI_KEY_DEFAULT_UID			"root"

#define INI_KEY_SECTION				"keywords"
#define INI_KEY_DATABASE			"database"
#define INI_KEY_DEFAULT_DATABASE	""
#define INI_KEY_DBUSER 				"dbuser"
#define INI_KEY_DEFAULT_DBUSER		""
#define INI_KEY_DBPASS				"password"
#define INI_KEY_DEFAULT_DBPASS		""
#define INI_KEY_DBHOST				"dbhost"
#define INI_KEY_DEFAULT_DBHOST		"localhost"
#define INI_KEY_TABLE				"table"
#define INI_KEY_DEFAULT_TABLE		""

#define INI_STATUS_SECTION			"status"
#define INI_STATUS_DATABASE			"database"
#define INI_STATUS_DEFAULT_DATABASE ""
#define INI_STATUS_DBUSER			"dbuser"
#define INI_STATUS_DEFAULT_DBUSER	""
#define INI_STATUS_DBPASS			"password"
#define INI_STATUS_DEFAULT_DBPASS	""
#define INI_STATUS_DBHOST			"dbhost"
#define INI_STATUS_DEFAULT_DBHOST	"localhost"
#define INI_STATUS_TABLE			"table"
#define INI_STATUS_DEFAULT_TABLE	""

#define INI_IVY_SECTION			"ivy"
#define INI_IVYNAME_KEY			"name"
#define INI_DEFAULT_IVYNAME		"ccd3db"
#define INI_IVYPEERNAME_KEY		"peername"
#define INI_DEFAULT_PEERNAME	"ccd3"
#define INI_IVYNET_KEY			"net"
#define INI_DEFAULT_IVYNET		"127.255.255.255"
#define INI_IVYMSG_KEY			"trigger"
#define INI_DEFAULT_IVYMSG		"ccd3.exposure.end"
#define INI_IVYVAL_KEY			"value"
#define INI_DEFAULT_IVYVAL		""
#define INI_IVYRESPONSE_KEY		"response"
#define INI_DEFAULT_IVYRESPONSE	"ccd3.con.command keyword"
#define INI_IVYREADY_KEY		"on_ready"
#define INI_DEFAULT_IVYREADY	"ready"

#define INI_LOG_SECTION				"log"
#define INI_LOG_FILE				"logfile"
#define INI_LOG_SYSLOG_VAL			"syslog"
#define INI_LOG_DEFAULT_FILE		INI_LOG_SYSLOG_VAL
#define INI_LOG_IDENT				"syslog_ident"
#define INI_LOG_DEFAULT_IDENT		"ccd3db"
#define INI_LOG_FACILITY			"syslog_facility"
#define INI_LOG_DEFAULT_FACILITY	"LOG_USER"

#define DB_SEQ_IDX		0
#define DB_KEY_IDX		1
#define DB_VAL_IDX		2
#define DB_COMMENT_IDX	3
#define DB_TYPE_IDX		4
#define DB_EXT_IDX		5

// Text to identify this software package
const char CCD3DBProgramHeader[] =
	" CCD3 Database connection " CCD3DBVersionTxt "\n"
	" Copenhagen University, Astronomical Observatory\n"
	" Copyright (C) 2009, All rights reserved\n\n";

const char CCD3DBProgramInfo[] =
	"\n"
	"Build information:"				"\n"
	"Revision:	"SVN_REVISION			"\n"
	"Build by:	"CURRENT_USER 			"\n"
	"Date:		"__DATE__ ", " __TIME__ "\n"
	"Host:		"HOST_NAME				"\n"
	"System:		"OS_VERSION			"\n"
	"Compiler:	"GCC_VERSION			"\n"
	"c flags:	"C_FLAGS				"\n"
	"Linker:		"LD_VERSION			"\n"
	"l flags:	"L_FLAGS				"\n";

// Help text for command line options
const char CCD3DBCmdlineHelp[] =
	"Usage: ccd3db [<switches>]"																"\n"
	"-d --daemon"																				"\n"
		"\tRelease console and go to background"												"\n"
	"-c --config [config file]"																	"\n"
		"\tUse configuration file [config file]"												"\n"
	"-v --verbose [level]"																		"\n"
		"\tSet verbosity level [level], default = normal"										"\n"
		"\tvalid values are 0..4 or \"silent\", \"fatal\", \"error\", \"normal\" and \"debug\".""\n"
	"-l --log-verbose [level]"																	"\n"
		"\tSet logging verbosity level [level], default = normal"								"\n"
		"\tvalid values are 0..4 or \"silent\", \"fatal\", \"error\", \"normal\" and \"debug\".""\n"
	"-V --version"																				"\n"
		"\tDisplay version information and exit"												"\n"
	"-h --help"																					"\n"
		"\tDisplay command line help and exit"													"\n";

// Option enumerations
typedef enum {
	coConfig     = 'c',
	coDaemon     = 'd',
	coVerbose    = 'v',
	coLogVerbose = 'l',
	coVersion    = 'V',
	coHelp	     = 'h'
} CCD3DBOptions;

// Long option enumeration elements
static struct option long_options[] = {
	{"config",		required_argument,  0,  coConfig	},
	{"daemon",		no_argument,		0,  coDaemon	},
	{"verbose",		required_argument,	0,	coVerbose	},
	{"log-verbose", required_argument,	0,	coLogVerbose},
	{"version",		no_argument,		0,	coVersion	},
	{"help",		no_argument,		0,	coHelp		},
	{NULL,			0,					0,	0			}
};

static char short_options[] = "c:dvl:Vh?";

void signal_handler_dmy(int signum);
ccd3db* ccd3db::me = NULL;

void trigger_dmy_callback( IvyClientPtr app, void *user_data, int argc, char **argv ){
	ccd3db* parent = (ccd3db*)user_data;
	if( !parent ) return;
	parent->trigger_callback(app, argc, argv);
}

void db_dmy_callback( IvyClientPtr app, void *user_data, int argc, char **argv ){
	db_callback_parm* parm = (db_callback_parm*)user_data;
	if( !parm ) return;
	ccd3db* parent = parm->parent;
	if( !parent ) return;
	parent->db_callback(app, argc, argv, parm);
}

void ivyapp_dmy_callback( IvyClientPtr app, void* user_data, IvyApplicationEvent event){
	ccd3db* parent = (ccd3db*)user_data;
	if( !parent ) return;
	parent->ivyapp_callback(app, event);
}

void ivydie_dmy_callback( IvyClientPtr app, void* user_data, int id){
	ccd3db* parent = (ccd3db*)user_data;
	if( !parent ) return;
	parent->ivydie_callback(app, id);
}

ccd3db::ccd3db(int argc, char** argv) {
	char ivyname[256];
	char ivynet[256];
	char* tmp;

	if( me ){
		throw ECCD3DB("only 1 instance allowed!");
	}
	me = this;
	gettimeofday(&start_time, NULL);
	daemon_mode = false;
	do_quit = false;
	duplicate_present = false;
#ifdef DEBUG
	strcpy(log_verbosity, "debug");
	strcpy(print_verbosity, "debug");
#else
	strcpy(log_verbosity, "normal");
	strcpy(print_verbosity, "normal");
#endif
	strcpy(config_filename, "");

	parse_options(argc, argv);

	if( do_quit ) return;

	find_configfile(config_filename, argc, argv, (char*)"ccd3");
	if( !strlen(config_filename)) throw ECCD3DB("Unable to find configuration file");

	ini = new TIniFile(config_filename);
	init_log();

	if( daemon_mode ){
		daemonize();
	}

	PRINT(L_NORMAL, CCD3DBProgramHeader);
	PRINT(L_NORMAL, "Using configuration file: %s\n", config_filename);

	// Open keyword database
	ini->ReadString(INI_KEY_SECTION, INI_KEY_DATABASE, INI_KEY_DEFAULT_DATABASE, key_database);
	ini->ReadString(INI_KEY_SECTION, INI_KEY_DBUSER,   INI_KEY_DEFAULT_DBUSER,   key_user);
	ini->ReadString(INI_KEY_SECTION, INI_KEY_DBPASS,   INI_KEY_DEFAULT_DBPASS,   key_pass);
	ini->ReadString(INI_KEY_SECTION, INI_KEY_DBHOST,   INI_KEY_DEFAULT_DBHOST,   key_host);
	ini->ReadString(INI_KEY_SECTION, INI_KEY_TABLE,    INI_KEY_DEFAULT_TABLE,    keyword_table);

	// Open status database
	ini->ReadString(INI_STATUS_SECTION, INI_KEY_DATABASE, INI_KEY_DEFAULT_DATABASE, sts_database);
	ini->ReadString(INI_STATUS_SECTION, INI_KEY_DBUSER,   INI_KEY_DEFAULT_DBUSER,   sts_user);
	ini->ReadString(INI_STATUS_SECTION, INI_KEY_DBPASS,   INI_KEY_DEFAULT_DBPASS,   sts_pass);
	ini->ReadString(INI_STATUS_SECTION, INI_KEY_DBHOST,   INI_KEY_DEFAULT_DBHOST,   sts_host);
	ini->ReadString(INI_STATUS_SECTION, INI_KEY_TABLE,    INI_KEY_DEFAULT_TABLE,    status_table);

	// Open ivy bus
	ini->ReadString(INI_IVY_SECTION, INI_IVYNAME_KEY, INI_DEFAULT_IVYNAME, ivyname);
	ini->ReadString(INI_IVY_SECTION, INI_IVYNET_KEY, INI_DEFAULT_IVYNET, ivynet);
	ini->ReadString(INI_IVY_SECTION, INI_IVYMSG_KEY, INI_DEFAULT_IVYMSG, ivymessage);
	ini->ReadString(INI_IVY_SECTION, INI_IVYVAL_KEY, INI_DEFAULT_IVYVAL, ivyvalue);
	ini->ReadString(INI_IVY_SECTION, INI_IVYRESPONSE_KEY, INI_DEFAULT_IVYRESPONSE, ivyresponse);
	ini->ReadString(INI_IVY_SECTION, INI_IVYREADY_KEY, INI_DEFAULT_IVYREADY, ivyready);

	ivy = new cCCD3ivy(ivyname, ivynet, ivyapp_dmy_callback, NULL, this);

	ini->ReadString(INI_IVY_SECTION, INI_IVYPEERNAME_KEY, INI_DEFAULT_PEERNAME, peername);

	ivy->Subscribe(trigger_dmy_callback, (void*)this, "%s", ivymessage);
	sprintf(ivystartmsg, "application.start");
	sprintf(ivystopmsg,  "application.stop");

	strcpy(dbnames[0], "");

	ini->ReadSectionKeys("status_schema", dbnames);

	status_db = new cCCD3mysql(sts_database, sts_user, sts_pass, sts_host);
	db_reset_status();
	delete status_db;
	status_db = NULL;

	db_callback_parm* parm;
	for(int n=0; strlen(dbnames[n]); n++){
		parm = new db_callback_parm(this);
		strcpy(parm->dbFieldName, dbnames[n]);
		ini->ReadString("status_schema", parm->dbFieldName, "", parm->IvyToken);

		// Is this definition a constant in config
		tmp = strchr(parm->IvyToken, '\"');
		if( tmp ){
			PRINT(L_DEBUG, "Binding db:%s to constant value\n", parm->dbFieldName);
		} else {
			PRINT(L_DEBUG, "Binding db:%s to %s.%s\n", parm->dbFieldName, peername, parm->IvyToken);
			ivy->Subscribe(db_dmy_callback, (void*)parm, "(%s.%s.*)", peername, parm->IvyToken);
		}
	}
}

ccd3db::~ccd3db() {

	if( ivy ){
		delete ivy;
		ivy = NULL;
	}

	if( keyword_db ){
		delete keyword_db;
		keyword_db = NULL;
	}

	if( status_db ){
		delete status_db;
		status_db = NULL;
	}

	if( ini ){
		delete ini;
		ini = NULL;
	}
	PRINT(L_NORMAL, "CCD3 Databanormalse connection shutdown\n");
}

void ccd3db::parse_options(int argc, char** argv)
{
	int c=0;

	opterr = 0;

	while ( c != EOF ) {

		int option_index = 0;

		c = getopt_long (argc, argv, short_options, long_options, &option_index);

		switch (c) {
		case    EOF      	:	break;

		case	coConfig	:	if( 1 != sscanf(optarg, "%s", config_filename) )
									throw EInvalidArg("Could not parse config file (%s)", optarg);

								if( !file_exists(config_filename) ){
									throw EInvalidArg("Invalid configurationfile (%s)", config_filename);
								}

								break;

		case	coDaemon	:	daemon_mode = true;
								break;

		case	coVerbose	: 	strncpy(print_verbosity, optarg, 10);
								break;
		case 	coLogVerbose:	strncpy(log_verbosity, optarg, 10);
								break;

		case	coVersion 	: 	PRINT(L_NORMAL, "%s%s", CCD3DBProgramHeader, CCD3DBProgramInfo);
								do_quit = true;
								break;

		case	coHelp 		:	PRINT(L_ALWAYS, CCD3DBCmdlineHelp);
								do_quit = true;
								break;

		case	'?'			:	break;
								//throw EUnknownArg("Unknown argument found: 0%o", optopt);

		case	':'			:	throw EMissingArg("Missing a mandatory argument to \"%s\"", long_options[option_index].name);

		case	0			:	PRINT(L_ERROR, "How did I end up here .. please inform (jja@astro.ku.dk)???\n");
								break;

        default				:	throw EInvalidArg("Invalid option found: 0%o ??\n", c);
		}
	} // while()

	if ( optind < argc ) {
		throw EUnknownArg("Unknown argument found on command line: \"%s\"", argv[optind]);
	}
}

void ccd3db::init_log(void)
{
	char str_logfile[256];
	char log_ident[256];
	char str_facility[256];

	ini->ReadString(INI_LOG_SECTION, INI_LOG_FILE, INI_LOG_DEFAULT_FILE, str_logfile);

	if( !strcasecmp(str_logfile, INI_LOG_SYSLOG_VAL )){
		// Syslog is selected
		ini->ReadString(INI_LOG_SECTION, INI_LOG_IDENT, INI_LOG_DEFAULT_IDENT, log_ident);
		ini->ReadString(INI_LOG_SECTION, INI_LOG_FACILITY, INI_LOG_DEFAULT_FACILITY, str_facility);
		new cCCD3log(log_ident, str_facility);
	} else {
		// Log file is selected
		new cCCD3log(str_logfile);
	}

	LOG->set_log_verbosity(log_verbosity);
	LOG->set_print_verbosity(print_verbosity);
	LOG->insert_debug_str("[debug] ");

}

void ccd3db::daemonize(void)
{
   	char run_as_user[256] = "";

    PRINT(L_DEBUG, "Daemonizing\n" );

    pid_t pid, sid;//, parent;

    /* Fork off the parent process */
	PRINT(L_DEBUG, "Forking child\n");
    pid = fork();

    if (pid < 0) {
        PRINT(MAKE_FLAG(ccFatal, ccFatal), "Unable to fork child daemon, code=%d (%s)\n", errno, strerror(errno) );
        throw ECCD3DB("Unable to fork child", errno);
    }

    /* If we got a good PID, then we can exit the parent process. */
    if (pid > 0) {
    	PRINT(MAKE_FLAG(ccDebug, ccNormal), "Forked child pid=%d\n", pid);
        exit(EXIT_SUCCESS);
    }

    PRINT(MAKE_FLAG(ccDebug, ccNormal), "Running as child pid=%d\n", getpid());
    /* At this point we are executing as the child process */

    ini->ReadString(INI_APP_SECTION, INI_KEY_UID, INI_KEY_DEFAULT_UID, run_as_user);

	if( strlen(run_as_user) ){
        struct passwd *pw = getpwnam(run_as_user);
        if ( pw ) {

            PRINT(MAKE_FLAG(ccDebug, ccNormal), "setting user to %s\n", run_as_user );

            if(0 > setuid( pw->pw_uid )){
                PRINT(L_FATAL, "Failed setting user to %s (%s)\n", run_as_user, strerror(errno) );
            	throw ECCD3DB("Failed setting user to %s (%s)\n", run_as_user, strerror(errno) );
            }

        } else {
            PRINT(L_FATAL, "Unknown user set? \"%s\" (%s)\n", run_as_user, strerror(errno) );
        	throw ECCD3DB("Unknown user set? \"%s\" (%s)\n", run_as_user, strerror(errno) );
        }
	}

    //parent = getppid();

    signal(SIGUSR1, signal_handler_dmy);
    signal(SIGTERM, signal_handler_dmy);
    signal(SIGTSTP, SIG_IGN); /* Various TTY signals */
    signal(SIGTTOU, SIG_IGN);
    signal(SIGTTIN, SIG_IGN);
    signal(SIGHUP,  SIG_IGN); /* Ignore hangup signal */

    /* Change the file mode mask */
    umask(0);

    /* Create a new SID for the child process */
    sid = setsid();
    if (sid < 0) {		// Process db
        PRINT(L_FATAL, "unable to create new session, code %d (%s)\n", errno, strerror(errno) );
        throw ECCD3DB("unable to create new session, code %d (%s)\n", errno, strerror(errno) );
    }

    /* Change the current working directory.  This prevents the current
       directory from being locked; hence not being able to remove it. */
    if ((chdir("/")) < 0) {
        PRINT(L_FATAL, "unable to change directory to %s, code %d (%s)\n", "/", errno, strerror(errno) );
        throw ECCD3DB("unable to change directory to %s, code %d (%s)\n", "/", errno, strerror(errno) );
    }

    /* Redirect standard files */
	close(STDIN_FILENO);
	close(STDOUT_FILENO);
	close(STDERR_FILENO);
}

void ccd3db::trigger_callback(IvyClientPtr, int argc, char**argv){
	char msg[256];
	char** db_res;
	int cnt;//, f_cnt;

	PRINT(L_DEBUG, "Trigger condition found\n");

	// TBD .. check value
	// Process db
	// Send ivy messages
	try{
		keyword_db = new cCCD3mysql(key_database, key_user, key_pass, key_host);
		keyword_db->query("select * from `%s` order by `SEQNO`", keyword_table);
		cnt = keyword_db->get_result();
	} catch( EMYSQL &ex){
		//do_quit = true;
		PRINT(L_ERROR, "%s\n", ex.what());
		cnt = 0;
	}

	for(int n=0; n < cnt; n++){

		//f_cnt = keyword_db->get_field_cnt();
		db_res = keyword_db->get_row();
		sprintf(msg, "%s.%s %s %s %s \"%s\" \"%s\"", peername, ivyresponse, db_res[DB_EXT_IDX], db_res[DB_TYPE_IDX], db_res[DB_KEY_IDX], db_res[DB_VAL_IDX], db_res[DB_COMMENT_IDX]);

		PRINT(L_DEBUG, "Writing: %s\n", msg);
		//ivy->SendAnonymous(msg);
		ivy->Send("%s", msg);
	}

	keyword_db->close_result();
	delete keyword_db;
	keyword_db = NULL;

	if( strlen(ivyready) ){
		PRINT(L_DEBUG, "signaling ready with: \"%s.%s\"\n", peername, ivyready);
		//ivy->SendAnonymous("%s.%s", peername, ivyready);
		ivy->Send("%s.%s", peername, ivyready);
	}
}

void ccd3db::db_reset_status(void)
{
	int res;

	// See if any rows are present
	status_db->query("SELECT * FROM %s", status_table);
	res = status_db->get_result();
	status_db->close_result();

	// If not, then add one
	if( !res ){
		PRINT(L_DEBUG, "Found no rows to update, inserting row into status db\n");
		status_db->query("INSERT INTO %s VALUES()", status_table);
	}

	for(int n=0; strlen(dbnames[n]);n++){
		PRINT(L_DEBUG, "Resetting status field \"%s\"\n", dbnames[n]);
		status_db->query("UPDATE %s SET %s = \"%s\"", status_table, dbnames[n], " ");

	}
}

void ccd3db::db_callback(IvyClientPtr, int argc, char** argv, db_callback_parm* parm){
	char val[256];
	char* str;

	if( !argc ){
		PRINT(L_DEBUG, "Unexpected condition in db_callback()\n");
		return;
	}

	if( strlen(parm->IvyToken)){
		str = strstr(argv[0], parm->IvyToken);
		str += strlen(parm->IvyToken);
		while(*str == ' ') str++;
		strcpy(val, str);
	} else {
		strcpy(val, argv[0]);
	}
	try{
		status_db->query("UPDATE %s SET %s = \"%s\"", status_table, parm->dbFieldName, val);
	}catch(EMYSQL &ex){
		PRINT(L_ERROR, "%s\n", ex.what());
	}

}

void ccd3db::ivyapp_callback(IvyClientPtr app, IvyApplicationEvent event)
{
	char* app_name;
	char* host_name;
	unsigned long utime;
	struct timeval now;
	app_name = (char*)IvyGetApplicationName(app);
	host_name = (char*)IvyGetApplicationHost(app);

	if( !strcasecmp(app_name, ivy->Name())){
		if(  event == IvyApplicationDisconnected ){
			duplicate_present = false;
			return;
		} else {
			duplicate_present = true;
			gettimeofday(&now, NULL);
			utime = now.tv_sec * 1000000 + now.tv_usec - start_time.tv_sec * 1000000 - start_time.tv_usec;
			signal(SIGALRM, signal_handler_dmy);
			ualarm(utime, 0);
			return;
		}
		// if this is not my peer or i'm busy handling duplicate ivy agents
	} else if( strcasecmp(app_name, peername) || duplicate_present ){
		return;
	}


	switch( event ){
	case IvyApplicationConnected:
		PRINT(L_NORMAL, "Peer detected (%s@%s), requesting status\n", app_name, host_name);
		status_db = new cCCD3mysql(sts_database, sts_user, sts_pass, sts_host);
		request_updates();
		PRINT(L_NORMAL, "Waiting for trigger \"%s\"...\n", ivymessage);
		break;
	case IvyApplicationDisconnected:
		PRINT(L_NORMAL, "Lost peer: %s@%s...\n", app_name, host_name);
		if( status_db ){
			db_reset_status();
			delete status_db;
		}
		status_db = NULL;
		PRINT(L_NORMAL, "Waiting for peer...\n");
		break;
	default:
		break;
	}
}

void ccd3db::ivydie_callback(IvyClientPtr app, int id)
{
	if( status_db ){
		delete status_db;
		status_db = NULL;
	}
}

void ccd3db::request_updates(void)
{
	char updates[MAX_DB_FIELDS+1][MAX_VAL_LEN];
	char val[MAX_VAL_LEN];
	char* tmp;
	char* tmp2;

	ini->ReadSectionValues("update_status", updates);

	for(int n=0; strlen(updates[n]); n++){
		PRINT(L_DEBUG,"Requesting update on %s\n", updates[n]);
		//ivy->SendAnonymous("%s.%s\n", peername, updates[n]);
		ivy->Send("%s.%s\n", peername, updates[n]);
	}

	for(int n=0; strlen(dbnames[n]);n++){
		ini->ReadString("status_schema", dbnames[n], "", val);

		// Is this definition a constant in config
		tmp = strchr(val, '\"');
		if( tmp ){
			tmp++;
			tmp2 = strchr(tmp, '\"');
			if( !tmp2 )
				throw EInvalidConfig("Syntax error near \"%s\"", tmp);
			*tmp2= 0;
			PRINT(L_DEBUG, "Setting constant %s to db:%s\n", dbnames[n], tmp);
			status_db->query("UPDATE %s SET %s = \"%s\"", status_table, dbnames[n], tmp);
		}
	}
}

void ccd3db::run()
{
	PRINT(L_DEBUG, "Starting run loop\n");
	if( !do_quit ){

		ivy->Run(ivystartmsg);

		if( !status_db ){
			PRINT(L_NORMAL, "Waiting for peer...\n");
		}

		while( !do_quit )
			usleep(100000);

		if( duplicate_present ){
			PRINT(L_ERROR, "Duplicate ivy name detected (%s) - backing out...\n", ivy->Name());
		} else if( status_db ){
			db_reset_status();
		}

		ivy->Send(ivystopmsg);
		ivy->Stop();
	}
	PRINT(L_DEBUG, "Ending run loop\n");
}

void ccd3db::signal_handler(int signum)
{
    switch(signum) {
    case SIGALRM:	if( duplicate_present ){
    					do_quit = true;
    				}
					break;

    case SIGUSR1: 	exit(EXIT_SUCCESS);
    				break;

    case SIGTERM:	// Does not work for some reason??? TBD
					do_quit = true;
    	    		break;
    }
}

void signal_handler_dmy(int signum)
{
	ccd3db::me->signal_handler(signum);
}

// EOF
