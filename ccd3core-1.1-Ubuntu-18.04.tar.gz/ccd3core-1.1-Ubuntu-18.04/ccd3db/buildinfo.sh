#!/bin/sh
TARGET=buildinfo.h
echo "generating build info"

gcc --version  | awk 'NR == 1' | awk '{print "#define GCC_VERSION \"" $1" "$2" "$3" "$4" "$5" "$6" "$7 "\""}' > $TARGET
echo "#define C_FLAGS $1" >> $TARGET
ld --version  | awk 'NR == 1' | awk '{print "#define LD_VERSION \"" $1" "$2" "$3" "$4" "$5" "$6" "$7 "\""}' >> $TARGET
echo "#define L_FLAGS $2" >> $TARGET
hostname -A | awk '{print "#define HOST_NAME \""$1"\""}' >> $TARGET
uname -posrim | awk '{print "#define OS_VERSION \""$1" "$2" "$3" "$6"\""}' >> $TARGET
whoami | awk '{print "#define CURRENT_USER \""$1"\""}' >> $TARGET
svn info | grep Revision | awk '{print "#define SVN_REVISION \""$2"\""}' >> $TARGET
echo '#define BUILD_DATE "'`date`'"' >> $TARGET