#!/usr/bin/python

import sys
import os
from os.path import join as opjoin, basename, splitext
import ConfigParser
import MySQLdb
import numpy as np
from random import random
import imp
import re

from PyQt4.QtCore import Qt, QCoreApplication, QTranslator, QLocale
from PyQt4.QtCore import pyqtSignal, pyqtSlot
from PyQt4.QtCore import QStringList
from PyQt4.QtCore import QTimer
from PyQt4.QtGui import *
from PyQt4.Qwt5.Qwt import *

# "Constants"
okGreen = QColor(0, 170, 127)

dict_camera   = {}
dict_shutter  = {}
dict_autosave = {}

dict_ampl     = { 1: 'A',
                  2: 'B',
                  3: 'AB',
                  4: 'C',
                  5: 'AC',
                  6: 'BC',
                  7: 'ABC',
                  8: 'D',
                  9: 'AD',
                  10: 'BD',
                  11: 'ABD',
                  12: 'CD',
                  13: 'ACD',
                  14: 'BCD',
                  15: 'ABCD'}

def initialize_strings():
    global dict_camera, dict_shutter, dict_ampl, dict_autosave

    dict_camera   = { 0: QCoreApplication.translate('Camera status', 'Idle'),
                      1: QCoreApplication.translate('Camera status', 'Integrating'),
                      2: QCoreApplication.translate('Camera status', 'Readout'),
                      3: QCoreApplication.translate('Camera status', 'Clear'),
                      4: QCoreApplication.translate('Camera status', 'Shutter delay') }

    dict_shutter  = { 0: QCoreApplication.translate('Shutter status', 'Off'),
                      1: QCoreApplication.translate('Shutter status', 'On') }

    dict_autosave = { 0: QCoreApplication.translate('Autosave', 'OFF'),
                      1: QCoreApplication.translate('Autosave', 'ON') }
    

class Ui(object):
    def __init__(self):
        self.__containers = {}

    def appendLayout(self, name, widget):
        self.__containers[name] = widget

    def appendToLayout(self, name, widget):
        try:
            self.__containers[name].addWidget(widget)
        except KeyError:
            pass

class AdvancedConfigParser(ConfigParser.ConfigParser):
    ADVOPTCRE = re.compile('(.+)\[([^]]+)\]$')
    def _read(self, fp, fpname):
        ConfigParser.ConfigParser._read(self, fp, fpname)

        def setValue(dc, key, subkeys, value):
            if not subkeys:
                if key in dc and type(dc[key]) is dict:
                    raise ValueError("Type conflict")
                else:
                    dc[key] = value
            else:
                if key not in dc:
                    ndc = dc[key] = {}
                elif type(dc[key]) is not dict:
                    raise ValueError("Type conflict")
                else:
                    ndc = dc[key]

                setValue(ndc, subkeys[0], subkeys[1:], value)

        for sec in self.sections():
            for entry, value in self.items(sec):
                mo = self.ADVOPTCRE.match(entry)
                if mo:
                    name, key = mo.groups()
                    name = name.strip()
                    key = (''.join(key.split())).split(',')

                    try:
                        d = self.get(sec, name)
                        if type(d) is not dict:
                            raise ConfigParser.ParsingError("Conflicting indexing for [%s]:%s" % (sec, entry))
                    except ConfigParser.NoOptionError:
                        d = {}

                    try:
                        setValue(d, key[0], key[1:], value)
                    except ValueError:
                        raise ConfigParser.ParsingError("Conflicting indexing for [%s]:%s" % (sec, entry))

                    self.set(sec, name, d)
                    self.remove_option(sec, entry)

def getConfigInteger(config, section, name):
    try:
        return config.getint(section, name)
    except ValueError:
        string = QCoreApplication.translate('Error messages', '[%s]:%s is not an integer',
                                            'This is when reading from a config file. "[section]:keyword is not an integer"')
        raise ConfigParser.Error(string % (section, name))

def setForegroundColor(widget, color):
    pal = widget.palette()
    pal.setColor(QPalette.WindowText, color)
    widget.setPalette(pal)

def frmt(x):
    """Format exposure times"""
    if 0 < x < 1000:
        return "%d ms" % x
    x = x/1000.0

    if abs(round(x) - x) < 0.01:
        return "%.0f" % x

    return "%.2f s" % x

class PluginInterface(object):
    def __init__(self, iface):
        self.__iface = iface
        self.__plugins = []

    def registerPlugin(self, module, config, initial_data = {}):
        ret = module.init(config, initial_data, self)
        if ret:
            self.__plugins.append(ret)
            if ret.queriesDatabase:
                self.__iface.dh.appendPlugin(ret)

    def updatePlugins(self, data):
        for plugin in self.__plugins:
            plugin.update(data)

    def setGeometryLayout(self, layout):
        self.__iface.ui.geometryGroupBox.setLayout(layout)

    def showGeometryWidget(self, visible):
        self.__iface.ui.geometryGroupBox.setVisible(visible)

    def appendToContainer(self, name, widget):
        self.__iface.ui.appendToLayout(name, widget)

class PluginLoader(object):
    def __init__(self, config):
        self.path = config.get('general', 'plugins_path').split(':')

    def load(self, name, config):
        module = None
        prev_path = sys.path
        sys.path = self.path + prev_path
        try:
            try:
                tmp = imp.find_module(config['plugin'])
                module = imp.load_module(name, *tmp)
            except ImportError, e:
                print >> sys.stderr, "Couldn't load the plugin"
                print >> sys.stderr, "Reason: ", str(e)
            except RuntimeError, e:
                print >> sys.stderr, str(e)
        finally:
            sys.path = prev_path

        return module

class Ccd3StatusMainWindow(QMainWindow):
    def __init__(self, config, parent=None):
        super(Ccd3StatusMainWindow, self).__init__(parent)

        self.config = config
        self.debug_model = QStringListModel()
        self.plug_iface = PluginInterface(self)

        # self.readSchematic(config)

        # Setup the database
        self.dh = MySQLHandler(self.config)

        self.ui = Ui()
        self.uiSetup()

        self.dataAgeLimit = getConfigInteger(self.config,
                                             "gui",
                                             "data_age_limit")
        try:
            self.initializePlugins(self.__readStatusFromDatabase())
        except DBException:
            print >> sys.stderr("Couldn't initialize plugins: no database access")

        self.addStretches()

        # Setup and start the timer
        self.timerSetup(getConfigInteger(self.config,
                                         "gui",
                                         "refresh_interval"))

        self.updateTimer.start()

    def initializePlugins(self, initial_status):
        loader = PluginLoader(self.config)
        try:
            for name, section in self.config.items('gui-plugins'):
                plug_sect = dict(self.config.items(section))
                module = loader.load(name, plug_sect)
                if module:
                    self.plug_iface.registerPlugin(module, plug_sect, initial_status)
        except ConfigParser.NoSectionError:
            # No plugin section: this is ok
            # TODO: We may want to distinguish from no 'gui-plugins' and missing
            #       individual plugin sections
            pass

    def readSchematic(self, config):
        # Get the detector schematic
        prev_path = sys.path
        plugins_path = config.get('general', 'plugins_path')
        sys.path = plugins_path.split(':') + prev_path
        ccd_section = config.get('gui', 'ccd_section')
        ccd_config = dict(config.items(ccd_section))
        self.detectorView = None
        try:
            tmp = imp.find_module(ccd_config['plugin'])
            detector_factory = imp.load_module('detectormodule', *tmp).getDetector
            self.detectorView = detector_factory(ccd_config)
        except ImportError:
            print >> sys.stderr, "Couldn't find the plugins directory"
        except RuntimeError, e:
            print >> sys.stderr, str(e)
        sys.path = prev_path

    def closeEvent(self, event):
        self.dh.close()
        super(Ccd3StatusMainWindow, self).closeEvent(event)

    @pyqtSlot(str)
    def appendDebugLine(self, string):
        last = self.debug_model.rowCount()
        self.debug_model.insertRows(last, 1)
        idx = self.debug_model.index(last)
        self.debug_model.setData(idx, string)

    def timerSetup(self, interval):
        self.updateTimer = QTimer()
        self.updateTimer.setInterval(interval)
        self.updateTimer.timeout.connect(self.updateStatus)

    def addStretches(self):
        widgets = (0, 1, 2)
        for wn in widgets:
            self.ui.tab_status.widget(wn).layout().addStretch()

    def uiSetup(self):
        self.setWindowTitle(self.config.get('gui', 'system_name'))

        self.ui.tab_status = tab_status = QTabWidget()
        self.setCentralWidget(tab_status)

        # Define the Status tab
        status_tab = QWidget()
        st_vly   = QVBoxLayout(status_tab)
        self.ui.appendLayout('STATUS', st_vly)

        st_grly1 = QGridLayout()
        st_grly1.addWidget(QLabel(QCoreApplication.translate('Camera status', '<b>Camera:</b>')),     0, 0)
        st_grly1.addWidget(QLabel(QCoreApplication.translate('Camera status', '<b>Time left:</b>')),  0, 2)
        st_grly1.addWidget(QLabel(QCoreApplication.translate('Camera status', '<b>Int. Time:</b>')),  1, 0)
        st_grly1.addWidget(QLabel(QCoreApplication.translate('Camera status', '<b>Multi Exp.:</b>')), 1, 2)
        self.ui.CAMERA_MODE = QLabel(QCoreApplication.translate('Camera status', 'Idle',
                                                                'Placeholder: Camera'))
        setForegroundColor(self.ui.CAMERA_MODE, okGreen)
        self.ui.TINT_RES    = QLabel('9999 s')
        self.ui.TINT        = QLabel('9999 s')
        self.ui.MULTIEXP    = QLabel('999/999')
        st_grly1.addWidget(self.ui.CAMERA_MODE, 0, 1, Qt.AlignCenter)
        st_grly1.addWidget(self.ui.TINT_RES,    0, 3, Qt.AlignCenter)
        st_grly1.addWidget(self.ui.TINT,        1, 1, Qt.AlignCenter)
        st_grly1.addWidget(self.ui.MULTIEXP,    1, 3, Qt.AlignCenter)

        st_grly2 = QGridLayout()
        st_grly2.addWidget(QLabel(QCoreApplication.translate('Camera status', 'Exposure',
                                                             'Exposure progress bar')), 0, 0)
        st_grly2.addWidget(QLabel(QCoreApplication.translate('Camera status', 'Readout',
                                                             'Readout progress bar')),  1, 0)
        self.ui.EXP_PROGRESS = QProgressBar()
        self.ui.EXP_PROGRESS.setTextVisible(True)
        self.ui.EXP_PROGRESS.setValue(24)
        self.ui.EXP_PROGRESS.setAlignment(Qt.AlignHCenter)
        self.ui.READ_PROGRESS = QProgressBar()
        self.ui.READ_PROGRESS.setTextVisible(True)
        self.ui.READ_PROGRESS.setAlignment(Qt.AlignHCenter)
        st_grly2.addWidget(self.ui.EXP_PROGRESS,  0, 1)
        st_grly2.addWidget(self.ui.READ_PROGRESS, 1, 1)

        st_geomgb = QGroupBox()
        st_geomgb.setTitle(QCoreApplication.translate('CCD Geometry', ' Geometry ',
                                                      'Frame title'))
        st_geomgb.setVisible(False)

        self.ui.geometryGroupBox = st_geomgb

        st_outputgb = QGroupBox()
        st_outputgb.setTitle(QCoreApplication.translate('Output info', ' Output ',
                                                        'Frame title'))
        st_outputly = QGridLayout(st_outputgb)
        st_outputly.addWidget(QLabel(QCoreApplication.translate('Output info', 'AutoSave:')), 0, 0, Qt.AlignRight)
        st_outputly.addWidget(QLabel(QCoreApplication.translate('Output info', 'File:')),     1, 0, Qt.AlignRight)

        self.ui.AUTOSAVE = QLabel(QCoreApplication.translate('Output info', 'ON',
                                                             'Placeholder: Autosave'))
        self.ui.AUTOSAVE.setSizePolicy(QSizePolicy.MinimumExpanding,
                                       QSizePolicy.Preferred)
        self.ui.CUR_FILENAME = QLabel('/work/ccd3/output/myfile.fits')
        self.ui.CUR_FILENAME.setSizePolicy(QSizePolicy.MinimumExpanding,
                                           QSizePolicy.Preferred)
        st_outputly.addWidget(self.ui.AUTOSAVE,     0, 1)
        st_outputly.addWidget(self.ui.CUR_FILENAME, 1, 1)

        st_othersgb = QGroupBox()
        st_othersly = QGridLayout(st_othersgb)
        self.ui.AMPL_MODE0 = QLabel('A')
        self.ui.SPEED_LABEL = QLabel('0')
        self.ui.READOUT_LABEL = QLabel(QCoreApplication.translate('Miscellanea', 'n.a.',
                                                                  'Placeholder: RON'))
        self.ui.SHUTTER = QLabel(QCoreApplication.translate('Miscellanea', 'ON',
                                                            'Placeholder: Auto Shutter'))
        self.ui.DATA_AGE = QLabel('12')
        st_othersly.addWidget(QLabel(QCoreApplication.translate('Miscellanea', 'Amplifier:')),  0, 0, Qt.AlignRight)
        st_othersly.addWidget(QLabel(QCoreApplication.translate('Miscellanea', 'Pix. speed:')), 1, 0, Qt.AlignRight)
        st_othersly.addWidget(QLabel(QCoreApplication.translate('Miscellanea', 'RON:')),        2, 0, Qt.AlignRight)
        st_othersly.addWidget(self.ui.AMPL_MODE0,    0, 1, Qt.AlignRight)
        st_othersly.addWidget(self.ui.SPEED_LABEL,   1, 1, Qt.AlignRight)
        st_othersly.addWidget(self.ui.READOUT_LABEL, 2, 1, Qt.AlignRight)
        st_othersly.setColumnStretch(2, 1)
        st_othersly.addWidget(QLabel(QCoreApplication.translate('Miscellanea', 'Auto Shutter:')),        0, 3, Qt.AlignRight)
        st_othersly.addWidget(QLabel(QCoreApplication.translate('Miscellanea', '<b>Status Delay:</b>')), 2, 3, Qt.AlignRight)
        st_othersly.addWidget(self.ui.SHUTTER,       0, 4, Qt.AlignRight)
        st_othersly.addWidget(self.ui.DATA_AGE,      2, 4, Qt.AlignRight)

        st_vly.addLayout(st_grly1)
        st_vly.addLayout(st_grly2)
        st_vly.addWidget(st_geomgb)
        st_vly.addWidget(st_outputgb)
        st_vly.addWidget(st_othersgb)

        tab_status.addTab(status_tab, QCoreApplication.translate('Tab names', 'Status'))

        # Define the Metrics tab
        metrics_tab = QWidget()
        mt_vly = QVBoxLayout(metrics_tab)
        self.ui.appendLayout('METRICS', mt_vly)

        mt_envgb = QGroupBox()
        mt_envgb.setTitle(QCoreApplication.translate('Entorno', ' Environment '))
        mt_envly = QGridLayout(mt_envgb)
        self.ui.REFTEMP = QLabel('0')
        self.ui.CCDTEMP = QLabel('0')
        self.ui.DEWARTEMP = QLabel('0')
        self.ui.DEWARPRESS = QLabel('0')
        mt_envly.addWidget(QLabel(QCoreApplication.translate('Environment', '<b>CCD temp:</b>')),  0, 0, Qt.AlignRight)
        mt_envly.addWidget(self.ui.REFTEMP,             0, 1, Qt.AlignRight)
        mt_envly.addWidget(QLabel('<b>C</b>'),          0, 2)
        mt_envly.addWidget(QLabel(QCoreApplication.translate('Environment', '<b>Ref. temp:</b>')), 1, 0, Qt.AlignRight)
        mt_envly.addWidget(self.ui.CCDTEMP,             1, 1, Qt.AlignRight)
        mt_envly.addWidget(QLabel('<b>C</b>'),          1, 2)
        vline = QFrame()
        vline.setFrameShape(QFrame.VLine)
        vline.setFrameShadow(QFrame.Sunken)
        mt_envly.addWidget(vline, 0, 3, 2, 1)
        mt_envly.addWidget(QLabel(QCoreApplication.translate('Environment', '<b>LN2 temp:</b>')), 0, 4, Qt.AlignRight)
        mt_envly.addWidget(self.ui.DEWARTEMP,          0, 5, Qt.AlignRight)
        mt_envly.addWidget(QLabel('<b>C</b>'),         0, 6)
        mt_envly.addWidget(QLabel(QCoreApplication.translate('Environment', '<b>Pressure:</b>')), 1, 4, Qt.AlignRight)
        mt_envly.addWidget(self.ui.DEWARPRESS,         1, 5, Qt.AlignRight)
        mt_envly.addWidget(QLabel('<b>mBar</b>'),      1, 6)

        self.ui.TemperaturePlot = QwtPlot()
        self.ui.PressurePlot = QwtPlot()

        mt_vly.addWidget(mt_envgb)
        mt_vly.addWidget(self.ui.TemperaturePlot)
        mt_vly.addWidget(self.ui.PressurePlot)

        tab_status.addTab(metrics_tab, 'Metrics')

        # Define the Engineering tab
        eng_tab = QWidget()
        eng_vly = QVBoxLayout(eng_tab)
        self.ui.appendLayout('ENGINEERING', eng_vly)

        eng_grly1 = QGridLayout()
        self.ui.EXP_PROGRESS_2  = QProgressBar()
        self.ui.EXP_PROGRESS_2.setTextVisible(True)
        self.ui.EXP_PROGRESS_2.setAlignment(Qt.AlignHCenter)
        self.ui.READ_PROGRESS_2 = QProgressBar()
        self.ui.READ_PROGRESS_2.setTextVisible(True)
        self.ui.READ_PROGRESS_2.setAlignment(Qt.AlignHCenter)
        self.ui.MEM_PROGRESS_2  = QProgressBar()
        self.ui.MEM_PROGRESS_2.setTextVisible(True)
        self.ui.MEM_PROGRESS_2.setAlignment(Qt.AlignHCenter)
        self.ui.DESC_PROGRESS   = QProgressBar()
        self.ui.DESC_PROGRESS.setTextVisible(True)
        self.ui.DESC_PROGRESS.setAlignment(Qt.AlignHCenter)
        self.ui.FILE_PROGRESS_2 = QProgressBar()
        self.ui.FILE_PROGRESS_2.setTextVisible(True)
        self.ui.FILE_PROGRESS_2.setAlignment(Qt.AlignHCenter)
        self.ui.EXP_PROGRESS_2.setValue(24)
        self.ui.DESC_PROGRESS.setValue(24)
        self.ui.FILE_PROGRESS_2.setValue(24)
        eng_grly1.addWidget(QLabel(QCoreApplication.translate('Engineering progress bars', 'Exposure')),    0, 0)
        eng_grly1.addWidget(QLabel(QCoreApplication.translate('Engineering progress bars', 'Readout')),     1, 0)
        eng_grly1.addWidget(QLabel(QCoreApplication.translate('Engineering progress bars', 'Memory')),      2, 0)
        eng_grly1.addWidget(QLabel(QCoreApplication.translate('Engineering progress bars', 'Descrambler')), 3, 0)
        eng_grly1.addWidget(QLabel(QCoreApplication.translate('Engineering progress bars', 'File')),        4, 0)
        eng_grly1.addWidget(self.ui.EXP_PROGRESS_2,  0, 1)
        eng_grly1.addWidget(self.ui.READ_PROGRESS_2, 1, 1)
        eng_grly1.addWidget(self.ui.MEM_PROGRESS_2,  2, 1)
        eng_grly1.addWidget(self.ui.DESC_PROGRESS,   3, 1)
        eng_grly1.addWidget(self.ui.FILE_PROGRESS_2, 4, 1)

        # Begin: Timing Group Box
        eng_timgb = QGroupBox()
        eng_timgb.setTitle(QCoreApplication.translate('Engineering: timing (video)', ' Timing '))
        eng_timly = QGridLayout(eng_timgb)

        eng_tim_vidgb = QGroupBox()
        eng_tim_vidgb.setTitle(QCoreApplication.translate('Engineering: timing (video)', ' Video '))
        eng_tim_vidly = QGridLayout(eng_tim_vidgb)
        self.ui.TSAM = QLabel('72')
        self.ui.TSND = QLabel('6')
        self.ui.CDSG = QLabel('50000')
        eng_tim_vidly.addWidget(QLabel(QCoreApplication.translate('Engineering: timing (video)', 'Sample time:')),   0, 0, Qt.AlignRight)
        eng_tim_vidly.addWidget(QLabel(QCoreApplication.translate('Engineering: timing (video)', 'Settling time:')), 1, 0, Qt.AlignRight)
        eng_tim_vidly.addWidget(QLabel(QCoreApplication.translate('Engineering: timing (video)', 'CDS gain:')),      2, 0, Qt.AlignRight)
        eng_tim_vidly.addWidget(self.ui.TSAM,             0, 1, 1, 1, Qt.AlignRight)
        eng_tim_vidly.addWidget(self.ui.TSND,             1, 1, 1, 1, Qt.AlignRight)
        eng_tim_vidly.addWidget(self.ui.CDSG,             2, 1, 1, 2, Qt.AlignRight)
        eng_tim_vidly.addWidget(QLabel(QCoreApplication.translate('Engineering: timing (video)', 'Clocks')),         0, 2, 1, 2, Qt.AlignRight)
        eng_tim_vidly.addWidget(QLabel(QCoreApplication.translate('Engineering: timing (video)', 'Clocks')),         1, 2, 1, 2, Qt.AlignRight)
        eng_tim_vidly.addWidget(QLabel('X'),              2, 3, 1, 1, Qt.AlignRight)

        eng_tim_pargb = QGroupBox()
        eng_tim_pargb.setTitle(QCoreApplication.translate('Engineering: timing (parallel)', ' Parallel '))
        eng_tim_parly = QGridLayout(eng_tim_pargb)
        self.ui.TPPW = QLabel('250')
        self.ui.TPOL = QLabel('125')
        self.ui.TPTR = QLabel('40')
        eng_tim_parly.addWidget(QLabel(QCoreApplication.translate('Engineering: timing (parallel)', 'Pulse width:')), 0, 0, Qt.AlignRight)
        eng_tim_parly.addWidget(QLabel(QCoreApplication.translate('Engineering: timing (parallel)', 'overlap:')),     1, 0, Qt.AlignRight)
        eng_tim_parly.addWidget(QLabel(QCoreApplication.translate('Engineering: timing (parallel)', 'rise/fall:')),   2, 0, Qt.AlignRight)
        eng_tim_parly.addWidget(self.ui.TPPW,           0, 1, Qt.AlignRight)
        eng_tim_parly.addWidget(self.ui.TPOL,           1, 1, Qt.AlignRight)
        eng_tim_parly.addWidget(self.ui.TPTR,           2, 1, Qt.AlignRight)
        eng_tim_parly.addWidget(QLabel(QCoreApplication.translate('Engineering: timing (parallel)', 'Clocks')),       0, 2)
        eng_tim_parly.addWidget(QLabel(QCoreApplication.translate('Engineering: timing (parallel)', 'Clocks')),       1, 2)
        eng_tim_parly.addWidget(QLabel(QCoreApplication.translate('Engineering: timing (parallel)', 'Clocks')),       2, 2)

        eng_tim_sergb = QGroupBox()
        eng_tim_sergb.setTitle(' Serial ')
        eng_tim_serly = QGridLayout(eng_tim_sergb)
        self.ui.TSPW = QLabel('24')
        self.ui.TSOL = QLabel('4')
        self.ui.TSTR = QLabel('8')
        eng_tim_serly.addWidget(QLabel('Pulse width:'), 0, 0, Qt.AlignRight)
        eng_tim_serly.addWidget(QLabel('overlap:'),     1, 0, Qt.AlignRight)
        eng_tim_serly.addWidget(QLabel('rise/fall:'),   2, 0, Qt.AlignRight)
        eng_tim_serly.addWidget(self.ui.TSPW,           0, 1, Qt.AlignRight)
        eng_tim_serly.addWidget(self.ui.TSOL,           1, 1, Qt.AlignRight)
        eng_tim_serly.addWidget(self.ui.TSTR,           2, 1, Qt.AlignRight)
        eng_tim_serly.addWidget(QLabel('Clocks'),       0, 2)
        eng_tim_serly.addWidget(QLabel('Clocks'),       1, 2)
        eng_tim_serly.addWidget(QLabel('Clocks'),       2, 2)

        eng_timly.addWidget(eng_tim_vidgb, 0, 0)
        eng_timly.addWidget(eng_tim_pargb, 1, 0)
        eng_timly.addWidget(eng_tim_sergb, 1, 1)
        # End: Timing Group Box

        def addChannelTab(tab_widget, number):
            tab = QWidget()
            tably = QVBoxLayout(tab)

            bvoltgb = QGroupBox()
            bvoltgb.setTitle(' Bias Voltages ')
            VBHA = QLabel('23.0')
            VBHB = QLabel('12.0')
            VBHC = QLabel('24.0')
            VBLA = QLabel('-3.5')
            VBLB = QLabel('-2.5')
            setattr(self.ui, 'VBHA' + number, VBHA)
            setattr(self.ui, 'VBHB' + number, VBHB)
            setattr(self.ui, 'VBHC' + number, VBHC)
            setattr(self.ui, 'VBLA' + number, VBLA)
            setattr(self.ui, 'VBLB' + number, VBLB)
            bvoltly = QGridLayout(bvoltgb)
            bvoltly.addWidget(QLabel('high A:'), 0, 0)
            bvoltly.addWidget(QLabel('high B:'), 1, 0)
            bvoltly.addWidget(QLabel('high C:'), 2, 0)
            bvoltly.addWidget(VBHA,              0, 1, Qt.AlignRight)
            bvoltly.addWidget(VBHB,              1, 1, Qt.AlignRight)
            bvoltly.addWidget(VBHC,              2, 1, Qt.AlignRight)
            bvoltly.addWidget(QLabel('Volts'),   0, 2, Qt.AlignRight)
            bvoltly.addWidget(QLabel('Volts'),   1, 2, Qt.AlignRight)
            bvoltly.addWidget(QLabel('Volts'),   2, 2, Qt.AlignRight)
            vline = QFrame()
            vline.setFrameShape(QFrame.VLine)
            vline.setFrameShadow(QFrame.Sunken)
            bvoltly.addWidget(vline,             0, 3, 3, 1)
            bvoltly.addWidget(QLabel('low A:'),  0, 4)
            bvoltly.addWidget(QLabel('low B:'),  1, 4)
            bvoltly.addWidget(VBLA,              0, 5, Qt.AlignRight)
            bvoltly.addWidget(VBLB,              1, 5, Qt.AlignRight)
            bvoltly.addWidget(QLabel('Volts'),   0, 6, Qt.AlignRight)
            bvoltly.addWidget(QLabel('Volts'),   1, 6, Qt.AlignRight)

            goffgb = QGroupBox()
            goffgb.setTitle(' Gain/Offset ')
            GAIN = QLabel('1')
            OFFS = QLabel('500')
            ZERO = QLabel('10000')
            setattr(self.ui, 'GAIN' + number, GAIN)
            setattr(self.ui, 'OFFS' + number, OFFS)
            setattr(self.ui, 'ZERO' + number, ZERO)
            goffly = QGridLayout(goffgb)
            goffly.addWidget(QLabel('gain:'), 0, 0)
            goffly.addWidget(GAIN,            0, 1, Qt.AlignRight)
            goffly.addWidget(QLabel('X'),     0, 2)
            vline = QFrame()
            vline.setFrameShape(QFrame.VLine)
            vline.setFrameShadow(QFrame.Sunken)
            goffly.addWidget(vline,           0, 3, 2, 1)
            goffly.addWidget(QLabel('offs:'), 0, 4, Qt.AlignRight)
            goffly.addWidget(QLabel('zero:'), 1, 4, Qt.AlignRight)
            goffly.addWidget(OFFS,            0, 5, Qt.AlignRight)
            goffly.addWidget(ZERO,            1, 5, Qt.AlignRight)
            goffly.addWidget(QLabel('lsb'),   0, 6)
            goffly.addWidget(QLabel('lsb'),   1, 6)

            goffout_ly = QHBoxLayout()
            goffout_ly.addWidget(goffgb)
            goffout_ly.addStretch()

            tably.addWidget(bvoltgb)
            tably.addLayout(goffout_ly)
            tab_widget.addTab(tab, number)

        eng_chngb = QGroupBox()
        eng_chngb.setTitle(' Channels ')
        eng_chnly = QVBoxLayout(eng_chngb)
        eng_chntw = QTabWidget()
        for nmb in range(0, 8):
            addChannelTab(eng_chntw, str(nmb))
        eng_chnly.addWidget(eng_chntw)

        eng_vly.addLayout(eng_grly1)
        eng_vly.addWidget(eng_timgb)
        eng_vly.addWidget(eng_chngb)

        tab_status.addTab(eng_tab, 'Engineering')

        # Define the Debug tab
        debug_tab = QWidget()
        debug_ly  = QVBoxLayout(debug_tab)
        self.ui.appendLayout('DEBUG', debug_ly)

        debug_view = QListView()
        debug_view.setModel(self.debug_model)
        debug_ly.addWidget(debug_view)

        tab_status.addTab(debug_tab, 'Debug')

        # Initialize the Temperature plot
        plt = self.ui.TemperaturePlot
        self.alignScales(plt)
        plt.t = np.arange(-3600.1, 0.0, 0.5)
        plt.x = np.ones(len(plt.t), dtype=float) * -120
        plt.y = np.ones(len(plt.t), dtype=float) * -180

        plt.ccdtemp = QwtPlotCurve('CCD Temp')
        plt.ccdtemp.attach(plt)
        plt.ccdtemp.setPen(QPen(Qt.red))

        plt.ln2temp = QwtPlotCurve('LN2 Temp')
        plt.ln2temp.attach(plt)
        plt.ln2temp.setPen(QPen(Qt.blue))

        plt.setAxisScale(QwtPlot.xBottom, -3600, 0, 600)
        plt.setAxisTitle(QwtPlot.xBottom, ' ')
        plt.setAxisTitle(QwtPlot.yLeft, "<font size=-2><font color='red'>CCD</font>,<font color='blue'>Dewar</font> Temp. (C)</font>")

        # Initialize the Pressure plot
        plt = self.ui.PressurePlot

        logplot = QwtLog10ScaleEngine()
        plt.setAxisScaleEngine(QwtPlot.yLeft,logplot)
        self.alignScales(plt)

        plt.t = np.arange(-3600.1, 0.0, 0.5)
        plt.y = np.ones(len(plt.t), dtype=float) * 10e-5

        plt.plot = QwtPlotCurve(' ')
        plt.plot.attach(plt)
        plt.plot.setPen(QPen(Qt.blue))

        plt.setAxisScale(QwtPlot.xBottom, -3600, 0, 600)
        plt.setAxisTitle(QwtPlot.xBottom, ' ')
        plt.setAxisScale(QwtPlot.yLeft, 10e-7, 10e-4)
        plt.setAxisTitle(QwtPlot.yLeft, "<font size=-2><font color='blue'>Pressure</font> (mBar)")

        # Initialize the debug model

        self.appendDebugLine('Debug 1')
        self.appendDebugLine('Debug 2')
        self.appendDebugLine('Debug 3')

    def setPropertyValue(self, prop_name, value):
        """Takes a string and looks for a member of self.ui whose name matches
           said string. Then it takes the 'value' string and sets it as that
           widget's new text"""
        self.getPropertyByName(prop_name).setText(str(value))

    def setProgress(self, prop_name, status, status_prop = None):
        self.getPropertyByName(prop_name).setValue(status[status_prop or prop_name])

    def setPropertyWithDict(self, prop_name, status, dct, undef = 'Undefined'):
        self.setPropertyValue(prop_name, dct.get(status[prop_name], undef))

    def setPropertyWithFormat(self, prop_name, status, frmt):
        self.setPropertyValue(prop_name, frmt(status[prop_name]))

    def getPropertyByName(self, prop_name):
        return getattr(self.ui, prop_name)

    def __readStatusFromDatabase(self):
        return self.dh.queryCCDStatus()

    @pyqtSlot()
    def updateStatus(self):
        """When triggered, retrieves the current data and updates the display
           with it"""

        try:
            DATA_AGE = self.getPropertyByName('DATA_AGE')
            status = self.__readStatusFromDatabase()

            da = status['DATE_AGE']
            color = (okGreen if da <= self.dataAgeLimit else Qt.red)
            setForegroundColor(DATA_AGE, color)
            DATA_AGE.setText(str(da) + 's')
        except DBException, e:
            setForegroundColor(DATA_AGE, Qt.red)
            DATA_AGE.setText('ERR')
            return

        CAMERA_MODE = self.getPropertyByName('CAMERA_MODE')
        if status['HOLD'] == 1:
            CAMERA_MODE.setText('Hold')
            setForegroundColor(CAMERA_MODE, Qt.red)
        else:
            CAMERA_MODE.setText(dict_camera.get(status['CAMERA_MODE'],'Undefined'))
            setForegroundColor(CAMERA_MODE, okGreen)

        self.setPropertyWithDict('SHUTTER', status, dict_shutter)
        self.setPropertyWithDict('AMPL_MODE0', status, dict_ampl)
        self.setPropertyWithDict('AUTOSAVE', status, dict_autosave)

        for prop in ('TINT_RES', 'TINT'):
            self.setPropertyWithFormat(prop, status, frmt)
        self.setPropertyValue('MULTIEXP',
                              "%s / %s" % (status['MULTACT'],
                                           status['MULTITOT']))
        for prop in ('EXP_PROGRESS', 'READ_PROGRESS', 'DESC_PROGRESS'):
            self.setProgress(prop, status)

        for prop in ('EXP_PROGRESS_2', 'READ_PROGRESS_2', 'MEM_PROGRESS_2', 'FILE_PROGRESS_2'):
            self.setProgress(prop, status, prop[:-2])

        self.setPropertyValue('SPEED_LABEL', status['READ_SPEED'])

        for prop in ('CCDTEMP', 'REFTEMP', 'DEWARTEMP', 'DEWARPRESS',
                     'TSAM', 'TSND', 'CDSG',
                     'TSPW', 'TSOL', 'TSTR',
                     'TPPW', 'TPOL', 'TPTR',):
            self.setPropertyValue(prop, status[prop])

        for n in [str(x) for x in range(4)]:
            for prop in ('VBHA', 'VBHB', 'VBHC', 'VBLA', 'VBLB',
                         'GAIN', 'OFFS', 'ZERO'):
                self.setPropertyValue(prop + n, status[prop + n])

        impath, curfile = status['IMPATH'], status['CUR_FILENAME']
        self.setPropertyValue('CUR_FILENAME', impath + curfile)

        self.plug_iface.updatePlugins(status)

        # Temperature plot update
        plt = self.ui.TemperaturePlot

        # Add the latest value to the arrays and roll to the left
        plt.x[0] = status['CCDTEMP']
        plt.y[0] = status['DEWARTEMP']
        plt.x = np.roll(plt.x, -1)
        plt.y = np.roll(plt.y, -1)

        plt.ccdtemp.setData(plt.t, plt.x)
        plt.ln2temp.setData(plt.t, plt.y)

        plt.replot()

        # Pressure plot update
        plt = self.ui.PressurePlot

        # Add the latest value to the array and roll to the left
        # plt.y[0] = status['DEWARPRESS']
        plt.y[0] = 10e-5 + 10e-6*random()
        plt.y = np.roll(plt.y, -1)

        plt.plot.setData(plt.t, plt.y)

        plt.replot()

    def alignScales(self, plot):
        cnv = plot.canvas()
        cnv.setFrameStyle(QFrame.Box | QFrame.Plain)
        cnv.setLineWidth(1)
        for i in range(QwtPlot.axisCnt):
            scaleWidget = plot.axisWidget(i)
            scaleDraw   = plot.axisScaleDraw(i)

            if scaleWidget:
                scaleWidget.setMargin(0)
            if scaleDraw:
                scaleDraw.enableComponent(QwtAbstractScaleDraw.Backbone, False)

class DBException(Exception):
  pass


class MySQLHandler(object):
    "Wrapper class for retrieving CCD status values from a MySQL databases"

    def __init__(self, config):
        "Initialize the MySQL connection"

	try:
	  # Create a persistent database connection
          self.__cnx = MySQLdb.connect(host=config.get("mysql","host"),
                                       user=config.get("mysql","user"),
                                       passwd=config.get("mysql","passwd"),
                                       db=config.get("mysql","db")
                                       )

          self.main_table = config.get("mysql","status")
          self.plugins = []
 	except MySQLdb.Error, e:
          raise DBException ("Fatal Error: %s (%d)" % (e.args[1], e.args[0]))

    def tuple2dict(self,cursor):
        "Convert a tuple of dictionaries into a dictionary"

        return dict([(x['pos'], x['name']) for x in cursor.fetchall()])


    def close(self):
        "Close database connection"

        if self.__cnx is not None:
            self.__cnx.close()
            self.__cnx = None

    def queryCCDStatus(self):
        "Return a dictionary of CCD status values to be shown in the GUI"

	try:
	    status = {}
	    cursor = self.__cnx.cursor(MySQLdb.cursors.DictCursor)
	    cursor.execute('''SELECT *, TIME_TO_SEC(TIMEDIFF(NOW(),TS)) AS DATE_AGE
                                FROM %s''' % self.main_table)
	    self.__cnx.commit()
	    a = cursor.fetchone()
            for plugin in self.plugins:
                try:
                    a.update(plugin.queryDatabase(cursor))
                except RuntimeError, e:
                    print e

	    return a

	except Exception, e:
          raise DBException ("Error: %s (%s)" % (str(e.__class__), str(e)))

    def appendPlugin(self, plug):
        if plug not in self.plugins:
            self.plugins.append(plug)

def main():
    config = AdvancedConfigParser()
    configpaths = ['./ccd3status.cfg', '/etc/ccd3/ccd3status.cfg']

    try:
        which_conf = [x for x in configpaths if os.path.exists(x)][0]
        config.read(which_conf)
        print >> sys.stderr, "Using '%s' as config file" % (which_conf)
    except IndexError:
        print >> sys.stderr, "Error: Can not find configuration file"
        return 1

    app = QApplication(sys.argv)
    trans = QTranslator()
    trans.load("ccdstatus_" + QLocale.system().name())
    app.installTranslator(trans)

    initialize_strings()

    try:
        mwin = Ccd3StatusMainWindow(config)
    except ConfigParser.NoSectionError, e:
        print >> sys.stderr, "Error when reading the configuration"
        print >> sys.stderr, "There's no section '%s'" % e.section
        return 1
    except ConfigParser.NoOptionError, e:
        print >> sys.stderr, "Error when reading the configuration"
        print >> sys.stderr, "There's no option '%s' in section '%s'" % (e.option, e.section)
        return 1
    except ConfigParser.Error, e:
        print >> sys.stderr, "Error when reading the configuration"
        print >> sys.stderr, e
        return 1
    except DBException, e:
        print >> sys.stderr, e
        return 1

    mwin.show()

    res = app.exec_()

    return res

if __name__ == '__main__':
    sys.exit(main())
