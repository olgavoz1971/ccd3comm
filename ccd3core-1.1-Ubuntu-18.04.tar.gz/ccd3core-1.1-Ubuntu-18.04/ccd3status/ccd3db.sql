-- phpMyAdmin SQL Dump
-- version 3.3.2deb1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 28, 2011 at 01:20 PM
-- Server version: 5.1.41
-- PHP Version: 5.3.2-1ubuntu4.7

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `ccd3db`
--

-- --------------------------------------------------------

--
-- Table structure for table `ALFOSCinst`
--

CREATE TABLE IF NOT EXISTS `ALFOSCinst` (
  `ALAPRTNM` varchar(50) NOT NULL,
  `ALAPRTID` varchar(50) NOT NULL,
  `ALAPRPOS` varchar(50) NOT NULL,
  `ALAPRSTP` varchar(50) NOT NULL,
  `ALAPRALG` varchar(10) NOT NULL,
  `ALFLTNM` varchar(50) NOT NULL,
  `ALFLTID` varchar(50) NOT NULL,
  `ALFLTPOS` varchar(50) NOT NULL,
  `ALFLTSTP` varchar(50) NOT NULL,
  `ALGRNM` varchar(50) NOT NULL,
  `ALGRID` varchar(50) NOT NULL,
  `ALGRPOS` varchar(50) NOT NULL,
  `ALGRSTP` varchar(50) NOT NULL,
  `ALGRALG` varchar(10) NOT NULL,
  `ALFOCUS` varchar(50) NOT NULL,
  `ALCENWAV` varchar(50) NOT NULL,
  `ALAPRSLX` varchar(10) NOT NULL,
  `ALAPRSLY` varchar(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='ALFOSC instrument status';

--
-- Dumping data for table `ALFOSCinst`
--

INSERT INTO `ALFOSCinst` (`ALAPRTNM`, `ALAPRTID`, `ALAPRPOS`, `ALAPRSTP`, `ALAPRALG`, `ALFLTNM`, `ALFLTID`, `ALFLTPOS`, `ALFLTSTP`, `ALGRNM`, `ALGRID`, `ALGRPOS`, `ALGRSTP`, `ALGRALG`, `ALFOCUS`, `ALCENWAV`, `ALAPRSLX`, `ALAPRSLY`) VALUES
('Open', '0', '7', '279150', 'Y', 'Open', '0', '7', '281250', 'Open_(Lyot)', '0', '7', '280100', 'Y', '1810', 'NA', '0.0', '0.0');

-- --------------------------------------------------------

--
-- Table structure for table `ccd3_status`
--

CREATE TABLE IF NOT EXISTS `ccd3_status` (
  `TS` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `CAMERA_MODE` tinyint(4) NOT NULL DEFAULT '0' COMMENT 'Integer describing the camera mode (idle/integrating/readout/shutter_delay)',
  `XTOT` int(11) NOT NULL DEFAULT '0' COMMENT 'Total X size',
  `YTOT` int(11) NOT NULL DEFAULT '0' COMMENT 'Total Y size',
  `XSIZE` int(11) NOT NULL DEFAULT '0' COMMENT 'Window X size',
  `YSIZE` int(11) NOT NULL DEFAULT '0' COMMENT 'Window y size',
  `XBEGIN` int(11) NOT NULL DEFAULT '0' COMMENT 'Beginning of window in X',
  `YBEGIN` int(11) NOT NULL DEFAULT '0' COMMENT 'Beginning of window in Y',
  `XBIN` int(11) NOT NULL DEFAULT '0' COMMENT 'Binning in X',
  `YBIN` int(11) NOT NULL DEFAULT '0' COMMENT 'Binning in Y',
  `AMPL_MODE0` int(11) NOT NULL DEFAULT '0' COMMENT 'Readout amplifier',
  `AMPL_MODE1` int(11) NOT NULL DEFAULT '0',
  `DET_MODE` int(11) NOT NULL DEFAULT '0',
  `INT_MODE` int(11) NOT NULL DEFAULT '0' COMMENT 'Integration mode (auto shutter, auto readout, auto preclear)',
  `TINT` double NOT NULL DEFAULT '0' COMMENT 'Initial integration time',
  `TINT_RES` double NOT NULL DEFAULT '0' COMMENT 'Residual integration time',
  `TINT_ELAPSED` double NOT NULL DEFAULT '0' COMMENT 'Elapsed integration time',
  `HOLD` tinyint(4) NOT NULL DEFAULT '0',
  `SHUTTER` tinyint(4) NOT NULL DEFAULT '0',
  `SH_DELAY` double NOT NULL DEFAULT '0' COMMENT 'Shutter delay',
  `XOVER` int(11) NOT NULL DEFAULT '0' COMMENT 'X overscan',
  `YOVER` int(11) NOT NULL DEFAULT '0' COMMENT 'Y overscan',
  `AOVER` int(11) NOT NULL DEFAULT '0' COMMENT 'Artificial overscan (only on X)',
  `READ_SPEED` int(11) NOT NULL DEFAULT '0' COMMENT 'Readout speed in kpix/sec',
  `READ_PROGRESS` int(11) NOT NULL DEFAULT '0' COMMENT 'Porcentage read out',
  `EXP_PROGRESS` int(11) NOT NULL DEFAULT '0' COMMENT 'Exposure progress in percent',
  `MEM_PROGRESS` int(11) NOT NULL DEFAULT '0',
  `DESC_PROGRESS` int(11) NOT NULL DEFAULT '0',
  `FILE_PROGRESS` int(11) NOT NULL DEFAULT '0',
  `CUR_FILENAME` varchar(80) NOT NULL DEFAULT ' ' COMMENT 'Current filename',
  `IMPATH` varchar(80) NOT NULL DEFAULT ' ' COMMENT 'Image storage path',
  `AUTOSAVE` int(11) NOT NULL DEFAULT '0' COMMENT 'Autosave on/off (1/0) (is image stored after readout',
  `MULTITOT` int(11) NOT NULL DEFAULT '0',
  `MULTACT` int(11) NOT NULL DEFAULT '0',
  `CCDTEMP` double NOT NULL DEFAULT '0',
  `REFTEMP` double NOT NULL DEFAULT '0',
  `DEWARTEMP` double NOT NULL DEFAULT '0',
  `DEWARPRESS` double NOT NULL DEFAULT '0',
  `VBHA0` double NOT NULL DEFAULT '0',
  `VBHB0` double NOT NULL DEFAULT '0',
  `VBHC0` double NOT NULL DEFAULT '0',
  `VBLA0` double NOT NULL DEFAULT '0',
  `VBLB0` double NOT NULL DEFAULT '0',
  `TSAM` int(11) NOT NULL DEFAULT '0',
  `TSPW` int(11) NOT NULL DEFAULT '0',
  `TSOL` int(11) NOT NULL DEFAULT '0',
  `TSND` int(11) NOT NULL DEFAULT '0',
  `TSTR` int(11) NOT NULL DEFAULT '0',
  `GAIN0` double NOT NULL DEFAULT '0',
  `CDSG` int(11) NOT NULL DEFAULT '0',
  `OFFS0` int(11) NOT NULL DEFAULT '0',
  `ZERO0` int(11) NOT NULL DEFAULT '0',
  `TPOL` int(11) NOT NULL DEFAULT '0',
  `TPTR` int(11) NOT NULL DEFAULT '0',
  `TPPW` int(11) NOT NULL DEFAULT '0',
  `VBHA1` double NOT NULL DEFAULT '0',
  `VBHB1` double NOT NULL DEFAULT '0',
  `VBHC1` double NOT NULL DEFAULT '0',
  `VBLA1` double NOT NULL DEFAULT '0',
  `VBLB1` double NOT NULL DEFAULT '0',
  `OFFS1` int(11) NOT NULL DEFAULT '0',
  `ZERO1` int(11) NOT NULL DEFAULT '0',
  `GAIN1` double NOT NULL DEFAULT '0',
  `VBHA2` double NOT NULL DEFAULT '0',
  `VBHB2` double NOT NULL DEFAULT '0',
  `VBHC2` double NOT NULL DEFAULT '0',
  `VBLA2` double NOT NULL DEFAULT '0',
  `VBLB2` double NOT NULL DEFAULT '0',
  `OFFS2` int(11) NOT NULL DEFAULT '0',
  `ZERO2` int(11) NOT NULL DEFAULT '0',
  `GAIN2` double NOT NULL DEFAULT '0',
  `VBHA3` double NOT NULL DEFAULT '0',
  `VBHB3` double NOT NULL DEFAULT '0',
  `VBHC3` double NOT NULL DEFAULT '0',
  `VBLA3` double NOT NULL DEFAULT '0',
  `VBLB3` double NOT NULL DEFAULT '0',
  `OFFS3` int(11) NOT NULL DEFAULT '0',
  `ZERO3` int(11) NOT NULL DEFAULT '0',
  `GAIN3` double NOT NULL DEFAULT '0',
  `XPHY` int(11) NOT NULL DEFAULT '0',
  `YPHY` int(11) NOT NULL DEFAULT '0',
  `WATCH_DOG` tinyint(4) NOT NULL DEFAULT '0' COMMENT 'Will be regularly updated by ccd3comm'
) ENGINE=MEMORY DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ccd3_status`
--

INSERT INTO `ccd3_status` (`TS`, `CAMERA_MODE`, `XTOT`, `YTOT`, `XSIZE`, `YSIZE`, `XBEGIN`, `YBEGIN`, `XBIN`, `YBIN`, `AMPL_MODE0`, `AMPL_MODE1`, `DET_MODE`, `INT_MODE`, `TINT`, `TINT_RES`, `TINT_ELAPSED`, `HOLD`, `SHUTTER`, `SH_DELAY`, `XOVER`, `YOVER`, `AOVER`, `READ_SPEED`, `READ_PROGRESS`, `EXP_PROGRESS`, `MEM_PROGRESS`, `DESC_PROGRESS`, `FILE_PROGRESS`, `CUR_FILENAME`, `IMPATH`, `AUTOSAVE`, `MULTITOT`, `MULTACT`, `CCDTEMP`, `REFTEMP`, `DEWARTEMP`, `DEWARPRESS`, `VBHA0`, `VBHB0`, `VBHC0`, `VBLA0`, `VBLB0`, `TSAM`, `TSPW`, `TSOL`, `TSND`, `TSTR`, `GAIN0`, `CDSG`, `OFFS0`, `ZERO0`, `TPOL`, `TPTR`, `TPPW`, `VBHA1`, `VBHB1`, `VBHC1`, `VBLA1`, `VBLB1`, `OFFS1`, `ZERO1`, `GAIN1`, `VBHA2`, `VBHB2`, `VBHC2`, `VBLA2`, `VBLB2`, `OFFS2`, `ZERO2`, `GAIN2`, `VBHA3`, `VBHB3`, `VBHC3`, `VBLA3`, `VBLB3`, `OFFS3`, `ZERO3`, `GAIN3`, `XPHY`, `YPHY`, `WATCH_DOG`) VALUES
('2011-03-28 12:23:21', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `FASUinst`
--

CREATE TABLE IF NOT EXISTS `FASUinst` (
  `FAFLTNM` varchar(50) NOT NULL,
  `FAFLTID` varchar(10) NOT NULL,
  `FAFLTPOS` varchar(10) NOT NULL,
  `FBFLTNM` varchar(50) NOT NULL,
  `FBFLTID` varchar(10) NOT NULL,
  `FBFLTPOS` varchar(10) NOT NULL,
  `CLAMP1` varchar(10) NOT NULL,
  `CLAMPNM1` varchar(10) NOT NULL,
  `CLAMPID1` varchar(10) NOT NULL,
  `CLAMP2` varchar(10) NOT NULL,
  `CLAMPNM2` varchar(10) NOT NULL,
  `CLAMPID2` varchar(10) NOT NULL,
  `CLAMP3` varchar(10) NOT NULL,
  `CLAMPNM3` varchar(10) NOT NULL,
  `CLAMPID3` varchar(10) NOT NULL,
  `CLAMP4` varchar(10) NOT NULL,
  `CLAMPNM4` varchar(10) NOT NULL,
  `CLAMPID4` varchar(10) NOT NULL,
  `CMIRROR` varchar(10) NOT NULL,
  `FARETARD` varchar(10) NOT NULL,
  `FARETANG` varchar(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='FASU Instrument Status';

--
-- Dumping data for table `FASUinst`
--

INSERT INTO `FASUinst` (`FAFLTNM`, `FAFLTID`, `FAFLTPOS`, `FBFLTNM`, `FBFLTID`, `FBFLTPOS`, `CLAMP1`, `CLAMPNM1`, `CLAMPID1`, `CLAMP2`, `CLAMPNM2`, `CLAMPID2`, `CLAMP3`, `CLAMPNM3`, `CLAMPID3`, `CLAMP4`, `CLAMPNM4`, `CLAMPID4`, `CMIRROR`, `FARETARD`, `FARETANG`) VALUES
('Open', '0', '0', 'Open', '0', '0', '0', ' He ', 'OSRAM He/1', '0', ' Ne ', 'OSRAM Ne/1', '0', ' Halogen', 'OSRAM 6441', '0', ' ThAr Holl', 'Cathodeon ', '0', 'OUT', 'UNKNOWN');

-- --------------------------------------------------------

--
-- Table structure for table `header`
--

CREATE TABLE IF NOT EXISTS `header` (
  `SEQNO` int(11) NOT NULL,
  `NAME` varchar(8) NOT NULL,
  `VALUE` varchar(80) NOT NULL,
  `COMMENT` varchar(80) NOT NULL,
  `DATATYPE` varchar(10) NOT NULL,
  `DESTEXT` int(11) NOT NULL COMMENT 'Destination fits extensions for this keyword',
  `Active` tinyint(1) NOT NULL DEFAULT '1' COMMENT 'Enable this value in fits header',
  KEY `SEQNO` (`SEQNO`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `header`
--

INSERT INTO `header` (`SEQNO`, `NAME`, `VALUE`, `COMMENT`, `DATATYPE`, `DESTEXT`, `Active`) VALUES
(1, 'ALAPRTNM', 'Open', 'ALFOSC aperture wheel. Name', 'TSTRING', 0, 1),
(2, 'ALAPRTID', '0', 'ALFOSC aperture wheel. ID', 'TINT', 0, 1),
(3, 'ALAPRPOS', '7', 'ALFOSC aperture wheel. Slot Position', 'TINT', 0, 1),
(4, 'ALAPRSTP', '279150', 'ALFOSC aperture wheel. Step Position', 'TINT', 0, 1),
(5, 'ALFLTNM', 'Open', 'ALFOSC filter wheel. Name', 'TSTRING', 0, 1),
(6, 'ALFLTID', '0', 'ALFOSC filter wheel. NOT filter number', 'TINT', 0, 1),
(7, 'ALFLTPOS', '7', 'ALFOSC filter wheel. Slot Position', 'TINT', 0, 1),
(8, 'ALFLTSTP', '281250', 'ALFOSC filter wheel. Step Position', 'TINT', 0, 1),
(9, 'ALGRNM', 'Open_(Lyot)', 'ALFOSC grism wheel. Name', 'TSTRING', 0, 1),
(10, 'ALGRID', '0', 'ALFOSC grism wheel. ID', 'TINT', 0, 1),
(11, 'ALGRPOS', '7', 'ALFOSC grism wheel. Slot Position', 'TINT', 0, 1),
(12, 'ALGRSTP', '280100', 'ALFOSC grism wheel. Step Position', 'TINT', 0, 1),
(13, 'ALFOCUS', '1810', 'ALFOSC camera focus position', 'TINT', 0, 1),
(14, 'ALCENWAV', 'N/A', 'ALFOSC spectroscopy center wavelength', 'TSTRING', 0, 1),
(15, 'FAFLTNM', 'Open', 'FASU filter wheel 1/A Name', 'TSTRING', 0, 1),
(15, 'FAFLTID', '0', 'FASU filter wheel 1/A NOT filter number', 'TINT', 0, 1),
(17, 'FAFLTPOS', '0', 'FASU filter wheel 1/A Slot position', 'TINT', 0, 1),
(18, 'FBFLTNM', 'Open', 'FASU filter wheel 2/B Name', 'TSTRING', 0, 1),
(19, 'FBFLTID', '0', 'FASU filter wheel 2/B NOT filter number', 'TINT', 0, 1),
(20, 'FBFLTPOS', '0', 'FASU filter wheel 2/B Slot position', 'TINT', 0, 1),
(21, 'CLAMP1', '0', 'FASU calibration lamp 1 is off', 'TINT', 0, 1),
(22, 'CLAMPNM1', ' He ', 'FASU calibration lamp 1 name', 'TSTRING', 0, 1),
(23, 'CLAMPID1', 'OSRAM He/1', 'FASU calibration lamp 1 id', 'TSTRING', 0, 1),
(24, 'CLAMP2', '0', 'FASU calibration lamp 2 is off', 'TINT', 0, 1),
(25, 'CLAMPNM2', ' Ne ', 'FASU calibration lamp 2 name', 'TSTRING', 0, 1),
(26, 'CLAMPID2', 'OSRAM Ne/1', 'FASU calibration lamp 2 id', 'TSTRING', 0, 1),
(27, 'CLAMP3', '0', 'FASU calibration lamp 3 is off', 'TINT', 0, 1),
(28, 'CLAMPNM3', ' Halogen', 'FASU calibration lamp 3 name', 'TSTRING', 0, 1),
(29, 'CLAMPID3', 'OSRAM 6441', 'FASU calibration lamp 3 id', 'TSTRING', 0, 1),
(30, 'CLAMP4', '0', 'FASU calibration lamp 4 is off', 'TINT', 0, 1),
(31, 'CLAMPNM4', ' ThAr Holl', 'FASU calibration lamp 4 name', 'TSTRING', 0, 1),
(32, 'CLAMPID4', 'Cathodeon ', 'FASU calibration lamp 4 id', 'TSTRING', 0, 1),
(33, 'CMIRROR', '0', 'FASU calibration mirror is out', 'TINT', 0, 1),
(34, 'FARETARD', 'OUT', 'Position of Retarder Plate', 'TSTRING', 0, 1),
(35, 'FARETANG', 'UNKNOWN', 'Retarder Plate Angle', 'TSTRING', 0, 1),
(36, 'ALAPRSLX', '0.0', 'Current aperture detector X pos.', 'TFLOAT', 0, 1),
(37, 'ALAPRSLX', '0.0', 'Current aperture detector X pos.', 'TFLOAT', 0, 1),
(38, 'UT', '15.163611', 'TCS UTC at start (2010-05-17 15:09:49)', 'TDOUBLE', 0, 1),
(39, 'ST', '5.6525', 'Sidereal time at start (05:39:09)', 'TDOUBLE', 0, 1),
(40, 'RA', '84.230398871731', 'Right ascention at start ( 5h:36m:55.3s)', 'TDOUBLE', 0, 1),
(41, 'DEC', '28.996768632623', 'Declination at start (28d:59m:48.4s)', 'TDOUBLE', 0, 1),
(42, 'RADECSYS', 'FK5', '', 'TSTRING', 0, 1),
(43, 'TELALT', '89.7199554443', 'Telescope altitude', 'TDOUBLE', 0, 1),
(44, 'AZIMUTH', '119.2008056641', 'Telescope azimuth', 'TDOUBLE', 0, 1),
(45, 'AIRMASS', '1.0000119449223', 'Airmass at start (sec(z))', 'TDOUBLE', 0, 1),
(46, 'FIELD', '35.3243', 'Field rotation at start', 'TDOUBLE', 0, 1),
(47, 'ROTPOS', '-90', 'Rotator angle at start', 'TDOUBLE', 0, 1),
(48, 'CCDPROBE', 'park', 'CCD probe', 'TSTRING', 0, 1),
(49, 'AUXPOS', '1198', 'Autoguider probe X position', 'TINT', 0, 1),
(50, 'AUYPOS', '4998', 'Autoguider probe Y position', 'TINT', 0, 1),
(51, 'AUBXPOS', '255', 'Autoguider box X position', 'TINT', 0, 1),
(52, 'AUBYPOS', '255', 'Autoguider box Y position', 'TINT', 0, 1),
(53, 'AUSTATUS', '0', 'Autoguider status', 'TINT', 0, 1),
(54, 'TELFOCUS', '24189', 'Telescope focus at start', 'TINT', 0, 1),
(55, 'TCSTGT', '', 'TCS Catalogue Entry', 'TSTRING', 0, 1),
(56, 'OBJRA', '22.7', 'Catalogue RA in decimal deg.', 'TDOUBLE', 0, 1),
(57, 'OBJDEC', '55.2779999986', 'Catalogue DEC in decimal deg.', 'TDOUBLE', 0, 1),
(58, 'OBJPMRA', '0', 'Catalogue proper motion in RA', 'TDOUBLE', 0, 1),
(59, 'OBJPMDEC', '0', 'Catalogue proper motion in DEC', 'TDOUBLE', 0, 1),
(60, 'OBJEQUIN', '2000.0', 'Catalogue equinox for coordinates', 'TFLOAT', 0, 1),
(62, 'OBSGEO-X', '5327395.9638', 'Cartesian Coordinate X', 'TDOUBLE', 0, 1),
(63, 'OBSGEO-Y', '-1719170.4876', 'Cartesian Coordinate Y', 'TDOUBLE', 0, 1),
(64, 'OBSGEO-Z', '3051490.766', 'Cartesian Coordinate Z', 'TDOUBLE', 0, 1),
(70, 'IMAGETYP', '  ', 'Image type', 'TSTRING', 0, 1),
(67, 'QCRDATE', '31-07-1969', 'bah', 'TSTRING', 0, 1),
(105, 'QCDDATE', 'UNDEFINED', 'Detector characteristics reference date', 'TSTRING', 2, 1),
(100, 'DARK', '0.0', 'e-/hr/pix', 'TDOUBLE', 2, 1),
(95, 'GAIN', '0.0', 'e-/ADU', 'TDOUBLE', 1, 1),
(85, 'QCDDATE', 'UNDEFINED', 'Detector characteristics reference date', 'TSTRING', 1, 1),
(80, 'DARK', '0.0', 'e-/hr/pix', 'TDOUBLE', 1, 1),
(72, 'IMAGECAT', '', 'Image category', 'TSTRING', 0, 1),
(71, 'OBS_MODE', '', 'Observing mode', 'TSTRING', 0, 1),
(69, 'OBSERVER', 'Jacob Clasen', 'Observer name', 'TSTRING', 0, 1),
(68, 'OBJECT', 'test object', 'Object name', 'TSTRING', 0, 1),
(90, 'RDNOISE', '0.0', 'e-', 'TDOUBLE', 1, 1),
(110, 'RDNOISE', '0.0', 'e-', 'TDOUBLE', 2, 1),
(115, 'GAIN', '0.0', 'e-/ADU', 'TDOUBLE', 2, 1),
(75, 'BIASSEC', '[1:50,1:2052]', '', 'TSTRING', 1, 1),
(97, 'BIASSEC', '[1025:1074,1:2052]', '', 'TSTRING', 2, 1),
(74, 'TRIMSEC', '[53:1074,1:2052]', '', 'TSTRING', 1, 1),
(76, 'DATASEC', '[53:1074,1:2052]', '', 'TSTRING', 10, 0),
(96, 'TRIMSEC', '[1:1020,1:2052]', '', 'TSTRING', 2, 1),
(98, 'DATASEC', '[1:1020,1:2052]', '', 'TSTRING', 20, 0),
(77, 'CCDSEC', '[1:1022,1:2052]', '', 'TSTRING', 1, 1),
(99, 'CCDSEC', '[1023:2042,1:2052]', '', 'TSTRING', 2, 1);

-- --------------------------------------------------------

--
-- Stand-in structure for view `Keywords`
--
CREATE TABLE IF NOT EXISTS `Keywords` (
`SEQNO` int(11)
,`NAME` varchar(8)
,`VALUE` varchar(80)
,`COMMENT` varchar(80)
,`DATATYPE` varchar(10)
,`DESTEXT` int(11)
);
-- --------------------------------------------------------

--
-- Table structure for table `TCSStatusNow`
--

CREATE TABLE IF NOT EXISTS `TCSStatusNow` (
  `DateTimeUT` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `TimeST` time NOT NULL DEFAULT '00:00:00',
  `PowerIsOn` tinyint(1) NOT NULL DEFAULT '0',
  `AltitudePosDeg` double NOT NULL DEFAULT '0',
  `AzimuthPosDeg` double NOT NULL DEFAULT '0',
  `RotatorPosDeg` double NOT NULL DEFAULT '0',
  `TelescopeModeNumber` tinyint(1) NOT NULL DEFAULT '0',
  `MoveModeNumber` tinyint(1) NOT NULL DEFAULT '0',
  `RotatorIsAutomatic` tinyint(1) NOT NULL DEFAULT '0',
  `FieldRotationDeg` double NOT NULL DEFAULT '0',
  `InstrumentParallacticAngle` double NOT NULL DEFAULT '0',
  `ObjectPointedToObjectNameLength` tinyint(2) NOT NULL DEFAULT '0',
  `ObjectPointedToObjectName` varchar(21) NOT NULL DEFAULT '0',
  `ObjectPointedToRAhours` double NOT NULL DEFAULT '0',
  `ObjectPointedToDECdegrees` double NOT NULL DEFAULT '0',
  `ObjectPointedToEpochYears` double NOT NULL DEFAULT '0',
  `ObjectPointedToRAproMotionArcsecPerYear` double NOT NULL DEFAULT '0',
  `ObjectPointedToDECproMotionArcsecPerYear` double NOT NULL DEFAULT '0',
  `ObjectIsValid` tinyint(1) NOT NULL DEFAULT '0',
  `ObjectRAhours` double NOT NULL DEFAULT '0',
  `ObjectDECdeg` double NOT NULL DEFAULT '0',
  `ReferenceRAhours` double NOT NULL DEFAULT '0',
  `ReferenceDECdeg` double NOT NULL DEFAULT '0',
  `RateRAarcsecPerHour` double NOT NULL DEFAULT '0',
  `RateDECarcsecPerHour` double NOT NULL DEFAULT '0',
  `EquatorialOffsetRAarcsec` double NOT NULL DEFAULT '0',
  `EquatorialOffsetDECarcsec` double NOT NULL DEFAULT '0',
  `PermanentOffsetRAarcsec` double NOT NULL DEFAULT '0',
  `PermanentOffsetDECarcsec` double NOT NULL DEFAULT '0',
  `HorizontalOffsetAltitudeArcsec` double NOT NULL DEFAULT '0',
  `HorizontalOffsetAzimuthArcsec` double NOT NULL DEFAULT '0',
  `ActualRAhours` double NOT NULL DEFAULT '0',
  `ActualDECdeg` double NOT NULL DEFAULT '0',
  `ActualFieldRotDeg` double NOT NULL DEFAULT '0',
  `ZenithDistanceDeg` double NOT NULL DEFAULT '0',
  `AirMass` double NOT NULL DEFAULT '0',
  `RAactualRadJ2000` double NOT NULL DEFAULT '0',
  `DECactualRadJ2000` double NOT NULL DEFAULT '0',
  `UpperHatchOpened` tinyint(1) NOT NULL DEFAULT '0',
  `UpperHatchClosed` tinyint(1) NOT NULL DEFAULT '0',
  `LowerHatchOpened` tinyint(1) NOT NULL DEFAULT '0',
  `LowerHatchClosed` tinyint(1) NOT NULL DEFAULT '0',
  `SidePortNorthOpened` tinyint(1) NOT NULL DEFAULT '0',
  `SidePortNorthClosed` tinyint(1) NOT NULL DEFAULT '0',
  `SidePortEastOpened` tinyint(1) NOT NULL DEFAULT '0',
  `SidePortEastClosed` tinyint(1) NOT NULL DEFAULT '0',
  `SidePortSouthOpened` tinyint(1) NOT NULL DEFAULT '0',
  `SidePortSouthClosed` tinyint(1) NOT NULL DEFAULT '0',
  `SidePortWestOpened` tinyint(1) NOT NULL DEFAULT '0',
  `SidePortWestClosed` tinyint(1) NOT NULL DEFAULT '0',
  `FocusMainPos` smallint(6) NOT NULL DEFAULT '0',
  `FocusDeltaPos` smallint(6) NOT NULL DEFAULT '0',
  `MirrorCoversOpened` tinyint(1) NOT NULL DEFAULT '0',
  `MirrorCoversClosed` tinyint(1) NOT NULL DEFAULT '0',
  `LoadCell1` smallint(6) NOT NULL DEFAULT '0',
  `LoadCell2` smallint(6) NOT NULL DEFAULT '0',
  `LoadCell3` smallint(6) NOT NULL DEFAULT '0',
  `GuideProbeX` mediumint(9) NOT NULL DEFAULT '0',
  `GuideProbeY` mediumint(9) NOT NULL DEFAULT '0',
  `TVisOn` tinyint(1) NOT NULL DEFAULT '0',
  `TVfocusPos` smallint(6) NOT NULL DEFAULT '0',
  `TVfilterNumber` tinyint(2) NOT NULL DEFAULT '0',
  `CameraProbeParked` tinyint(1) NOT NULL DEFAULT '0',
  `CameraProbeInSplitPos` tinyint(1) NOT NULL DEFAULT '0',
  `CameraProbeInCCDpos` tinyint(1) NOT NULL DEFAULT '0',
  `CCDfilterNumber` tinyint(2) NOT NULL DEFAULT '0',
  `CCDfiltNameLength` tinyint(2) NOT NULL DEFAULT '0',
  `CCDfiltName` varchar(21) NOT NULL DEFAULT '0',
  `AutoguiderModeNumber` tinyint(1) NOT NULL DEFAULT '0',
  `StarBoxQuadrantSize` smallint(6) NOT NULL DEFAULT '0',
  `StarBoxPosX` smallint(6) NOT NULL DEFAULT '0',
  `StarBoxPosY` smallint(6) NOT NULL DEFAULT '0',
  `StarBoxAveragePixelIntensity` double NOT NULL DEFAULT '0',
  `BackgroundBoxQSize` smallint(6) NOT NULL DEFAULT '0',
  `BackgroundBoxPosX` smallint(6) NOT NULL DEFAULT '0',
  `BackgroundBoxPosY` smallint(6) NOT NULL DEFAULT '0',
  `BackgroundBoxAveragePixelIntensity` smallint(6) NOT NULL DEFAULT '0',
  `FilteredQuotaX` double NOT NULL DEFAULT '0',
  `FilteredQuotaY` double NOT NULL DEFAULT '0',
  `IntensityOffsetXarcsec` double NOT NULL DEFAULT '0',
  `IntensityOffsetYarcsec` double NOT NULL DEFAULT '0',
  `BoxMotionActive` tinyint(1) NOT NULL DEFAULT '0',
  `BoxMotionRArateArcsecPerHour` double NOT NULL DEFAULT '0',
  `BoxMotionDECrateArcsecPerHour` double NOT NULL DEFAULT '0',
  `BoxAtEdge` tinyint(1) NOT NULL DEFAULT '0',
  `ExternalPowerOK` tinyint(1) NOT NULL DEFAULT '0',
  `TemperatureMachineRoomOK` tinyint(1) NOT NULL DEFAULT '0',
  `TemperatureElectronicsRoomOK` tinyint(1) NOT NULL DEFAULT '0',
  `DomeFansAreOn` tinyint(1) NOT NULL DEFAULT '0',
  `ServiceLoftFansAreOn` tinyint(1) NOT NULL DEFAULT '0',
  `CompressorOK` tinyint(1) NOT NULL DEFAULT '0',
  `WaterLeak` tinyint(1) NOT NULL DEFAULT '0',
  `AdjustingAzimuthTurns` tinyint(1) NOT NULL DEFAULT '0',
  `AutoCloseInAction` tinyint(1) NOT NULL DEFAULT '0',
  `KeepLowerHatchClosed` tinyint(1) NOT NULL DEFAULT '0',
  `KeepUpperHatchClosed` tinyint(1) NOT NULL DEFAULT '0',
  `KeepAwayFromWind` tinyint(1) NOT NULL DEFAULT '0',
  `CPUloadPercentAverageMinute` double NOT NULL DEFAULT '0',
  `AutoguiderAccumulatedAltOffsetArcSec` double NOT NULL DEFAULT '0',
  `AutoguiderAccumulatedAzOffsetArcSec` double NOT NULL DEFAULT '0',
  `AutoguiderUpperLeftQuadrant` double NOT NULL DEFAULT '0',
  `AutoguiderUpperRightQuadrant` double NOT NULL DEFAULT '0',
  `AutoguiderLowerLeftQuadrant` double NOT NULL DEFAULT '0',
  `AutoguiderLowerRightQuadrant` double NOT NULL DEFAULT '0',
  `AutoguiderContrast` double NOT NULL DEFAULT '0',
  `AutoguiderPixIntensityDiff` double NOT NULL DEFAULT '0',
  `AutoguiderPixIntensityDiffLimit` double NOT NULL DEFAULT '0',
  `AutoguiderGuideStarLost` tinyint(1) NOT NULL DEFAULT '0',
  `AutoguiderQuotaAdjustLimit` double NOT NULL DEFAULT '0',
  `AutoguiderQuota_X` double NOT NULL DEFAULT '0',
  `AutoguiderQuota_Y` double NOT NULL DEFAULT '0',
  `AutoguiderX_OffsetArcSec` double NOT NULL DEFAULT '0',
  `AutoguiderY_OffsetArcSec` double NOT NULL DEFAULT '0',
  `AutoguiderAltOffsetArcSec` double NOT NULL DEFAULT '0',
  `AutoguiderAzOffsetArcSec` double NOT NULL DEFAULT '0',
  `ActAltLowerSoftLimitDeg` double NOT NULL DEFAULT '0',
  `ActAltSpeed1sFiltDegPerSec` double NOT NULL DEFAULT '0',
  `ActAzSpeed1sFiltDegPerSec` double NOT NULL DEFAULT '0',
  `ActualRotatorSpeed1sFiltDegPerSec` double NOT NULL DEFAULT '0',
  `ActualStructureTemperature` double NOT NULL DEFAULT '0',
  `ADC_ArmIsOut` tinyint(1) NOT NULL DEFAULT '0',
  `ADC_ArmIsIn` tinyint(1) NOT NULL DEFAULT '0',
  `ADC_Mode` smallint(6) NOT NULL DEFAULT '0',
  `ADC_Prism1initialized` tinyint(1) NOT NULL DEFAULT '0',
  `ADC_Prism1actPosDeg` double NOT NULL DEFAULT '0',
  `ADC_Prism2initialized` tinyint(1) NOT NULL DEFAULT '0',
  `ADC_Prism2actPosDeg` double NOT NULL DEFAULT '0',
  `ADC_MaxReplyTime10minutesInterval` double NOT NULL DEFAULT '0',
  `AltitudeMotor1CurrentFiltered` double NOT NULL DEFAULT '0',
  `AltitudeMotor2CurrentFiltered` double NOT NULL DEFAULT '0',
  `AltitudeBalanceCheck` double NOT NULL DEFAULT '0',
  `AltitudePosErrArcsec` double NOT NULL DEFAULT '0',
  `AutoPositioningMode` smallint(6) NOT NULL DEFAULT '0',
  `AzimuthMotor1CurrentFiltered` double NOT NULL DEFAULT '0',
  `AzimuthMotor2CurrentFiltered` double NOT NULL DEFAULT '0',
  `AzimuthPosErrArcsec` double NOT NULL DEFAULT '0',
  `AzimuthTurns` smallint(6) NOT NULL DEFAULT '0',
  `BuildingMinPosDuringSession` double NOT NULL DEFAULT '0',
  `BuildingMaxPosDuringSession` double NOT NULL DEFAULT '0',
  `BuildingPosErrDeg` double NOT NULL DEFAULT '0',
  `DisplacementPositionError` double NOT NULL DEFAULT '0',
  `FocusPositionError` double NOT NULL DEFAULT '0',
  `FocusSavedValue` double NOT NULL DEFAULT '0',
  `FocusDeltaSavedValue` double NOT NULL DEFAULT '0',
  `InstrumentNameNumber` smallint(6) NOT NULL DEFAULT '0',
  `LowerHatchMoving` tinyint(1) NOT NULL DEFAULT '0',
  `MirrorServo1posErr10sMean` double NOT NULL DEFAULT '0',
  `MirrorServo2posErr10sMean` double NOT NULL DEFAULT '0',
  `MirrorServo3posErr10sMean` double NOT NULL DEFAULT '0',
  `CCDfilter_NOT_Number` smallint(6) NOT NULL DEFAULT '0',
  `CCDfilt_1_NameLength` tinyint(4) NOT NULL DEFAULT '0',
  `CCDfilt_1_Name` varchar(21) NOT NULL DEFAULT '0',
  `CCDfilt_1_NOT_Number` smallint(6) NOT NULL DEFAULT '0',
  `CCDfilt_2_NameLength` tinyint(4) NOT NULL DEFAULT '0',
  `CCDfilt_2_Name` varchar(21) NOT NULL DEFAULT '0',
  `CCDfilt_2_NOT_Number` smallint(6) NOT NULL DEFAULT '0',
  `CCDfilt_3_NameLength` tinyint(4) NOT NULL DEFAULT '0',
  `CCDfilt_3_Name` varchar(21) NOT NULL DEFAULT '0',
  `CCDfilt_3_NOT_Number` smallint(6) NOT NULL DEFAULT '0',
  `CCDfilt_4_NameLength` tinyint(4) NOT NULL DEFAULT '0',
  `CCDfilt_4_Name` varchar(21) NOT NULL DEFAULT '0',
  `CCDfilt_4_NOT_Number` smallint(6) NOT NULL DEFAULT '0',
  `CCDfilt_5_NameLength` tinyint(4) NOT NULL DEFAULT '0',
  `CCDfilt_5_Name` varchar(21) NOT NULL DEFAULT '0',
  `CCDfilt_5_NOT_Number` smallint(6) NOT NULL DEFAULT '0',
  `CCDfilt_6_NameLength` tinyint(4) NOT NULL DEFAULT '0',
  `CCDfilt_6_Name` varchar(21) NOT NULL DEFAULT '0',
  `CCDfilt_6_NOT_Number` smallint(6) NOT NULL DEFAULT '0',
  `CCDfilt_7_NameLength` tinyint(4) NOT NULL DEFAULT '0',
  `CCDfilt_7_Name` varchar(21) NOT NULL DEFAULT '0',
  `CCDfilt_7_NOT_Number` smallint(6) NOT NULL DEFAULT '0',
  `CCDfilt_8_NameLength` tinyint(4) NOT NULL DEFAULT '0',
  `CCDfilt_8_Name` varchar(21) NOT NULL DEFAULT '0',
  `CCDfilt_8_NOT_Number` smallint(6) NOT NULL DEFAULT '0',
  `CCDfilt_9_NameLength` tinyint(4) NOT NULL DEFAULT '0',
  `CCDfilt_9_Name` varchar(21) NOT NULL DEFAULT '0',
  `CCDfilt_9_NOT_Number` smallint(6) NOT NULL DEFAULT '0',
  `OffsetSizeRAarcsec` double NOT NULL DEFAULT '0',
  `OffsetSizeDECarcsec` double NOT NULL DEFAULT '0',
  `PreferredFieldID` smallint(6) NOT NULL DEFAULT '0',
  `ProbeStepSizeXarcsec` double NOT NULL DEFAULT '0',
  `ProbeStepSizeYarcsec` double NOT NULL DEFAULT '0',
  `RotatorMotor1CurrentFiltered` double NOT NULL DEFAULT '0',
  `RotatorMotor2CurrentFiltered` double NOT NULL DEFAULT '0',
  `RotatorBalanceCheck` double NOT NULL DEFAULT '0',
  `RotatorPosErrDeg` double NOT NULL DEFAULT '0',
  `RotatorTimeToLimitMinutes` double NOT NULL DEFAULT '0',
  `TimeSincePoweringOnHours` double NOT NULL DEFAULT '0',
  `TimeSincePoweringOffHours` double NOT NULL DEFAULT '0',
  `TimeSinceRebootHours` double NOT NULL DEFAULT '0',
  `UpperHatchMoving` tinyint(1) NOT NULL DEFAULT '0',
  `RPCserverCounter` int(11) NOT NULL DEFAULT '0',
  `RPCserverDataInBytes` double NOT NULL DEFAULT '0',
  `RPCserverDataOutBytes` double NOT NULL DEFAULT '0',
  `RPCclientCounter` int(11) NOT NULL DEFAULT '0',
  `RPCclientDataOutBytes` double NOT NULL DEFAULT '0',
  `RPCclientDataInBytes` double NOT NULL DEFAULT '0',
  `SocketServerCounter` int(11) NOT NULL DEFAULT '0',
  `SocketServerDataInBytes` double NOT NULL DEFAULT '0',
  `SocketServerDataOutBytes` double NOT NULL DEFAULT '0',
  `SocketClientCounter` int(11) NOT NULL DEFAULT '0',
  `SocketClientDataOutBytes` double NOT NULL DEFAULT '0',
  `SocketClientDataInBytes` double NOT NULL DEFAULT '0',
  `StarBoxContent41x41` blob NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Current TCS Status';

--
-- Dumping data for table `TCSStatusNow`
--

INSERT INTO `TCSStatusNow` (`DateTimeUT`, `TimeST`, `PowerIsOn`, `AltitudePosDeg`, `AzimuthPosDeg`, `RotatorPosDeg`, `TelescopeModeNumber`, `MoveModeNumber`, `RotatorIsAutomatic`, `FieldRotationDeg`, `InstrumentParallacticAngle`, `ObjectPointedToObjectNameLength`, `ObjectPointedToObjectName`, `ObjectPointedToRAhours`, `ObjectPointedToDECdegrees`, `ObjectPointedToEpochYears`, `ObjectPointedToRAproMotionArcsecPerYear`, `ObjectPointedToDECproMotionArcsecPerYear`, `ObjectIsValid`, `ObjectRAhours`, `ObjectDECdeg`, `ReferenceRAhours`, `ReferenceDECdeg`, `RateRAarcsecPerHour`, `RateDECarcsecPerHour`, `EquatorialOffsetRAarcsec`, `EquatorialOffsetDECarcsec`, `PermanentOffsetRAarcsec`, `PermanentOffsetDECarcsec`, `HorizontalOffsetAltitudeArcsec`, `HorizontalOffsetAzimuthArcsec`, `ActualRAhours`, `ActualDECdeg`, `ActualFieldRotDeg`, `ZenithDistanceDeg`, `AirMass`, `RAactualRadJ2000`, `DECactualRadJ2000`, `UpperHatchOpened`, `UpperHatchClosed`, `LowerHatchOpened`, `LowerHatchClosed`, `SidePortNorthOpened`, `SidePortNorthClosed`, `SidePortEastOpened`, `SidePortEastClosed`, `SidePortSouthOpened`, `SidePortSouthClosed`, `SidePortWestOpened`, `SidePortWestClosed`, `FocusMainPos`, `FocusDeltaPos`, `MirrorCoversOpened`, `MirrorCoversClosed`, `LoadCell1`, `LoadCell2`, `LoadCell3`, `GuideProbeX`, `GuideProbeY`, `TVisOn`, `TVfocusPos`, `TVfilterNumber`, `CameraProbeParked`, `CameraProbeInSplitPos`, `CameraProbeInCCDpos`, `CCDfilterNumber`, `CCDfiltNameLength`, `CCDfiltName`, `AutoguiderModeNumber`, `StarBoxQuadrantSize`, `StarBoxPosX`, `StarBoxPosY`, `StarBoxAveragePixelIntensity`, `BackgroundBoxQSize`, `BackgroundBoxPosX`, `BackgroundBoxPosY`, `BackgroundBoxAveragePixelIntensity`, `FilteredQuotaX`, `FilteredQuotaY`, `IntensityOffsetXarcsec`, `IntensityOffsetYarcsec`, `BoxMotionActive`, `BoxMotionRArateArcsecPerHour`, `BoxMotionDECrateArcsecPerHour`, `BoxAtEdge`, `ExternalPowerOK`, `TemperatureMachineRoomOK`, `TemperatureElectronicsRoomOK`, `DomeFansAreOn`, `ServiceLoftFansAreOn`, `CompressorOK`, `WaterLeak`, `AdjustingAzimuthTurns`, `AutoCloseInAction`, `KeepLowerHatchClosed`, `KeepUpperHatchClosed`, `KeepAwayFromWind`, `CPUloadPercentAverageMinute`, `AutoguiderAccumulatedAltOffsetArcSec`, `AutoguiderAccumulatedAzOffsetArcSec`, `AutoguiderUpperLeftQuadrant`, `AutoguiderUpperRightQuadrant`, `AutoguiderLowerLeftQuadrant`, `AutoguiderLowerRightQuadrant`, `AutoguiderContrast`, `AutoguiderPixIntensityDiff`, `AutoguiderPixIntensityDiffLimit`, `AutoguiderGuideStarLost`, `AutoguiderQuotaAdjustLimit`, `AutoguiderQuota_X`, `AutoguiderQuota_Y`, `AutoguiderX_OffsetArcSec`, `AutoguiderY_OffsetArcSec`, `AutoguiderAltOffsetArcSec`, `AutoguiderAzOffsetArcSec`, `ActAltLowerSoftLimitDeg`, `ActAltSpeed1sFiltDegPerSec`, `ActAzSpeed1sFiltDegPerSec`, `ActualRotatorSpeed1sFiltDegPerSec`, `ActualStructureTemperature`, `ADC_ArmIsOut`, `ADC_ArmIsIn`, `ADC_Mode`, `ADC_Prism1initialized`, `ADC_Prism1actPosDeg`, `ADC_Prism2initialized`, `ADC_Prism2actPosDeg`, `ADC_MaxReplyTime10minutesInterval`, `AltitudeMotor1CurrentFiltered`, `AltitudeMotor2CurrentFiltered`, `AltitudeBalanceCheck`, `AltitudePosErrArcsec`, `AutoPositioningMode`, `AzimuthMotor1CurrentFiltered`, `AzimuthMotor2CurrentFiltered`, `AzimuthPosErrArcsec`, `AzimuthTurns`, `BuildingMinPosDuringSession`, `BuildingMaxPosDuringSession`, `BuildingPosErrDeg`, `DisplacementPositionError`, `FocusPositionError`, `FocusSavedValue`, `FocusDeltaSavedValue`, `InstrumentNameNumber`, `LowerHatchMoving`, `MirrorServo1posErr10sMean`, `MirrorServo2posErr10sMean`, `MirrorServo3posErr10sMean`, `CCDfilter_NOT_Number`, `CCDfilt_1_NameLength`, `CCDfilt_1_Name`, `CCDfilt_1_NOT_Number`, `CCDfilt_2_NameLength`, `CCDfilt_2_Name`, `CCDfilt_2_NOT_Number`, `CCDfilt_3_NameLength`, `CCDfilt_3_Name`, `CCDfilt_3_NOT_Number`, `CCDfilt_4_NameLength`, `CCDfilt_4_Name`, `CCDfilt_4_NOT_Number`, `CCDfilt_5_NameLength`, `CCDfilt_5_Name`, `CCDfilt_5_NOT_Number`, `CCDfilt_6_NameLength`, `CCDfilt_6_Name`, `CCDfilt_6_NOT_Number`, `CCDfilt_7_NameLength`, `CCDfilt_7_Name`, `CCDfilt_7_NOT_Number`, `CCDfilt_8_NameLength`, `CCDfilt_8_Name`, `CCDfilt_8_NOT_Number`, `CCDfilt_9_NameLength`, `CCDfilt_9_Name`, `CCDfilt_9_NOT_Number`, `OffsetSizeRAarcsec`, `OffsetSizeDECarcsec`, `PreferredFieldID`, `ProbeStepSizeXarcsec`, `ProbeStepSizeYarcsec`, `RotatorMotor1CurrentFiltered`, `RotatorMotor2CurrentFiltered`, `RotatorBalanceCheck`, `RotatorPosErrDeg`, `RotatorTimeToLimitMinutes`, `TimeSincePoweringOnHours`, `TimeSincePoweringOffHours`, `TimeSinceRebootHours`, `UpperHatchMoving`, `RPCserverCounter`, `RPCserverDataInBytes`, `RPCserverDataOutBytes`, `RPCclientCounter`, `RPCclientDataOutBytes`, `RPCclientDataInBytes`, `SocketServerCounter`, `SocketServerDataInBytes`, `SocketServerDataOutBytes`, `SocketClientCounter`, `SocketClientDataOutBytes`, `SocketClientDataInBytes`, `StarBoxContent41x41`) VALUES
('2009-12-04 11:02:45', '14:44:49', 0, 89.7046508789, 119.0427703857, -90, 0, 0, 0, -90, -90, 0, '', 4.6564305556, 25.2182777772, 2000, 0, 0, 0, 4.666538335, 25.2372468462, 4.6664607748, 25.2434478465, 0, 0, 0, 0, 0, 0, 18.68, 0.7, 14.7197452056, 29.0081707319, 34.82, 0.2953491358, 1.0000132322, 3.8517501556, 0.5070187646, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 23543, 0, 0, 1, 511, 503, 479, 1198, 4998, 0, 478, 0, 1, 0, 0, -1, 9, 'Undefined', 0, 10, 255, 255, 5.71, 5, 400, 400, 5, 1, 1, -2.2200000286, -1.4500000477, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 61.05, 0, 0, 1, 1, 1, 1, 1, 0.01, 0.5, 1, 0.03, 1, 1, 0, 0, 0, 0, 6.02, 0, 0, 0, 10.75, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0.01, 0.04, 0.04, -1, 2.82, 2.83, 0, 99.12, 2.21, 23270, 0, 4, 0, 0, 0, 0, 0, 5, 'U_no6', 6, 5, 'B_no8', 8, 5, 'V_no9', 9, 6, 'R_no10', 10, 6, 'i_no13', 13, 12, 'H_alpha_no29', 29, 11, 'SDSS_z_no86', 86, 11, 'Clear_no126', 126, 8, 'NoFilter', 0, 10, 10, 4, 5, 5, 0, 0, 0, 0, 0, 4.59, 45.34, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '');

-- --------------------------------------------------------

--
-- Table structure for table `WCS`
--

CREATE TABLE IF NOT EXISTS `WCS` (
  `SEQNO` int(11) NOT NULL,
  `NAME` varchar(8) NOT NULL,
  `VALUE` varchar(80) NOT NULL,
  `COMMENT` varchar(80) NOT NULL,
  `DATATYPE` varchar(10) NOT NULL,
  `DESTEXT` int(11) NOT NULL,
  `Active` tinyint(4) NOT NULL DEFAULT '1' COMMENT 'Enable this value in fits header'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `WCS`
--

INSERT INTO `WCS` (`SEQNO`, `NAME`, `VALUE`, `COMMENT`, `DATATYPE`, `DESTEXT`, `Active`) VALUES
(1, 'CTYPE1', 'RA---TAN', 'Gnomonic projection', 'TSTRING', 1, 1),
(2, 'CTYPE2', 'DEC--TAN', 'Gnomonic projection', 'TSTRING', 1, 1),
(3, 'CRVAL1', '84.2303988717', 'RA at reference point', 'TDOUBLE', 1, 1),
(4, 'CRVAL2', '28.9967686326', 'DEC at reference point', 'TDOUBLE', 1, 1),
(5, 'CUNIT1', 'deg', 'Unit of first axis', 'TSTRING', 1, 1),
(6, 'CUNIT2', 'deg', 'Unit of second axis', 'TSTRING', 1, 1),
(7, 'CRPIX1', '-1097915.00', 'Reference pixel on first axis', 'TDOUBLE', 1, 1),
(8, 'CRPIX2', '997.00', 'Reference pixel on second axis', 'TDOUBLE', 1, 1),
(9, 'CD1_1', '-3.05660163005397e-05', 'Transformation matrix for primary WCS', 'TDOUBLE', 1, 1),
(10, 'CD1_2', '-4.31311339009032e-05', 'Transformation matrix for primary WCS', 'TDOUBLE', 1, 1),
(11, 'CD2_1', '-4.31311339009032e-05', 'Transformation matrix for primary WCS', 'TDOUBLE', 1, 1),
(12, 'CD2_2', '3.05660163005397e-05', 'Transformation matrix for primary WCS', 'TDOUBLE', 1, 1),
(1, 'CTYPE1', 'RA---TAN', 'Gnomonic projection', 'TSTRING', 2, 1),
(2, 'CTYPE2', 'DEC--TAN', 'Gnomonic projection', 'TSTRING', 2, 1),
(3, 'CRVAL1', '84.2303988717', 'RA at reference point', 'TDOUBLE', 2, 1),
(4, 'CRVAL2', '28.9967686326', 'DEC at reference point', 'TDOUBLE', 2, 1),
(5, 'CUNIT1', 'deg', 'Unit of first axis', 'TSTRING', 2, 1),
(6, 'CUNIT2', 'deg', 'Unit of second axis', 'TSTRING', 2, 1),
(7, 'CRPIX1', '-1099014.00', 'Reference pixel on first axis', 'TDOUBLE', 2, 1),
(8, 'CRPIX2', '997.00', 'Reference pixel on second axis', 'TDOUBLE', 2, 1),
(9, 'CD1_1', '-3.05660163005397e-05', 'Transformation matrix for primary WCS', 'TDOUBLE', 2, 1),
(10, 'CD1_2', '-4.31311339009032e-05', 'Transformation matrix for primary WCS', 'TDOUBLE', 2, 1),
(11, 'CD2_1', '-4.31311339009032e-05', 'Transformation matrix for primary WCS', 'TDOUBLE', 2, 1),
(12, 'CD2_2', '3.05660163005397e-05', 'Transformation matrix for primary WCS', 'TDOUBLE', 2, 1);

-- --------------------------------------------------------

--
-- Structure for view `Keywords`
--
DROP TABLE IF EXISTS `Keywords`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `Keywords` AS select `header`.`SEQNO` AS `SEQNO`,`header`.`NAME` AS `NAME`,`header`.`VALUE` AS `VALUE`,`header`.`COMMENT` AS `COMMENT`,`header`.`DATATYPE` AS `DATATYPE`,`header`.`DESTEXT` AS `DESTEXT` from `header` where `header`.`Active` union select `WCS`.`SEQNO` AS `SEQNO`,`WCS`.`NAME` AS `NAME`,`WCS`.`VALUE` AS `VALUE`,`WCS`.`COMMENT` AS `COMMENT`,`WCS`.`DATATYPE` AS `DATATYPE`,`WCS`.`DESTEXT` AS `DESTEXT` from `WCS` where `WCS`.`Active`;
