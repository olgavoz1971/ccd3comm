#!/usr/bin/python

from PyQt4.QtCore import Qt, QLineF, QRectF, QCoreApplication
from PyQt4.QtGui import *
from commonplugin import Plugin
from commondetector import CCD
import re

class DetectorSchematic(QGraphicsScene):
    woffset = (100, -100)
    def __init__(self, maxX, maxY, leftOv, rightOv, vertical = True,
                 ampDef = {0: 'b,l', 1: 'b,r'}):
        super(DetectorSchematic, self).__init__(0, 0, maxX + 200, -maxY - 200)
        self.xDim     = maxX
        self.yDim     = maxY
        # self.xBeg     = 1
        # self.yBeg     = 1
        # self.xSize    = maxX
        # self.ySize    = maxY
        self.vertical = vertical

        self.ccd      = CCD(maxX, maxY, leftOv, rightOv, ampDef = ampDef)
        self.addItem(self.ccd)

        self.window = QGraphicsRectItem(QRectF(0, 0, maxX, -maxY), self.ccd)
        self.window.setBrush(QBrush(Qt.white, Qt.SolidPattern))
        self.window.setOpacity(0.9)

        self.window_start = QGraphicsEllipseItem(-5, -5, 10, 10, self.window)
        blue = QColor(50, 50, 255)
        self.window_start.setPen(QPen(blue))
        self.window_start.setBrush(QBrush(blue, Qt.SolidPattern))

        self.readout = QGraphicsRectItem(0, 0, 0, 0, self.window)
        self.readout.setBrush(QBrush(Qt.SolidPattern))

        self.initializeElements()

    @property
    def xBeg(self):
        return self.window.x()

    @property
    def yBeg(self):
        return self.window.y()

    @property
    def xSize(self):
        return self.window.width()

    @property
    def ySize(self):
        return self.window.height()

    def initializeElements(self):
        self.ccd.setPos(*DetectorSchematic.woffset)
        # Window and Window_start positions are relative to
        # their 'parent' object
        self.window.setPos(0, 0)
        self.window_start.setPos(0, 0)
        self.window_start.setScale(6)

    def setDimensions(self, ccdNo, x, y):
        self.xDim, self.yDim = x, y
        self.update()

    def setWindow(self, ccdNo, x, y, xoff, yoff):
        # self.xBeg, self.yBeg = x, y
        # self.xSize, self.ySize = xoff, yoff

        x, y = x - 1, -(y - 1)
        w, h = xoff, -yoff
        c = self.window.rect()
        if (x != c.x()) or (y != c.y()) or (w != c.width()) or (h != c.height()):
            self.window.setRect(x, y, w, h)
            self.window_start.setPos(x, y)
        self.update()

    def setAmplifiers(self, ccdNo, mode):
        self.ccd.setAmpMode(mode)
        self.update()

class DetectorView(QGraphicsView):
    def __init__(self, scene):
        super(DetectorView, self).__init__(scene)
        self.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.setResizeAnchor(QGraphicsView.AnchorViewCenter)
        self.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)
        self.resizeEvent(None)

    def resizeEvent(self, event):
        matrix = QMatrix()
        scene = self.scene()
        denom = min(scene.width() - 150, scene.height() - 150)
        matrix.scale( abs(float(self.width()) / denom),
                      abs(float(self.height()) / denom) )
        self.setMatrix(matrix)

    def updateStatus(self, data):
        scene = self.scene()
        xbin, ybin = data['XBIN'], data['YBIN']
        scene.setWindow(0, data['XBEGIN'] -1,
                           data['YBEGIN'] -1,
                           data['XSIZE'] * xbin,
                           data['YSIZE'] * ybin)
        scene.setAmplifiers(0, data['AMPL_MODE0'])

amp_pos_re = re.compile(r"amp_position\[(\d+)\]")
max_amps = 4
valid_amp_indices = range(max_amps)

def getDetector(config, data):
    try:
        namps = int(config['number_amps'])
        if namps < 1:
            raise RuntimeError("Detector config: 'numbers_amp' must be > 0")
        elif namps > max_amps:
            raise RuntimeError("Detector config: 'numbers_amp' must be <= %d" % max_amps)
    except KeyError:
        raise RuntimeError('Detector config is missing number_amps')
    except ValueError:
        raise RuntimeError("Detector config: 'number_amps' is not an integer")

    ampDef = {}
    try:
        for k, v in config['amp_position'].items():
            index = int(k)
            if index not in valid_amp_indices:
                raise RuntimeError("Detector config: '%s' index out of range" % k)
            ampDef[index] = v.strip()
        ramps = len(ampDef)
    except ValueError, e:
        raise RuntimeError('amp_position[%s] is not a valid keyword' % k)
    except KeyError:
        ramps = 0

    if namps != ramps:
        raise RuntimeError("You've declared %d amplifiers, but configured %d!" %
                           (namps, ramps))

    xsize = int(data.get('XTOT') or config['xsize'])
    ysize = int(data.get('YTOT') or config['ysize'])
    over  = int(data.get('XOVER') or config['overscan'])
    ds = DetectorSchematic(xsize, ysize, over, over, ampDef = ampDef)
    dv = DetectorView(ds)
    dv.origScene = ds

    return dv

def init(config, initial_data, plug_interface):
    plug = Plugin()

    st_geomly = QVBoxLayout()

    st_geomtlably = QGridLayout()
    detsize = QLabel('UNKNOWNxUNKNOWN')
    winbeg = QLabel('UNKNOWN, UNKNOWN')
    winsiz = QLabel('UNKNOWNxUNKNOWN')
    st_geomtlably.addWidget(QLabel(QCoreApplication.translate('CCD Geometry', '<b>Detector size:</b>')), 0, 0)
    st_geomtlably.addWidget(QLabel(QCoreApplication.translate('CCD Geometry', '<b>Window starts:</b>')), 1, 0)
    st_geomtlably.addWidget(QLabel(QCoreApplication.translate('CCD Geometry', '<b>Window dimensions:</b>')), 2, 0)
    st_geomtlably.addWidget(detsize,  0, 1, Qt.AlignRight)
    st_geomtlably.addWidget(winbeg, 1, 1, Qt.AlignRight)
    st_geomtlably.addWidget(winsiz,  2, 1, Qt.AlignRight)
    st_geomly.addLayout(st_geomtlably)

    detector = getDetector(config, initial_data)

    bdot = QLabel(QCoreApplication.translate('CCD Geometry', '<b>(blue dot)</b>'))
    bdot.setSizePolicy(QSizePolicy.MinimumExpanding,
                       QSizePolicy.Preferred)
    st_geomtlably.addWidget(bdot, 1, 3)
    detly = QHBoxLayout()
    detector.setFixedSize(436, 436)
    detly.addStretch()
    detly.addWidget(detector)
    detly.addStretch()
    st_geomly.addLayout(detly)

    st_geomblably = QHBoxLayout()
    st_geomblably.addWidget(QLabel(QCoreApplication.translate('CCD Geometry', '<b>Binning</b>')))
    binning = QLabel('100:100')
    st_geomblably.addWidget(binning)
    st_geomblably.addStretch()
    st_geomblably.addWidget(QLabel(QCoreApplication.translate('CCD Geometry', '<b>Overscan</b>')))
    overscan = QLabel('50:50')
    st_geomblably.addWidget(overscan)
    st_geomly.addLayout(st_geomblably)

    plug.addUiElement('DETSIZE', detsize, lambda x,y: x.setText("%dx%d" % (y['XTOT'], y['YTOT'])))
    plug.addUiElement('WINBEGIN', winbeg, lambda x,y: x.setText("(%d, %d)" % (y['XBEGIN'], y['YBEGIN'])))
    plug.addUiElement('WINSIZE', winsiz, lambda x,y: x.setText("%dx%d" % (y['XSIZE'], y['YSIZE'])))
    plug.addUiElement('BINNING', binning, lambda x,y: x.setText("%d:%d" % (y['XBIN'], y['YBIN'])))
    plug.addUiElement('OVERSCAN', overscan, lambda x,y: x.setText("%d:%d" % (y['XOVER'], y['YOVER'])))
    plug.addUiElement('DETECTOR', detector, lambda x,y: x.updateStatus(y))

    plug_interface.setGeometryLayout(st_geomly)
    plug_interface.showGeometryWidget(True)

    return plug

# Standalone test code
if __name__ == '__main__':
    from PyQt4.QtGui import QWidget, QApplication, QVBoxLayout
    import sys

    app = QApplication(sys.argv)
    ds = DetectorSchematic(2148, 4102, 50, 50, ampDef = {0: 'b,l', 1: 'l,t'})
    # ds = DetectorSchematic(2198, 2052, 50, 50, ampDef = {0: 'b,l', 1: 'l,t'})
    view = DetectorView(ds)
    view.setGeometry(0, 0, 1000, 1000)
    view.show()
    sys.exit(app.exec_())
