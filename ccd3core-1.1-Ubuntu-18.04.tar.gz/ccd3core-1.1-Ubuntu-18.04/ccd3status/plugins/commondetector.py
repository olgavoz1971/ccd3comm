from PyQt4.QtCore import Qt, QPointF, QRectF
from PyQt4.QtGui import QBrush
from PyQt4.QtGui import QPolygonF
from PyQt4.QtGui import QPixmap
from PyQt4.QtGui import QGraphicsPolygonItem, QGraphicsRectItem
import math

checker_xpm = ["20 20 2 1",
               "       c #CCCCCCCCCCCC",
               ".      c #999999999999",
               "          ..........",
               "          ..........",
               "          ..........",
               "          ..........",
               "          ..........",
               "          ..........",
               "          ..........",
               "          ..........",
               "          ..........",
               "          ..........",
               "..........          ",
               "..........          ",
               "..........          ",
               "..........          ",
               "..........          ",
               "..........          ",
               "..........          ",
               "..........          ",
               "..........          ",
               "..........          "]

class Amplifier(QGraphicsPolygonItem):
    def __init__(self, parent = 0):
        p = QPolygonF([QPointF(1, 0),
                       QPointF(0, math.sqrt(3)),
                       QPointF(-1, 0)])
        super(Amplifier, self).__init__(p, parent)
        self.setBrush(QBrush(Qt.SolidPattern))
        self.setActive(False)

    def setActive(self, status):
        self.setVisible(status is True)

class CCD(QGraphicsRectItem):
    def __init__(self, width, height, lo, ro, ampDef):
        rect = QRectF(0, 0, width, -height)
        super(CCD, self).__init__(rect)
        self.setBrush(QBrush(QPixmap(checker_xpm)))

        self.lOver = QGraphicsRectItem(0, 0, lo, -height, self)
        self.rOver = QGraphicsRectItem(0, 0, ro, -height, self)
        self.lOver.setBrush(QBrush(Qt.SolidPattern))
        self.rOver.setBrush(QBrush(Qt.SolidPattern))

        self.amplifiers = {}

        self.ampMode  = 0

        self.w, self.h = width, height
        self.lo, self.ro = lo, ro

        self.initializeElements(ampDef)
        self.setAmpMode(255)

    @property
    def nAmpl(self):
        return len(self.amplifiers)

    def initializeElements(self, ampDef):
        # TODO: Change the overscan to match CCD orientation
        self.lOver.setPos(0, 0)
        self.rOver.setPos(self.w - self.ro, 0)

        for index, pos in ampDef.items():
            amp = Amplifier(self)
            amp.setScale(30)
            self.setAmpPosition(amp, pos)
            self.amplifiers[index] = amp

    def setAmpMode(self, mode):
        if mode == self.ampMode:
            return

        for index, amp in self.amplifiers.items():
            amp.setActive((mode & (1 << index)) != 0)
        self.ampMode = mode

    possibleAmpPositions = ( ('b','l'), ('b','r'),
                             ('t','l'), ('t','r'),
                             ('l','t'), ('l','b'),
                             ('r','t'), ('r','b') )

    def setAmpPosition(self, amp, pos):
        badAmpDef = RuntimeError('Bad amplifier definition: ' + pos)
        try:
            primary, secondary = [x.strip().lower() for x in pos.split(',')]
        except ValueError:
            raise badAmpDef

        if (primary, secondary) not in CCD.possibleAmpPositions:
            raise badAmpDef

        if primary == 'b':
            rot = 0
            x, y = ((60, 15) if secondary == 'l' else
                    (self.w - 60, 15))
        elif primary == 't':
            rot = 180
            x, y = ((60, -(self.h + 30)) if secondary == 'l' else
                    (self.w - 60, -(self.h + 30)))
        elif primary == 'l':
            rot = 90
            x, y = ((-30, -60) if secondary == 'b' else
                    (-30, -(self.h - 60)))
        elif primary == 'r':
            rot = 270
            x, y = ((self.w + 15, -60) if secondary == 'b' else
                    (self.w + 15, -(self.h - 60)))

        amp.setRotation(rot)
        amp.setPos(x, y)
