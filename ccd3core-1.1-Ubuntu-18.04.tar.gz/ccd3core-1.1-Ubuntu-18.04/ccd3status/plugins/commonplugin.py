class Plugin(object):
    def __init__(self, uses_db = False):
        self.ui_elements = {}
        self._database_user = uses_db

    def addUiElement(self, name, element, update = None):
        self.ui_elements[name] = (element, update)

    def update(self, status):
        for name, (element, updater) in self.ui_elements.items():
            if not updater:
                element.setText(str(status.get(name, 'UNKNOWN')))
            else:
                updater(element, status)

    @property
    def queriesDatabase(self):
        return self._database_user

    def queryDatabase(self, cursor):
        raise RuntimeError("Not implemented")
