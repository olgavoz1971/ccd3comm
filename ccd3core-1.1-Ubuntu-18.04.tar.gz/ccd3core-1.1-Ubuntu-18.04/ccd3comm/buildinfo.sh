#!/bin/sh
BUILD_TARGET=buildinfo.h
VERSION_TARGET=svninfo.h
TMP_VERSION_TARGET=svninfo.tmp.h
MD5_TARGET=md5sum.h
echo "generating build info"

echo '#include "'$VERSION_TARGET'"' > $BUILD_TARGET
gcc --version  | awk 'NR == 1' | awk '{print "#define GCC_VERSION \"" $1" "$2" "$3" "$4" "$5" "$6" "$7 "\""}' >> $BUILD_TARGET
echo "#define C_FLAGS $1" >> $BUILD_TARGET
ld --version  | awk 'NR == 1' | awk '{print "#define LD_VERSION \"" $1" "$2" "$3" "$4" "$5" "$6" "$7 "\""}' >> $BUILD_TARGET
echo "#define L_FLAGS $2" >> $BUILD_TARGET
hostname -A | awk '{print "#define HOST_NAME \""$1"\""}' >> $BUILD_TARGET
uname -posrim | awk '{print "#define OS_VERSION \""$1" "$2" "$3" "$6"\""}' >> $BUILD_TARGET
whoami | awk '{print "#define CURRENT_USER \""$1"\""}' >> $BUILD_TARGET
echo '#define BUILD_DATE "'`date`'"' >> $BUILD_TARGET

REVISION=$(svnversion .)

if [ "0" = "$?" ]; then
    echo "#define SVN_REVISION \"$REVISION\"" > $TMP_VERSION_TARGET
    cmp -s $VERSION_TARGET $TMP_VERSION_TARGET
    if [ "0" != "$?" ]; then
	mv -f $TMP_VERSION_TARGET $VERSION_TARGET
    fi
    rm -f $TMP_VERSION_TARGET
fi

