/*
 *  Copyright (c) 2007 Copenhagen University Astronomical Observatory
 *  All possible rights reserved
 *	Filename:	ccd3engine.cpp
 *  Abstract:
 *  Author:		Jeppe Jønch Andersen (jja@astro.ku.dk)
 *  Revision:
 *  Remarks:
 */

#include <sys/time.h>
#include <unistd.h>
#include <math.h>
#include <signal.h>
#include <stdarg.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <errno.h>
#include <assert.h>
#ifdef MEMWATCH
	#include <memwatch.h>
#endif
#include "ccd3_engine.h"
#include "ccd3_con.h"
#include "common.h"
#include "ccd3_log.h"

// Prototype for callback routines
void SilentDmyCallback(HSUBSCRIPTION hSubscription, char* data, void* parm);
void ExposureDmyCallback(HSUBSCRIPTION hSubscription, char* data, void* parm);
void ReadoutDmyCallback(HSUBSCRIPTION hSubscription, char* data, void* parm);
void DrvDmyCallback(HSUBSCRIPTION hSubscription, char* data, void* parm);
void IvyDmyCallback(IvyClientPtr app, void* data, int argc, char** argv);

const int TOKEN_LEN = 14;
const int UPDATE_TOKEN_COUNT = 31;
const char UpdateTokens[UPDATE_TOKEN_COUNT][TOKEN_LEN] = {
	"?xsiz",
	"?ysiz",
	"?deav",
	"?deen",
	"?rdav",
	"?rden",
	"?xbeg",
	"?ybeg",
	"?xbin",
	"?ybin",
	"?time",
	"?tmpw",
	"?tmpa",
	"?tmpl",
	"?pres",
	"?shut",
	"?stat",
	"?rexp",
	"?tsam",
	"?fpix",
	"?vshi",
	"?vslo",
	"?vphi",
	"?vplo",
	"?vbha 0",
	"?vbhb 0",
	"?vbhc 0",
	"?vbla 0",
	"?vblb 0",
	"?zero 0",
	"?gain 0"
};

// messages tokens used in idle conditions
const int IDLE_TOKEN_COUNT = 4;
const char IdleTokens[IDLE_TOKEN_COUNT][TOKEN_LEN] = {
	"?stat",
	"?pres",
	"?tmpl",
	"?tmpa"/*,
	DRV_QUESTION " " DRV_RX,
	DRV_QUESTION " " DRV_QUEUE*/
};

// message tokens used during exposure
const int EXPOSURE_TOKEN_COUNT = 3;
const char ExposureTokens[EXPOSURE_TOKEN_COUNT][TOKEN_LEN] = {
		"?stat",
		"?tima",
		"?timr"
};

// message tokens used when transferring data
const int READOUT_TOKEN_COUNT = 4;

const char ReadoutTokens[READOUT_TOKEN_COUNT][TOKEN_LEN] = {
	"?stat",
	DRV_QUESTION " " DRV_PROGRESS,
	"?tima",
	DRV_QUESTION " " DRV_PROGRESS
};

// message tokens used when communication is in trouble
const int COMM_TOKEN_COUNT = 3;
const char CommTokens[COMM_TOKEN_COUNT][TOKEN_LEN] = {
	DRV_QUESTION " " DRV_RX,
	DRV_QUESTION " " DRV_TX,
	DRV_QUESTION " " DRV_MEM,
//	DRV_QUESTION " " DRV_QUEUE,
	//DRV_QUESTION " " DRV_RESET,
};

const char IVY_PORT_STR[] =  "2010";

// Engine class. This class is providing the main logical functionality of the CCD3 device.
//////////////////////////////////////////////////////////////////////////////
// Constructor

cCCD3engine::cCCD3engine(ccd3_array_schema* a_array_schema, int a_blocksize)
{
	FatalErr = false;
	array_schema = a_array_schema;
	blocksize = a_blocksize;

	fctl = NULL;
	fdata = NULL;

	// Default CAM parameters
    ybin = 1;
    xbin = 1;
    xbeg = 1;
    ybeg = 1;
    rexp = 1;
    ccdtemp = 0;
    ln2temp = 0;
    p_dewar = 0;
    shutter = 0;
    time_actual = 0;
    pci_mem_size = 0;
    watch_dog = 0;
    test_skipoffload = false;
    delay_filewrite = true;
//    rm_std_comment = false;
    rm_std_comment = true;

	comm_down = false;
	last_comm_lost = false;
	disregard_brek = false;
	do_quit = false;

	allow_fileclose = true;
    rx_ok = true;
    tx_ok = true;
	State = csIdle;
	LastState = State;
    exposure_token_idx = 0;
    readout_token_idx = 0;
    idle_token_idx = 0;
    comm_token_idx = 0;
    processing = false;
    cam_busy = false;
    n_window = 1;
    ds9 = NULL;
	fits_processor = NULL;
	shm_processor = NULL;
	stat_processor = NULL;
	descrambler = NULL;

	mptr = NULL;
	shm = NULL;
	
	preview = NULL;

	gettimeofday(&startup_time, NULL);
	gettimeofday(&last_comm, NULL);

	// Create two BYTE fifo's for command channel
	rx_cmd_buf = new cFifo(BUFFER_SIZE);			 // 8 bit rx cmd buffer
	Subscriptions = new SubscriptionQueue(MAX_SUBSCRIPTIONS, MAX_CALLBACK);

    hLastQuery = 0;
	hXsiz  = Subscriptions->Subscribe("!xsiz", SilentDmyCallback, this);
	hYsiz  = Subscriptions->Subscribe("!ysiz", SilentDmyCallback, this);
	hXbeg  = Subscriptions->Subscribe("!xbeg", SilentDmyCallback, this);
	hYbeg  = Subscriptions->Subscribe("!ybeg", SilentDmyCallback, this);
	hXbin  = Subscriptions->Subscribe("!xbin", SilentDmyCallback, this);
	hYbin  = Subscriptions->Subscribe("!ybin", SilentDmyCallback, this);
	hShut  = Subscriptions->Subscribe("!shut", SilentDmyCallback, this);
	hTemp  = Subscriptions->Subscribe("!tmpa", SilentDmyCallback, this);
	hTset  = Subscriptions->Subscribe("!tmpw", SilentDmyCallback, this);
	hTln2  = Subscriptions->Subscribe("!tmpl", SilentDmyCallback, this);
	hPres  = Subscriptions->Subscribe("!pres", SilentDmyCallback, this);
	hTime  = Subscriptions->Subscribe("!time", SilentDmyCallback, this);
	hStat  = Subscriptions->Subscribe("!stat", SilentDmyCallback, this);
	hTimr  = Subscriptions->Subscribe("!timr", SilentDmyCallback, this);
	hTima  = Subscriptions->Subscribe("!tima", SilentDmyCallback, this);
	hRden  = Subscriptions->Subscribe("!rden", SilentDmyCallback, this);
	hRdav  = Subscriptions->Subscribe("!rdav", SilentDmyCallback, this);
	hBrek  = Subscriptions->Subscribe("!brek", SilentDmyCallback, this);
	hSint  = Subscriptions->Subscribe("!sint", SilentDmyCallback, this);
	hFres  = Subscriptions->Subscribe("!fres", SilentDmyCallback, this);
	hRexp  = Subscriptions->Subscribe("!rexp", SilentDmyCallback, this);
	hDeav  = Subscriptions->Subscribe("!deav", SilentDmyCallback, this);
	hDeen  = Subscriptions->Subscribe("!deen", SilentDmyCallback, this);
	hTsam  = Subscriptions->Subscribe("!tsam", SilentDmyCallback, this);
	hFpix  = Subscriptions->Subscribe("!fpix", SilentDmyCallback, this);
	hVshi  = Subscriptions->Subscribe("!vshi", SilentDmyCallback, this);
	hVslo  = Subscriptions->Subscribe("!vslo", SilentDmyCallback, this);
	hVphi  = Subscriptions->Subscribe("!vphi", SilentDmyCallback, this);
	hVplo  = Subscriptions->Subscribe("!vplo", SilentDmyCallback, this);
    hVbha  = Subscriptions->Subscribe("!vbha", SilentDmyCallback, this);
    hVbhb  = Subscriptions->Subscribe("!vbhb", SilentDmyCallback, this);
    hVbhc  = Subscriptions->Subscribe("!vbhc", SilentDmyCallback, this);
    hVbla  = Subscriptions->Subscribe("!vbla", SilentDmyCallback, this);
    hVblb  = Subscriptions->Subscribe("!vblb", SilentDmyCallback, this);
    hZero  = Subscriptions->Subscribe("!zero", SilentDmyCallback, this);
    hGain  = Subscriptions->Subscribe("!gain", SilentDmyCallback, this);
    hOffs  = Subscriptions->Subscribe("!offs", SilentDmyCallback, this);
    hComm  = Subscriptions->Subscribe("!comm", SilentDmyCallback, this);

	hError = Subscriptions->Subscribe("!ERROR", SilentDmyCallback, this);
	hDrv   = Subscriptions->Subscribe(DRV_ANSWER, DrvDmyCallback, this);
	hProgress = Subscriptions->Subscribe(DRV_ANSWER " " DRV_PROGRESS, ReadoutDmyCallback, this);

}

//////////////////////////////////////////////////////////////////////////////
// Destructor

cCCD3engine::~cCCD3engine(void)
{
	if( Busy() ){
		CommandCam((char*)"brek");
	}
	
	CloseProcessingString();

	if( mptr && mptr != MAP_FAILED ){
		munmap(mptr, pci_mem_size);
		mptr = NULL;
	}

	if( fctl ){
		fclose(fctl);
		fctl = NULL;
	}

	if( fdata ){
		fclose(fdata);
		fdata = NULL;
	}

	if(rx_cmd_buf){
		delete rx_cmd_buf;
		rx_cmd_buf = NULL;
	}

	if(shm){
		delete shm;
		shm = NULL;
	}

	if( Subscriptions ){
		delete Subscriptions;
		Subscriptions = NULL;
	}

}

//////////////////////////////////////////////////////////////////////////////
// Let externals subscribe to messages

HSUBSCRIPTION cCCD3engine::Subscribe(const char* cmd, SubscriptionCallback Callback, void* UserData, DWORD Mode)
{
	return Subscriptions->Subscribe(cmd, Callback, UserData, Mode);
}

//////////////////////////////////////////////////////////////////////////////
// Default callback

void cCCD3engine::SubscribeDefault(SubscriptionCallback Callback, void* UserData, DWORD Mode)
{
	Subscriptions->SubscribeDefault(Callback, UserData, Mode);
}

//////////////////////////////////////////////////////////////////////////////
// Update all interal metrics from controller

bool cCCD3engine::Update(void)
{
	int res;

	try{

		for(int idx = 0; idx < UPDATE_TOKEN_COUNT && !do_quit; idx ++){
			res = SendString( UpdateTokens[idx] );
			if( res > 0){
				PRINT(L_NORMAL, ".");
			} else {
				PRINT(L_NORMAL, "..failed!\n");
				return false;
			}
		}

	} catch(common_exception &ex){
		PRINT(L_ERROR, "..failed (\"%s\")\n", ex.what());
		return false;
	}
	return true;
}

//////////////////////////////////////////////////////////////////////////////
//  Stop further processing

void cCCD3engine::Quit(void){
	do_quit = true;
}

//////////////////////////////////////////////////////////////////////////////
// Wait until reading is possible on any of the filedescriptors in filedes

int cCCD3engine::Wait_IO(int* filedes, int size, bool persistent)
{
	int n, ret;
	char char_buf[BUFFER_SIZE];
	char* ch_ptr;
	fd_set set;
	struct timeval timeout = { 0, 0};
	struct timeval now;
	struct timeval diff_time;
	static bool handling_event = false;

	do { // forever
		do { // while descriptor not signaled

			FD_ZERO(&set);

			// Get user descriptors
			for(n=0; n < size && !wait_reply; n++){
				FD_SET(filedes[n], &set);
			}

			// Add control file descriptor also
			FD_SET(fileno(fctl), &set);

			timeout.tv_usec = Busy() ? CCD3_ACTIVE_UPDATE_INTERVAL : CCD3_IDLE_UPDATE_INTERVAL;

			// Wait for user descriptor or ctl
			if( (ret = select(FD_SETSIZE, &set, NULL, NULL, &timeout)) == -1 ){
				throw ECCD3Engine("Failed waiting for I/O ()", errno);
			}

			if( do_quit ){
				return 0;
			}

			if( !ret ){
				if( wait_reply && !comm_down ){
					// Check comm timeout
					gettimeofday(&now, NULL);
					timersub(&now, &last_comm, &diff_time);
					if( diff_time.tv_sec * 1000000 + diff_time.tv_usec > MAX_COMM_TIMEOUT){
						comm_down = true;
						printf("comm timeout\n");
					}
					/*if( diff_time.tv_sec * 1000000 + diff_time.tv_usec > MAX_COMM_TIMEOUT){
						char tmp[] = "!ERROR Controller not responding!";
						CON->IvySend(ivy_comm_error, tmp);
						Subscriptions->HandleEvent(tmp);
						gettimeofday(&last_comm, NULL);
						wait = false;

						if( hLastQuery ){
							Subscriptions->Unsubscribe(hLastQuery);
							hLastQuery = NULL;
						}
						//SendString(DRV_COMMAND " " DRV_RESET);
						return 0;
					}*/

				} else { // timeout
					// If time to request transfer progress
					// Note: value in timeout when select() returns are different in
					// linux to other unix'es ... handle as undefined for portability

					if( comm_down ) {
						if( wait_reply )
							return Reset() ? 0 : -1;
						else if( 0 > SendString(CommTokens[comm_token_idx++ % COMM_TOKEN_COUNT])){
							return Reset() ? 0 : -1;
						}
					} else if( processing ){
						SendString( ReadoutTokens[readout_token_idx++ % READOUT_TOKEN_COUNT]);
					} else if( cam_busy ){
						SendString( ExposureTokens[exposure_token_idx++ % EXPOSURE_TOKEN_COUNT]);
					} else {
						switch( State ){
						case csIdle:
							CON->IvySend(ivy_application_idle, "%d", watch_dog++ % 2);
							SendString(IdleTokens[idle_token_idx++ % IDLE_TOKEN_COUNT]);
							break;
						case csClearing:
						case csShutterDelay:
						case csIntegrating:
							rx_cmd_buf->put((void*)"!sint\n", 6);
							cam_busy = true;
							//StartExposure();
							//SendString( ExposureTokens[exposure_token_idx++ % EXPOSURE_TOKEN_COUNT]);
							break;
						case csReadout:
							SendString( ReadoutTokens[readout_token_idx++ % READOUT_TOKEN_COUNT]);
							break;
						default: throw ECCD3Engine("Unknown camera state? (%d)", (int)State);
						}
					}
				}
			} // if (!ret)

		} while (!ret);

		// if ctl data
		if( FD_ISSET(fileno(fctl), &set) ){
				n = min(rx_cmd_buf->free(), BUFFER_SIZE);
				ret = fread(char_buf, 1, n, fctl);

				char_buf[ret] = '\0';

				if( ret != rx_cmd_buf->put(char_buf, ret)){
					throw ECCD3Engine("character buffer overrun!");
				}

				gettimeofday(&last_comm, NULL);

				for(ch_ptr = char_buf; ch_ptr;){
					ch_ptr = strchr(ch_ptr,'\n');
					if(ch_ptr) {
						ch_ptr++;
						wait_reply ? wait_reply-- : wait_reply;
					}
				}

		} // if ctl data


		if( !handling_event ){

			// If a complete line was recived from cam
			while( (n = rx_cmd_buf->indexof((void*)"\n")) != -1 ){
				rx_cmd_buf->get(char_buf, n+1);
				char_buf[n]=0;
				CON->IvySend(ivy_cam_reply, "%s", char_buf);
				// Check line agains queries
				handling_event = true;
				try {
					Subscriptions->HandleEvent(char_buf);
				} catch(ESubscriptionQueue &ex){
					// The callback event made a pooh!!
					//PRINT(L_ERROR, "Failed handling event: \"%s\" with message: \"%s\"\n", char_buf, ex.what());
					handling_event = false;
					throw;
					//break;
				}
				handling_event = false;
			} // while (complete replies in buffer)
		} // if( !handling_event ..

		// if signal on user descriptors
		for(n=0; n < size; n++){
			if(FD_ISSET(filedes[n], &set)) return n;
		}

		if( !persistent && !wait_reply ) return 0;

	} while( FOREVER ); // while

	// something is terrible wrong here !"#¤!"#
	throw ECCD3Engine("Unexpected condition found in Wait_IO");
}

//////////////////////////////////////////////////////////////////////////////
// Service wrapper

int cCCD3engine::Wait_IO(int filedes, bool persistent)
{
	int arr[1] = {filedes};
	return Wait_IO(arr, 1, persistent);
}

//////////////////////////////////////////////////////////////////////////////
// Service wrapper

int cCCD3engine::Wait_IO(bool persistent)
{
	return Wait_IO(NULL, 0, persistent);
}

//////////////////////////////////////////////////////////////////////////////
// Suspend execution for usecs
void cCCD3engine::Sleep(int usecs)
{
	usleep(usecs);
	gettimeofday(&last_comm, NULL);
}
//////////////////////////////////////////////////////////////////////////////
// Request driver to reset

bool cCCD3engine::Reset(void)
{
	static bool is_resetting = false;
	int retry_cnt = 0;

	if( is_resetting ){
		// Don't recurse resets
		return false;
	}

	is_resetting = true;

	while( is_resetting && !do_quit ) {

		if( retry_cnt++ ){
			Sleep(CCD3_INIT_RETRY_INTERVAL);
			PRINT(L_NORMAL, "\n");
		}

		PRINT(L_NORMAL, "Connecting to controller ..");
		CON->IvySend(ivy_application_reset);
		wait_reply = 0;
		cam_busy = false;
		processing = false;
		timerclear(&start_time);
		timerclear(&end_time);


		if( InitComm() && !do_quit){
			if( Update() ){
				PRINT(L_NORMAL, "\n");
				//CON->Prompt();
				is_resetting = false;
				break;
			}
		}
	}
	return true;
}

///////////////////////////////////////////////////////////////////////////////

void cCCD3engine::SilentCallback(HSUBSCRIPTION Subscription)
{
	int tmp;
	DWORD new_read;
	DWORD detector_no;
	DWORD channel_no;
	float tmp_float;

	char *result = Subscriptions->GetResponse(Subscription);

	if( Subscription == hError ){
		if( hLastQuery ){
			Subscriptions->Unsubscribe(hLastQuery);
		}
		return;
	}

	if( Subscription == hBrek ){
		if( !disregard_brek ){
			EndReadout();
		}
		return;
	}

	if( Subscription == hRexp ){
		if( 1 != sscanf(result, "%lu", &rexp)){
			PRINT(L_ERROR, "Could not translate rexp: \"%s\"\n", result);
		}
		return;
	}

	if( Subscription == hTime ){

		if( 1 != sscanf(result,"%lu",&exp_time)){
			PRINT(L_ERROR, "Could not translate time: \"%s\"\n", result);
		}
		return;

	}

	if( Subscription == hRden ){

		if( 2 != sscanf(result, "%lu %lu",&detector_no, &new_read)){
			PRINT(L_ERROR, "Could not translate rden: \"%s\"\n", result);
			return;
		}

		array_schema->get_detector_schema(detector_no)->set_enabled_amps(new_read);

		if( !detector_no ){
			while ( ++detector_no < array_schema->get_detectors_enabled() ){
				SendString("?rden %d", detector_no);
			}
		}
		return;
	}

	if( Subscription == hXsiz ){
		unsigned new_xsiz;
		if( 1 != sscanf(result,"%u",&new_xsiz)){
			PRINT(L_ERROR, "Could not translate xsiz: \"%s\"\n", result);
		} else {
			array_schema->set_detector_xsiz(new_xsiz);
		}
		return;

	}

	if( Subscription == hYsiz ){
		unsigned new_ysiz;
		if( 1 != sscanf(result,"%u",&new_ysiz)){
			PRINT(L_ERROR, "Could not translate ysiz: \"%s\"\n", result);
		} else {
			array_schema->set_detector_ysiz(new_ysiz);
		}
		return;

	}

	if( Subscription == hXbeg ){
		if( 1 != sscanf(result,"%lu",&xbeg)){
			PRINT(L_ERROR, "Could not translate xbeg: \"%s\"\n", result);
		}
		return;
	}

	if( Subscription == hYbeg ){
		if( 1 != sscanf(result,"%lu",&ybeg)){
			PRINT(L_ERROR, "Could not translate ybeg: \"%s\"\n", result);
		}
		return;
	}

	if( Subscription == hXbin ){
		if( 1 != sscanf(result,"%lu",&xbin)){
			PRINT(L_ERROR, "Could not translate xbin: \"%s\"\n", result);
			return;
		}
		SendString( "?xsiz");
		return;
	}

	if( Subscription == hYbin ){
		if( 1 != sscanf(result, "%lu", &ybin)){
			PRINT(L_ERROR, "Could not translate ybin: \"%s\"\n", result);
			return;
		}
		SendString( "?ysiz");
		return;
	}

	if( Subscription == hRdav ){
		unsigned new_rdav;
		if( 1 != sscanf(result, "%x", &new_rdav)){
			PRINT(L_ERROR, "Could not translate rdav: \"%s\"\n", result);
			return;
		}

		for(int n = 0; n < MAX_DETECTORS; n++ ){
			array_schema->get_detector_schema(n)->set_available_amps(new_rdav);
		}

		return;
	}

	/*if( Subscription == hRddr ){
		unsigned new_rddr;
		if( 1 != sscanf(result, "%u", &new_rddr)){
			PRINT(L_ERROR, "Could not translate rddr: \"%s\"\n", result);
			return;
		}
		// TODO Set up read directions on amplifiers
	}*/

	if( Subscription == hDeav ){
		unsigned new_deav;
		if( 1 != sscanf(result, "%u", &new_deav) ){
			PRINT(L_ERROR, "Could not translate deav: \"%s\"\n", result);
		}
		array_schema->set_available_detectors(new_deav);

		return;
	}

	if( Subscription == hDeen ){
		unsigned new_deen;
		if( 1 != sscanf(result, "%u", &new_deen)){
			PRINT(L_ERROR, "Could not translate deav: \"%s\"\n", result);
		}

		array_schema->set_enabled_detectors(new_deen);

		return;
	}

	if( Subscription == hSint ){
		//StartExposure();
		return;
	}

	if( Subscription == hTimr ){

		if( 1 != sscanf(result, "%d", &time_left)){
			PRINT(L_ERROR, "Could not parse timr response: \"%s\"\n", result);
		}
		ExposureCallback(Subscription);
		return;

	}

	if( Subscription == hTima ){

		if( 1 != sscanf(result, "%d", &time_actual)){
			PRINT(L_ERROR, "Could not parse tima response: \"%s\"\n", result);
		}
		return;

	}

	if( Subscription == hStat ){
		
		if( 1 != sscanf(result, "%d", &tmp)){
			PRINT(L_ERROR, "Could not parse stat response: \"%s\"\n", result);
		} else {

			State = (TCamState)(tmp >> 12);
			if( LastState != State ){
				CON->IvySend(ivy_cam_stat, "%d", State);
				LastState = State;
			}

		}
		return;
		
	}

	if( Subscription == hShut ){

		if( 1 != sscanf(result, "%lu", &shutter)){
			PRINT(L_ERROR, "Could not translate shutter: \"%s\"\n", result);
		}
		return;

	}

	if( Subscription == hTemp ){

		if( 1 != sscanf(result, "%f", &ccdtemp)){
			PRINT(L_ERROR, "Could not translate ccd temperature: \"%s\"\n", result);
		}
		return;

	}

	if( Subscription == hTset ){

		if( 1 != sscanf(result, "%f", &ccdref)){
			PRINT(L_ERROR, "Could not translate ccd set point: \"%s\"\n", result);
		}
		return;

	}

	if( Subscription == hTln2 ){

		if( 1 != sscanf(result, "%f", &ln2temp)){
			PRINT(L_ERROR, "Could not translate ln2 temperature: \"%s\"\n", result);
		}
		return;

	}

	if( Subscription == hPres ){

		if( 1 != sscanf(result, "%f", &p_dewar)){
			PRINT(L_ERROR, "Could not translate deware pressure: \"%s\"\n", result);
		}
		return;

	}

	if( Subscription == hFres ){
		for(int idx = 0; idx < UPDATE_TOKEN_COUNT; idx ++){
			SendString( UpdateTokens[idx]);
		}
		return;
	}


	if( Subscription == hTsam ){

		if( 1 != sscanf(result, "%lu", &tsam)){
			PRINT(L_ERROR, "Could not translate tsam: \"%s\"\n", result);
		}
		return;

	}

	if( Subscription == hFpix ){

		if( 1 != sscanf(result, "%lu", &fpix)){
			PRINT(L_ERROR, "Could not translate fpix: \"%s\"\n", result);
		}
		return;

	}

	if( Subscription == hVshi ){

		if( 1 != sscanf(result, "%f", &vshi)){
			PRINT(L_ERROR, "Could not translate vshi: \"%s\"\n", result);
		}
		return;

	}

	if( Subscription == hVslo ){

		if( 1 != sscanf(result, "%f", &vslo)){
			PRINT(L_ERROR, "Could not translate vslo: \"%s\"\n", result);
		}
		return;

	}

	if( Subscription == hVphi ){

		if( 1 != sscanf(result, "%f", &vphi)){
			PRINT(L_ERROR, "Could not translate vphi: \"%s\"\n", result);
		}
		return;

	}

	if( Subscription == hVplo ){

		if( 1 != sscanf(result, "%f", &vplo)){
			PRINT(L_ERROR, "Could not translate vplo: \"%s\"\n", result);
		}
		return;

	}

	if( Subscription == hVbha ){
		if( 2 != sscanf(result, "%lu %f", &channel_no, &tmp_float)){
			PRINT(L_ERROR, "Could not translate vbha: \"%s\"\n", result);
			return;
		}

		if( channel_no >= array_schema->get_amps_available() ){
			PRINT(L_ERROR, "?d vbha: \"%s\"\n", result);
			return;
		}

		array_schema->channel2amplifier(channel_no)->vbha = tmp_float;

		if( !channel_no ){
			while ( ++channel_no < array_schema->get_amps_available() ){
				SendString("?vbha %d", channel_no);
			}
		}
		return;
	}

	if( Subscription == hVbhb ){
		if( 2 != sscanf(result, "%lu %f", &channel_no, &tmp_float)){
			PRINT(L_ERROR, "Could not translate vbhb: \"%s\"\n", result);
			return;
		}

		if( channel_no >= array_schema->get_amps_available() ){
			PRINT(L_ERROR, "Invalid response from controller vbhb: \"%s\"\n", result);
			return;
		}

		array_schema->channel2amplifier(channel_no)->vbhb = tmp_float;

		if( !channel_no ){
			while ( ++channel_no < array_schema->get_amps_available() ){
				SendString("?vbhb %d", channel_no);
			}
		}
		return;
	}

	if( Subscription == hVbhc ){
		if( 2 != sscanf(result, "%lu %f", &channel_no, &tmp_float)){
			PRINT(L_ERROR, "Could not translate vbhc: \"%s\"\n", result);
			return;
		}

		if( channel_no >= array_schema->get_amps_available() ){
			PRINT(L_ERROR, "Invalid response from controller vbhc: \"%s\"\n", result);
			return;
		}

		array_schema->channel2amplifier(channel_no)->vbhc = tmp_float;

		if( !channel_no ){
			while ( ++channel_no < array_schema->get_amps_available() ){
				SendString("?vbhc %d", channel_no);
			}
		}
		return;
	}

	if( Subscription == hVbla ){
		if( 2 != sscanf(result, "%lu %f", &channel_no, &tmp_float)){
			PRINT(L_ERROR, "Could not translate vbla: \"%s\"\n", result);
			return;
		}

		if( channel_no >= array_schema->get_amps_available() ){
			PRINT(L_ERROR, "Invalid response from controller vbla: \"%s\"\n", result);
			return;
		}

		array_schema->channel2amplifier(channel_no)->vbla = tmp_float;

		if( !channel_no ){
			while ( ++channel_no < array_schema->get_amps_available() ){
				SendString("?vbla %d", channel_no);
			}
		}
		return;
	}

	if( Subscription == hVblb ){
		if( 2 != sscanf(result, "%lu %f", &channel_no, &tmp_float)){
			PRINT(L_ERROR, "Could not translate vblb: \"%s\"\n", result);
			return;
		}

		if( channel_no >= array_schema->get_amps_available() ){
			PRINT(L_ERROR, "Invalid response from controller gain: \"%s\"\n", result);
			return;
		}

		array_schema->channel2amplifier(channel_no)->vblb = tmp_float;

		if( !channel_no ){
			while ( ++channel_no < array_schema->get_amps_available() ){
				SendString("?vblb %d", channel_no);
			}
		}
		return;
	}

	if( Subscription == hZero ){
		if( 2 != sscanf(result, "%lu %d", &channel_no, &tmp)){
			PRINT(L_ERROR, "Could not translate zero: \"%s\"\n", result);
			return;
		}

		if( channel_no >= array_schema->get_amps_available() ){
			PRINT(L_ERROR, "Invalid response from controller zero: \"%s\"\n", result);
			return;
		}

		array_schema->channel2amplifier(channel_no)->zero = tmp;

		if( !channel_no ){
			while ( ++channel_no < array_schema->get_amps_available() ){
				SendString("?zero %d", channel_no);
			}
		}
		return;
	}

	if( Subscription == hGain ){
		if( 2 != sscanf(result, "%lu %f", &channel_no, &tmp_float)){
			PRINT(L_ERROR, "Could not translate gain: \"%s\"\n", result);
			return;
		}

		if( channel_no >= array_schema->get_amps_available() ){
			PRINT(L_ERROR, "Invalid response from controller gain: \"%s\"\n", result);
			return;
		}

		array_schema->channel2amplifier(channel_no)->gain = tmp_float;

		if( !channel_no ){
			while ( ++channel_no < array_schema->get_amps_available() ){
				SendString("?gain %d", channel_no);
			}
		}
		return;
	}

	if( Subscription == hOffs ){
		if( 2 != sscanf(result, "%lu %f", &channel_no, &tmp_float)){
			PRINT(L_ERROR, "Could not translate offs: \"%s\"\n", result);
			return;
		}

		if( channel_no >= array_schema->get_amps_available() ){
			PRINT(L_ERROR, "Invalid response from controller offs: \"%s\"\n", result);
			return;
		}

		// we don't use this metric
		//array_def->channel2amplifier(channel_no)->gain = tmp_float;

		if( !channel_no ){
			while ( ++channel_no < array_schema->get_amps_available() ){
				SendString("?offs %d", channel_no);
			}
		}
		return;
	}

	if( Subscription == hComm ){
		wait_reply++;
		return;
	}

	PRINT(L_ERROR, "Received unknown message: \"%s\"\n", result);
}

///////////////////////////////////////////////////////////////////////////////
//

void cCCD3engine::DriverMessage(HSUBSCRIPTION Subscription)
{
	char *msg;
	int new_rx_ok, new_tx_ok;

	if( Subscription != hDrv ){
		throw ECCD3Engine("Unknown driver message received");
	}

	msg = Subscriptions->GetResponse(Subscription);

	if( strstr(msg, DRV_RX) ){
		
		if( 1 != sscanf(msg, "%*s %d", &new_rx_ok) ){
			PRINT(L_ERROR, "Failed parsing driver message: \"%s\"\n", msg);
			return; 
		}
		
		if( new_rx_ok != rx_ok ){
			rx_ok = new_rx_ok;
			if( rx_ok ){ // NOTE: Reported by console
				CON->IvySend(ivy_comm_ok, "Rx fiber OK");
				//PRINT(L_NORMAL, "Rx fiber OK\n");
				//CON->Prompt();
			} else {
				CON->IvySend(ivy_comm_error, "Communication error, lost rx fiber");
				//Reset();
				//PRINT(L_ERROR, "\nCommunication error, lost rx fiber");
				//CON->Prompt();
			}
		}
		comm_down = !tx_ok || !rx_ok;
	}

	if( strstr(msg, DRV_TX) ){

		if( 1 != sscanf(msg, "%*s %d", &new_tx_ok) ){
			PRINT(L_ERROR, "Failed parsing driver message: \"%s\"\n", msg);
			return;
		}

		if( new_tx_ok != tx_ok ){
			tx_ok = new_tx_ok;
			if( tx_ok ){ // NOTE: Reported by console
				CON->IvySend(ivy_comm_ok, "Tx fiber OK");
				// TODO Update??
				//PRINT(L_NORMAL, "Tx fiber OK\n");
				//CON->Prompt();
			} else {
				CON->IvySend(ivy_comm_error, "Communication error, tx fiber is down");
				//Reset();
				//PRINT(L_ERROR, "\nCommunication error, lost tx fiber");
				//CON->Prompt();
			}
		}
		comm_down = !tx_ok || !rx_ok;
	}
	
	if( strstr(msg, DRV_MEM) ){
		if( !mptr ){

			if( 1 != sscanf(msg, "%*s %u", &pci_mem_size)){
				PRINT(L_ERROR, "Failed parsing driver message: \"%s\"\n", msg);
				return;
			}

			mptr = (unsigned int*)mmap(0, pci_mem_size, PROT_READ|PROT_WRITE, MAP_FILE|MAP_SHARED, fileno(fdata), 0);

			if(mptr == MAP_FAILED) {
				throw ECCD3Engine("Could not map CCD3 data: \"%s\"", strerror(errno));
			}

			shm = new cCCD3mem(2 * pci_mem_size, true );

		}
	}
}

///////////////////////////////////////////////////////////////////////////////

void cCCD3engine::SetPreview(ds9_comm *new_ds9)
{
	ds9 = new_ds9;

	if( !ds9 && preview ){
		preview->cancel_xpa();
	}

	if( ds9 && Busy() ){
		if( preview ){
			preview->resume_xpa(ds9->xpa());
		} else {
			preview = new cCCD3Preview(shm_processor, shm->Mem, array_schema, ds9->xpa(), shm->getid(), blocksize);
		}
	}
}

///////////////////////////////////////////////////////////////////////////////
// Set preview mode

ds9_comm* cCCD3engine::GetPreview(void){
	return ds9;
}

///////////////////////////////////////////////////////////////////////////////
// Specifies if multiple amplifier readouts should be combined into one image
void cCCD3engine::SetCombine(bool new_combine)
{
	combine = new_combine;
}

///////////////////////////////////////////////////////////////////////////////
// Returns extension combination mode
bool cCCD3engine::GetCombine(void){
	return combine;
}

///////////////////////////////////////////////////////////////////////////////
// Specifies whether geometry settings are respected when writing the .fits
// file
void cCCD3engine::SetFileGeometry(bool new_file_geometry){
	geometry_in_file = new_file_geometry;
}

///////////////////////////////////////////////////////////////////////////////
// Returns extension combination mode
bool cCCD3engine::GetFileGeometry(void){
	return geometry_in_file;
}

void cCCD3engine::SetRealtime(bool new_realtime){
	realtime = new_realtime;
}

bool cCCD3engine::GetRealtime(void){
	return realtime;
}


///////////////////////////////////////////////////////////////////////////////

/*void cCCD3engine::ShowBuffer(int width, int height)
{
	if( !show_ds9 ) {
		ShowDS9(true);
	}

	xsiz = width;
	ysiz = height;
	pix_cnt = xsiz * ysiz;
	PRINT(ccAlways, "Updating DS9, please wait ...\n");
	memcpy(shm->Mem, mptr, pix_cnt * sizeof(mptr[0]) );

	xpa->set("scale limits %d %d", minval, maxval);
	xpa->set("scale mode user");
	//xpa->set("minmax mode sample");
	//xpa->set("minmax interval 100");
	xpa->set("update now");
//		xpa->set("minmax mode auto");
//		xpa->set("scale mode minmax");
//		xpa->set("update");

	// Don't complain about missing communication because of lengthy processing
	gettimeofday(&last_comm, NULL);
}*/

/*void cCCD3engine::WriteBufferToFile(char* filename)
{

	PRINT(ccAlways, "Writing file, please wait ...\n");

	if(!strcasecmp(filename, AUTO_FILENAME)){
		// Autofilename selected
		sprintf(offload_fits_info.filename, "CCD3-%d.fits", 0);
		for(int n=1; file_exists(offload_fits_info.filename); n++){
			sprintf(offload_fits_info.filename, "CCD3-%d.fits", n);
		}
	} else {
		strcpy(offload_fits_info.filename, filename);
	}

	offload_fits_info.src = (char*)mptr;
	offload_fits_info.xsiz = xsiz;
	offload_fits_info.ysiz = ysiz;
	offload_fits = new cCCD3offload_fits(&offload_fits_info);

	int completed = offload_fits->progress();
	PRINT(ccAlways, "completed before = %d\n", completed);

	offload_fits->save(xsiz * ysiz * 4);

	completed = offload_fits->progress();
	PRINT(ccAlways, "completed after = %d\n", completed);
	while( completed < (xsiz * ysiz * 4) && !offload_fits_info.status ){
		usleep(CCD3_UPDATE_INTERVAL);
		completed = offload_fits->progress();
		PRINT(ccAlways, "completed = %d\n", completed);
	}

	PRINT(ccAlways, "File written\n");

	// wait for write
	offload_fits->write_key((char*)"SYSTEM",   (char*)"CCD3", CCD3_FITS_HDR);
	offload_fits->write_key((char*)"FILENAME", (char*)offload_fits_info.filename, (char*)NULL);
	offload_fits->write_key((char*)"DETNAME",  (char*)"");
	offload_fits->write_key((char*)"CHIPID",   (char*)"");
	offload_fits->write_key((char*)"DATAMIN",  (int*)&minval);
	offload_fits->write_key((char*)"DATAMAX",  (int*)&maxval);
	// float offload_fits->write_key("EXPTIME",  (void*)&exptime, NULL, &status);


	offload_fits->save(0);
	delete offload_fits;

	PRINT(ccAlways, "Image saved in file: %s\n", offload_fits_info.filename);

	// Don't complain about missing communication because of lengthy processing
	gettimeofday(&last_comm, NULL);
}*/

///////////////////////////////////////////////////////////////////////////////

void cCCD3engine::SelectDevice(int idx)
{
	throw ECCD3Engine("Command not available yet!");
}

///////////////////////////////////////////////////////////////////////////////

void cCCD3engine::SelectCam(int idx)
{
	throw ECCD3Engine("Command not available yet!");
}

///////////////////////////////////////////////////////////////////////////////
// Set orientation of image
void cCCD3engine::set_mirror_xy(bool a_mirror_x, bool a_mirror_y){
	if( Busy() ){
		PRINT(L_ERROR, "Not available during operations\n");
	} else {
		array_schema->set_mirror(a_mirror_x, a_mirror_y);
	}
}

///////////////////////////////////////////////////////////////////////////////
// mirror x axis
void cCCD3engine::set_mirror_x(bool a_mirror_x){
	if( Busy() ){
		PRINT(L_ERROR, "Not available during operations\n");
	} else {
		array_schema->set_mirror_x( a_mirror_x );
	}
}

///////////////////////////////////////////////////////////////////////////////
// mirror y axis
void cCCD3engine::set_mirror_y(bool a_mirror_y){
	if( Busy() ){
		PRINT(L_ERROR, "Not available during operations\n");
	} else {
		array_schema->set_mirror_y( a_mirror_y );
	}
}

///////////////////////////////////////////////////////////////////////////////

void cCCD3engine::set_rotate(t_rotation a_rotation){
	if( Busy() ){
		PRINT(L_ERROR, "Not available during operations\n");
	} else {
		array_schema->set_rotation(a_rotation);
	}
}

///////////////////////////////////////////////////////////////////////////////
// Set new filename and open file
void cCCD3engine::OpenFile(const char* path, const char* filename){
	char tmp_name[MAX_PATH];
	strcpy(tmp_name, path);
	strcat(tmp_name, filename);
	OpenFile(tmp_name);
}

///////////////////////////////////////////////////////////////////////////////

void cCCD3engine::OpenFile(const char* new_filename)
{
	if( strlen(new_filename) ){
		//strcpy(cCCD3fits_processor::filename, new_filename);
		strcpy(next_filename, new_filename);
	}
}

///////////////////////////////////////////////////////////////////////////////

void cCCD3engine::AllowFileClose(bool a_allow_fileclose)
{
	allow_fileclose = a_allow_fileclose;
}

///////////////////////////////////////////////////////////////////////////////

char* cCCD3engine::Filename(void)
{
	return next_filename;
}

///////////////////////////////////////////////////////////////////////////////
// Write keyword to .fits file

void cCCD3engine::WriteKeyword(const char* str, ...)
{	
	char buf[256];
	va_list arg;
	va_start (arg, str);
	vsprintf(buf, str, arg);
	va_end (arg);

	cCCD3fits_processor::write_key(buf);
	CON->IvySend(ivy_file_keyword, buf);
}

///////////////////////////////////////////////////////////////////////////////
// Transmit a string on character stream

int cCCD3engine::SendString(const char* fmt, ...)
{
	int ret;
	char buf[256];

	va_list arg;
	va_start (arg, fmt);
	vsprintf(buf, fmt, arg);
	va_end (arg);

	while( wait_reply && !comm_down && !do_quit){
		ret = Wait_IO( false );
		if( ret < 0 ){
			return ret;
		}
	}

	return SendStringNow("%s", buf);
}

///////////////////////////////////////////////////////////////////////////////
// Transmit a string on character stream, but don't wait for replies

int cCCD3engine::SendStringNow(const char* fmt, ...){
	int ret;
	char tmp[256];
	char buf[256];
	size_t n = 0;

	if( comm_down || do_quit)
		return -1;

	va_list arg;
	va_start (arg, fmt);
	vsprintf(buf, fmt, arg);
	va_end (arg);

	while( n <= strlen(buf)+1 ){

		ret = fprintf(fctl, "%s\n", &buf[n]);

		if( ret <= 0 ){
			throw ECCD3Engine("Failed writing to control device (%s) with error %d\n", buf, ret);
		} else if( ret < ((int)strlen(buf)+1) ){
			n += ret;
			strncpy(tmp, buf, ret);
			tmp[ret]= 0;
			PRINT(ccDebug, "SendString (%s|%s)\n", tmp, &buf[ret]);
		} else {
			break;
		}
	}

	wait_reply++;

	CON->IvySend(ivy_cam_query, "%s", buf);
	fflush(fctl);
	return ret;

}

///////////////////////////////////////////////////////////////////////////////
// Query the CAM controller for the message in buf and sets up the wait queue
// for the response. A handle for the request is returned

HSUBSCRIPTION cCCD3engine::QueryCam(char* buf, SubscriptionCallback Callback, void* UserData, DWORD Count){
	char Query[CAM_MAX_QUERY_LEN];
	int ret;
	char* ptr;

	sprintf(Query, "%c%s", CAM_QUESTION_PREFIX, buf);	// Command
	ret = SendString(Query);
	if(0 > ret) return (HSUBSCRIPTION)NULL;

	ptr = strstr(buf, " ");
	if(ptr) *ptr = '\0';
	sprintf(Query, "%c%s", CAM_ANSWER_PREFIX, buf);		// Expected response string

	hLastQuery = Subscriptions->Subscribe(Query, Callback, UserData, Count);
	return hLastQuery;

}

///////////////////////////////////////////////////////////////////////////////
// Send a command to the CAM controller

HSUBSCRIPTION cCCD3engine::CommandCam(char* buf, SubscriptionCallback Callback, void* UserData, DWORD Count){
	char Query[CAM_MAX_QUERY_LEN];
	char Response[CAM_MAX_QUERY_LEN];
	char* ptr;

	sprintf(Query, "%c%s", CAM_COMMAND_PREFIX, buf);		// Command

	ptr = strstr(buf, " ");
	if(ptr) *ptr = '\0';

	if( Callback ){
		sprintf(Response, "%c%s", CAM_ANSWER_PREFIX, buf);	// Expected response string
		hLastQuery = Subscriptions->Subscribe(Response, Callback, UserData, Count);
	}

	SendString(Query);

	return hLastQuery;
}

///////////////////////////////////////////////////////////////////////////////
// Returns the result of a previously prepared wait on a status message
// A pointer to a string holding the result is returned. NULL is returned
// if the result has not yet been received.
// If any errors occur the value CCD3_ERROR is returned

char* cCCD3engine::QueryCamResponse(HSUBSCRIPTION handle, char* arg, char* result, bool stop)
{
	if( result ){
		strcpy(result, Subscriptions->GetResponse(handle));
	}

	if( arg ){
		strcpy(arg, Subscriptions->GetCommand(handle));
	}

	if( stop ){
		Subscriptions->Unsubscribe(handle);
	}

	return result;
}

///////////////////////////////////////////////////////////////////////////////
//
bool cCCD3engine::InitComm(void)
{
	int error = 0;
	int flags;

	if( fctl ){
		fclose(fctl);
	}

	fctl = fopen(CTL_DEVICE, "r+");
	if(!fctl){
		error = errno;
		switch( error ){
			case EIO	: throw ECCD3Engine("Could not open CCD3 control device (%d:%s): \"%s\", is the camera turned on? .. the fiber connected properly?", error, strerror(error), CTL_DEVICE);
			case ENOENT	: throw ECCD3Engine("Could not open CCD3 control device (%d:%s): \"%s\", is the CCD3 kernel driver loaded?", error, strerror(error), CTL_DEVICE);
			default		: throw ECCD3Engine("Could not open CCD3 control device (%d:%s): \"%s\"!", error, strerror(error), CTL_DEVICE);
		}
	}

	flags = fcntl( fileno(fctl), F_GETFD);
	flags |= FD_CLOEXEC;

	if( 0 > fcntl(fileno(fctl), F_SETFD, flags)){
		error = errno;
		throw ECCD3Engine("Failed setting control file descriptor options, err=%d", error);
	}

	flags = fcntl( fileno(fctl), F_GETFL);
	flags |= O_NONBLOCK;
	flags |= O_SYNC;

	if( 0 > fcntl(fileno(fctl), F_SETFL, flags)){
		error = errno;
		throw ECCD3Engine("Failed setting control file flag options, err=%d", error);
	}

	if( fdata ){
		fclose(fdata);
	}

	fdata = fopen(DATA_DEVICE, "rb+");
	if(!fdata){
		error = errno;
		throw ECCD3Engine("Could not open CCD3 data device (%d:%s): \"%s\"!", error, strerror(error), DATA_DEVICE);
	}

	flags = fcntl( fileno(fdata), F_GETFD);

	if( flags != -1 ){
		flags |= FD_CLOEXEC;
	}

	if( 0 > fcntl(fileno(fdata), F_SETFD, flags)){
		error = errno;
		throw ECCD3Engine("Failed setting data device options, err=%d", error);
	}

	comm_down = 0;
	tx_ok = 1;
	rx_ok = 1;

	rx_cmd_buf->clear();

	//SendString(DRV_COMMAND " " DRV_RESET);

	for(int n=0; n < COMM_TOKEN_COUNT; n++){
		if( 0 > SendString(CommTokens[comm_token_idx++ % COMM_TOKEN_COUNT])){
			return false;
		}
	}
	Wait_IO(false);

	return error ? false : true;
}

///////////////////////////////////////////////////////////////////////////////
//
void cCCD3engine::InitProcessingString(void)
{
	memset(shm->Mem, FITS_NULL_VALUE, shm->size());  // clear storage

	// Handle shm_processor
	if( shm_processor ){
		delete shm_processor;
	}

	shm_processor = new cCCD3shm_processor(mptr, &shm->Mem[1 * array_schema->get_pix_cnt()], blocksize);
	shm_processor->set_offload(test_skipoffload);

	// Handle stat_processor
	if( stat_processor ){
		delete stat_processor;
	}

	stat_processor	 = new cCCD3statistic_processor(shm_processor, FITS_NULL_VALUE, 1, blocksize);

	// Handle descrambler and preview
	if( preview ){
		delete preview;
		preview = NULL;
	}

	if ( descrambler ){
		delete descrambler;
		descrambler = NULL;
	}

	// Handle fits processor
	if( fits_processor ){
		delete fits_processor;
	}

	if( ds9 ){
		preview = new cCCD3Preview(shm_processor, shm->Mem, array_schema, ds9->xpa(), shm->getid(), blocksize);
		// Let pre_process() execute
		preview->save(0);
	}

	descrambler = new cCCD3ArrayDescrambler(shm_processor, &shm->Mem[2 * array_schema->get_pix_cnt()], array_schema, combine, geometry_in_file, blocksize);
	// Let pre_process() execute
	descrambler->save(0);

	fits_processor = new cCCD3fits_processor(next_filename, descrambler , blocksize - blocksize % array_schema->get_xsiz());
	fits_processor->save(0);
// JK 16.03.2022
        rm_std_comment = true;
//
	fits_processor->set_fits_std_comment(!rm_std_comment);

	if( delay_filewrite ){
		fits_processor->pause();
	}
	strcpy(next_filename, "");

	if( realtime ){
		RaisePriorities();
	}

}

///////////////////////////////////////////////////////////////////////////////
// Will raise priorities on processing threads
void cCCD3engine::RaisePriorities(void){

	if( shm_processor ){
		shm_processor->set_priority(sched_get_priority_max(SCHED_FIFO));
	}

	if( stat_processor ){
		stat_processor->set_priority(sched_get_priority_max(SCHED_FIFO));
	}

	if( preview ){
		preview->set_priority(sched_get_priority_max(SCHED_FIFO));
	}

	if( descrambler ){
		descrambler->set_priority(sched_get_priority_max(SCHED_FIFO));
	}

	if( fits_processor){
		fits_processor->set_priority(sched_get_priority_max(SCHED_FIFO));
	}

}

///////////////////////////////////////////////////////////////////////////////

void cCCD3engine::CheckProcessingString(void){

	try {
		if( shm_processor ){
			if( shm_processor->error()){
				throw ECCD3Engine("shm processing thread made a pooh");
			}
		}

		if( stat_processor ){
			if( stat_processor->error()){
				throw ECCD3Engine("statistic processing thread made a pooh");
			}
		}

		if( descrambler ){
			if( descrambler->error()){
				throw ECCD3Engine("descrambler processing thread made a pooh");
			}
		}

		if( preview ){
			if( preview->error()){
				throw ECCD3Engine("preview processing thread made a pooh");
			}
		}

		if( fits_processor ){
			if( fits_processor->error()){
				throw ECCD3Engine(".fits processing thread made a pooh");
			}
		}
	} catch( common_exception &ex ){
		aborted = true;
		PRINT(L_NORMAL, "%s\n", ex.what());
		CON->IvySend(ivy_application_error, "%s", ex.what());
		CommandCam((char*)"brek");
	}
}

///////////////////////////////////////////////////////////////////////////////

void cCCD3engine::CloseProcessingString(void)
{
	if( shm_processor ){
		delete shm_processor;
		shm_processor = NULL;
	}

	if( stat_processor ){
		delete stat_processor;
		stat_processor = NULL;
	}

	if( fits_processor ){
		// fits_processor has a dependency to the descrambler, so it needs to be
		// paused before the descramber can be deleted.
		fits_processor->pause();
		while(!fits_processor->paused());
	}

	if( descrambler ){
		delete descrambler;
		descrambler = NULL;
	}

	if( preview ){
		delete preview;
		preview = NULL;
	}

	if( fits_processor ){
		delete fits_processor;
		fits_processor = NULL;
		if( !aborted ){
			CON->IvySend(ivy_file_close);
			Subscriptions->HandleEvent((char*)ENGINE_FILECLOSE);
		}
	}

}

///////////////////////////////////////////////////////////////////////////////
// Prepare for next exposure

void cCCD3engine::StartExposure(void){

/*	if( Busy() ){
		PRINT(L_ERROR, "ERROR: can't handle new exposure while busy!\n");
		disregard_brek = true;
		SendString("@brek");
		return;
	}
	disregard_brek = false;
*/
	SendString(DRV_COMMAND " " DRV_RESET);
	cam_busy = true;
	aborted = false;
	last_data_progress = 0;
	last_shm_progress = 0;
	last_stat_progress = 0;
	last_desc_progress = 0;
	last_preview_progress = 0;
	last_file_progress = 0;
	last_cnt = 0;
	cnt = 0;
	no_data = 0;
	time_left = exp_time;
	time_actual = 0;

	cCCD3fits_processor::exp_start();

	CON->IvySend(ivy_exposure_start);
	CON->IvySend(ivy_exposure_progress, "0");
	CON->IvySend(ivy_transfer_progress, "0");
	CON->IvySend(ivy_shm_progress, "0");
	CON->IvySend(ivy_stat_progress, "0");
	CON->IvySend(ivy_descramble_progress, "0");
	CON->IvySend(ivy_preview_progress, "0");
	CON->IvySend(ivy_file_progress, "0");

	if( rexp ){
		InitProcessingString();
	}

	Subscriptions->HandleEvent((char*)ENGINE_EXPOSE);
}

///////////////////////////////////////////////////////////////////////////////
// Show status of exposure

void cCCD3engine::ExposureCallback(HSUBSCRIPTION Subscription){
	ldiv_t res;
	int exp_progress = 0;

	if( !cam_busy ) return;
	if( !(time_left + time_actual) ) return;
	if( State == csIdle ) return;

	res = ldiv(100 * time_actual, time_left + time_actual);
	exp_progress = res.quot;

	CON->IvySend(ivy_exposure_progress, "%d", exp_progress);

	CheckProcessingString();

	if( exp_progress >= 100 ){
		EndExposure();
	}
}

///////////////////////////////////////////////////////////////////////////////

void cCCD3engine::EndExposure(void){

	if( !cam_busy ) return;

	cCCD3fits_processor::exp_end(time_actual);

	CON->IvySend(ivy_exposure_progress, "%d", 100);
	if( !aborted ){
		CON->IvySend(ivy_exposure_end);
	}

	if( rexp ){
		StartReadout();
	} else {
		cam_busy = false;
	}

}


///////////////////////////////////////////////////////////////////////////////
// Start offloading data

void cCCD3engine::StartReadout(void)
{
	processing = true;
	PRINT(L_NORMAL, "Processing image on %u detectors @ %ux%u = %u pixels\n", array_schema->get_detectors_enabled(), array_schema->get_xsiz(), array_schema->get_ysiz(), array_schema->get_pix_cnt());
	CON->Prompt(L_NORMAL);
	Subscriptions->HandleEvent((char*)ENGINE_READOUT);
}

///////////////////////////////////////////////////////////////////////////////
// Show status of data transfer

void cCCD3engine::ReadoutCallback(HSUBSCRIPTION Subscription)
{
	char* str;
	ldiv_t res;
	unsigned data_progress = 0;
	unsigned file_progress = 0;
	unsigned shm_progress = 0;
	unsigned stat_progress = 0;
	unsigned desc_progress = 0;
	unsigned preview_progress = 0;
	bool data_finish = true;
	bool file_finish = true;
	bool shm_finish = true;
	bool stat_finish = true;
	bool desc_finish = true;
	bool preview_finish = true;

	if( ! processing ) return;

	CheckProcessingString();

	str = Subscriptions->GetResponse(Subscription);

	if( 1 != sscanf(str, "%*s %d", &cnt)){
		PRINT(L_ERROR, "Could not parse progress response: \"%s\"\n", str);
		return;
	}

	if(cnt > array_schema->get_pix_cnt()){
		PRINT(L_ERROR, "Data overflow?? expected %d px and found %d\n", array_schema->get_pix_cnt(), cnt);
//		return;   JK
	}

	res = ldiv(100 * cnt, array_schema->get_pix_cnt());
	data_progress = res.quot;
	data_finish = cnt >= array_schema->get_pix_cnt();

	if( data_progress ){

		if( !last_data_progress ){
			CON->IvySend(ivy_transfer_start);
			gettimeofday(&start_time, NULL);
		}

		if( data_progress != last_data_progress ){
			CON->IvySend(ivy_transfer_progress, "%d", data_progress);
			if( data_finish ){
				gettimeofday(&end_time, NULL);
				CON->IvySend(ivy_transfer_end);
			}
		}

		if( data_progress == last_data_progress && !data_finish){
			if( ++no_data >= (MAX_INACTIVITY_TIME / CCD3_ACTIVE_UPDATE_INTERVAL) ){
				PRINT(L_ERROR, "\nInactivity detected, transfer aborted at %d%%!\n", data_progress);
				CommandCam((char*)"brek");
			}
		} else {
			no_data = 0;
		}
	}

	shm_progress = shm_processor->progress();
	stat_progress = stat_processor->progress();
	desc_progress = descrambler ? descrambler->progress() : preview->progress();
	preview_progress = preview ? preview->progress() : preview_progress;
	file_progress = fits_processor->progress();

	shm_finish = shm_progress >= array_schema->get_pix_cnt();
	stat_finish = stat_progress >= array_schema->get_pix_cnt();
	desc_finish = descrambler ? desc_progress >= array_schema->get_pix_cnt() : true;
	preview_finish = preview ? preview_progress >= array_schema->get_pix_cnt() : true;
	file_finish = fits_processor ? file_progress >= array_schema->get_pix_cnt() : true;

	// offloading to shared mem
	shm_processor->save(cnt);

	if( shm_progress ){

		if( !last_shm_progress ){
			CON->IvySend(ivy_shm_start);
		}

		if( shm_progress != last_shm_progress ){
			CON->IvySend(ivy_shm_progress, "%d", 100 * shm_progress / array_schema->get_pix_cnt());
			if( shm_finish ){
				gettimeofday(&shm_end_time, NULL);
				CON->IvySend(ivy_shm_end);
			}
		}

	}

	if( stat_progress ){

		if( !last_stat_progress ){
			CON->IvySend(ivy_stat_start);
		}

		if( stat_progress != last_stat_progress ){
			CON->IvySend(ivy_stat_progress, "%d", 100 * stat_progress / array_schema->get_pix_cnt());
			if( stat_finish ){
				CON->IvySend(ivy_stat_end);
			}
		}

		if( preview ){
			preview->set_minmax(stat_processor->get_min(), stat_processor->get_max());
		}
	}

	if( desc_progress ){

		if( !last_desc_progress ){
			CON->IvySend(ivy_descramble_start);
		}

		if ( desc_progress != last_desc_progress ) {
			CON->IvySend(ivy_descramble_progress, "%d", 100 * desc_progress / array_schema->get_pix_cnt());

			if( desc_finish ){
				CON->IvySend(ivy_descramble_end);
				if( delay_filewrite ){
					fits_processor->resume();
				}
			}

		}
	}

	if( preview && preview_progress){

		if( !last_preview_progress ){
			CON->IvySend(ivy_preview_start);
		}

		if( preview_progress != last_preview_progress ){
			CON->IvySend(ivy_preview_progress, "%d", 100 * preview_progress / array_schema->get_pix_cnt());

			if( preview_finish ){
				CON->IvySend(ivy_preview_end);
			}
		}
	}

	if( file_progress ){

		if( !last_file_progress ){
			CON->IvySend(ivy_file_start);
			gettimeofday(&fits_start_time, NULL);
		}

		if( file_progress != last_file_progress ){
			CON->IvySend(ivy_file_progress, "%d", 100 * file_progress / array_schema->get_pix_cnt());
			if( file_finish ){
				gettimeofday(&fits_end_time, NULL);
				CON->IvySend(ivy_file_end);
			}
		}

		if ( file_finish && allow_fileclose && data_finish && shm_finish && desc_finish && preview_finish) {
			EndReadout();
		}
	}

	last_data_progress = data_progress;
	last_shm_progress  = shm_progress;
	last_stat_progress = stat_progress;
	last_desc_progress = desc_progress;
	last_preview_progress = preview_progress;
	last_file_progress = file_progress;
	last_cnt = cnt;
}

///////////////////////////////////////////////////////////////////////////////
// End offloading data

void cCCD3engine::EndReadout(void)
{
	ccd3_detector_schema* detector_schema;
	ccd3_amplifier_schema* amplifier_schema;
	char amp_key[128];
	char old_amp_val[128];
	float bytespeed, pixspeed, transfer_time;
	unsigned minval, maxval;
	float average, deviation;
	char key[256];
	int dest_ext = 0;

	if( !Busy() ) return;

	LOGMSG(LOG_INFO, "Transfer end");

	aborted = aborted || cnt < array_schema->get_pix_cnt();

	processing = false;
	cam_busy = false;

	if( aborted ) {

		PRINT(L_ERROR, "Transfer aborted\n");

	} else {

		transfer_time = ((end_time.tv_sec * 1000000 + end_time.tv_usec) - (start_time.tv_sec * 1000000 + start_time.tv_usec));
		transfer_time /= 1000; 				// to mSecs
		pixspeed = cnt / transfer_time ;	// kpix/sec
		bytespeed = (pixspeed * 4) / 1000;	// Mbyte/sec

		minval = stat_processor->get_min();
		maxval = stat_processor->get_max();
		average = stat_processor->get_average();
		deviation = stat_processor->get_deviation();

		PRINT(L_DBGNRM, "\n");
		PRINT(L_DBGNRM, "Transfer:\n");
		PRINT(L_DBGNRM, "Read %d pixels in %.2f seconds\n", cnt, transfer_time/1000);
		PRINT(L_DBGNRM, "Rate = %.1f kpx/s, %.2f MB/s\n", pixspeed, bytespeed);
		PRINT(L_DBGNRM, "Min  = %u\n", minval);
		PRINT(L_DBGNRM, "Max   = %u\n", maxval);
		PRINT(L_DBGNRM, "Avg   = %.0f\n", average);
		PRINT(L_DBGNRM, "Dev   = %.0f\n", deviation);

		transfer_time = ((shm_end_time.tv_sec * 1000000 + shm_end_time.tv_usec) - (start_time.tv_sec * 1000000 + start_time.tv_usec));
		transfer_time /= 1000; // to msecs
		pixspeed = cnt / transfer_time ;  // kpix/sec
		bytespeed = (pixspeed * 4) / 1000; // Mbyte/sec
		PRINT(L_DBGNRM, "\n");
		PRINT(L_DBGNRM, "Memory:\n");
		PRINT(L_DBGNRM, "Read %d pixels in %.2f seconds\n", cnt, transfer_time/1000);
		PRINT(L_DBGNRM, "Rate = %.1f kpx/s, %.2f MB/s\n", pixspeed, bytespeed);

		try{
			if( fits_processor ){

				float f_exp_time = (float)time_actual / 1000;
				cCCD3fits_processor::write_key(MAIN_HDR, TFLOAT, "EXPTIME", &f_exp_time, "exposure time");

				switch(array_schema->get_rotation()){
				case r0:
					cCCD3fits_processor::write_key(MAIN_HDR, TSTRING, "ROTATE", "0", "Rotation of image");
					break;
				case r90:
					cCCD3fits_processor::write_key(MAIN_HDR, TSTRING, "ROTATE", "90", "Rotation of image");
					break;
				case r180:
					cCCD3fits_processor::write_key(MAIN_HDR, TSTRING, "ROTATE", "180", "Rotation of image");
					break;
				case r270:
					cCCD3fits_processor::write_key(MAIN_HDR, TSTRING, "ROTATE", "270", "Rotation of image");
					break;
				default:
					cCCD3fits_processor::write_key(MAIN_HDR, TSTRING, "ROTATE", "Unknown?", "Rotation of image");
					break;
				}

				cCCD3fits_processor::write_key(MAIN_HDR, "MIRROR_X", array_schema->get_mirror_x(), "Image is mirrored across horizontal axis");
				cCCD3fits_processor::write_key(MAIN_HDR, "MIRROR_Y", array_schema->get_mirror_y(), "Image is mirrored across vertical axis");

				for(unsigned detector_no=0; detector_no < array_schema->get_detectors_available(); detector_no++){

					detector_schema = array_schema->get_detector_schema(detector_no);

					if( !detector_schema->is_enabled() ) continue;

					strcpy(old_amp_val, "");

					for(unsigned amp_no=0; amp_no < detector_schema->get_amps_available(); amp_no++){

						amplifier_schema = detector_schema->get_amp_schema(amp_no);
						if( !amplifier_schema->enabled ) continue;

						dest_ext = combine ? 1 : dest_ext + 1;
						sprintf(key, "ZERO%d-%d", detector_no, amp_no);
						cCCD3fits_processor::write_key(dest_ext, TINT, key, &amplifier_schema->zero, NULL);
						sprintf(key, "GAIN%d-%d", detector_no, amp_no);
						cCCD3fits_processor::write_key(dest_ext, TFLOAT, key, &amplifier_schema->gain, NULL);
						sprintf(key, "VBHA%d-%d", detector_no, amp_no);
						cCCD3fits_processor::write_key(dest_ext, TFLOAT, key, &amplifier_schema->vbha, "Bias high A (V)");
						sprintf(key, "VBHB%d-%d", detector_no, amp_no);
						cCCD3fits_processor::write_key(dest_ext, TFLOAT, key, &amplifier_schema->vbhb, "Bias high B (V)");
						sprintf(key, "VBHC%d-%d", detector_no, amp_no);
						cCCD3fits_processor::write_key(dest_ext, TFLOAT, key, &amplifier_schema->vbhc, "Bias high C (V)");
						sprintf(key, "VBLA%d-%d", detector_no, amp_no);
						cCCD3fits_processor::write_key(dest_ext, TFLOAT, key, &amplifier_schema->vbla, "Bias low A (V)");
						sprintf(key, "VBLB%d-%d", detector_no, amp_no);
						cCCD3fits_processor::write_key(dest_ext, TFLOAT, key, &amplifier_schema->vblb, "Bias low B (V)");

						sprintf(old_amp_val, "%s%c", old_amp_val, 'A' + amp_no);

					} // for amps

					cCCD3fits_processor::write_key(MAIN_HDR, TSTRING, "AMPLMODE", old_amp_val, "Amplifier mode");

					sprintf(amp_key, "DETMODE%d", detector_no);
					int detector_mode = detector_schema->get_enabled_mask();
					cCCD3fits_processor::write_key(MAIN_HDR, TUINT, amp_key, &detector_mode, "Detector mode");

				} // for detectors

				cCCD3fits_processor::write_key("%d TSTRING CCDSUM \"%d %d\"", EXT_HDR, xbin, ybin);
				cCCD3fits_processor::write_key("%d TSTRING DETWIN1 \"[%d:%d, %d:%d]\"", MAIN_HDR, xbeg, array_schema->get_xsiz()*xbin + xbeg - 1, ybeg, array_schema->get_ysiz()*ybin + ybeg - 1);
				cCCD3fits_processor::write_key(MAIN_HDR, TUINT,	"DATAMIN", (int*)&minval, "Minimum data value");
				cCCD3fits_processor::write_key(MAIN_HDR, TUINT,	"DATAMAX", (int*)&maxval, "Maximum data value");
				cCCD3fits_processor::write_key(MAIN_HDR, TFLOAT, "CCDTEMP", &ccdtemp, "Detector temperature");
				cCCD3fits_processor::write_key(MAIN_HDR, TFLOAT, "LN2TEMP", &ln2temp, "LN2 temperature");
				cCCD3fits_processor::write_key(MAIN_HDR, TFLOAT, "P_DEWAR", &p_dewar, "Dewar pressure");
				cCCD3fits_processor::write_key(MAIN_HDR, TSTRING, "SHSTAT", shutter ? "OPEN" : "CLOSED", "Shutter status");
				cCCD3fits_processor::write_key(MAIN_HDR, TUINT,	"DETXBIN", &xbin, "X binning");
				cCCD3fits_processor::write_key(MAIN_HDR, TUINT,	"DETYBIN", &ybin, "T binning");
				cCCD3fits_processor::write_key(MAIN_HDR, TUINT,	"NWINDOWS", &n_window, NULL);
				cCCD3fits_processor::write_key(MAIN_HDR, TUINT,	"TSAM", &tsam, "Clamp and sample time in clocks");
				cCCD3fits_processor::write_key(MAIN_HDR, TUINT,	"FPIX", &fpix, "Readout speed in pix/sec");
				cCCD3fits_processor::write_key(MAIN_HDR, TFLOAT, "VSHI", &vshi, NULL);
				cCCD3fits_processor::write_key(MAIN_HDR, TFLOAT, "VSLO", &vslo, NULL);
				cCCD3fits_processor::write_key(MAIN_HDR, TFLOAT, "VPHI", &vphi, NULL);
				cCCD3fits_processor::write_key(MAIN_HDR, TFLOAT, "VPLO", &vplo, NULL);

				transfer_time = ((fits_end_time.tv_sec * 1000000 + fits_end_time.tv_usec) - (fits_start_time.tv_sec * 1000000 + fits_start_time.tv_usec));
				transfer_time /= 1000; // to msecs
				pixspeed = cnt / transfer_time ;  // kpix/sec
				bytespeed = (pixspeed * 4) / 1000; // Mbyte/sec
				PRINT(L_DBGNRM, "\n");
				PRINT(L_DBGNRM, "File:\n");
				PRINT(L_DBGNRM, "Read %d pixels in %.2f seconds\n",cnt, transfer_time/1000);
				PRINT(L_DBGNRM, "Rate = %.1f kpx/s, %.2f MB/s\n", pixspeed, bytespeed);
				PRINT(L_NORMAL, "Saved file: \"%s\"\n", fits_processor->get_filename());
			} else {
				PRINT(L_NORMAL, "WARNING: No file was set, data has *NOT* been saved!!\n");
			} // if fits and fits_valid

		} catch (cCCD3processor::eProcessor &ex){
			PRINT(L_ERROR, " An error occurred while handling fits file: \"%s\"\n", ex.what());
		} // try
	} // if !aborted

	CloseProcessingString();

	CON->Prompt(L_NORMAL);
}

///////////////////////////////////////////////////////////////////////////////

/*bool cCCD3engine::SaveBuffer(char* filename)
{
	bool fits_finish = false;
	unsigned progress = 0;

	if( !cnt ) return false;
	if( !fits_processor ) return false;

	strcpy(fits_processor->filename, filename);
	CON->IvySend(ivy_file_start);
	fits_processor->resume();

	do{
		fits_processor->save( cnt );
		progress = fits_processor->progress();
		fits_finish = progress >= cnt;
		CON->IvySend(ivy_file_progress, "%d", 100 * progress / cnt);
	} while( !fits_finish );

	CON->IvySend(ivy_file_end);
	CloseFile();

	return true;
}*/

///////////////////////////////////////////////////////////////////////////////

BOOL cCCD3engine::Busy()
{
	return (State != csIdle) || cam_busy;
}

///////////////////////////////////////////////////////////////////////////////
// Engineering routine for physical test of onboard memory

void cCCD3engine::TestMemBlock(int size)
{
	struct timeval start_time;
	struct timeval end_time;
	float time;
	float speed;
	int errors;
	unsigned test_size;

	test_size = size ? size * (1024*1024) : pci_mem_size + 1;

	PRINT(L_ALWAYS, "Testing CCD3 acquisition card onboard memory..\n");
	unsigned* buf = new unsigned[test_size >> 2];
	PRINT(L_ALWAYS, "Filling %dMB system memory buffer\n", test_size / (1024*1024));
	gettimeofday(&start_time, NULL);
	for(unsigned n=0; n < test_size >> 2; n++){
		buf[n] = n;
	}
	gettimeofday(&end_time, NULL);
	time = ((end_time.tv_sec * 1000000 + end_time.tv_usec) - (start_time.tv_sec * 1000000 + start_time.tv_usec));
	time /= 1000000; 		// to secs
	speed = test_size / (time * 1000000);
	PRINT(L_ALWAYS, "Time for filling system memory = %3.3f Sec\n", time);
	PRINT(L_ALWAYS, "Speed = %3.3f MB/s\n", speed);

	PRINT(L_ALWAYS, "\n");
	PRINT(L_ALWAYS, "Copying %dMB to PCI memory\n", test_size / (1024*1024));
	gettimeofday(&start_time, NULL);
	memcpy(mptr, buf, test_size);
	gettimeofday(&end_time, NULL);
	time = ((end_time.tv_sec * 1000000 + end_time.tv_usec) - (start_time.tv_sec * 1000000 + start_time.tv_usec));
	time /= 1000000;		// to secs
	speed = test_size / (time * 1000000);
	PRINT(L_ALWAYS, "Writing time  = %3.3f Sec\n", time);
	PRINT(L_ALWAYS, "Writing speed = %3.3f MB/s\n", speed);

	PRINT(L_ALWAYS, "\n");
	PRINT(L_ALWAYS, "Reading %dMB from PCI memory\n", test_size / (1024*1024) );
	gettimeofday(&start_time, NULL);
	memcpy(buf, mptr, test_size);
	gettimeofday(&end_time, NULL);
	time = ((end_time.tv_sec * 1000000 + end_time.tv_usec) - (start_time.tv_sec * 1000000 + start_time.tv_usec));
	time /= 1000000; 		// to msecs
	speed = test_size / (time * 1000000);
	PRINT(L_ALWAYS, "Reading time  = %3.3f Sec\n", time);
	PRINT(L_ALWAYS, "Reading speed = %3.3f MB/s\n", speed);

	PRINT(L_ALWAYS, "\n");
	PRINT(L_ALWAYS, "Validating %dMB on PCI memory\n", test_size / (1024*1024) );
	gettimeofday(&start_time, NULL);
	for(unsigned n=errors=0; n < test_size >> 2; n++){
		if( buf[n] != n){
			errors++;
		}
	}
	gettimeofday(&end_time, NULL);
	time = ((end_time.tv_sec * 1000000 + end_time.tv_usec) - (start_time.tv_sec * 1000000 + start_time.tv_usec));
	time /= 1000000; 		// to msecs
	speed = test_size / (time * 1000000);
	PRINT(L_ALWAYS, "Time for validating data = %3.3f Sec\n", time);
	PRINT(L_ALWAYS, "Speed = %3.3f MB/s\n", speed);
	PRINT(L_ALWAYS, "Validation errors = %d\n", errors << 2);

	delete[] buf;
	gettimeofday(&last_comm, NULL);
}

void cCCD3engine::TestMemSingle(int size)
{
	struct timeval start_time;
	struct timeval end_time;
	float time;
	float speed;
	int errors;
	unsigned test_size;

	test_size = size ? size * (1024*1024) : pci_mem_size + 1;

	PRINT(L_ALWAYS, "Testing CCD3 acquisition card onboard memory..\n");
	PRINT(L_ALWAYS, "%dMB of PCI memory, sequential values\n", test_size / (1024*1024));
	gettimeofday(&start_time, NULL);
	
	for(unsigned n=errors=0; n < test_size >> 2; n++){
		mptr[n] = n;
	}

	for(unsigned n=errors=0; n < test_size >> 2; n++){
		if(mptr[n] != n){
			errors++;
		}
	}
	
	gettimeofday(&end_time, NULL);
	time = ((end_time.tv_sec * 1000000 + end_time.tv_usec) - (start_time.tv_sec * 1000000 + start_time.tv_usec));
	time /= 1000000;		// to secs
	speed = test_size / (time * 1000000);
	PRINT(L_ALWAYS, "Validation time = %3.3f Sec\n", time);
	PRINT(L_ALWAYS, "Speed = %3.3f MB/s\n", speed);
	PRINT(L_ALWAYS, "Errors found: %d\n", errors << 2);

	PRINT(L_ALWAYS, "\n");
	PRINT(L_ALWAYS, "%dMB of PCI memory, single value (0xAA)\n", test_size / (1024*1024));
	gettimeofday(&start_time, NULL);
	
	for(unsigned n=0; n < test_size >> 2; n++){
		mptr[n] = 0xAAAAAAAA;
	}

	for(unsigned n=errors=0; n < test_size >> 2; n++){
		if(mptr[n] != 0xAAAAAAAA){
			errors++;
		}
	}
	
	gettimeofday(&end_time, NULL);
	time = ((end_time.tv_sec * 1000000 + end_time.tv_usec) - (start_time.tv_sec * 1000000 + start_time.tv_usec));
	time /= 1000000;		// to secs
	speed = test_size / (time * 1000000);
	PRINT(L_ALWAYS, "Validation time = %3.3f Sec\n", time);
	PRINT(L_ALWAYS, "Speed = %3.3f MB/s\n", speed);
	PRINT(L_ALWAYS, "Errors found: %d\n", errors << 2);

	PRINT(L_ALWAYS, "\n");
	PRINT(L_ALWAYS, "%dMB of PCI memory, single value (0x55)\n", test_size / (1024*1024) );
	gettimeofday(&start_time, NULL);
	
	for(unsigned n=0; n < test_size >> 2; n++){
		mptr[n] = 0x55555555;
	}

	for(unsigned n=errors=0; n < test_size >> 2; n++){
		if(mptr[n] != 0x55555555){
			errors++;
		}
	}
	
	gettimeofday(&end_time, NULL);
	time = ((end_time.tv_sec * 1000000 + end_time.tv_usec) - (start_time.tv_sec * 1000000 + start_time.tv_usec));
	time /= 1000000;		// to secs
	speed = test_size / (time * 1000000);
	PRINT(L_ALWAYS, "Validation time = %3.3f Sec\n", time);
	PRINT(L_ALWAYS, "Speed = %3.3f MB/s\n", speed);
	PRINT(L_ALWAYS, "Errors found: %d\n", errors << 2);

	gettimeofday(&last_comm, NULL);
}

void cCCD3engine::SetTestPattern(int pattern)
{
	cCCD3shm_processor::set_pattern(pattern);
}

void cCCD3engine::SetTestOffload(bool skip_offload)
{
	test_skipoffload = skip_offload;
	if( shm_processor ){
		shm_processor->set_offload(test_skipoffload);
	}
}

void cCCD3engine::SetDelayedFilewrite(bool delay)
{
	delay_filewrite = delay;
}

void cCCD3engine::SetRemoveStdComment(bool new_remove_std_comment)
{
    rm_std_comment = new_remove_std_comment;
}
///////////////////////////////////////////////////////////////////////////////

void ReadoutDmyCallback(HSUBSCRIPTION hSubscription, char* data, void* parm)
{
	cCCD3engine* Engine = (cCCD3engine*)parm;
	Engine->ReadoutCallback(hSubscription);
}

///////////////////////////////////////////////////////////////////////////////

void SilentDmyCallback(HSUBSCRIPTION hSubscription, char* data, void* parm)
{
	cCCD3engine* Engine = (cCCD3engine*)parm;
	Engine->SilentCallback(hSubscription);
}

void DrvDmyCallback(HSUBSCRIPTION hSubscription, char* data, void* parm)
{
	cCCD3engine* Engine = (cCCD3engine*)parm;
	Engine->DriverMessage(hSubscription);
}

///////////////////////////////////////////////////////////////////////////////
// Debug function

void cCCD3engine::ShowDebug(void)
{
	PRINT(L_DEBUG, "Debug counters:\n");
	PRINT(L_DEBUG, "time = %d\n", time);
	PRINT(L_DEBUG, "xsiz = %d\n", array_schema->get_xsiz());
	PRINT(L_DEBUG, "ysiz = %d\n", array_schema->get_ysiz());
	PRINT(L_DEBUG, "pix_cnt = %d\n", array_schema->get_pix_cnt());
	//PRINT(L_DEBUG, "transferring = %s\n", transferring ? "true":"false");
//	PRINT(L_DEBUG, "minval = %d\n", minval);
//	PRINT(L_DEBUG, "maxval = %d\n", maxval);
//	PRINT(L_DEBUG, "device_idx = %d\n", device_idx);
//	PRINT(L_DEBUG, "cam_idx = %d\n", cam_idx);
	//PRINT(L_DEBUG, "progress = %d\n", progress);
}

///////////////////////////////////////////////////////////////////////////////
// Debug function

void cCCD3engine::ShowCallback(void)
{
    Subscriptions->Show();
}

///////////////////////////////////////////////////////////////////////////////
// EOF
