#ifndef CCD3_INIFILES_H_
#define CCD3_INIFILES_H_

#define INI_APP_SECTION					"application"
#define INI_APP_PREVIEW					"preview"
#define INI_APP_DEFAULT_PREVIEW			false
#define INI_APP_ANSI					"ansi"
#define INI_APP_DEFAULT_ANSI			"true"
#define INI_APP_UID						"uid"
#define INI_APP_DEFAULT_UID				"root"
#define INI_APP_REALTIME				"realtime_processing"
#define INI_APP_DEFAULT_REALTIME		false
#define INI_APP_BLOCKSIZE				"blocksize"
#define INI_APP_DEFAULT_BLOCKSIZE		DEFAULT_BLOCKSIZE

#define INI_SCRIPT_SECTION				"scripting"
#define INI_SCRIPT_ONAPPSTART			"exec_on_appstart"
#define INI_SCRIPT_ONEXPOSURE			"exec_on_exposure"
#define INI_SCRIPT_ONREADOUT			"exec_on_readout"
#define INI_SCRIPT_ONFILECLOSE			"exec_on_fileclose"
#define INI_SCRIPT_ONAPPCLOSE			"exec_on_appclose"
#define INI_SCRIPT_DEFAULT_FILE			""
#define INI_SCRIPT_DIR					"scriptdir"
#define INI_SCRIPT_DEFAULT_DIR			""


#define INI_FILE_SECTION				"file"
#define INI_FILE_DELAY					"delay_write"
#define INI_FILE_DEFAULT_DELAY			false
#define INI_FILE_RM_FITS_COMMENT			"remove_std_comment"
#define INI_FILE_DEFAULT_RM_FITS_COMMENT		false
#define INI_FILE_COMBINE				"combine"
#define INI_FILE_DEFAULT_COMBINE		true
#define INI_FILE_USE_GEOMETRY			"correct_geometry"
#define INI_FILE_DEFAULT_USE_GEOMETRY 	true
#define INI_FILE_ALLOWCLOSE				"allow_close_on"
#define INI_FILE_DEFAULT_ALLOWCLOSE		""
#define INI_FILE_PREFIX					"prefix"
#define INI_FILE_DEFAULT_PREFIX			"ccd3-"
#define INI_FILE_AUTO					"autosave"
#define INI_FILE_DEFAULT_AUTO			"true"
#define INI_FILE_NAMESTYLE				"namestyle"
#define INI_FILE_DEFAULT_NAMESTYLE		"default"
#define INI_FILE_DATE_SHIFT				"dateshift"
#define INI_FILE_DEFAULT_DATE_SHIFT		12
#define INI_FILE_DIR					"output_dir"
#define INI_FILE_DEFAULT_DIR			""
#define INI_FILE_NOT_NAMESTYLE			"NOT"

#define INI_DET_SECTION					"detector_layout"
#define INI_DET_LAYOUT					"layout"
#define INI_DET_DEFAULT_LAYOUT			"-"
#define INI_DET_MIRRORX					"mirror_x"
#define INI_DET_DEFAULT_MIRRORX			false
#define INI_DET_MIRRORY					"mirror_y"
#define INI_DET_DEFAULT_MIRRORY			false
#define INI_DET_ROTATE					"rotate"
#define INI_DET_DEFAULT_ROTATE			"0"

#define INI_LOG_SECTION					"log"
#define INI_LOG_FILE					"logfile"
#define INI_LOG_SYSLOG_VAL				"syslog"
#define INI_LOG_DEFAULT_FILE			INI_LOG_SYSLOG_VAL
#define INI_LOG_IDENT					"syslog_ident"
#define INI_LOG_DEFAULT_IDENT			"ccd3"
#define INI_LOG_FACILITY				"syslog_facility"
#define INI_LOG_DEFAULT_FACILITY		"LOG_USER"

#define INI_IVY_SECTION					"ivy_message_bus"
#define INI_IVY_NAME					"name"
#define INI_IVY_DEFAULT_NAME			"ccd3"
#define INI_IVY_ENABLE					"enable"
#define INI_IVY_DEFAULT_ENABLE			"false"
#define INI_IVY_NET						"net"
#define INI_IVY_DEFAULT_NET				"127.255.255.255:2010"

#define INI_MYSQL_SECTION				"mysql"
#define INI_MYSQL_ENABLE				"enable"
#define INI_MYSQL_DEFAULT_ENABLE		"false"
#define INI_MYSQL_HOST					"host"
#define INI_MYSQL_DEFAULT_HOST			"localhost"
#define INI_MYSQL_DB					"database"
#define INI_MYSQL_DEFAULT_DB			"ccd3"
#define INI_MYSQL_USER					"user"
#define INI_MYSQL_DEFAULT_USER			"root"
#define INI_MYSQL_PASSWORD				"password"
#define INI_MYSQL_DEFAULT_PASSWORD		""


#endif /*CCD3_INIFILES_H_*/
