/*
 * ccd3_array_def.cpp
 *
 *  Created on: Dec 16, 2010
 *      Author: jja
 */

#include "ccd3_array_def.h"

#define AMP_0_POS			0
#define AMP_1_POS 			1
#define AMP_2_POS			2
#define AMP_3_POS 			3

#define AMP_0(MASK) 		( (MASK >> AMP_0_POS) & 0x1 )
#define AMP_1(MASK) 		( (MASK >> AMP_1_POS) & 0x1 )
#define AMP_2(MASK) 		( (MASK >> AMP_2_POS) & 0x1 )
#define AMP_3(MASK) 		( (MASK >> AMP_3_POS) & 0x1 )

#define AMP_BOT(MASK)		( AMP_0(MASK) | AMP_1(MASK) )
#define AMP_TOP(MASK)		( AMP_2(MASK) | AMP_3(MASK) )
#define AMP_LEFT(MASK)		( AMP_0(MASK) | AMP_2(MASK) )
#define AMP_RIGHT(MASK)		( AMP_1(MASK) | AMP_3(MASK) )

#define DIVIDE_VERT(MASK)	( AMP_TOP(MASK)  & AMP_BOT(MASK) )
#define DIVIDE_HORZ(MASK)	( AMP_LEFT(MASK) & AMP_RIGHT(MASK) )

///////////////////////////////////////////////////////////////////////////////

unsigned cnt2mask(unsigned cnt){
	return (0x1 << cnt);
}

///////////////////////////////////////////////////////////////////////////////

unsigned mask2cnt(unsigned mask){
	unsigned res = 0;
	for(unsigned n=res=0; n < MAX_DETECTORS; n++){
		if( mask & cnt2mask(n)){
			res++;
		}
	}
	return res;
}

///////////////////////////////////////////////////////////////////////////////
// detector definition
ccd3_detector_schema::ccd3_detector_schema(void){
	xsiz = 0;
	ysiz = 0;
	xbeg = 0;
	ybeg = 0;
	amp_enabled_mask = 0;
	amp_available_mask = 0;
	enabled = false;
}

///////////////////////////////////////////////////////////////////////////////

void ccd3_detector_schema::set_enabled_amps(unsigned a_enabled_mask){

	unsigned amp_xsiz;
	unsigned amp_ysiz;

	amp_enabled_mask = a_enabled_mask;

	amp_xsiz = (AMP_0(amp_enabled_mask) && AMP_1(amp_enabled_mask))  ||
			   (AMP_2(amp_enabled_mask) && AMP_3(amp_enabled_mask))  ||
			   ((orientation == aoVertical) &&
			    ((AMP_1(amp_enabled_mask) && AMP_2(amp_enabled_mask)) ||
			     (AMP_0(amp_enabled_mask) && AMP_3(amp_enabled_mask))))
			   ? xsiz >> 1 : xsiz;

	amp_ysiz = (AMP_0(amp_enabled_mask) && AMP_2(amp_enabled_mask))  ||
			   (AMP_1(amp_enabled_mask) && AMP_3(amp_enabled_mask))  ||
			   ((orientation == aoHorizontal) &&
			    ((AMP_1(amp_enabled_mask) && AMP_2(amp_enabled_mask)) ||
			     (AMP_0(amp_enabled_mask) && AMP_3(amp_enabled_mask))))
			   ? ysiz >> 1 : ysiz;

	for(unsigned n=0; n < MAX_DETECTOR_AMPS; n++){
		amplifier[n].enabled = amp_enabled_mask & cnt2mask(n);

		if( !amplifier[n].enabled ){
			continue;
		}


		amplifier[n].xsiz = amp_xsiz;
		amplifier[n].ysiz = amp_ysiz;
	}


	amplifier[0].placement.xbeg = 0;
	amplifier[1].placement.xbeg = amp_xsiz == xsiz ? 0 : amp_xsiz;
	amplifier[2].placement.xbeg = 0;
	amplifier[3].placement.xbeg = amp_xsiz == xsiz ? 0 : amp_xsiz;

	amplifier[0].placement.ybeg = 0;
	amplifier[1].placement.ybeg = 0;
	amplifier[2].placement.ybeg = amp_ysiz == ysiz ? 0 : amp_ysiz;
	amplifier[3].placement.ybeg = amp_ysiz == ysiz ? 0 : amp_ysiz;

	amplifier[1].placement.mirror_x = true;
	amplifier[3].placement.mirror_x = true;
	amplifier[2].placement.mirror_y = true;
	amplifier[3].placement.mirror_y = true;

}

///////////////////////////////////////////////////////////////////////////////

void ccd3_detector_schema::set_size(unsigned new_xsiz, unsigned new_ysiz)
{
	set_xsiz(new_xsiz);
	set_ysiz(new_ysiz);
}

//////////////////////////////////////////////////////////////////////////////

void ccd3_detector_schema::set_xsiz(unsigned new_xsiz){
	xsiz = new_xsiz;
	set_enabled_amps(amp_enabled_mask);
}

///////////////////////////////////////////////////////////////////////////////

void ccd3_detector_schema::set_ysiz(unsigned new_ysiz){
	ysiz = new_ysiz;
	set_enabled_amps(amp_enabled_mask);
}

///////////////////////////////////////////////////////////////////////////////

unsigned ccd3_detector_schema::get_amps_enabled(void){
	return mask2cnt(amp_enabled_mask);
}

///////////////////////////////////////////////////////////////////////////////

unsigned ccd3_detector_schema::get_amps_available(void){
	return mask2cnt(amp_available_mask);
}

///////////////////////////////////////////////////////////////////////////////

bool ccd3_detector_schema::is_amp_bottom(unsigned amp_idx){
	return AMP_BOT( cnt2mask(amp_idx) );
}

///////////////////////////////////////////////////////////////////////////////

bool ccd3_detector_schema::is_amp_top(unsigned amp_idx){
	return AMP_TOP( cnt2mask(amp_idx) );
}

///////////////////////////////////////////////////////////////////////////////

bool ccd3_detector_schema::is_amp_left(unsigned amp_idx){
	return AMP_LEFT( cnt2mask(amp_idx) );
}

///////////////////////////////////////////////////////////////////////////////

bool ccd3_detector_schema::is_amp_right(unsigned amp_idx){
	return AMP_RIGHT( cnt2mask(amp_idx) );
}

///////////////////////////////////////////////////////////////////////////////

bool ccd3_detector_schema::is_top_amps_enabled(void){
	return AMP_TOP(amp_enabled_mask);
}

///////////////////////////////////////////////////////////////////////////////

bool ccd3_detector_schema::is_bottom_amps_enabled(void){
	return AMP_BOT(amp_enabled_mask);
}

///////////////////////////////////////////////////////////////////////////////

bool ccd3_detector_schema::is_left_amps_enabled(void){
	return AMP_LEFT(amp_enabled_mask);
}

///////////////////////////////////////////////////////////////////////////////

bool ccd3_detector_schema::is_right_amps_enabled(void){
	return AMP_RIGHT(amp_enabled_mask);
}

///////////////////////////////////////////////////////////////////////////////
// Array definition
ccd3_array_schema::ccd3_array_schema(void){
	rows = 0;
	cols = 0;
	det_avail_mask = 0;
	det_enabl_mask = 0;
}

///////////////////////////////////////////////////////////////////////////////

void ccd3_array_schema::parse_layout(char* str){
	unsigned detector_setup_cnt = 0;
	char detector_spec;
	char* ptr = str;

	rows = 1;
	cols = 0;

	while( *ptr ){
		while(*ptr == ' ') ptr++;

		if( 1 != sscanf(ptr, "%c", &detector_spec)){
			throw e_ccd3_array_schema("Invalid detector layout: \"%s\"", str);
		}

		if( *ptr == ':' && cols ){
			rows++;
			ptr++;
			continue;
		} else if( *ptr == DET_HORIZONTAL ){
			get_detector_schema(detector_setup_cnt)->set_orientation( aoHorizontal );
			cols++;
		} else if( *ptr == DET_VERTICAL ){
			get_detector_schema(detector_setup_cnt)->set_orientation( aoVertical );
			cols++;
		} else {
				// format error
				throw e_ccd3_array_schema("Invalid detector layout: \"%s\"", str);
		}

		detector_setup_cnt++;

		if( detector_setup_cnt > MAX_DETECTORS){
			throw e_ccd3_array_schema("A maximum of %d detectors are supported!", MAX_DETECTORS);
		}

		if( rows > MAX_ARRAY_ROWS ){
			throw e_ccd3_array_schema("A maximum of %d detector rows are supported!", MAX_ARRAY_ROWS);
		}

		if( cols > MAX_ARRAY_COLS ){
			throw e_ccd3_array_schema("A maximum of %d detector coloumns  are supported!", MAX_ARRAY_COLS);
		}

		ptr++;
	}

	if( cols * rows != detector_setup_cnt ){
		throw e_ccd3_array_schema("Invalid detector layout: \"%s\"", str);
	}

}

void ccd3_array_schema::validate_setup(void)
{
	ccd3_detector_schema* detector_schema;
	unsigned amps_enabled = get_detector_schema(0)->get_amps_enabled();

	for(unsigned detector_no=1; detector_no < (cols*rows); detector_no++){
		detector_schema = get_detector_schema(detector_no);

		if( detector_schema->is_enabled() && detector_schema->get_amps_enabled() != amps_enabled ){
			throw e_ccd3_array_schema("Unsupported readout combination");
		}
	}
}

///////////////////////////////////////////////////////////////////////////////

void ccd3_array_schema::set_detector_size(unsigned new_xsiz, unsigned new_ysiz)
{
	set_detector_xsiz(new_xsiz);
	set_detector_ysiz(new_ysiz);
}

///////////////////////////////////////////////////////////////////////////////

void ccd3_array_schema::set_detector_xsiz(unsigned new_xsiz){

	for(int detector_no=0; detector_no < MAX_DETECTORS; detector_no++){
		get_detector_schema(detector_no)->set_xsiz(new_xsiz);
	}

}

///////////////////////////////////////////////////////////////////////////////

void ccd3_array_schema::set_detector_ysiz(unsigned new_ysiz){

	for(int detector_no=0; detector_no < MAX_DETECTORS; detector_no++){
		get_detector_schema(detector_no)->set_ysiz(new_ysiz);
	}

}

///////////////////////////////////////////////////////////////////////////////

void ccd3_array_schema::set_enabled_detectors(unsigned new_detector_mask){

	if( new_detector_mask == det_enabl_mask ) return;

	// Check available detectors
	for(int detector_no=0; detector_no < MAX_DETECTORS; detector_no++){
		if( new_detector_mask & (0x1 << detector_no) && !det_avail_mask & (0x1 << detector_no) ){
			throw e_ccd3_array_schema("Requested detector (%d) is not present");
		}
	}

	// Set enabled detectors
	det_enabl_mask = new_detector_mask;

	for(int detector_no=0; detector_no < MAX_DETECTORS; detector_no++){
		get_detector_schema(detector_no)->set_enabled( cnt2mask(detector_no) & det_enabl_mask );
	}

}

///////////////////////////////////////////////////////////////////////////////

void ccd3_array_schema::set_available_detectors(unsigned new_detector_mask){

	if( mask2cnt(new_detector_mask) > (rows * cols)){
		throw e_ccd3_array_schema("detector count exceeds defined detector setup!");
	}

	det_avail_mask = new_detector_mask;
}

///////////////////////////////////////////////////////////////////////////////

unsigned ccd3_array_schema::channel2detector_idx(unsigned channel){
	unsigned channel_cnt;
	unsigned detector_no;

	for(detector_no=channel_cnt=0; detector_no < get_detectors_available(); detector_no++){

		channel_cnt += detectors[detector_no].get_amps_available();

		if( channel < channel_cnt ){
			return detector_no;
		}
	}

	throw e_ccd3_array_schema("channel out of bounds");
}

///////////////////////////////////////////////////////////////////////////////

unsigned ccd3_array_schema::channel2amp_idx(unsigned channel){
	unsigned channel_cnt;
	unsigned detector_no;

	for(detector_no=channel_cnt=0; detector_no < get_detectors_available(); detector_no++){

		if( channel <= (channel_cnt + detectors[detector_no].get_amps_available()) ){
			return channel - channel_cnt;
		}

		channel_cnt += detectors[detector_no].get_amps_available();
	}

	throw e_ccd3_array_schema("channel out of bounds");
}

///////////////////////////////////////////////////////////////////////////////

ccd3_amplifier_schema* ccd3_array_schema::channel2amplifier(unsigned channel){
	return get_detector_schema(channel2detector_idx(channel))->get_amp_schema(channel2amp_idx(channel));
}

///////////////////////////////////////////////////////////////////////////////

unsigned ccd3_array_schema::get_xsiz(void){
	return get_detector_schema(0)->get_xsiz() * (is_left_detectors_enabled() && is_right_detectors_enabled()  ?  2 : 1 );
}

///////////////////////////////////////////////////////////////////////////////

unsigned ccd3_array_schema::get_ysiz(void){
	return get_detector_schema(0)->get_ysiz() * (is_top_detectors_enabled()  && is_bottom_detectors_enabled() ?  2 : 1 );
}

///////////////////////////////////////////////////////////////////////////////

unsigned ccd3_array_schema::get_detectors_available(void){
	return mask2cnt(det_avail_mask);
}

///////////////////////////////////////////////////////////////////////////////

unsigned ccd3_array_schema::get_detectors_enabled(void){
	return mask2cnt(det_enabl_mask);
}

///////////////////////////////////////////////////////////////////////////////

unsigned ccd3_array_schema::get_amps_available(void){
	unsigned channel_cnt = 0;
	unsigned detector_no = 0;
	ccd3_detector_schema* detector_schema;

	for(detector_no=0; detector_no < get_detectors_available(); detector_no++){
		detector_schema = get_detector_schema(detector_no);
		channel_cnt += detector_schema->get_amps_available();
	}
	return channel_cnt;
}

///////////////////////////////////////////////////////////////////////////////

unsigned ccd3_array_schema::get_amps_enabled(void){
	unsigned amp_cnt;
	unsigned detector_no;
	ccd3_detector_schema* detector_schema;

	for(detector_no=amp_cnt=0; detector_no < get_detectors_available(); detector_no++){
		detector_schema = get_detector_schema(detector_no);

		if( detector_schema->is_enabled() ){
			amp_cnt += detector_schema->get_amps_enabled();
		}

	}
	return amp_cnt;
}

///////////////////////////////////////////////////////////////////////////////

ccd3_detector_schema* ccd3_array_schema::get_detector_schema(unsigned detector_no){

	if( detector_no >= MAX_DETECTORS ){
		throw e_ccd3_array_schema("%s: Detector index (%d) out of bounds", "ccd3_array_schema::get_detector_schema()", detector_no);
	}

	return &detectors[detector_no];
}

///////////////////////////////////////////////////////////////////////////////

unsigned ccd3_array_schema::get_pix_cnt(void){
	return get_xsiz() * get_ysiz();
}

///////////////////////////////////////////////////////////////////////////////

unsigned ccd3_array_schema::bottom_mask(void){
	unsigned res;

	for(unsigned n=res=0; n < cols; n++){
		res |= 0x1 << n;
	}

	return res;
}

///////////////////////////////////////////////////////////////////////////////

unsigned ccd3_array_schema::top_mask(void){
	return MAX_DETECTORS_MASK & ~bottom_mask();
}

///////////////////////////////////////e_ccd3_array_def////////////////////////////////////////

unsigned ccd3_array_schema::left_mask(void){
	unsigned res;

	for(unsigned n=res=0; n < rows; n++){
		res |= 0x1 << (n * cols);
	}

	return res;
}

///////////////////////////////////////////////////////////////////////////////

unsigned ccd3_array_schema::right_mask(void){
	return MAX_DETECTORS_MASK & ~left_mask();
}

///////////////////////////////////////////////////////////////////////////////

bool ccd3_array_schema::is_detector_bottom(unsigned det_idx){
	return cnt2mask(det_idx) & bottom_mask();
}

///////////////////////////////////////////////////////////////////////////////

bool ccd3_array_schema::is_detector_top(unsigned det_idx){
	return cnt2mask(det_idx) & top_mask();
}

///////////////////////////////////////////////////////////////////////////////

bool ccd3_array_schema::is_detector_left(unsigned det_idx){
	return cnt2mask(det_idx) & left_mask();
}

///////////////////////////////////////////////////////////////////////////////

bool ccd3_array_schema::is_detector_right(unsigned det_idx){
	return cnt2mask(det_idx) & right_mask();
}

///////////////////////////////////////////////////////////////////////////////

bool ccd3_array_schema::is_top_detectors_enabled(void){
	return top_mask() & det_enabl_mask;
}

///////////////////////////////////////////////////////////////////////////////

bool ccd3_array_schema::is_bottom_detectors_enabled(void){
	return bottom_mask() & det_enabl_mask;
}

///////////////////////////////////////////////////////////////////////////////

bool ccd3_array_schema::is_left_detectors_enabled(void){
	return left_mask() & det_enabl_mask;
}

///////////////////////////////////////////////////////////////////////////////

bool ccd3_array_schema::is_right_detectors_enabled(void){
	return right_mask() & det_enabl_mask;
}

///////////////////////////////////////////////////////////////////////////////
// EOF
