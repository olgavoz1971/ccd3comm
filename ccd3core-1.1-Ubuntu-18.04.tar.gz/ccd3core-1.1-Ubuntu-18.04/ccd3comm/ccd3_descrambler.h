/*
 * ccd3_descrambler.h
 *
 *  Created on: Dec 11, 2009
 *      Author: jja
 */

#ifndef CCD3_DESCRAMBLER_H_
#define CCD3_DESCRAMBLER_H_

#include "ccd3_pixel_processor.h"
#include "ccd3_geometry_processor.h"
#include "ccd3_array_def.h"

///////////////////////////////////////////////////////////////////////////////

class cCCD3AmplifierDescrambler {
protected:
	unsigned xsiz;
	unsigned ysiz;
	ccd3_amplifier_schema* amplifier_schema;
	cCCD3image_transformation amplifier_transformation;
	unsigned pix_cnt(void);

public:
	cCCD3AmplifierDescrambler(ccd3_amplifier_schema* a_amplifier_schema, cCCD3image_transformation offset = c_noop());
	t_point idx2xy(unsigned idx);
	t_point get_size(void){ return t_point(get_xsiz(), get_ysiz()); };
	unsigned get_xsiz(void){ return xsiz; };
	unsigned get_ysiz(void){ return ysiz; };
	typedef common_exception eCCD3AmplifierDescrambler;
};

///////////////////////////////////////////////////////////////////////////////

class cCCD3DetectorDescrambler {
protected:
	bool combine;
	bool use_corrections;
	cCCD3AmplifierDescrambler* amps[MAX_DETECTOR_AMPS];
	cCCD3image_transformation amp_shifts[MAX_DETECTOR_AMPS];
	cCCD3image_transformation detector_transformation;
	ccd3_detector_schema* detector_schema;

public:
	cCCD3DetectorDescrambler(ccd3_detector_schema* a_detector_schema, cCCD3image_transformation detector_offset, bool a_combine, bool a_corrections);
	~cCCD3DetectorDescrambler(void);
	void prepare_descrambler_image(void);
	void prepare_descrambler_extensions(void);
	t_point idx2xy(unsigned idx);
	unsigned get_xsiz(void){
		return combine ? detector_transformation.get_size(detector_schema->get_size()).x : amps[0]->get_xsiz();
	};

	unsigned get_ysiz(void){
		return combine ? detector_transformation.get_size(detector_schema->get_size()).y : amps[0]->get_ysiz() * amps_enabled();
	};

	t_point get_size(void){
		return combine ? detector_transformation.get_size(detector_schema->get_size()) : t_point(get_xsiz(), get_ysiz());
	};

	unsigned amps_enabled(void){
		unsigned cnt = 0;
		for(int n=0; n < MAX_DETECTOR_AMPS; n++){
			cnt += amps[n] ? 1 : 0;
		}
		return cnt;
	};
	typedef common_exception eCCD3DetectorDescrambler;
};

///////////////////////////////////////////////////////////////////////////////

class cCCD3ArrayDescrambler : public cCCD3pixel_processor
{
protected:
	int* index_start;
	int* index_end;
	int* index;
	bool index_valid;
	bool combine;
	bool corrections;
	unsigned detector_enabled_cnt;
	ccd3_array_schema* array_schema;
	cCCD3image_transformation array_transformation;
	cCCD3image_transformation detector_shifts[MAX_DETECTORS];
	cCCD3DetectorDescrambler* detectors[MAX_DETECTORS];
	void prepare_geometry(void);
	void prepare_geometry_2image(void);
	void prepare_geometry_2extensions(void);
	void setup_pixel_indexes(void);
	bool pre_process(void);
	int process(int pix_from, int pix_cnt);

public:
	cCCD3ArrayDescrambler(	cCCD3processor* a_src_class,
							unsigned* a_dst,
							ccd3_array_schema* array_def,
							bool a_combine,
							bool a_corrections,
							int a_blocksize);

	~cCCD3ArrayDescrambler(void);
	int idx2idx(int idx, int ext);
	t_point idx2xy(int idx, int ext);
	typedef common_exception eCCD3ArrayDescrambler;
};

#endif /* CCD3_DESCRAMBLER_H_ */
///////////////////////////////////////////////////////////////////////////////
// EOF

