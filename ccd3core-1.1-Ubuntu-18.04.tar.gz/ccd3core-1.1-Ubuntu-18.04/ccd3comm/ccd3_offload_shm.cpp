/*
 * ccd3_offload_shm.cpp
 *
 *  Created on: Dec 11, 2009
 *      Author: jja
 */

#include "ccd3_offload_shm.h"
#define MAX_PATTERN 3

int cCCD3shm_processor::test_pattern = 0;

///////////////////////////////////////////////////////////////////////////////
// cCCD3offload_shm specialization

cCCD3shm_processor::cCCD3shm_processor(unsigned* a_src, unsigned* a_dst, int a_blocksize)
: cCCD3processor(a_src, a_dst, a_blocksize)
{
	strcpy(name, "cCCD3shm_processor");
}

cCCD3shm_processor::cCCD3shm_processor(cCCD3processor* a_src_class, unsigned* a_src, unsigned* a_dst, int a_blocksize)
: cCCD3processor(a_src_class, a_dst, a_blocksize)
{
	strcpy(name, "cCCD3shm_processor");
}

void cCCD3shm_processor::set_pattern(int pattern)
{
	if( pattern > MAX_PATTERN){
		throw ECCD3shm("Invalid pattern!");
	}
	test_pattern = pattern;
}

void cCCD3shm_processor::set_offload(bool skip_offload)
{
	test_skipoffload = skip_offload;
}


int cCCD3shm_processor::process(int pix_from, int pix_cnt)
{
	if( !test_skipoffload ){
		memcpy(&dst[pix_from], &src[pix_from], pix_cnt << 2);
	}

	switch( test_pattern )
	{
	case 0:
		// No syntetic data
		break;

	case 1:
		// Emulate data with forth running values starting from 1M
		for(int n=0; n < pix_cnt; n++){
			dst[pix_from + n] = (pix_from + n) + 1000000;
		}
		break;

	case 2:
		// Emulate 2 amps, values are = amp_idx * 1000000 + idx + 1M
		for(int n=0; n < pix_cnt; n++){
			dst[pix_from + n] = ((pix_from + n) % 2) * 1000000 + ((pix_from + n) >> 1) + 1000000;
		}
		break;

	case 3:
		// Emulate 4 amps, values are = amp_idx * 1000000 + idx
		for(int n=0; n < pix_cnt; n++){
			dst[pix_from + n] = ((pix_from+n) % 4) * 1000000 + ((pix_from + n) >> 2) + 1000000;
		}
		break;
	default:
		return false;
	}

	return pix_cnt;
}
