#include <string.h>
#include <unistd.h>
#include <errno.h>
#include <sys/syscall.h>
#include <typeinfo>
#include "ccd3_processor.h"
#include "ccd3_log.h"

#define DEFAULT_DESTINATION_CNT 4

// Forward decl of thread function
void* thread_wrapper(cCCD3processor* parent);

///////////////////////////////////////////////////////////////////////////////

cCCD3processor::cCCD3processor(unsigned* a_src, unsigned* a_dst, int a_blocksize){
	src = a_src;
	src_class = NULL;
	dst = a_dst;
	dst_classes = new cFifo(DEFAULT_DESTINATION_CNT, sizeof(pCCD3processor));
	blocksize = a_blocksize;
	thread = 0;
	thread_error = false;
	is_running = false;

	strcpy(name, typeid(*this).name());

	reset();
}

///////////////////////////////////////////////////////////////////////////////

cCCD3processor::cCCD3processor(pCCD3processor a_src_class, unsigned* a_dst, int a_blocksize){
	src = a_src_class->dst;
	dst = a_dst;
	dst_classes = new cFifo(DEFAULT_DESTINATION_CNT, sizeof(pCCD3processor));
	src_class = a_src_class;
	blocksize = a_blocksize;
	thread = 0;//NULL;
	thread_error = false;
	is_running = false;

	strcpy(name, "cCCD3processor");

	reset();

	src_class->register_dst(this);
}

///////////////////////////////////////////////////////////////////////////////

cCCD3processor::~cCCD3processor(void)
{
	stop_thread();
	delete dst_classes;
}

///////////////////////////////////////////////////////////////////////////////

void cCCD3processor::reset(void)
{
	do_pause = false;
	is_paused = true;
	cnt = 0;
	completed = 0;

	stop_thread();
	init_thread();
}

///////////////////////////////////////////////////////////////////////////////

void cCCD3processor::init_thread(void)
{
	pthread_mutexattr_t attributes;

	pthread_mutex_init(&mutex, NULL);
	pthread_cond_init(&condition, NULL);

	pthread_mutexattr_init(&attributes);
	pthread_mutexattr_settype(&attributes, PTHREAD_MUTEX_ERRORCHECK);
	pthread_mutex_init(&thread_mutex, &attributes);
	pthread_mutexattr_destroy(&attributes);

	//pthread_mutex_lock(&thread_mutex);
	//lock_thread();

	do_run = true;

	if( 0 != (errno = pthread_create(&thread, NULL, (void*(*)(void*))thread_wrapper, this)) ){
		throw eProcessor("Failed to start processing thread", errno);
	}

}

///////////////////////////////////////////////////////////////////////////////

void cCCD3processor::set_priority(int a_priority)
{
	sched_param parm;
	parm.__sched_priority = a_priority;
	if( 0 != (errno = pthread_setschedparam(thread, SCHED_FIFO, &parm)) ){
		throw eProcessor("Failed to set scheduling parameters", errno);
	}
}
///////////////////////////////////////////////////////////////////////////////

void cCCD3processor::stop_thread(void)
{
	int ret;
	do_run = false;
	do_pause = false;

	if( thread ){
		while( is_running ){
			unlock_thread();
		}

		ret = pthread_join(thread, NULL);

		if( ret || is_running ){
			throw eProcessor("Failed stopping thread (%d)", ret);
		}

		is_paused = true;
		thread = 0;
		pthread_mutex_destroy(&thread_mutex);
		pthread_mutex_destroy(&mutex);
		pthread_cond_destroy(&condition);
	}
}

///////////////////////////////////////////////////////////////////////////////

void cCCD3processor::register_dst(pCCD3processor a_dst_class){

	dst_classes->put(&a_dst_class);
	a_dst_class->src = dst;
	a_dst_class->src_class = this;
}

///////////////////////////////////////////////////////////////////////////////

void cCCD3processor::lock(void){
	if( 0 != (errno =  pthread_mutex_lock(&mutex))){
		throw eProcessor("Failed locking mutex", errno);
	}
}

///////////////////////////////////////////////////////////////////////////////

void cCCD3processor::unlock(void){
	if( 0 != (errno = pthread_mutex_unlock(&mutex)) ){
		throw eProcessor("Failed unlocking mutex", errno);
	}
}

///////////////////////////////////////////////////////////////////////////////

void cCCD3processor::lock_thread(void){
	if( 0 != (errno = pthread_mutex_lock(&thread_mutex)) ){
		throw eProcessor("Failed locking thread mutex", errno);
	}

	if( 0 != (errno = pthread_cond_wait(&condition, &thread_mutex)) ){
		throw eProcessor("Failed waiting on pthread condition", errno);
	}

	if( 0 != (errno = pthread_mutex_unlock(&thread_mutex)) ){
		throw eProcessor("Failed unlocking thread mutex", errno);
	}
}

///////////////////////////////////////////////////////////////////////////////

void cCCD3processor::unlock_thread(void){

	if( 0 != (errno = pthread_mutex_lock(&thread_mutex)) ){
		throw eProcessor("Failed locking mutex while unlocking thread", errno);
	}

	if( 0 != (errno  = pthread_cond_signal(&condition)) ){
		throw eProcessor("Failed signalling pthread condition", errno);
	}

	if( 0 != (errno = pthread_mutex_unlock(&thread_mutex)) ){
		throw eProcessor("Failed unlocking thread mutex", errno);
	}
}

///////////////////////////////////////////////////////////////////////////////

long cCCD3processor::progress(void) {
	long my_completed;
	lock();
	my_completed = completed;
	unlock();
	return my_completed;
}

///////////////////////////////////////////////////////////////////////////////

bool cCCD3processor::finish(void) {
	bool res;
	lock();
	res = completed >= cnt;
	unlock();
	return res;
}

///////////////////////////////////////////////////////////////////////////////

void cCCD3processor::check_next(void)
{
	pCCD3processor next = NULL;

	for(int n=0; n < dst_classes->size(); n++){
		dst_classes->peek(&next, 1, n);
		next->save(completed);
	}
}

///////////////////////////////////////////////////////////////////////////////

void cCCD3processor::save(int a_cnt)
{
	if( !src_class && !src)
		throw eProcessor("Operation on processor class with unconnected source!");

	lock();

	if( a_cnt < cnt ){
		// Illegal ..

	} else {
		cnt = a_cnt;
	}

	if ( !do_pause ){
		unlock_thread();
	}
	
	unlock();
	check_next();
}

///////////////////////////////////////////////////////////////////////////////

void* cCCD3processor::worker_thread(void)
{
	int last_cnt = 0;
	int cpy_cnt;
	int res;

	pid = getpid();
	ppid = getppid();
	lwp = syscall(SYS_gettid);
	is_running = true;

	try {

		lock_thread();

		if( pre_process() ){

			while( do_run ) {

				lock();
				is_paused = false;
				cpy_cnt = cnt - last_cnt;
				cpy_cnt = min(cpy_cnt, blocksize);
				unlock();

				if( do_run && cpy_cnt ){

					res = process(last_cnt, cpy_cnt);
					if( res ){
						last_cnt += res;

						// wait on metrics mutex to update metrics
						lock();
						completed = last_cnt;
						unlock();
						check_next();  // TODO .. no really sure if it is wise to do this here???
					}
				} else {
					res = 0;
				}

				if( !res ) {
					// wait until more cnt .. or somebody says finish
					lock();
					is_paused = true;
					unlock();
					lock_thread();
				}
			} // while()

			post_process();

		} // if( pre_process() )

	} catch (exception &ex ){
		is_paused = true;
		is_running = false;
		thread_error = true;
		throw;
	}

	is_paused = true;
	is_running = false;
	return NULL;
}

///////////////////////////////////////////////////////////////////////////////

void* thread_wrapper(cCCD3processor* parent)
{
	char* trace=(char*)"";

	try {
		return parent->worker_thread();
	} catch(common_exception &ex) {

		printf("\n*** FATAL error in processing thread: %s ***\n\n", ex.what());
		printf("Stack trace for support personal:\n");

		LOGMSG(LOG_EMERG, "\n*** FATAL processing error: %s ***\n\n", ex.what());
		LOGMSG(LOG_EMERG, "Stack trace for support personal:\n");

		// Print stack trace
		for(int n=2; trace; n++){
			if( NULL != (trace = ex.trace(n)) ){
				printf("\t%s\n",trace ? trace : "");
				LOGMSG(LOG_EMERG, "\t%s\n",trace ? trace : "");
			}
		}
		fflush(stdout);
		parent->thread_error = true;
		parent->is_running = false;
		return NULL;
	}
}

///////////////////////////////////////////////////////////////////////////////
// EOF
