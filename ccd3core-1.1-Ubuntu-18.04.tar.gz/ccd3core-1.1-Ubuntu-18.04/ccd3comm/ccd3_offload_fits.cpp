/*
 * ccd3offload_fits.cpp
 *
 *  Created on: Dec 11, 2009
 *      Author: jja
 */

#include <stdarg.h>
#include <sys/time.h>
#include "ccd3_offload_fits.h"
#define MAX_HEADER_KEYWORDS 512

cFifo* cCCD3fits_processor::keywords = NULL;
struct timeval cCCD3fits_processor::t_exp_start = {0,0};

///////////////////////////////////////////////////////////////////////////////
// cCCD3offload_fits specialization

cCCD3fits_processor::cCCD3fits_processor(char* a_filename, unsigned* a_src, int a_xsiz, int a_ysiz, int a_blocksize)
: cCCD3pixel_processor(a_src, NULL, a_xsiz, a_ysiz, a_blocksize)
{
	descrambler = NULL;
	strcpy(filename, a_filename);
	init_class();
}

///////////////////////////////////////////////////////////////////////////////

cCCD3fits_processor::cCCD3fits_processor(char* a_filename, cCCD3pixel_processor* a_src_class, int a_blocksize)
: cCCD3pixel_processor(a_src_class, NULL, a_blocksize)
{
	descrambler = dynamic_cast<cCCD3ArrayDescrambler*>(a_src_class);
	strcpy(filename, a_filename);
	init_class();
}

///////////////////////////////////////////////////////////////////////////////

void cCCD3fits_processor::init_class(void)
{
	status = 0;
	memset(fits, 0, sizeof(fitsfile*) * (MAX_FITS_EXTENSIONS + 1));
	strcpy(name, "cCCD3fits_processor");
}

///////////////////////////////////////////////////////////////////////////////

cCCD3fits_processor::~cCCD3fits_processor(void)
{
	stop_thread();

	if( fits[0] && !status ){
		for(unsigned ext = 0; ext <= ext_cnt; ext++){
			fits_close_file(fits[ext], &status);
		}
	}
	if( keywords ){
		delete keywords;
		keywords = NULL;
	}

	// If we were aborted, dismiss file
	if( completed != (pix_cnt() * ext_cnt) ){
		remove(filename);
	}
	strcpy(filename, "");
}

///////////////////////////////////////////////////////////////////////////////

/*
void cCCD3fits_processor::end(void)
{
	struct tm *TM;
	time_t Tt;
	char key[] = "TM_END";
	int sec_count;
	time (&Tt);
	TM = gmtime(&Tt);
	sec_count = TM->tm_sec + (60 * (TM->tm_min + (60 * TM->tm_hour)));
	write_key(0, TUINT, key, &sec_count);
}
*/

///////////////////////////////////////////////////////////////////////////////

void cCCD3fits_processor::exp_start(void)
{
	char str_date[256];
	//double second;
	//char time_string[256];

	gettimeofday(&t_exp_start, NULL);
	//second = get_timedate_str(&t_exp_start, str_date);
	get_timedate_str(&t_exp_start, str_date);
	write_key(0, TSTRING, "DATE-OBS", str_date, "Start of exposure");
	write_key(0, TSTRING, "DATE_OBS", str_date, "Start of exposure");

	/*
	sprintf(time_string,"%7.3f",second);
	second = atof(time_string);
	write_key(0, TDOUBLE, "TM_START", &second, "Start of exposure in sec. since midnight");
	*/
}

///////////////////////////////////////////////////////////////////////////////

void cCCD3fits_processor::exp_end(int time_actual)
{
	struct timeval t_exp_end;
	struct timeval t_exp_avg;
	//double second;
	char str_date[256];

	t_exp_end = t_exp_start;
	t_exp_end.tv_sec  += time_actual/1000;					// millisecs to secs
	t_exp_end.tv_usec += (time_actual % 1000) * 1000;		// reminder to usecs

	t_exp_avg.tv_sec = (t_exp_end.tv_sec + t_exp_start.tv_sec) / 2;
	t_exp_avg.tv_usec = (t_exp_end.tv_usec + t_exp_start.tv_usec) / 2;

	// Correct for ½ rounding in tv_sec
	t_exp_avg.tv_usec += ((t_exp_end.tv_sec + t_exp_start.tv_sec) % 2) * 1000000/2;

	while ( t_exp_avg.tv_usec > 1000000 ){
		t_exp_avg.tv_sec++;
		t_exp_avg.tv_usec -= 1000000;
	}

	fflush(stdout);
	get_timedate_str(&t_exp_avg, str_date);
	write_key(0, TSTRING, "DATE-AVG", str_date, "Mid-point of exposure");
	//second = get_timedate_str(&t_exp_end, str_date);
}

///////////////////////////////////////////////////////////////////////////////

void cCCD3fits_processor::check_fits_error(int sts){
	char buf[31];

	if( sts ){
		fits_get_errstatus(sts, buf);
		throw eFitsProcessor(".fits error: %s", buf);
	}
}


///////////////////////////////////////////////////////////////////////////////

void cCCD3fits_processor::set_fits_std_comment(bool new_fits_std_comment){
    fits_std_comment = new_fits_std_comment;
}

///////////////////////////////////////////////////////////////////////////////

void cCCD3fits_processor::commit_keywords(void)
{
	int size;
	fits_keyword* kwords;

	if( !keywords ) return;
	size = keywords->size();
	if( !size ) return;

	kwords = new fits_keyword[size];
	if( !kwords) throw eFitsProcessor("Memory allocation error");
	keywords->getbuf(kwords);

	for(int n = 0; n < size; n++){
		if( kwords[n].extension == EXT_HDR){
			for( unsigned ext = 1; ext <= ext_cnt; ext++ ){
				kwords[n].extension = ext;
				set_keyword(&kwords[n]);
			}
		} else if( kwords[n].extension == ALL_HDR){
			for( unsigned ext = 0; ext <= ext_cnt; ext++ ){
				kwords[n].extension = ext;
				set_keyword(&kwords[n]);
			}
		}else {
			set_keyword(&kwords[n]);
		}
	}

	delete[] kwords;
	kwords = NULL;
	delete keywords;
	keywords = NULL;

	if( !fits_std_comment ){
	    // Delete annoying comment:
	    // COMMENT  FITS (Flexible Image Transport System) format is defined in 'Astronomy
	    // COMMENT  and Astrophysics' vol 376, page 359; bibcode 2001A&A...376..359H.
	    fits_delete_record(fits[0], 5, &status);
	    fits_delete_record(fits[0], 5, &status);
	}
}

///////////////////////////////////////////////////////////////////////////////

void cCCD3fits_processor::set_keyword(fits_keyword* keyword){

	if( keyword->extension <= ext_cnt){
		::fits_update_key(fits[keyword->extension], keyword->type, keyword->key, keyword->value, keyword->comment, &status);

		if( status == KEY_NO_EXIST ){
			::fits_write_key(fits[keyword->extension], keyword->type, keyword->key, keyword->value, keyword->comment, &status);
		}

		check_fits_error(status);
	}
}

///////////////////////////////////////////////////////////////////////////////

void cCCD3fits_processor::write_key(const char* string, ...)
{
	va_list arg;
	char buf[256];
	char extension[256];
	char type[256]="";
	char key[256]="";
	char value[256]="";
	char *comment_str = NULL;
	char* c_ptr;
	char* delim_ptr;

	va_start (arg, string);
	vsprintf(buf, string, arg);
	va_end (arg);

	if( 3 > sscanf(buf, "%s %s %s %s", extension, type, key, value)){
		throw eFitsProcessor("Invalid key string, see help");
	}

	c_ptr = strstr(buf, value);
	if(*c_ptr == '"'){
		c_ptr++;
		delim_ptr = strstr(c_ptr, "\"");
		if( !delim_ptr ){
			throw eFitsProcessor("missing closing delimiter in string");
		}
		*delim_ptr = '\0';
		strcpy(value, c_ptr);
	} else {
		throw eFitsProcessor("missing start delimiter in string");
	}

	c_ptr = ++delim_ptr;

	delim_ptr = strstr(c_ptr, "\"");

	if( delim_ptr ){	// if start of comment found
		c_ptr = delim_ptr + 1;
		delim_ptr = strstr(c_ptr, "\"");
		if( !delim_ptr ){
			throw eFitsProcessor("missing delimiter in comment");
		}
		*delim_ptr = '\0';
		comment_str = c_ptr;
	}

	write_key(extension, type, key, value, comment_str);

}

void cCCD3fits_processor::write_key(const char* extension, const char* type, const char* key, const char* value, const char* comment)
{
	char my_string[256]="";
	int my_int;
	double my_double;
	void* val = NULL;
	int n_type = -1;
	int n_ext = -1;

	for( int n=0; n < header_type_count; n++){
		if( !strcasecmp(type, header_types[n].type_str) ){
			n_type = header_types[n].type;
			break;
		}
	}

	if( n_type == -1 )
		throw eFitsProcessor("unknown fits header type (%s)", type);

	switch(n_type){
		// TBD .. Really don't know what do with these??
		//case TBIT
		//case TBYTE	:
		//case TSBYTE	:
		case TSTRING : 	strcpy(my_string, value);
						val = my_string;
						break;

		case TUSHORT : 	if( 1 != sscanf(value, "%hu", (unsigned short*)&my_int)){
							throw eFitsProcessor("invalid TUSHORT value: \"%s\"", value);
						}
						val = &my_int;
						break;

		case TSHORT	 : 	if( 1 != sscanf(value, "%hd", (short*)&my_int)){
							throw eFitsProcessor("invalid TSHORT value: \"%s\"", value);
						}
						val = &my_int;
						break;

		case TUINT	 : 	if( 1 != sscanf(value, "%u",  (unsigned*)&my_int)){
							throw eFitsProcessor("invalid TUINT value: \"%s\"", value);
						}
						val = &my_int;
						break;

		case TLOGICAL:  val = &my_int;
						if( 1 == sscanf(value, "%d", (int*)&my_int)){
							break;
						} else if( !strcasecmp("T", value)){
							my_int = 1;
							break;
						} else if( !strcasecmp("F", value)){
							my_int = 0;
							break;
						} else {
							throw eFitsProcessor("invalid TLOGICAL value: \"%s\"", value);
						}

		case TINT	 : 	if( 1 != sscanf(value, "%d", &my_int)){
							throw eFitsProcessor("invalid TINT value: \"%s\"", value);
						}
						val = &my_int;
						break;

		case TULONG	 : 	if( 1 != sscanf(value, "%ld", (unsigned long*)&my_int)){
							throw eFitsProcessor("invalid TULONG value: \"%s\"", value);
						}
						val = &my_int;
						break;

		case TLONG	 : 	if( 1 != sscanf(value, "%lu", (long*)&my_int)){
							throw eFitsProcessor("invalid TLONG value: \"%s\"", value);
						}
						val = &my_int;
						break;

		case TFLOAT	 :	if( 1 != sscanf(value, "%f", (float*)&my_double)){
							throw eFitsProcessor("invalid TFLOAT value: \"%s\"", value);
						}
						val = &my_double;
						break;

		case TDOUBLE :  if( 1 != sscanf(value, "%lf", &my_double)){
							throw eFitsProcessor("invalid TDOUBLE value: \"%s\"", value);
						}
						val = &my_double;
						break;

		default		 :  throw eFitsProcessor("Unknown fits header type conversion");
	}

	if( 1 != sscanf(extension, "%d ", &n_ext)){
		throw eFitsProcessor("Invalid extension format, see help");
	}

	write_key(n_ext, n_type, (char*)key, val, (char*)comment);
}

///////////////////////////////////////////////////////////////////////////////

void cCCD3fits_processor::write_key(int extension, const int type, const char* key, const void* value, const char* comment)
{
	fits_keyword keyword;
	int sz = 0;

	for( int n=0; n < header_type_count; n++){
		if( type == header_types[n].type ){
			sz = header_types[n].b_size;;
			break;
		}
	}

	keyword.extension = extension;
	keyword.type = type;
	strcpy(keyword.key, key);
	memcpy(keyword.value, value, sz);
	strcpy(keyword.comment, comment ? comment : "");

	write_key(&keyword);
}

///////////////////////////////////////////////////////////////////////////////
void cCCD3fits_processor::write_key(int extension, const char* key, const bool value, const char* comment){
	write_key(extension, TLOGICAL, key, &value, comment);
}

///////////////////////////////////////////////////////////////////////////////
void cCCD3fits_processor::write_key(int extension, const char* key, const int value, const char* comment){
	write_key(extension, TINT, key, &value, comment);
}

///////////////////////////////////////////////////////////////////////////////
void cCCD3fits_processor::write_key(int extension, const char* key, const unsigned value, const char* comment){
	write_key(extension, TUINT, key, &value, comment);
}


///////////////////////////////////////////////////////////////////////////////

void cCCD3fits_processor::write_key(fits_keyword* keyword){

	/*if( keyword->extension != ALL_HDR && keyword->extension != EXT_HDR && keyword->extension > ext_cnt ){
		throw eFitsProcessor("Invalid extension \"%d\", only %d extensions in this file", keyword->extension, ext_cnt);
	}*/

	if( !keywords ){
		keywords = new cFifo(MAX_HEADER_KEYWORDS, sizeof(fits_keyword));
	}

	keywords->put(keyword);
}

///////////////////////////////////////////////////////////////////////////////

double cCCD3fits_processor::get_timedate_str(struct timeval* time, char* buf)
{
	struct tm* TM;
	int year, month, day, hour, minute;//, second;
	double f_second, acc_second;
	int sts = 0;

	TM = gmtime(&time->tv_sec);
	year = TM->tm_year + 1900;
	month = TM->tm_mon + 1;
	day = TM->tm_mday;
	hour =  TM->tm_hour;
	minute =  TM->tm_min;
	f_second =  TM->tm_sec;
	f_second += (double)time->tv_usec / 1000000.0;

	fits_time2str(year, month, day, hour, minute, f_second, 3, buf, &sts);
	check_fits_error(sts);

	//second = TM->tm_sec + (60 * (TM->tm_min + (60 * TM->tm_hour)));
	acc_second = TM->tm_sec + (60 * (TM->tm_min + (60 * TM->tm_hour)));
	acc_second += (double)time->tv_usec / 1000000.0;
	return acc_second;
}

///////////////////////////////////////////////////////////////////////////////

bool cCCD3fits_processor::pre_process(void){
	int timeref;
	char str_file_date[256];
	long naxis[2];
	char *ptr;
	char tmp[MAX_PATH];
	char my_filename[MAX_PATH];

	strcpy(my_filename, filename);

	if( !strlen(my_filename) ){
		return false;
	}

	// Main header in fits[0]
	if( file_exists(my_filename)){
		fits_open_file(&fits[0], my_filename, READWRITE, &status);
	} else {
		fits_create_file(&fits[0], my_filename, &status);
		if( my_filename[0] == '!'){
			strcpy(tmp, my_filename);
			strcpy(my_filename, &tmp[1]);
		}
	}
	check_fits_error(status);

	fits_create_img(fits[0], ULONG_IMG, 0, NULL, &status);
	check_fits_error(status);

	fits_get_system_time(str_file_date, &timeref, &status);
	check_fits_error(status);

	write_key(0, TSTRING, "DATE", str_file_date, "HDU creation");

	ptr = strrchr(my_filename, '/');
	if( !ptr ){
		ptr = my_filename;
	} else {
		ptr++;
	}
	write_key(0, TSTRING, "FILENAME", ptr, "Filename");

	naxis[0] = xsiz;
	naxis[1] = ysiz;

	// First fits extension in fits[1]
	for(unsigned ext=1; ext <= ext_cnt; ext++){

		fits_open_file(&fits[ext], my_filename, READWRITE, &status);
		check_fits_error(status);

		fits_create_img(fits[ext], ULONG_IMG, 2, naxis, &status);
		check_fits_error(status);

		fits_movabs_hdu(fits[ext], ext + 1, NULL, &status);
		check_fits_error(status);

		write_key("%d TSTRING EXTNAME \"im%d\"", ext, ext);
		write_key(ext, TUINT, "IMAGEID", &ext, NULL);
		write_key("%d TLOGICAL INHERIT \"T\"", ext);
	}

	return true;
}

int cCCD3fits_processor::process(int from, int cnt)
{
	int cpy_cnt;
	int cpy_from;
	long fpixel[2];
	long lpixel[2];
	long fpixel2[2];
	long lpixel2[2];
	int ext_base;
	int ext_offset;
	unsigned int* p_src;
	unsigned ext_idx;
	bool horizontal_write = false;
	t_point point_start;
	t_point point_end;

	cpy_cnt = cnt / ext_cnt;	// Per ext
	cpy_cnt -= cpy_cnt % xsiz;	// only complete lines
	cpy_from = from / ext_cnt;

	if( cpy_cnt ){

		for(ext_idx=0; ext_idx < ext_cnt; ext_idx++){

			if( descrambler ){
				// A descrambled image may be filled from either side .. in any order
				// Find start/end point for descrambled image subset
				point_start = descrambler->idx2xy(cpy_from, ext_idx);
				point_end = descrambler->idx2xy(cpy_from + cpy_cnt - 1, ext_idx);

				horizontal_write = abs(point_start.x - point_end.x) != (int)(xsiz-1) && abs(point_start.y - point_end.y) == (int)(ysiz-1);

				// normalize possibly rotated and mirrored coordinates, reversed data sequence
				// and so forth, which cfitsio does not like
				// First corner
				fpixel[0] = min(point_start.x, point_end.x);
				fpixel[1] = min(point_start.y, point_end.y);
				// Last corner
				lpixel[0] = max(point_start.x, point_end.x);
				lpixel[1] = max(point_start.y, point_end.y);

			} else {
				// Otherwise assume forth-running pixels, starting from 1,1
				// First corner
				fpixel[0] = 1 + (cpy_from % xsiz);
				fpixel[1] = 1 + (cpy_from / xsiz);
				// Last corner
				lpixel[0] = 1 + ((cpy_from + cpy_cnt -1) % xsiz);
				lpixel[1] = 1 + ((cpy_from + cpy_cnt -1) / xsiz);

			}

			ext_base = ext_idx * pix_cnt();

			if( horizontal_write ){
				// in this mode we need to write one single line at a time

				fpixel2[0] = fpixel[0];
				lpixel2[0] = lpixel[0];

				for(int n=fpixel[1]; n <= lpixel[1]; n++){
					fpixel2[1] = n;
					lpixel2[1] = n;
					ext_offset = (fpixel2[0]-1) + (fpixel2[1]-1) * xsiz;
					p_src = &src[ext_base + ext_offset];
					fits_write_subset(fits[ext_idx + 1], TUINT, fpixel2, lpixel2, p_src, &status);
					check_fits_error(status);
				}

			} else {

				ext_offset = (fpixel[0]-1) + (fpixel[1]-1) * xsiz;
				p_src = &src[ext_base + ext_offset];
				fits_write_subset(fits[ext_idx + 1], TUINT, fpixel, lpixel, p_src, &status);

			}
			check_fits_error(status);
		}
	}

	return cpy_cnt * ext_cnt;
}

///////////////////////////////////////////////////////////////////////////////

void cCCD3fits_processor::post_process(void){
	commit_keywords();
}


///////////////////////////////////////////////////////////////////////////////
// EOF
