/*
 *  Copyright (c) 2006 Copenhagen University Astronomical Observatory
 *  All possible rights reserved
 *	Filename:	
 *  Abstract:	
 *  Author:		Jeppe Jønch Andersen (jja@astro.ku.dk)
 *  Revision:
 *  Remarks:
 */
 
#ifndef CCD3_SHM_H_
#define CCD3_SHM_H_
#include "ipc_shm.h"

class cCCD3mem : public TIpc
{
protected:
public:
	cCCD3mem(int size, bool FailExists);
	unsigned int* Mem;
};

#endif /*CCD3_SHM_H_*/

///////////////////////////////////////////////////////////////////////////////
// EOF
