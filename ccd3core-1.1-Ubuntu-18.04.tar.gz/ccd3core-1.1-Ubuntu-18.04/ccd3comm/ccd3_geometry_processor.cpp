/*
 * ccd3_geometry_processor.cpp
 *
 *  Created on: Apr 13, 2010
 *      Author: jja
 */

#include "ccd3_geometry_processor.h"
#include <unistd.h>

// Place image
cCCD3geometry_processor::cCCD3geometry_processor(unsigned* a_src, unsigned* a_dst, int a_xsiz, int a_ysiz, bool a_mirror_x, bool a_mirror_y, t_rotation a_rotation, int a_blocksize, int a_ext_cnt)
:cCCD3pixel_processor(a_src, a_dst, a_xsiz, a_ysiz, a_blocksize, a_ext_cnt)
{
	ext_cnt = a_ext_cnt;
	rotation = a_rotation;
	mirror_x = a_mirror_x;
	mirror_y = a_mirror_y;
	prepare_transformation();
}

cCCD3geometry_processor::cCCD3geometry_processor(cCCD3pixel_processor* a_src_class, unsigned* a_dst, bool a_mirror_x, bool a_mirror_y, t_rotation a_rotation, int a_blocksize)
: cCCD3pixel_processor(a_src_class, a_dst, a_blocksize)
{
	rotation = a_rotation;
	mirror_x = a_mirror_x;
	mirror_y = a_mirror_y;
	prepare_transformation();
}

cCCD3geometry_processor::cCCD3geometry_processor(cCCD3processor* a_src_class, unsigned* a_dst, int a_xsiz, int a_ysiz, bool a_mirror_x, bool a_mirror_y, t_rotation a_rotation, int a_blocksize, int a_ext_cnt)
: cCCD3pixel_processor(a_src_class, a_dst, a_blocksize)
{
	ext_cnt = a_ext_cnt;
	xsiz = a_xsiz;
	ysiz = a_ysiz;
	rotation = a_rotation;
	mirror_x = a_mirror_x;
	mirror_y = a_mirror_y;
	prepare_transformation();
}

cCCD3geometry_processor::~cCCD3geometry_processor(void)
{
	stop_thread();

	for(unsigned ext=0; ext < (ext_cnt -1); ext++){
		if( !childs[ext])continue;
		delete childs[ext];
	}
}

void cCCD3geometry_processor::prepare_transformation(void)
{
	memset(childs, 0, sizeof(childs));

	switch( rotation ){
	case r90:
		transformation *= rotate_90_matrice;
		break;
	case r180:
		transformation *= rotate_90_matrice;
		transformation *= rotate_90_matrice;
		break;
	case r270:
		transformation *= rotate_90_matrice;
		transformation *= rotate_90_matrice;
		transformation *= rotate_90_matrice;
		break;
	case r0:
	default:break;
	}

	if( mirror_x ){
		transformation *= mirror_x_matrice;
	}

	if( mirror_y ){
		transformation *= mirror_y_matrice;
	}

	switch( ext_cnt ){
	case 1:
		break;

	case 2:
		childs[0] = new cCCD3geometry_processor(&src[pix_cnt()], &dst[pix_cnt()], xsiz, ysiz, mirror_x, mirror_y, rotation, blocksize);
		break;

	case 4:
		for(int n=0; n < (4-1); n++){
			childs[n] = new cCCD3geometry_processor(&src[(n+1) * pix_cnt()], &dst[(n+1) * pix_cnt()], xsiz, ysiz, mirror_x, mirror_y, rotation, blocksize);
		}
		break;

	default:
		throw eGeometry_processor("Invalid number of extensions!");
	}

	src_xsiz = xsiz;
	src_ysiz = ysiz;
	xsiz = abs(transformation.x(src_xsiz, src_ysiz/*, 0, 0*/));
	ysiz = abs(transformation.y(src_xsiz, src_ysiz/*, 0, 0*/));
}

void cCCD3geometry_processor::register_dst(cCCD3processor* a_dst_class)
{
	cCCD3processor::register_dst( a_dst_class );
	for(unsigned ext=0; ext < (ext_cnt - 1); ext++){
		childs[ext]->register_dst(&dst[(ext+1) * pix_cnt()]);
		//childs[ext]->dst = &dst[(ext+1) * pix_cnt()];
	}
}

void cCCD3geometry_processor::register_dst(unsigned* a_dst)
{
	cCCD3processor::register_dst( a_dst );
	for(unsigned ext=0; ext < (ext_cnt - 1); ext++){
		childs[ext]->register_dst(&dst[(ext+1) * pix_cnt()]);
	}
}



int cCCD3geometry_processor::process(int pix_from, int pix_cnt)
{
	div_t d;
	int row;
	int col;
	int dst_row;
	int dst_col;

	if( !dst ) return 0;
	pix_from /= ext_cnt;
	pix_cnt  /= ext_cnt;

	for(unsigned ext = 0; ext < (ext_cnt - 1); ext++){
		childs[ext]->process(pix_from, pix_cnt);
	}

	d = div(pix_from, src_xsiz);
	int row_start = d.quot;
	d = div(pix_from + pix_cnt, src_xsiz);
	int row_to = d.quot;

	for(row = row_start; row <= row_to; row++){
		for(col = 0; col < src_xsiz; col++){
			dst_col = transformation.x(col, row/*, src_xsiz-1, src_ysiz-1*/);
			dst_row = transformation.y(col, row/*, src_xsiz-1, src_ysiz-1*/);
			dst[dst_row * xsiz + dst_col] = src[row * src_xsiz + col];
		}
	}

	//UpdateStatistics(pix_from, pix_from + pix_cnt, src);

	return pix_cnt;
}
