/*
 * ccd3_pixel_processor.cpp
 *
 *  Created on: Apr 6, 2011
 *      Author: root
 */

#ifndef CCD3_PIXEL_PROCESSOR_CPP_
#define CCD3_PIXEL_PROCESSOR_CPP_

#include "ccd3_pixel_processor.h"

///////////////////////////////////////////////////////////////////////////////
// cCCD3pixel_processor


cCCD3pixel_processor::cCCD3pixel_processor(unsigned int* a_src, unsigned* a_dst, int a_xsiz, int a_ysiz, int a_blocksize, int a_ext_cnt)
: cCCD3processor(a_src, a_dst, a_blocksize)
{
	xsiz = a_xsiz;
	ysiz = a_ysiz;
	ext_cnt = a_ext_cnt;
	strcpy(name, "cCCD3pixel_processor");
}

cCCD3pixel_processor::cCCD3pixel_processor(cCCD3pixel_processor* a_src_class, unsigned* a_dst, int a_blocksize)
: cCCD3processor(a_src_class, a_dst, a_blocksize)
{
	xsiz = a_src_class->xsiz;
	ysiz = a_src_class->ysiz;
	ext_cnt = a_src_class->ext_cnt;
	strcpy(name, "cCCD3pixel_processor");
}

cCCD3pixel_processor::cCCD3pixel_processor(cCCD3processor* a_src_class, unsigned* a_dst, int a_blocksize)
: cCCD3processor(a_src_class, a_dst, a_blocksize)
{
	xsiz = 0;
	ysiz = 0;
	ext_cnt = 0;
	strcpy(name, "cCCD3pixel_processor");
}


#endif /* CCD3_PIXEL_PROCESSOR_CPP_ */
