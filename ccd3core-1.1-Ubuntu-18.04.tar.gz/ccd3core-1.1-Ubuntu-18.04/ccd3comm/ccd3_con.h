/*
 *  Copyright (c) 2006 Copenhagen University Astronomical Observatory
 *  All possible rights reserved
 *	Filename:	ccd3comm_con.h
 *  Abstract:	
 *  Author:		Jeppe Jønch Andersen (jja@astro.ku.dk)
 *  Revision:
 *  Remarks:
 */
 
#ifndef CCD3COMM_CON_H_
#define CCD3COMM_CON_H_

#include <stdio.h>
#include "ccd3_engine.h"
#include "ccd3_ivy_schema.h"
#include "fifo.h"
#include "filo.h"
#include "ccd3_log.h"
#include "common_exception.h"
#include "ccd3_ivy.h"
#include "vt100.h"
#include "inifiles.h"
#include "ds9_interface.h"


#define DEFAULT_ANSI				true	/* use ansi codes						*/

#define MAX_PROGRAM_HEADER_LENGTH	60		/* length of a program header liner		*/
#define IVY_BUF_LENGTH				256
#define CCD3CmdUnknown		"Unknown command!\nType \"Help\" for usage information.\n"
#define CCD3CmdInvalid		"Invalid command!\nType \"Help\" for usage information.\n"

#define CCD3VersionTxt	"v0.1"

#define MAX_CMD_HISTORY 50
#define MAX_BATCH_FILES 10
#define MAX_CMDLINE_LEN 256

#define IS_OPTION_SET(x) (options & x)

#define IVY_MSG(x) IvyMessages[x].IvyToken

#define L_ANSI   MAKE_FLAG(ccNormal, ccDont)

#define CON cCCD3console::Instance()

typedef enum {
	nsUnknown = 0,
	nsNOT,
	nsDefault,
	nsCustom
} TNameStyle;

typedef struct {
	char args[MAX_PATH];
	char filename[MAX_PATH];
	FILE* file;
}TBatchfile;

class cCCD3console{
    protected:
	cCCD3engine* Engine;
	ccd3_array_schema Array;
	cCCD3ivy* ivy;			// Ivy bus connection
	ds9_comm* ds9;
	MsgRcvPtr ivy_id;
	IVY_MSG IvyMessages[ivy_msg_count];
	int ivy_pipe[2];
	BOOL EnableIvy;
	int cmd_executing;
	int date_shift;
	int event_handler_start;
	ccd3Verbosity cmd_executing_verbosity;
	BOOL DoQuit;	
	BOOL daemon_mode;
	BOOL rx_ok;
	BOOL tx_ok;
	time_t start_time;
	cFilo* batch_files;
	TIniFile* ini_file;
	char config_filename[MAX_PATH];
	char script_dir[MAX_PATH];
	char exec_on_appstart[MAX_PATH];
	char exec_on_exposure[MAX_PATH];
	char exec_on_readout[MAX_PATH];
	char exec_on_fileclose[MAX_PATH];
	char exec_on_appclose[MAX_PATH];
	char exec_on_error[MAX_PATH];
	char img_filepath[MAX_PATH];
	char filestd[MAX_PATH];
	char prefix[MAX_PATH];
	TNameStyle namestyle;
	bool autosave;
	unsigned char cmd_history_idx;
	cFifo* cmd_history;
	char keybuf[MAX_CMDLINE_LEN];
	char batchbuf[MAX_CMDLINE_LEN];
	char ivybuf[IVY_BUF_LENGTH];
	HSUBSCRIPTION hError;
	HSUBSCRIPTION hBrek;
	HSUBSCRIPTION hSint;
	HSUBSCRIPTION hDrv;
	HSUBSCRIPTION hExp;
	HSUBSCRIPTION hReadout;
	HSUBSCRIPTION hFileclose;
	HSUBSCRIPTION hEngineError;

	void   InitIniFile(void);
	void   CloseIniFile(void);
	void   InitIvy(void);
	void   CloseIvy(void);
	void   InitDS9(bool a_remote);
	void   CloseDS9(void);
	void   InitConsole(void);
	void   CloseConsole(void);
	void   InitLog(void);
	void   CloseLog(void);
	void   InitPriority(void);
	bool   StringIsTrue(char* str);
	bool   StringIsFalse(char* str);
	bool   StringIsBool(char* str);
	//void   AddStaticKeywords(void);
	bool   AddBatchfile(char* batch_filename, char* args = (char*)"");
	void   CloseBatchfile(void);
	void   CloseBatchfiles(void);
	void   InitFilename(void);
	void   OpenNextFile(char* path = NULL, char* name = NULL, bool overwrite = false);
	bool   CheckPath(char* path);
	void   SetFilepath(char* path);
	void   GetNOTFilename(const char* path, char* name);
	void   GetCCD3Filename(const char* path, char* name);
	void   GetCustomFilename(const char* path, char* name);
	int    GetNextFileno(const char* path, const char* pre, const char* post);
	void   GetFilename(const char* path, char* name);
	char*  GetConsoleCommand(char* buf);
	char*  GetBatchCommand(char* buf);
	char*  GetIvyCommand(char* buf);
	char*  GetCommand(char* buf);
	int    HandleEscapeSequence(char* buf, int idx);
	int    HandleBackspace(char* buf, int idx);
	int    HandleUnknownCommand(char* cmd);

	//void HandleRMS(char* buf);
	//void ShowStoredImage(int idx);
	void Evaluate(char* buf);
	void ShowMatrice(unsigned long* matrice, unsigned xsiz, unsigned ysiz, unsigned pos);
	// Utility functions
	void ParseOptions(int argc, char** argv);	    
	void PrintHelp(void);
	void PrintCmdlineHelp(void);
	void ProcessBatchFile(char* filename);
	void Execute(char* command_line, char* args = (char*)"", bool wait_child = false);
	char* getmd5(char* file);
	bool daemonize(void);
	static cCCD3console* me;
	static bool reload;
	
	// Callbacks
	void ConCallback(HSUBSCRIPTION hSubscription, char* data);
	void DefCallback(HSUBSCRIPTION hSubscription, char* data);
	void CamCallback(HSUBSCRIPTION hSubscription, char* data);
	void DrvCallback(HSUBSCRIPTION hSubscription, char* data);
	void EngineCallback(HSUBSCRIPTION hSubscription, char* data);
	void IvyCallback(IvyClientPtr app, int argc, char** argv);

	// Wrapper Callbacks
	friend void DmyConCallback(HSUBSCRIPTION hSubscription, char* data, void* user);
	friend void DmyDefCallback(HSUBSCRIPTION hSubscription, char* data, void* user);
	friend void DmyCamCallback(HSUBSCRIPTION hSubscription, char* data, void* user);
	friend void DmyDrvCallback(HSUBSCRIPTION hSubscription, char* data, void* user);
	friend void DmyEngineCallback(HSUBSCRIPTION hSubscription, char* data, void* user);
	friend void DmyIvyCallback(IvyClientPtr app, void* data, int argc, char** argv);

    public:
	cCCD3console(int argc, char** argv);
	~cCCD3console(void);
	static cCCD3console* Instance(void){ return me; };
	static bool IsReloading(void){ return reload; };
	static void DoReload(void){ reload = true; };
	//void Print(ccd3LogVerbosity Levels, const char* Str, ...);
	void Prompt(void);
	void Prompt(ccd3Verbosity Verb);
	void IvySend(IVY_MSG_IDX ivy_idx, const char* Str = "", ...);
	int Run(void);
	void Quit(void);

	typedef common_exception ECCD3;
	typedef ECCD3 EInvalidArg;
	typedef ECCD3 EMissingArg;
	typedef ECCD3 EUnknownArg;
};

#endif /*CCD3COMM_CON_H_*/

///////////////////////////////////////////////////////////////////////////////
// EOF
