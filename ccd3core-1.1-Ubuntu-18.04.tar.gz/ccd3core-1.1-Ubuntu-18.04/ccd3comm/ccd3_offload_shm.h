/*
 * ccd3_offload_shm.h
 *
 *  Created on: Dec 11, 2009
 *      Author: jja
 */

#ifndef CCD3_OFFLOAD_SHM_H_
#define CCD3_OFFLOAD_SHM_H_

#include <common_exception.h>
#include "ccd3_processor.h"

class cCCD3shm_processor : public cCCD3processor
{
protected:
	static int test_pattern;
	bool test_skipoffload;
	virtual int process(int pix_from, int pix_cnt);
public:
	static void set_pattern(int pattern);
	void set_offload(bool skip_offload);
	cCCD3shm_processor(unsigned* a_src, unsigned* a_dst, int a_bloksize);
	cCCD3shm_processor(cCCD3processor* a_src_class, unsigned* a_src, unsigned* a_dst, int a_bloksize);
	typedef common_exception ECCD3shm;
};

#endif /* CCD3_OFFLOAD_SHM_H_ */
