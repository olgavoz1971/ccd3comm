/*
 * ccd3_pixel_processor.h
 *
 *  Created on: Apr 6, 2011
 *      Author: root
 */

#ifndef CCD3_PIXEL_PROCESSOR_H_
#define CCD3_PIXEL_PROCESSOR_H_

#include "ccd3_processor.h"

class cCCD3pixel_processor : public cCCD3processor
{
protected:
	unsigned xsiz;
	unsigned ysiz;
	unsigned ext_cnt;

	int pix_cnt(void){
		return xsiz * ysiz;
	}

public:
	cCCD3pixel_processor(unsigned* a_src, unsigned* a_dst, int a_xsiz, int a_ysiz, int a_blocksize, int a_ext_cnt = 1);
	cCCD3pixel_processor(cCCD3pixel_processor* a_src_class, unsigned* a_dst, int a_blocksize);
	cCCD3pixel_processor(cCCD3processor* a_src_class, unsigned* a_dst, int a_blocksize);
	typedef eProcessor ePixelProcessor;
};


#endif /* CCD3_PIXEL_PROCESSOR_H_ */
