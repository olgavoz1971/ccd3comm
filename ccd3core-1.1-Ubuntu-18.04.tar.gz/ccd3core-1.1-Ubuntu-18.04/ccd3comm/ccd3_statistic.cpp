/*
 * ccd3_statistic.cpp
 *
 *  Created on: Apr 6, 2011
 *      Author: root
 */

#include <math.h>
#include <limits.h>
#include "ccd3_statistic.h"


cCCD3statistic_processor::cCCD3statistic_processor(cCCD3processor* a_src_class, unsigned a_null_val, unsigned a_period, int a_blocksize)
:cCCD3processor(a_src_class, NULL, a_blocksize)
{
	minval = UINT_MAX;
	maxval = 0;
	null_val = a_null_val;
	average = 0;
	deviation = 0;
	period = a_period;
	strcpy(name, "cCCD3statistic_processor");
}

void cCCD3statistic_processor::UpdateStatistics(int from, int to){
	double my_pow;
	unsigned* ptr = &src[from];
	unsigned* end = &src[to];

	do {
		if( *ptr != null_val){
			minval = min(minval, *ptr);
			maxval = max(maxval, *ptr);

			if( ptr - src ){
				average = ((average * (ptr - src - 1)) + *ptr) / (ptr - src);
				my_pow = pow(*ptr - average, 2);
				deviation = sqrt(((deviation * (ptr - src - 1)) + my_pow) / (ptr - src));
			} else {
				average = *ptr;
				deviation = 0;
			}
		}
		ptr += period;

	} while (ptr < end);
}

int cCCD3statistic_processor::process(int pix_from, int pix_cnt)
{
	UpdateStatistics(pix_from, pix_from + pix_cnt);
	return pix_cnt;
}

///////////////////////////////////////////////////////////////////////////////
// EOF

