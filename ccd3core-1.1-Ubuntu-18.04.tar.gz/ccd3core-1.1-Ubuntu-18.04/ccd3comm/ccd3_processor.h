#ifndef CCD3PROCESSOR_H_
#define CCD3PROCESSOR_H_

#include <pthread.h>
#include <stdlib.h>
#include "common.h"
#include "fifo.h"

///////////////////////////////////////////////////////////////////////////////
// Virtual base class for processing streams
class cCCD3processor;

typedef cCCD3processor* pCCD3processor;

class cCCD3processor
{
protected:
	pid_t pid;
	pid_t ppid;
	int lwp;
	int blocksize;
	bool do_run;
	bool do_pause;
	bool is_paused;
	bool is_running;	//
	bool thread_error;
	char name[256];
	unsigned* src;			// Source
	unsigned* dst;			// Destination
	long cnt;				// number of bytes to process
	long completed; 		// number of bytes already processed
	pthread_t thread;

	pthread_cond_t condition;
	pCCD3processor src_class;
	cFifo* dst_classes;

	pthread_mutex_t mutex;
	pthread_mutex_t thread_mutex;
	virtual void lock(void);
	virtual void unlock(void);
	virtual void lock_thread(void);
	virtual void unlock_thread(void);
	virtual void check_next(void);
	virtual void init_thread(void);
	virtual void stop_thread(void);

	virtual void* worker_thread(void);
	virtual bool pre_process(void){ return true; };
	virtual int process(int pix_from, int pix_cnt) = 0;
	virtual void post_process(void){};
	friend void* thread_wrapper(cCCD3processor* parent);

public:
	cCCD3processor(unsigned* a_src, unsigned* a_dst, int a_blocksize);
	cCCD3processor(pCCD3processor a_src_class, unsigned* a_dst, int a_blocksize);
	virtual ~cCCD3processor(void);
	virtual void reset(void);
	virtual char* get_name(void){ return name; };
	virtual long progress(void);
	virtual void save(int a_cnt);
	virtual bool finish(void);
	virtual bool error(void){ return thread_error; };
	virtual bool paused(void){ return is_paused; };
	virtual void pause(void){ do_pause = true; };
	virtual void resume(void){ do_pause = false; save(cnt); };
	virtual void register_dst(cCCD3processor* a_dst_class);
	virtual void register_dst(unsigned* a_dst){ dst = a_dst; };
	virtual void set_block_size(int a_blocksize){ blocksize = a_blocksize; };
	virtual void set_priority(int a_priority);
	
	typedef common_exception eProcessor;
};

///////////////////////////////////////////////////////////////////////////////
#endif /*CCD3PROCESSOR_H_*/
