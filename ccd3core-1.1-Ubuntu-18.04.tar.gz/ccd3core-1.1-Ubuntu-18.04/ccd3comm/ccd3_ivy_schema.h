#ifndef CCD3_IVY_SCHEMA_H_
#define CCD3_IVY_SCHEMA_H_

#include "ccd3_ini_schema.h"
#include "ccd3_ivy.h"

#define IVY_INI_TOKEN_SIZE 256

#define DEFAULT_IVY_PREFIX INI_IVY_DEFAULT_NAME

// Ivy application class messages
#define DEFAULT_IVY_APPLICATION_CLASS	"application"
#define DEFAULT_IVY_APPLICATION_START	DEFAULT_IVY_APPLICATION_CLASS ".start"
#define DEFAULT_IVY_APPLICATION_STOP	DEFAULT_IVY_APPLICATION_CLASS ".stop"
#define DEFAULT_IVY_APPLICATION_ERROR	DEFAULT_IVY_APPLICATION_CLASS ".error"
#define DEFAULT_IVY_APPLICATION_RESET	DEFAULT_IVY_APPLICATION_CLASS ".reset"
#define DEFAULT_IVY_APPLICATION_IDLE	DEFAULT_IVY_APPLICATION_CLASS ".idle"
#define INI_IVY_APP_START				"on_start"
#define INI_IVY_APP_STOP				"on_stop"
#define INI_IVY_APP_ERROR				"on_error"
#define INI_IVY_APP_RESET				"on_reset"
#define INI_IVY_APP_IDLE				"on_idle"

// Ivy console class messages
#define DEFAULT_IVY_CONSOLE_CLASS		"con"
#define DEFAULT_IVY_CON_COMMAND			DEFAULT_IVY_CONSOLE_CLASS ".command"
#define DEFAULT_IVY_CON_RESPONSE		DEFAULT_IVY_CONSOLE_CLASS ".response"
#define INI_IVY_CON_COMMAND				"on_command" 
#define INI_IVY_CON_RESPONSE			"on_response"

// Ivy exposure class messages
#define DEFAULT_IVY_EXPOSURE_CLASS		"exposure"
#define DEFAULT_IVY_EXPOSURE_START		DEFAULT_IVY_EXPOSURE_CLASS ".start"
#define DEFAULT_IVY_EXPOSURE_PROGRESS	DEFAULT_IVY_EXPOSURE_CLASS ".progress"
#define DEFAULT_IVY_EXPOSURE_END		DEFAULT_IVY_EXPOSURE_CLASS ".end"
#define INI_IVY_EXP_START				"on_exposure_start"
#define INI_IVY_EXP_PROGRESS			"on_exposure_progress"
#define INI_IVY_EXP_END					"on_exposure_end"

// Ivy camera data transfer class messages
#define DEFAULT_IVY_TRANSFER_CLASS		"transfer"
#define DEFAULT_IVY_TRANSFER_START		DEFAULT_IVY_TRANSFER_CLASS ".start"
#define DEFAULT_IVY_TRANSFER_PROGRESS	DEFAULT_IVY_TRANSFER_CLASS ".progress"
#define DEFAULT_IVY_TRANSFER_END		DEFAULT_IVY_TRANSFER_CLASS ".end"
#define INI_IVY_TRANSFER_START			"on_transfer_start"
#define INI_IVY_TRANSFER_PROGRESS		"on_transfer_progress"
#define INI_IVY_TRANSFER_END			"on_transfer_end"

// Ivy shared memory class messages
#define DEFAULT_IVY_SHM_CLASS			"shm"
#define DEFAULT_IVY_SHM_START			DEFAULT_IVY_SHM_CLASS ".start"
#define DEFAULT_IVY_SHM_PROGRESS		DEFAULT_IVY_SHM_CLASS ".progress"
#define DEFAULT_IVY_SHM_END				DEFAULT_IVY_SHM_CLASS ".end"
#define INI_IVY_SHM_START				"on_shm_start"
#define INI_IVY_SHM_PROGRESS			"on_shm_progress"
#define INI_IVY_SHM_END					"on_shm_end"

// Ivy statistic class messages
#define DEFAULT_IVY_STAT_CLASS			"stat"
#define DEFAULT_IVY_STAT_START			DEFAULT_IVY_STAT_CLASS ".start"
#define DEFAULT_IVY_STAT_PROGRESS		DEFAULT_IVY_STAT_CLASS ".progress"
#define DEFAULT_IVY_STAT_END			DEFAULT_IVY_STAT_CLASS ".end"
#define INI_IVY_STAT_START				"on_stat_start"
#define INI_IVY_STAT_PROGRESS			"on_stat_progress"
#define INI_IVY_STAT_END				"on_stat_end"

// Ivy descramble class messages
#define DEFAULT_IVY_DESCRAMBLE_CLASS	"descramble"
#define DEFAULT_IVY_DESCRAMBLE_START	DEFAULT_IVY_DESCRAMBLE_CLASS ".start"
#define DEFAULT_IVY_DESCRAMBLE_PROGRESS DEFAULT_IVY_DESCRAMBLE_CLASS ".progress"
#define DEFAULT_IVY_DESCRAMBLE_END		DEFAULT_IVY_DESCRAMBLE_CLASS ".end"
#define INI_IVY_DESCRAMBLE_START		"on_descramble_start"
#define INI_IVY_DESCRAMBLE_PROGRESS		"on_descramble_progress"
#define INI_IVY_DESCRAMBLE_END			"on_descramble_end"

// Ivy preview class messages
#define DEFAULT_IVY_PREVIEW_CLASS		"preview"
#define DEFAULT_IVY_PREVIEW_START		DEFAULT_IVY_PREVIEW_CLASS ".start"
#define DEFAULT_IVY_PREVIEW_PROGRESS 	DEFAULT_IVY_PREVIEW_CLASS ".progress"
#define DEFAULT_IVY_PREVIEW_END			DEFAULT_IVY_PREVIEW_CLASS ".end"
#define INI_IVY_PREVIEW_START			"on_preview_start"
#define INI_IVY_PREVIEW_PROGRESS		"on_preview_progress"
#define INI_IVY_PREVIEW_END				"on_preview_end"

// Ivy file class messages
#define DEFAULT_IVY_FILE_CLASS			"file"
#define DEFAULT_IVY_FILE_NAME			DEFAULT_IVY_FILE_CLASS ".name"
#define DEFAULT_IVY_FILE_PATH			DEFAULT_IVY_FILE_CLASS ".path"
#define DEFAULT_IVY_FILE_AUTO			DEFAULT_IVY_FILE_CLASS ".auto"
#define DEFAULT_IVY_FILE_STD			DEFAULT_IVY_FILE_CLASS ".std"
#define DEFAULT_IVY_FILE_CLOSE			DEFAULT_IVY_FILE_CLASS ".close"
#define DEFAULT_IVY_FILE_START			DEFAULT_IVY_FILE_CLASS ".start"
#define DEFAULT_IVY_FILE_PROGRESS		DEFAULT_IVY_FILE_CLASS ".progress"
#define DEFAULT_IVY_FILE_END			DEFAULT_IVY_FILE_CLASS ".end"
#define DEFAULT_IVY_FILE_KEYWORD		DEFAULT_IVY_FILE_CLASS ".keyword"
#define INI_IVY_FILE_NAME				"on_file_name"
#define INI_IVY_FILE_PATH				"on_file_path"
#define INI_IVY_FILE_AUTO				"on_file_auto"
#define INI_IVY_FILE_STD				"on_file_std"
#define INI_IVY_FILE_CLOSE				"on_file_close"
#define INI_IVY_FILE_START				"on_file_start"
#define INI_IVY_FILE_PROGRESS			"on_file_progress"
#define INI_IVY_FILE_END				"on_file_end"
#define INI_IVY_FILE_KEYWORD			"on_file_keyword"

// Ivy camera class messages
#define DEFAULT_IVY_CAM_CLASS			"cam"
#define DEFAULT_IVY_CAM_QUERY			DEFAULT_IVY_CAM_CLASS ".query"
#define DEFAULT_IVY_CAM_REPLY			DEFAULT_IVY_CAM_CLASS ".reply"
#define DEFAULT_IVY_CAM_ERROR			DEFAULT_IVY_CAM_CLASS ".error"
#define DEFAULT_IVY_CAM_XSIZ			DEFAULT_IVY_CAM_CLASS ".xsiz"
#define DEFAULT_IVY_CAM_YSIZ			DEFAULT_IVY_CAM_CLASS ".ysiz"
#define DEFAULT_IVY_CAM_READ			DEFAULT_IVY_CAM_CLASS ".read"
#define DEFAULT_IVY_CAM_TIME			DEFAULT_IVY_CAM_CLASS ".time"
#define DEFAULT_IVY_CAM_TIMR			DEFAULT_IVY_CAM_CLASS ".timr"
#define DEFAULT_IVY_CAM_STAT			DEFAULT_IVY_CAM_CLASS ".stat"
#define INI_IVY_CAM_QUERY				"on_cam_query"
#define INI_IVY_CAM_REPLY				"on_cam_reply"
#define INI_IVY_CAM_ERROR				"on_cam_error"
#define INI_IVY_CAM_XSIZ				"on_cam_xsiz"
#define INI_IVY_CAM_YSIZ				"on_cam_ysiz"
#define INI_IVY_CAM_READ				"on_cam_read"
#define INI_IVY_CAM_TIME				"on_cam_time"
#define INI_IVY_CAM_TIMR				"on_cam_timr"
#define INI_IVY_CAM_STAT				"on_cam_stat"

// Ivy communication class messages
#define DEFAULT_IVY_COMM_CLASS			"comm"
#define DEFAULT_IVY_COMM_OK				DEFAULT_IVY_COMM_CLASS ".ok"
#define DEFAULT_IVY_COMM_ERROR			DEFAULT_IVY_COMM_CLASS ".error"
#define DEFAULT_IVY_COMM_TIMEOUT		DEFAULT_IVY_COMM_CLASS ".timeout"
#define INI_IVY_COMM_OK					"on_comm_ok"
#define INI_IVY_COMM_ERROR				"on_comm_error"
#define INI_IVY_COMM_TIMEOUT			"on_comm_timeout"

// ivy message definitions
typedef char IVY_MSG_TEXT[IVY_MSG_SIZE];
typedef char IVY_INI_TOKEN[IVY_INI_TOKEN_SIZE];

typedef struct {
	IVY_MSG_TEXT IvyToken;
	IVY_INI_TOKEN IniToken;
} IVY_MSG;

// ivy message enumerations
typedef enum {
	ivy_none = 0,
	ivy_application_start,
	ivy_application_stop,
	ivy_application_error,
	ivy_application_reset,
	ivy_application_idle,
	ivy_console_command,
	ivy_console_response,
	ivy_exposure_start,
	ivy_exposure_progress,
	ivy_exposure_end,
	ivy_transfer_start,
	ivy_transfer_progress,
	ivy_transfer_end,
	ivy_shm_start,
	ivy_shm_progress,
	ivy_shm_end,
	ivy_stat_start,
	ivy_stat_progress,
	ivy_stat_end,
	ivy_descramble_start,
	ivy_descramble_progress,
	ivy_descramble_end,
	ivy_preview_start,
	ivy_preview_progress,
	ivy_preview_end,
	ivy_file_name,
	ivy_file_path,
	ivy_file_auto,
	ivy_file_std,
	ivy_file_close,
	ivy_file_start,
	ivy_file_progress,
	ivy_file_end,
	ivy_file_keyword,
	ivy_cam_query,
	ivy_cam_reply,
	ivy_cam_error,
	ivy_cam_xsiz,
	ivy_cam_ysiz,
	ivy_cam_read,
	ivy_cam_time,
	ivy_cam_timr,
	ivy_cam_stat,
	ivy_comm_ok,
	ivy_comm_error,
	ivy_comm_timeout,
	ivy_msg_count,
} IVY_MSG_IDX;

const IVY_MSG DEFAULT_IVY_MSG[ivy_msg_count] = {
	{ "",								"\0"						},
	{ DEFAULT_IVY_APPLICATION_START,	INI_IVY_APP_START			},
	{ DEFAULT_IVY_APPLICATION_STOP,		INI_IVY_APP_STOP			},
	{ DEFAULT_IVY_APPLICATION_ERROR,	INI_IVY_APP_ERROR			},
	{ DEFAULT_IVY_APPLICATION_RESET,	INI_IVY_APP_RESET			},
	{ DEFAULT_IVY_APPLICATION_IDLE,		INI_IVY_APP_IDLE			},
	{ DEFAULT_IVY_CON_COMMAND,			INI_IVY_CON_COMMAND			},
	{ DEFAULT_IVY_CON_RESPONSE,			INI_IVY_CON_RESPONSE		},
	{ DEFAULT_IVY_EXPOSURE_START,		INI_IVY_EXP_START			},
	{ DEFAULT_IVY_EXPOSURE_PROGRESS,	INI_IVY_EXP_PROGRESS		},
	{ DEFAULT_IVY_EXPOSURE_END,			INI_IVY_EXP_END				},
	{ DEFAULT_IVY_TRANSFER_START,		INI_IVY_TRANSFER_START		},
	{ DEFAULT_IVY_TRANSFER_PROGRESS,	INI_IVY_TRANSFER_PROGRESS	},
	{ DEFAULT_IVY_TRANSFER_END,			INI_IVY_TRANSFER_END		},
	{ DEFAULT_IVY_SHM_START,			INI_IVY_SHM_START			},
	{ DEFAULT_IVY_SHM_PROGRESS,			INI_IVY_SHM_PROGRESS		},
	{ DEFAULT_IVY_SHM_END,				INI_IVY_SHM_END				},
	{ DEFAULT_IVY_STAT_START,			INI_IVY_STAT_START			},
	{ DEFAULT_IVY_STAT_PROGRESS,		INI_IVY_STAT_PROGRESS		},
	{ DEFAULT_IVY_STAT_END,				INI_IVY_STAT_END			},
	{ DEFAULT_IVY_DESCRAMBLE_START,		INI_IVY_DESCRAMBLE_START	},
	{ DEFAULT_IVY_DESCRAMBLE_PROGRESS,	INI_IVY_DESCRAMBLE_PROGRESS	},
	{ DEFAULT_IVY_DESCRAMBLE_END,		INI_IVY_DESCRAMBLE_END		},
	{ DEFAULT_IVY_PREVIEW_START,		INI_IVY_PREVIEW_START		},
	{ DEFAULT_IVY_PREVIEW_PROGRESS,		INI_IVY_PREVIEW_PROGRESS	},
	{ DEFAULT_IVY_PREVIEW_END,			INI_IVY_PREVIEW_END			},
	{ DEFAULT_IVY_FILE_NAME,			INI_IVY_FILE_NAME			},
	{ DEFAULT_IVY_FILE_PATH,			INI_IVY_FILE_PATH			},
	{ DEFAULT_IVY_FILE_AUTO,			INI_IVY_FILE_AUTO			},
	{ DEFAULT_IVY_FILE_STD,				INI_IVY_FILE_STD			},
	{ DEFAULT_IVY_FILE_CLOSE,			INI_IVY_FILE_CLOSE			},
	{ DEFAULT_IVY_FILE_START,			INI_IVY_FILE_START			},
	{ DEFAULT_IVY_FILE_PROGRESS,		INI_IVY_FILE_PROGRESS		},
	{ DEFAULT_IVY_FILE_END,				INI_IVY_FILE_END			},
	{ DEFAULT_IVY_FILE_KEYWORD,			INI_IVY_FILE_KEYWORD		},
	{ DEFAULT_IVY_CAM_QUERY,			INI_IVY_CAM_QUERY			},
	{ DEFAULT_IVY_CAM_REPLY,			INI_IVY_CAM_REPLY			},
	{ DEFAULT_IVY_CAM_ERROR,			INI_IVY_CAM_ERROR			},
	{ DEFAULT_IVY_CAM_XSIZ,				INI_IVY_CAM_XSIZ			},
	{ DEFAULT_IVY_CAM_YSIZ,				INI_IVY_CAM_YSIZ			},
	{ DEFAULT_IVY_CAM_READ,				INI_IVY_CAM_READ			},
	{ DEFAULT_IVY_CAM_TIME,				INI_IVY_CAM_TIME			},
	{ DEFAULT_IVY_CAM_TIMR,				INI_IVY_CAM_TIMR			},
	{ DEFAULT_IVY_CAM_STAT,				INI_IVY_CAM_STAT			},
	{ DEFAULT_IVY_COMM_OK,				INI_IVY_COMM_OK				},
	{ DEFAULT_IVY_COMM_ERROR,			INI_IVY_COMM_ERROR			},
	{ DEFAULT_IVY_COMM_TIMEOUT,			INI_IVY_COMM_TIMEOUT		}
};


#endif /*CCD3_IVY_SCHEMA_H_*/
