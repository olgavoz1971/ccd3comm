/*
 * ccd3_descrambler.cpp
 *
 *  Created on: Dec 11, 2009
 *      Author: jja
 */

#include <stdlib.h>
#include "ccd3_descrambler.h"

///////////////////////////////////////////////////////////////////////////////
// Implementation of cCCD3Amplifier

cCCD3AmplifierDescrambler::cCCD3AmplifierDescrambler(ccd3_amplifier_schema* a_amplifier_schema, cCCD3image_transformation offset){

	amplifier_transformation = offset;
	amplifier_schema = a_amplifier_schema;

	t_point new_amp_size = amplifier_transformation.get_size(t_point(amplifier_schema->xsiz, amplifier_schema->ysiz) );
	xsiz = new_amp_size.x;
	ysiz = new_amp_size.y;

}

///////////////////////////////////////////////////////////////////////////////

unsigned cCCD3AmplifierDescrambler::pix_cnt(void){
	return xsiz * ysiz;
}

///////////////////////////////////////////////////////////////////////////////

t_point cCCD3AmplifierDescrambler::idx2xy(unsigned idx){

	if( idx >= pix_cnt() ){
		throw eCCD3AmplifierDescrambler("amplifier index out of bounds");
	}
	t_point org(1 + idx % amplifier_schema->xsiz, 1 + idx / amplifier_schema->xsiz);
	return amplifier_transformation.xy(org);
}

///////////////////////////////////////////////////////////////////////////////
// Implementation of cCCD3Detector

cCCD3DetectorDescrambler::cCCD3DetectorDescrambler(
		ccd3_detector_schema* a_detector_schema,
		cCCD3image_transformation detector_offset,
		bool a_combine,
		bool a_corrections)
{

	detector_transformation = detector_offset;
	detector_schema = a_detector_schema;
	combine = a_combine;
	use_corrections = a_corrections;

	memset(amps, 0, sizeof(amps));

	if( combine ){
		prepare_descrambler_image();
	} else {
		prepare_descrambler_extensions();
	}

}

///////////////////////////////////////////////////////////////////////////////

cCCD3DetectorDescrambler::~cCCD3DetectorDescrambler(void){
	for(unsigned n=0; n < MAX_DETECTOR_AMPS; n++){
		if( amps[n] ){
			delete amps[n];
			amps[n] = NULL;
		}
	}
}

///////////////////////////////////////////////////////////////////////////////

void cCCD3DetectorDescrambler::prepare_descrambler_image(void){
	cCCD3image_transformation amp_offset;
	ccd3_amplifier_schema* amplifier_schema;
	unsigned amps_enabled_cnt = 0;

	for(int amp_idx=amps_enabled_cnt=0; amp_idx < MAX_DETECTOR_AMPS; amp_idx++){

		amplifier_schema = detector_schema->get_amp_schema(amp_idx);

		if( !amplifier_schema->enabled )
			continue;

		amp_offset = c_noop();									// reset amplifier offset

		if( amplifier_schema->placement.mirror_x ){
			amp_offset *= c_mirror_x(amplifier_schema->xsiz + 1);
		}

		if( amplifier_schema->placement.mirror_y ){
			amp_offset *=  c_mirror_y(amplifier_schema->ysiz + 1);
		}

		amp_shifts[amps_enabled_cnt] += t_point(amplifier_schema->placement.xbeg, 0);
		amp_shifts[amps_enabled_cnt] += t_point(0, amplifier_schema->placement.ybeg);

		amps[amps_enabled_cnt++] = new cCCD3AmplifierDescrambler(amplifier_schema, amp_offset);
	} // for (amp_idx ..
}

///////////////////////////////////////////////////////////////////////////////

void cCCD3DetectorDescrambler::prepare_descrambler_extensions(void){
	cCCD3image_transformation amp_offset;
	ccd3_amplifier_schema* amplifier_schema;
	unsigned amps_enabled_cnt = 0;
	t_point original_amp_size;
	t_point new_amp_size;

	for(int amp_idx=amps_enabled_cnt=0; amp_idx < MAX_DETECTOR_AMPS; amp_idx++){

		amplifier_schema = detector_schema->get_amp_schema(amp_idx);
		original_amp_size = t_point(amplifier_schema->xsiz, amplifier_schema->ysiz);
		new_amp_size = original_amp_size;

		if( !amplifier_schema->enabled )
			continue;

		amp_offset = c_noop();									// reset amplifier offset

		if( detector_schema->is_amp_right(amp_idx) ){			// Does this amplifier reads out from right?
			amp_offset *= c_mirror_x(amplifier_schema->xsiz + 1);
		}

		if( detector_schema->is_amp_top(amp_idx) ){				// Does this amplifier read out from top?
			amp_offset *= c_mirror_y(amplifier_schema->ysiz + 1);
		}

		if( use_corrections ){

			if( detector_schema->get_mirror_x()){
				amp_offset *= c_mirror_x(amplifier_schema->xsiz + 1);
			}

			if( detector_schema->get_mirror_y()){
				amp_offset *= c_mirror_y(amplifier_schema->ysiz + 1);
			}


			switch( detector_schema->get_rotation() ){
			case r270:
				amp_offset *= c_rotate_90(new_amp_size.y + 1);
				new_amp_size = amp_offset.get_size( original_amp_size );
			case r180:
				amp_offset *= c_rotate_90(new_amp_size.y + 1);
				new_amp_size = amp_offset.get_size( original_amp_size );
			case r90:
				amp_offset *= c_rotate_90(new_amp_size.y + 1);
				new_amp_size = amp_offset.get_size( original_amp_size );
			case r0:
				break;
			default:
				throw eCCD3DetectorDescrambler("Invalid rotation");
			}
		}

		amp_shifts[amps_enabled_cnt] = t_point(0, new_amp_size.y * amps_enabled_cnt);
		amps[amps_enabled_cnt++] = new cCCD3AmplifierDescrambler(amplifier_schema, amp_offset);
	} // for( amp_idx ...
}

///////////////////////////////////////////////////////////////////////////////

t_point cCCD3DetectorDescrambler::idx2xy(unsigned idx){
	t_point amp_point;
	t_point shifted_point;
	t_point detector_point;
	amp_point = amps[idx % amps_enabled()]->idx2xy((idx / amps_enabled()));
	shifted_point = amp_shifts[idx % amps_enabled()].xy(amp_point);
	detector_point = detector_transformation.xy(shifted_point);
	return detector_point;
}

///////////////////////////////////////////////////////////////////////////////
// Implementation of cCCD3Array class

cCCD3ArrayDescrambler::cCCD3ArrayDescrambler(
		cCCD3processor* a_src_class,
		unsigned* a_dst,
		ccd3_array_schema* a_array_schema,
		bool a_combine,
		bool a_corrections,
		int a_blocksize
) : cCCD3pixel_processor(a_src_class, a_dst, a_blocksize)
{
	strcpy(name, "cCCD3ArrayDescrambler");

	combine = a_combine;
	corrections = a_corrections;
	array_schema = a_array_schema;
	memset(detectors, 0, sizeof(detectors));

	index_start = new int[array_schema->get_pix_cnt()];
	index = index_start;
	index_end = &index_start[array_schema->get_pix_cnt()];
	memset(index_start, 0, sizeof(*index_start) * array_schema->get_pix_cnt());
	index_valid = false;

	prepare_geometry();
}

///////////////////////////////////////////////////////////////////////////////

cCCD3ArrayDescrambler::~cCCD3ArrayDescrambler(void){

	stop_thread();

	for(unsigned n=0; n < detector_enabled_cnt; n++){
		if( detectors[n] ){
			delete detectors[n];
			detectors[n] = NULL;
		}
	}

	if( index_start ){
		delete[] index_start;
		index_start = NULL;
	}
}

///////////////////////////////////////////////////////////////////////////////
// extension idx to total idx
int cCCD3ArrayDescrambler::idx2idx(int idx, int ext){
	if( &index_start[idx * ext_cnt + ext] > index_end ){
		throw eCCD3ArrayDescrambler("Index out of bounds");
	}
	return index_start[(idx * ext_cnt) + ext];
}

///////////////////////////////////////////////////////////////////////////////
// from idx in extension -> x,y point in extension
t_point cCCD3ArrayDescrambler::idx2xy(int idx, int ext){
	t_point tmp;
	int new_idx;
	new_idx = combine ? idx : idx2idx(idx, ext);
	tmp.x = 1 + new_idx % xsiz;
	tmp.y = 1 + (new_idx / xsiz) - (combine ? 0 : ext * ysiz);
	return tmp;
}


///////////////////////////////////////////////////////////////////////////////

void cCCD3ArrayDescrambler::prepare_geometry(void){
	if( combine){
		prepare_geometry_2image();
	} else {
		prepare_geometry_2extensions();
	}
}

///////////////////////////////////////////////////////////////////////////////

void cCCD3ArrayDescrambler::prepare_geometry_2image(void){
	cCCD3image_transformation detector_offset;
	ccd3_detector_schema* detector_schema;
	int det_idx = 0;
	t_point original_size(array_schema->get_xsiz(), array_schema->get_ysiz());
	t_point new_size = original_size;

	// Setup detectors
	for(det_idx = detector_enabled_cnt = 0; det_idx < MAX_DETECTORS; det_idx++){

		detector_schema = array_schema->get_detector_schema(det_idx);

		if( !detector_schema->is_enabled())
			continue;

		detector_offset = c_noop();
		detector_shifts[det_idx] = c_noop();

		// if this detector reads out vertical, rotate it
		if( detector_schema->get_orientation() == DET_VERTICAL){
			detector_offset *= c_rotate_90(detector_schema->get_ysiz());
		}

		// if this detector is on the top row .. and there are active detectors at the bottom row
		if( array_schema->is_detector_top(det_idx) && array_schema->is_bottom_detectors_enabled() ){
			detector_shifts[det_idx] += t_point(0, detector_schema->get_ysiz());
		}

		// if this detector is on right coloumn .. and there are active detectors at left coloumn
		if( array_schema->is_detector_right(det_idx) && array_schema->is_left_detectors_enabled()){
			detector_shifts[det_idx] += t_point(detector_schema->get_xsiz(), 0);
		}

		detectors[detector_enabled_cnt++] = new cCCD3DetectorDescrambler(detector_schema, detector_offset, true, false);
	} // for( all detectors)

	if( corrections ){

		if( array_schema->get_mirror_x() ){
			array_transformation *= c_mirror_x(array_schema->get_xsiz() + 1);
		}

		if( array_schema->get_mirror_y() ){
			array_transformation *= c_mirror_y(array_schema->get_ysiz() + 1);
		}

		switch( array_schema->get_rotation() ){
		case r270:
			array_transformation *= c_rotate_90(new_size.y + 1);
			new_size = array_transformation.get_size(original_size);
		case r180:
			array_transformation *= c_rotate_90(new_size.y + 1);
			new_size = array_transformation.get_size(original_size);
		case r90:
			array_transformation *= c_rotate_90(new_size.y + 1);
			new_size = array_transformation.get_size(original_size);
		case r0:
			break;
		default:
			throw eCCD3ArrayDescrambler("Invalid rotation");
		}
	} // if( corrections )

	xsiz = new_size.x;
	ysiz = new_size.y;
	ext_cnt = 1;

}

///////////////////////////////////////////////////////////////////////////////
#define INCLUDE_GEOMETRY_IN_FILE

void cCCD3ArrayDescrambler::prepare_geometry_2extensions(void){
	cCCD3image_transformation detector_offset;
	ccd3_detector_schema* detector_schema;
	ext_cnt = array_schema->get_amps_enabled();

	// Setup detectors
	for(unsigned det_idx = detector_enabled_cnt = 0; det_idx < MAX_DETECTORS; det_idx++){

		detector_schema = array_schema->get_detector_schema(det_idx);

		if( !detector_schema->is_enabled() )
			continue;

		detector_offset = c_noop();

		// if this detector reads out vertical, rotate it
		if( detector_schema->get_orientation() == DET_VERTICAL ){
			detector_offset *= c_rotate_90(detector_schema->get_ysiz()); // TODO should this be actual ysiz?? .. please find out
		}

		detectors[detector_enabled_cnt] = new cCCD3DetectorDescrambler(detector_schema, detector_offset, false, corrections);
		detector_shifts[detector_enabled_cnt] = t_point(0, detectors[detector_enabled_cnt]->get_ysiz() * detector_enabled_cnt);;
		detector_enabled_cnt++;

	} // for()

	xsiz = detectors[0]->get_xsiz();
	ysiz = detectors[0]->get_ysiz() / detectors[0]->amps_enabled();
}

///////////////////////////////////////////////////////////////////////////////

void cCCD3ArrayDescrambler::setup_pixel_indexes(void)
{
	unsigned pix_idx;
	unsigned detector_idx;
	unsigned amp_idx, idx;
	t_point detector_pix;
	t_point shifted_pix;
	t_point array_pix;

	for(pix_idx=idx=0; pix_idx < array_schema->get_pix_cnt(); idx += detectors[0]->amps_enabled()){
		for(detector_idx=0; detector_idx < detector_enabled_cnt; detector_idx++){
			for(amp_idx=0; amp_idx < detectors[detector_idx]->amps_enabled(); amp_idx++){
				detector_pix = detectors[detector_idx]->idx2xy(idx + amp_idx);
				shifted_pix = detector_shifts[detector_idx].xy(detector_pix);
				array_pix = array_transformation.xy( shifted_pix );
				index_start[pix_idx++] = array_pix.x - 1 + (array_pix.y-1) * xsiz;
			}
		}
	}

	if( pix_idx != array_schema->get_pix_cnt()){
		throw eCCD3ArrayDescrambler("Internal descrambler error");
	}

	index_valid = true;
}

///////////////////////////////////////////////////////////////////////////////

bool cCCD3ArrayDescrambler::pre_process(void)
{
	setup_pixel_indexes();
	return index_valid;
}

///////////////////////////////////////////////////////////////////////////////

int cCCD3ArrayDescrambler::process(int pix_from, int pix_cnt)
{
	int pix_idx;

	pix_cnt -= pix_cnt % array_schema->get_xsiz();

	if((index_end - index) < pix_cnt) {
		throw eCCD3ArrayDescrambler("Descrambler data overflow, pix_from = %d, pix_cnt = %d, index_end = %p, index = %p", pix_from, pix_cnt, index_end, index);
	}

	for(pix_idx = pix_from; pix_idx < (pix_from + pix_cnt); pix_idx++){
		dst[*index++] = src[pix_idx];
	}

	return pix_cnt;
}

///////////////////////////////////////////////////////////////////////////////
// EOF
