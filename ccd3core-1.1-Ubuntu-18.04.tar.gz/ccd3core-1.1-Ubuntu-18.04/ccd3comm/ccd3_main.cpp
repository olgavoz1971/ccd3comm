/*
 *  Copyright (c) 2006 Copenhagen University Astronomical Observatory
 *  All possible rights reserved
 *	Filename:	
 *  Abstract:	
 *  Author:		Jeppe Jønch Andersen (jja@astro.ku.dk)
 *  Revision:
 *  Remarks:
 */
 
#include <stdio.h>
#include "ccd3_log.h"
#include "ccd3_con.h"


int main (int argc=0, char** argv=NULL)
{
	cCCD3console* Console = NULL;

	try {

		do {
			Console = new cCCD3console(argc, argv);
			Console->Run();
			delete Console;
	    } while( cCCD3console::IsReloading() );

	} catch(common_exception &ex) {

		printf("\n*** FATAL error: %s ***\n\n", ex.what());
		printf("Stack trace:\n");

		// Don't do logging if the error was raised by the logging system!
		if( !dynamic_cast<cCCD3log::ECCD3LOG*>(&ex) ){
			LOGMSG(LOG_ALERT, "\n*** FATAL error: %s ***\n\n", ex.what());
			LOGMSG(LOG_ALERT, "Stack trace:\n");
		}

		// Print stack trace
		for(int n=2; n < ex.size(); n++){
			printf("\t%s\n",ex.trace_name(n));
			if( !dynamic_cast<cCCD3log::ECCD3LOG*>(&ex) )
				LOGMSG(LOG_ALERT, "\t%s\n", ex.trace_name(n));
		}

		if( Console ){
			delete Console;
			Console = NULL;
		}

		fflush(stdout);
		exit(-1);
	} catch(...){         
	    void * array[25];
	    int nSize = backtrace(array, 25);
	    char ** symbols = backtrace_symbols(array, nSize);
	                  
	     for (int i = 0; i < nSize; i++){
	         printf("%s\n", symbols[i]);
	      }
	 
	    free(symbols);
		delete Console;
		exit(-1);
	}
}


/*
#include "imagedescrambler.h"

void CallbackEvent(void* AData, int sz);
void PrintPixels(TIDElementInfo* AElementInfo);

int main (int argc, char** argv) 
{

	    
		IMAGE DESCRAMBLING DEBUG	    
	    TIDPixelData Array[] = {	 1, 2, 3, 4, 5, 6,
	    							 7, 8, 9,10,11,12,
	    							13,14,15,16,17,18,
			    					19,20,21,22,23,24 };
	    	
	    	TIDElementInfo ElementInfo = {
	    		{6,4},						// 6x4 pixels 								
	    		{hlLeft, vlTop},				// Amplifier located in top left side		
	    		rdLeft,						// Readout direction from  right to left		
	    		Array
	    	};
	    	
	    	printf("Initial array:\n");
	    	PrintPixels(&ElementInfo);
	    	
	    	TIDReadoutLocation DstLocation = {hlRight, vlBottom};
	    					
	    TImageDescrambler Descrambler(&ElementInfo, 1, DstLocation);
	    Descrambler.RegisterEventCallback(CallbackEvent);
	    Descrambler.AddData(Array, sizeof(Array));
*/	    

/*
void CallbackEvent(void* AData, int sz)
{
	
}

#define max(x,y) (x > y ? x : y)
void PrintPixels(TIDElementInfo* AElementInfo)
{
	printf("Size = %dx%d pixels\n", AElementInfo->Size.Width, AElementInfo->Size.Height);
	
	for(int n=0; n < AElementInfo->Size.Height * AElementInfo->Size.Width; n++){
		printf("%d", AElementInfo->Pixels[n]);

		if( AElementInfo->Size.Width % max(n,1)){
			printf("%s", ", ");
		} else {
			printf("%s", "\n");
		}
	}
	
}*/
///////////////////////////////////////////////////////////////////////////////
// EOF
