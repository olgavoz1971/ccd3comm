/*
 * ccd3_array_def.h
 *
 *  Created on: Dec 16, 2010
 *      Author: jja
 */

#ifndef CCD3_ARRAY_DEF_H_
#define CCD3_ARRAY_DEF_H_

#include <common_exception.h>
#include "ccd3_geometry_processor.h"

///////////////////////////////////////////////////////////////////////////////

#define DET_HORIZONTAL	'-'
#define DET_VERTICAL	'|'


struct ccd3_image_placement {
	bool mirror_x;
	bool mirror_y;
	t_rotation rotation;
	unsigned xbeg;
	unsigned ybeg;
	ccd3_image_placement(void){
		mirror_x = false;
		mirror_y = false;
		rotation = r0;
		xbeg = 0;
		ybeg = 0;
	};
};

class ccd3_amplifier_schema {
public:
	bool enabled;
	float vbha;
	float vbhb;
	float vbhc;
	float vbla;
	float vblb;
	float gain;
	int zero;
	unsigned xsiz;
	unsigned ysiz;
	ccd3_image_placement placement;

	ccd3_amplifier_schema(void){
		enabled = false;
		vbha = 0;
		vbhb = 0;
		vbhc = 0;
		vbla = 0;
		vblb = 0;
		gain = 0;
		zero = 0;
		xsiz = 0;
		ysiz = 0;
	};
};

#define MAX_DETECTOR_AMPS		4
typedef enum {
	aoHorizontal,
	aoVertical
} amplifier_orientation;

/*
 * 	Amplifier positioning convention
 * 		2 3
 * 		0 1
 */

class ccd3_detector_schema {
protected:
	ccd3_amplifier_schema amplifier[MAX_DETECTOR_AMPS];
	amplifier_orientation orientation;
	unsigned xsiz;
	unsigned ysiz;
	unsigned xbeg;
	unsigned ybeg;
	unsigned amp_enabled_mask;
	unsigned amp_available_mask;
	bool enabled;
	ccd3_image_placement placement;

public:
	ccd3_detector_schema(void);

	void set_mirror(bool a_mirror_x, bool a_mirror_y){ set_mirror_x(a_mirror_x); set_mirror_y(a_mirror_y); };
	void set_mirror_x(bool a_mirror_x){ placement.mirror_x = a_mirror_x;};
	bool get_mirror_x(void){ return placement.mirror_x; };
	void set_mirror_y(bool a_mirror_y){ placement.mirror_y = a_mirror_y;};
	bool get_mirror_y(void){ return placement.mirror_y; };
	void set_rotation(t_rotation a_rotation){ placement.rotation = a_rotation;};
	t_rotation get_rotation(void){ return placement.rotation; };

	void set_enabled_amps(unsigned a_enabled_mask);
	void set_available_amps(unsigned a_available_mask){ amp_available_mask = a_available_mask; };
	void set_size(unsigned new_xsiz, unsigned new_ysiz);
	void set_xsiz(unsigned new_xsiz);
	void set_ysiz(unsigned new_ysiz);
	void set_orientation(amplifier_orientation a_orientation){ orientation = a_orientation; };
	void set_enabled(bool a_enabled){ enabled = a_enabled; };

	unsigned get_enabled_mask(void){ return amp_enabled_mask; };
	unsigned get_xsiz(void){ return xsiz; };
	unsigned get_ysiz(void){ return ysiz; };
	t_point  get_size(void){ return t_point(get_xsiz(), get_ysiz()); };
	amplifier_orientation get_orientation(void) { return orientation; };
	bool is_enabled(void){ return enabled; };
	ccd3_amplifier_schema* get_amp_schema(unsigned amp_no){ return &amplifier[amp_no]; };

	unsigned get_amps_enabled(void);
	unsigned get_amps_available(void);

	bool is_amp_bottom(unsigned amp_idx);
	bool is_amp_top(unsigned amp_idx);
	bool is_amp_left(unsigned amp_idx);
	bool is_amp_right(unsigned amp_idx);

	bool is_top_amps_enabled(void);
	bool is_bottom_amps_enabled(void);
	bool is_left_amps_enabled(void);
	bool is_right_amps_enabled(void);
};

#define MAX_ARRAY_FORMAT_LENGTH 100
#define MAX_DETECTORS			4
#define MAX_DETECTORS_MASK		0x0F
#define MAX_ARRAY_ROWS			2
#define MAX_ARRAY_COLS			2

class ccd3_array_schema {
protected:
	unsigned det_enabl_mask;
	unsigned det_avail_mask;
	unsigned cols;
	unsigned rows;
	unsigned bottom_mask(void);
	unsigned top_mask(void);
	unsigned left_mask(void);
	unsigned right_mask(void);

	ccd3_detector_schema detectors[MAX_DETECTORS];
	ccd3_image_placement placement;

public:
	ccd3_array_schema(void);
	void parse_layout(char* str);
	void validate_setup(void);

	void set_mirror(bool a_mirror_x, bool a_mirror_y){ set_mirror_x(a_mirror_x); set_mirror_y(a_mirror_y); };
	void set_mirror_x(bool a_mirror_x){
		placement.mirror_x = a_mirror_x;
		for(int n=0; n < MAX_DETECTORS; detectors[n++].set_mirror_x(placement.mirror_x));
	};
	bool get_mirror_x(void){ return placement.mirror_x; };
	void set_mirror_y(bool a_mirror_y){
		placement.mirror_y = a_mirror_y;
		for(int n=0; n < MAX_DETECTORS; detectors[n++].set_mirror_y(placement.mirror_y));
	};
	bool get_mirror_y(void){ return placement.mirror_y; };
	void set_rotation(t_rotation a_rotation){
		placement.rotation = a_rotation;
		for(int n=0; n < MAX_DETECTORS; detectors[n++].set_rotation(placement.rotation));
	};
	t_rotation get_rotation(void){ return placement.rotation; };

	void set_detector_size(unsigned new_xsiz, unsigned new_ysiz);
	void set_detector_xsiz(unsigned new_xsiz);
	void set_detector_ysiz(unsigned new_ysiz);

	void set_enabled_detectors(unsigned new_detector_mask);
	void set_available_detectors(unsigned new_detector_mask);

	unsigned channel2detector_idx(unsigned channel);
	unsigned channel2amp_idx(unsigned channel);
	ccd3_amplifier_schema* channel2amplifier(unsigned channel);

	unsigned get_xsiz(void);
	unsigned get_ysiz(void);
	unsigned get_detectors_available(void);
	unsigned get_detectors_enabled(void);
	unsigned get_amps_available(void);
	unsigned get_amps_enabled(void);
	ccd3_detector_schema* get_detector_schema(unsigned detector_no);

	unsigned get_pix_cnt(void);

	bool is_detector_bottom(unsigned det_idx);
	bool is_detector_top(unsigned det_idx);
	bool is_detector_left(unsigned det_idx);
	bool is_detector_right(unsigned det_idx);

	bool is_top_detectors_enabled(void);
	bool is_bottom_detectors_enabled(void);
	bool is_left_detectors_enabled(void);
	bool is_right_detectors_enabled(void);

	typedef common_exception e_ccd3_array_schema;
} ;


#endif /* CCD3_ARRAY_DEF_H_ */
