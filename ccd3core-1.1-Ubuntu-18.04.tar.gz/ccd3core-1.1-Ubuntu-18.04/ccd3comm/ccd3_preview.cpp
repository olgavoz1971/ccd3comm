/*
 * ccd3_preview.cpp
 *
 *  Created on: Apr 8, 2011
 *      Author: root
 */

#include <ccd3_log.h>
#include <unistd.h>
#include <stdarg.h>
#include <signal.h>
#include "ccd3_preview.h"

///////////////////////////////////////////////////////////////////////////////
//
cCCD3Preview::cCCD3Preview(cCCD3processor* a_src_class, unsigned* a_dst, ccd3_array_schema* array_def, xpa_interface* a_xpa, int a_shmid, int a_blocksize)
:cCCD3ArrayDescrambler(a_src_class, a_dst, array_def, true, true, a_blocksize)
{

	strcpy(name, "cCCD3Preview");
	shmid = a_shmid;
	resume_xpa(a_xpa);
}

///////////////////////////////////////////////////////////////////////////////
//
cCCD3Preview::~cCCD3Preview(void)
{
	stop_thread();

	if( xpa ){
		xpa->set("minmax scan");
		xpa->set("scale limits %d %d", min, max);
	}
}

///////////////////////////////////////////////////////////////////////////////
//
int cCCD3Preview::process(int pix_from, int pix_cnt)
{
	int ret;
	static bool minmax_scan = false;
	ret = cCCD3ArrayDescrambler::process(pix_from, pix_cnt);

	if( xpa ){
		//xpa->set("update off");
		xpa->set(minmax_scan ? "minmax sample" : "minmax scan");
		minmax_scan = !minmax_scan;
		lock();
		xpa->set("scale limits %d %d", min, max);
		unlock();

		//xpa->set("minmax scan");
		//xpa-set("update 1 100 100 300 400");
		//xpa->set("update 1 %d %d %d %d", 1, 1, xsiz, (pix_from + pix_cnt)/ xsiz);
		//xpa->set("update 1 %d %d %d %d", 1, 1, xsiz-1, ysiz-1);
		//xpa->set("minmax mode sample");
		//xpa->set("update now");
		//xpa->set("frame update now");
		//xpa->set("frame refresh");
	}

	return ret;
}

///////////////////////////////////////////////////////////////////////////////
//
void cCCD3Preview::set_minmax(unsigned a_min, unsigned a_max){
	lock();
	min = a_min;
	max = a_max;
	unlock();
}

///////////////////////////////////////////////////////////////////////////////
//
void cCCD3Preview::cancel_xpa(void)
{
	if( is_running && !paused() ){
		lock_thread();
	}

	xpa = NULL;

	if( is_running && !paused()){
		unlock_thread();
	}

}

///////////////////////////////////////////////////////////////////////////////
//
void cCCD3Preview::resume_xpa(xpa_interface* a_xpa)
{
	if( is_running && !paused()){
		lock_thread();
	}

	if( a_xpa ){
		a_xpa->set("view minmax yes");
		a_xpa->set("view lowhigh yes");
		//a_xpa->set("raise");

		//a_xpa->set("frame new");
		a_xpa->set("frame clear");
		a_xpa->set("frame center");

		// DS9 Page setup
		//a_xpa->set("page setup pagesize A4");
		//a_xpa->set("print command lpr");
		//a_xpa->set("print palette gray");
		//a_xpa->set("print resolution 75");
		//a_xpa->set("print level 1");

		// minmax
		a_xpa->set("minmax sample");
		a_xpa->set("minmax mode sample");
		//xpa->set("minmax scan");
		//xpa->set("minmax mode scan");
		//xpa->set("minmax interval 100");

		// scale
		a_xpa->set("scale mode minmax");
		//a_xpa->set("scale linear");
		//xpa->set("scale histequ");
		//xpa->set("scale mode zscale");
		//a_xpa->set("scale limits %d %d", 10000, 800000);


		// DS9 Image setup
		a_xpa->set("shm array shmid %d [xdim=%lu,ydim=%lu,bitpix=32]", shmid, xsiz, ysiz);
		a_xpa->set("zoom to fit");
		a_xpa->set("update now");
	}

	xpa = a_xpa;

	if( is_running ){
		unlock_thread();
	}
}

///////////////////////////////////////////////////////////////////////////////
// EOF
