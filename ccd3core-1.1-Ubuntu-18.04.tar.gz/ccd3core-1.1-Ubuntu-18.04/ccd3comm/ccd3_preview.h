/*
 * ccd3_preview.h
 *
 *  Created on: Apr 8, 2011
 *      Author: root
 */

#ifndef CCD3_PREVIEW_H_
#define CCD3_PREVIEW_H_

#include <xpa_interface.h>
#include "ccd3_descrambler.h"

class cCCD3Preview : public cCCD3ArrayDescrambler{
protected:
	unsigned min;
	unsigned max;
	int shmid;
    xpa_interface* xpa;
	virtual int process(int pix_from, int pix_cnt);
public:
	cCCD3Preview(cCCD3processor* a_src_class, unsigned* a_dst, ccd3_array_schema* array_def, xpa_interface* a_xpa, int shmid, int a_blocksize);
	~cCCD3Preview(void);
	void set_minmax(unsigned a_min, unsigned a_max);
	void cancel_xpa(void);
	void resume_xpa(xpa_interface* a_xpa);
	typedef common_exception ECCD3Preview;
};

#endif /* CCD3_PREVIEW_H_ */
