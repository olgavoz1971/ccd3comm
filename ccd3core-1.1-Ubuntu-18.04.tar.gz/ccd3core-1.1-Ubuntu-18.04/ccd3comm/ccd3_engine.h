/*
 *  Copyright (c) 2007 Copenhagen University Astronomical Observatory
 *  All possible rights reserved
 *	Filename:	ccd3engine.h
 *  Abstract:
 *  Author:		Jeppe Jønch Andersen (jja@astro.ku.dk)
 *  Revision:
 *  Remarks:
 */

#ifndef CCD3ENGINE_H_
#define CCD3ENGINE_H_

#include <fitsio.h>
#include <ccd3dev.h>
#include <subscription.h>
#include <fifo.h>
#include <common.h>
#include <ds9_interface.h>
#include "ccd3_shm.h"
#include "ccd3_statistic.h"
#include "ccd3_descrambler.h"
#include "ccd3_preview.h"
#include "ccd3_offload_shm.h"
#include "ccd3_offload_fits.h"

//#define RAISE_THREAD_PRIORITY

#define BUFFER_SIZE					512				/* generel buffer size						*/
#define MAX_CMD_LENGTH				12				/* maximum length of commands 				*/
#define MIN_CMD_LENGTH				1				/* minimum length of commands 				*/
#define MAX_CMD_DESCRIPTION			60				/* length of command description			*/
#define MAX_TX_RETRY_TIME			1000000			/* 1 Sec									*/
// Prefix codec
#define CAM_QUESTION_PREFIX			'?'				/* Cam questions are prefixed with ...		*/
#define CAM_ANSWER_PREFIX			'!'				/* Cam answers are prefixed with ...		*/
#define CAM_UNSOL_PREFIX			'#'				/* Unsolicited msg's are prefixed with .	*/
#define CAM_COMMAND_PREFIX  		'@'				/* Cam commands are prefixed with ...		*/
#define CAM_MAX_QUERY_LEN			256

#define MAX_SUBSCRIPTIONS  			200				/* Maximum number of message subscriptions	*/
#define MAX_CALLBACK				10				/* Maximum callback funcs on a message		*/
#define DEFAULT_DEVICE 				0 				/* Default to the first CCD3 device found 	*/
#define DEFAULT_CAM					8				/* Default camera to open 					*/
#define	MAX_CAM_COUNT				8				/* Max number of CCD's on a controller 		*/
#define MAX_COMM_TIMEOUT 			3000000			/* Max time without communication (uSecs)	*/
#define IMG_SAMPLE_INTERVAL			1				/* Distance between samples for min/max		*/
#define IMG_SAMPLE_MARGIN			1				/* Don't sample to much to the left or right*/

#define CTL_DEVICE 					"/dev/ccd3ctl"	/* Driver device control file				*/
#define DATA_DEVICE 				"/dev/ccd3"		/* Driver device data file					*/

#define DEFAULT_XSIZ 				0				/* Default image size						*/
#define DEFAULT_YSIZ 				0
#define DEFAULT_TIME				0
#define DEFAULT_PREVIEW				false

#define DEFAULT_TESTMODE			0				/* Default test mode						*/
#define DEFAULT_BLOCKSIZE			0x20000			/* Default processing block size			*/

#define CCD3_FITS_HDR 				((char*)"Created by NBI CCD3 camera system")
#define CCD3_IDLE_UPDATE_INTERVAL 	1000000 // 1 hz  200000			/* 5 hz 									*/
#define CCD3_ACTIVE_UPDATE_INTERVAL     200000  // 5 hz  50000			/* 20 hz									*/
#define CCD3_INIT_RETRY_INTERVAL    1000000			/* 1 hz										*/
#define MAX_INACTIVITY_TIME 		1000000 		/* 1 sec, uSecs 							*/


#define CCD3_ERROR  -1
#define CCD3_SUCCESS 0

#define ENGINE_TOKEN				"engine"
#define ENGINE_ANSWER				CAM_ANSWER ENGINE_TOKEN
#define ENGINE_COMMAND				CAM_COMMAND ENGINE_TOKEN
#define ENGINE_QUESTION				CAM_QUESTION ENGINE_TOKEN
#define ENGINE_EXPOSE				ENGINE_ANSWER ".expose"
#define ENGINE_READOUT				ENGINE_ANSWER ".readout"
#define ENGINE_FILECLOSE			ENGINE_ANSWER ".fileclose"
#define ENGINE_ERROR				ENGINE_ANSWER ".error"

typedef enum {
	csIdle			= 0x0,
	csIntegrating	= 0x1,
	csReadout   	= 0x2,
	csClearing		= 0x3,
	csShutterDelay  = 0x4
}TCamState;

class cCCD3engine
{
protected:
	// Fifo's and subscription queue for the command channel
    cFifo* rx_cmd_buf;
    // Subscription handles
    HSUBSCRIPTION hXsiz;
    HSUBSCRIPTION hYsiz;
    HSUBSCRIPTION hXbeg;
    HSUBSCRIPTION hYbeg;
    HSUBSCRIPTION hXbin;
    HSUBSCRIPTION hYbin;
    HSUBSCRIPTION hProgress;
    HSUBSCRIPTION hStat;
    HSUBSCRIPTION hTime;
    HSUBSCRIPTION hTimr;
    HSUBSCRIPTION hTima;
    HSUBSCRIPTION hRden;
    HSUBSCRIPTION hRdav;
    //HSUBSCRIPTION hRddr;
    HSUBSCRIPTION hDrv;
    HSUBSCRIPTION hBrek;
    HSUBSCRIPTION hSint;
    HSUBSCRIPTION hError;
    HSUBSCRIPTION hShut;
    HSUBSCRIPTION hTemp;
    HSUBSCRIPTION hTset;
    HSUBSCRIPTION hTln2;
    HSUBSCRIPTION hPres;
    HSUBSCRIPTION hFres;
    HSUBSCRIPTION hRexp;
    HSUBSCRIPTION hDeav;
    HSUBSCRIPTION hDeen;
    HSUBSCRIPTION hTsam;
    HSUBSCRIPTION hFpix;
    HSUBSCRIPTION hVshi;
    HSUBSCRIPTION hVslo;
    HSUBSCRIPTION hVphi;
    HSUBSCRIPTION hVplo;
    HSUBSCRIPTION hVbha;
    HSUBSCRIPTION hVbhb;
    HSUBSCRIPTION hVbhc;
    HSUBSCRIPTION hVbla;
    HSUBSCRIPTION hVblb;
    HSUBSCRIPTION hZero;
    HSUBSCRIPTION hGain;
    HSUBSCRIPTION hOffs;
    HSUBSCRIPTION hComm;
    HSUBSCRIPTION hLastQuery;
	SubscriptionQueue* Subscriptions;

    unsigned int *mptr;
	cCCD3mem *shm;

	// State information
        ccd3_array_schema* array_schema;
        DWORD xbin, ybin, xbeg, ybeg, rexp;
        DWORD exp_time, n_window, shutter, tsam, fpix, zero;
        float vshi, vslo, vphi, vplo;
        float gain, ccdtemp, ccdref, ln2temp, p_dewar;
        unsigned cnt, last_cnt;
        unsigned no_data;
        unsigned pci_mem_size;
        TCamState State;
        TCamState LastState;
        int time_left, time_actual;
        int exposure_token_idx;
        int readout_token_idx;
        int idle_token_idx;
        int comm_token_idx;
        int watch_dog;
        int blocksize;
    	int wait_reply;
        bool test_skipoffload;
        bool delay_filewrite;
	bool rm_std_comment;
        bool aborted;
        bool processing;
	bool cam_busy;
	bool comm_down;
	bool comm_timeout;
	bool last_comm_lost;
	bool rx_ok;
	bool tx_ok;
//	bool overflow;
	bool allow_fileclose;
	bool disregard_brek;
	bool combine;
	bool geometry_in_file;
	bool realtime;
	bool do_quit;
	char next_filename[MAX_PATH];

	//char char_buf[CHAR_BUF_SIZE];
	struct timeval start_time;
	struct timeval end_time;
	struct timeval shm_end_time;
	struct timeval fits_start_time;
	struct timeval fits_end_time;
	struct timeval last_comm;
	struct timeval startup_time;
	time_t exp_start_time;
	time_t exp_end_time;

	unsigned last_data_progress;
	unsigned last_shm_progress;
	unsigned last_stat_progress;
	unsigned last_desc_progress;
	unsigned last_preview_progress;
	unsigned last_file_progress;
	BOOL   FatalErr;
	FILE* fctl;
	FILE* fdata;

	ds9_comm* ds9;
	cCCD3shm_processor* shm_processor;
	cCCD3ArrayDescrambler* descrambler;
	cCCD3Preview* preview;
	cCCD3fits_processor* fits_processor;
	cCCD3statistic_processor* stat_processor;

	void ExposureCallback(HSUBSCRIPTION Subscription);
	void EndExposure(void);

	void StartReadout(void);
	void ReadoutCallback(HSUBSCRIPTION Subscription);
	void EndReadout(void);

	bool InitComm(void);
	void InitProcessingString(void);
	void CheckProcessingString(void);
	void CloseProcessingString(void);
	void RaisePriorities(void);

	void SilentCallback(HSUBSCRIPTION Subscription);
	void DriverMessage(HSUBSCRIPTION Subscription);

    // Wrapper callback functions
    friend void SilentDmyCallback(HSUBSCRIPTION hSubscription, char* data, void* parm);
    friend void ReadoutDmyCallback(HSUBSCRIPTION hSubscription, char* data, void* parm);
    friend void DrvDmyCallback(HSUBSCRIPTION hSubscription, char* data, void* parm);

public:
 	cCCD3engine(ccd3_array_schema* a_array_schema, int a_block_size);
	virtual ~cCCD3engine(void);
	HSUBSCRIPTION Subscribe(const char* cmd, SubscriptionCallback Callback = NULL, void* UserData = NULL, DWORD Mode = SM_ALWAYS);
	void SubscribeDefault(SubscriptionCallback Callback, void* UserData, DWORD Mode);
	void StartExposure(void);
	void   SelectDevice(int idx);
	void   SelectCam(int idx);
	void   set_mirror_xy(bool a_mirror_x, bool a_mirror_y);
	void   set_mirror_x(bool a_mirror_x);
	//bool   is_mirror_x(void) { return mirror_x; };
	void   set_mirror_y(bool amirror_y);
	//bool   is_mirror_y(void) { return mirror_y; };
	void   set_rotate(t_rotation a_rotation);
	//t_rotation is_rotate(void) { return rotation; };
	void   OpenFile(const char* path, const char* filename);
	void   OpenFile(const char* filename);
	void   AllowFileClose(bool a_allow_close);
	bool   isAllowFileClose(void){ return allow_fileclose; };
	char*  Filename(void);
	void   WriteKeyword(const char* str, ...);
	void   ShowDebug(void);
	void   ShowCallback(void);
	//void   UpdateStatistics(DWORD from, DWORD to, unsigned* Mem);
	void   SetPreview(ds9_comm *new_ds9);
	ds9_comm*   GetPreview(void);
	void   SetCombine(bool new_combine);
	bool   GetCombine(void);
	void   SetFileGeometry(bool new_file_geometry);
	bool   GetFileGeometry(void);
	void   SetRealtime(bool new_realtime);
	bool   GetRealtime(void);
	//bool   SaveBuffer(char* filename);
	int    SendString(const char* fmt, ...);
	int    SendStringNow(const char* fmt, ...);
	HSUBSCRIPTION QueryCam(char* buf, SubscriptionCallback Callback = NULL, void* UserData = NULL, DWORD Count = 0);
	HSUBSCRIPTION CommandCam(char* buf, SubscriptionCallback Callback = NULL, void* UserData = NULL, DWORD Count = 0);
	char*  QueryCamResponse(HSUBSCRIPTION handle, char* arg, char* result, bool stop);
	int    Wait_IO(int* filedes, int cnt, bool persistent = true);
	int    Wait_IO(int filedes, bool persistent = true);
	int    Wait_IO(bool persistent = true);
	void   Sleep(int usecs);
	bool   Reset(void);
	bool   Update(void);
	void   Quit(void);
	BOOL   Busy(void);
	void   TestMemBlock(int size);
	void   TestMemSingle(int size);
	void   SetTestPattern(int pattern);
	void   SetTestOffload(bool skip_offload);
	void   SetDelayedFilewrite(bool delay);
	void   SetRemoveStdComment(bool new_remove_std_comment);
    // Exception classes
	typedef common_exception ECCD3Engine;
};

#endif /*CCD3ENGINE_H_*/
