/*
 * ccd3_geometry_processor.h
 *
 *  Created on: Apr 13, 2010
 *      Author: jja
 */

#ifndef CCD3_IMAGE_PROCESSOR_H_
#define CCD3_IMAGE_PROCESSOR_H_

#include <stdlib.h>
#include "ccd3_pixel_processor.h"


#define MAX_PLACEMENT_EXTENSIONS 4

typedef enum {
	r0,
	r90,
	r180,
	r270
} t_rotation;

struct t_point{
	short x;
	short y;
	t_point(short a_x, short a_y){x =a_x; y=a_y;};
	t_point(void){x=0; y=0;};
};

/*t_point operator+(t_point a, t_point b){
	t_point tmp;
	tmp.x = a.x + b.x;
	tmp.y = a.y + b.y;
	return tmp;
};*/

// x*cos - y*sin + xsiz
// x*sin + y*cos + ysiz
typedef int op_matrice[2][2];

struct image_operand{
	op_matrice factor;		// x,y
	t_point shift;	// width, height
};

const image_operand rotate_90_matrice = {
	{	// factor
			{ 0,-1},
			{ 1, 0}
	},	// shift
			t_point(0, 0)
};

const image_operand mirror_x_matrice = {
	{
			{-1, 0},
			{ 0, 1}
	},
			t_point(0, 0)
};

const image_operand mirror_y_matrice = {
	{
			{ 1, 0},
			{ 0,-1}
	},
			t_point(0, 0)
};

const image_operand shift_x_matrice = {
	{
			{ 1, 0},
			{ 0, 1}
	},
			t_point(1, 0)
};

const image_operand shift_y_matrice = {
	{
			{ 1, 0},
			{ 0, 1}
	},
			t_point(0, 1)
};

const image_operand noop_matrice = {
	{
			{ 1, 0},
			{ 0, 1}
	},
			t_point(0, 0)
};

struct cCCD3image_transformation {
protected:
	image_operand operand;
public:

	cCCD3image_transformation(const image_operand &val){
		*this = val;
	};

	cCCD3image_transformation(void){
			*this = noop_matrice;
	};

	// Asignment operations
	cCCD3image_transformation& operator =(const image_operand &arg){
		memcpy(&operand, &arg, sizeof(operand));
		return *this;
	};

	cCCD3image_transformation& operator =(const cCCD3image_transformation &arg){
		*this = arg.operand;
		return *this;
	};

	// Multiply operations
	/*cCCD3image_transformation& operator <<(const int &arg){
		operand.shift.x *= arg;
		operand.shift.y *= arg;
		return *this;
	}*/

	/*cCCD3image_transformation& operator <<(const int &arg){
		return *this << arg;
	}*/

	cCCD3image_transformation& operator *(const image_operand &arg){
		image_operand tmp;
		tmp.factor[0][0] = arg.factor[0][0] * operand.factor[0][0] + arg.factor[1][0] * operand.factor[0][1];
		tmp.factor[0][1] = arg.factor[0][1] * operand.factor[0][0] + arg.factor[1][1] * operand.factor[0][1];

		tmp.factor[1][0] = arg.factor[0][0] * operand.factor[1][0] + arg.factor[1][0] * operand.factor[1][1];
		tmp.factor[1][1] = arg.factor[0][1] * operand.factor[1][0] + arg.factor[1][1] * operand.factor[1][1];



		tmp.factor[0][0] = operand.factor[0][0] * arg.factor[0][0] + operand.factor[1][0] * arg.factor[0][1];
		tmp.factor[0][1] = operand.factor[0][1] * arg.factor[0][0] + operand.factor[1][1] * arg.factor[0][1];

		tmp.factor[1][0] = operand.factor[0][0] * arg.factor[1][0] + operand.factor[1][0] * arg.factor[1][1];
		tmp.factor[1][1] = operand.factor[0][1] * arg.factor[1][0] + operand.factor[1][1] * arg.factor[1][1];

//		tmp.shift.x = arg.shift.x * operand.factor[0][0] + arg.shift.y * operand.factor[0][1] - operand.shift.x;
//		tmp.shift.y = arg.shift.x * operand.factor[1][0] + arg.shift.y * operand.factor[1][1] - operand.shift.y;

		tmp.shift.x = operand.shift.x * arg.factor[0][0] + operand.shift.y * arg.factor[0][1] + arg.shift.x;
		tmp.shift.y = operand.shift.x * arg.factor[1][0] + operand.shift.y * arg.factor[1][1] + arg.shift.y;

		*this = tmp;
		return *this;
	};

	cCCD3image_transformation& operator *=(const image_operand &arg){
		return *this * arg;
	};

	cCCD3image_transformation& operator *(const cCCD3image_transformation &arg){
		return *this * arg.operand;
	};

	cCCD3image_transformation& operator *=(const cCCD3image_transformation &arg){
		return *this * arg;
	};

	cCCD3image_transformation& operator +(const t_point &arg){
		operand.shift.x += arg.x;
		operand.shift.y += arg.y;
		return *this;
	};

	cCCD3image_transformation& operator +=(const t_point &arg){
		return *this + arg;
	};

	cCCD3image_transformation& operator =(const t_point &arg){
		operand.shift = arg;
		return *this;
	};
/*	cCCD3image_transformation& operator <<(const image_operand &arg){
		//operand.factor[0][0] += arg.factor[0][0];
		//operand.factor[0][1] += arg.factor[0][1];

		//operand.factor[1][0] += arg.factor[1][0];
		//operand.factor[1][1] += arg.factor[1][1];

		operand.shift.x += arg.shift.x;
		operand.shift.y += arg.shift.y;
		return *this;
	};*/


	/*cCCD3image_transformation& operator +=(const image_operand &arg){
		return *this + arg;
	};

	cCCD3image_transformation& operator +(const cCCD3image_transformation &arg){
		return *this + arg.operand;
	};

	cCCD3image_transformation& operator +=(const cCCD3image_transformation &arg){
		return *this  + arg;
	};

	cCCD3image_transformation& operator +(const int arg){
		operand.shift.x += arg;
		operand.shift.y += arg;
	}

	cCCD3image_transformation& operator +=(const int arg){
		return *this + arg;
	}*/

	// Get transformation
	int x(int a_x, int a_y) const {
		return a_x * operand.factor[0][0] + a_y * operand.factor[0][1] + operand.shift.x;
	};
        
	int y(int a_x, int a_y) const {
		return a_x * operand.factor[1][0] + a_y * operand.factor[1][1] + operand.shift.y;
	};

	t_point xy(int a_x, int a_y) const {
		t_point tmp(x(a_x, a_y), y(a_x, a_y));
		return tmp;
	};

	t_point xy(t_point point) const {
		return xy(point.x, point.y);
	}


	t_point get_size(t_point size) const {
		t_point point_left_bot(1, 1);
		t_point point_right_bot(size.x, 1);
		t_point point_right_top(size.x, size.y);
		t_point point_left_top(1, size.y);
		t_point new_size(0, 0);
		new_size.x = max(new_size.x, xy(point_left_bot).x);
		new_size.y = max(new_size.y, xy(point_left_bot).y);
		new_size.x = max(new_size.x, xy(point_right_bot).x);
		new_size.y = max(new_size.y, xy(point_right_bot).y);
		new_size.x = max(new_size.x, xy(point_right_top).x);
		new_size.y = max(new_size.y, xy(point_right_top).y);
		new_size.x = max(new_size.x, xy(point_left_top).x);
		new_size.y = max(new_size.y, xy(point_left_top).y);
		return new_size;
	}
};

class c_noop: public cCCD3image_transformation {
public:
	c_noop(void) : cCCD3image_transformation(noop_matrice){};
};

class c_shift_x: public cCCD3image_transformation {
protected:
public:
	c_shift_x(int width) : cCCD3image_transformation(shift_x_matrice){
		t_point shift(width, 0);
		*(cCCD3image_transformation*)this = shift;
	};
};

class c_shift_y: public cCCD3image_transformation {
protected:
public:
	c_shift_y(int height) : cCCD3image_transformation(shift_y_matrice){
		t_point shift( 0, height );
		*(cCCD3image_transformation*)this = shift;
	};
};

class c_rotate_90: public cCCD3image_transformation {
protected:
public:
	c_rotate_90(int height) : cCCD3image_transformation(rotate_90_matrice){
		//*this *= c_shift_x(height)
		t_point shift(height, 0);
		*(cCCD3image_transformation*)this = shift;

	};
};

class c_mirror_x: public cCCD3image_transformation {
protected:
public:
	c_mirror_x(int width) : cCCD3image_transformation(mirror_x_matrice){
		*this *= c_shift_x(width);
	};
};

class c_mirror_y: public cCCD3image_transformation {
protected:
public:
	c_mirror_y(int height) : cCCD3image_transformation(mirror_y_matrice){
		*this *= c_shift_y(height);
	};
};

class cCCD3geometry_processor: public cCCD3pixel_processor {
protected:
	t_rotation rotation;
	bool mirror_x;
	bool mirror_y;
	int src_xsiz;
	int src_ysiz;
	c_noop transformation;
	cCCD3geometry_processor* childs[MAX_PLACEMENT_EXTENSIONS - 1];
	void prepare_transformation(void);
	int process(int pix_from, int pix_cnt);
public:
	cCCD3geometry_processor(unsigned* a_src, unsigned* a_dst, int a_xsiz, int a_ysiz, bool a_mirror_x, bool a_mirror_y, t_rotation a_rotation, int a_blocksize, int a_ext_cnt = 1);
	cCCD3geometry_processor(cCCD3pixel_processor* a_src_class, unsigned* a_dst, bool a_mirror_x, bool a_mirror_y, t_rotation a_rotation, int a_blocksize);
	cCCD3geometry_processor(cCCD3processor* a_src_class, unsigned* a_dst, int a_xsiz, int a_ysiz, bool a_mirror_x, bool a_mirror_y, t_rotation a_rotation, int a_blocksize, int a_ext_cnt = 1);
	~cCCD3geometry_processor(void);
	void register_dst(cCCD3processor* a_dst_class);
	void register_dst(unsigned* a_dst);
	typedef ePixelProcessor eGeometry_processor;
};


#endif /* CCD3_IMAGE_PROCESSOR_H_ */
