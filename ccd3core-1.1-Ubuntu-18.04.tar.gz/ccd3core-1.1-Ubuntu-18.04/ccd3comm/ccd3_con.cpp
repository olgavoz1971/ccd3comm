/*
 *  Copyright (c) 2006 Copenhagen University Astronomical Observatory
 *  All possible rights reserved
 *	Filename:	ccd3comm_con.cpp
 *  Abstract:	
 *  Author:		Jeppe Jønch Andersen (jja@astro.ku.dk)
 *  Revision:
 *  Remarks:
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/time.h>
#include <sys/types.h>
#include <fcntl.h>
#include <errno.h>
#include <pwd.h>
#include <signal.h>
#include <ncurses.h>
#include <unistd.h>
#include <term.h>
#include <termios.h>
#include <math.h>
#include <limits.h>
#include <getopt.h>
#include <spawn.h>
#include <sys/wait.h>
#include <dirent.h>
#include "ccd3_con.h"
#include "buildinfo.h"
#include "fits_error.h"
#include "ccd3_ini_schema.h"

// General console command prompt
#define CCD3CmdPrompt "CCD3>"

#define DEFAULT_FITS_EXTENSION ".fits"
#define MAX_STATIC_FITSKEYS 100

// Text to identify this software package
const char CCD3ProgramHeader[] = 
	" CCD3 Camera controller command console " CCD3VersionTxt "\n"	
	" Copenhagen University, Astronomical Observatory\n"
	" Copyright (C) 2009, All rights reserved\n";

const char CCD3ProgramInfo[] =
	"\n"
	"Build information:"				"\n"
	"Revision:	"SVN_REVISION			"\n"
	"Build by:	"CURRENT_USER 			"\n"	
	"Date:		"__DATE__ ", " __TIME__ "\n"
	"Host:		"HOST_NAME				"\n"
	"System:		"OS_VERSION			"\n"
	"Compiler:	"GCC_VERSION			"\n"
	"c flags:	"C_FLAGS				"\n"
	"Linker:		"LD_VERSION			"\n"
	"l flags:	"L_FLAGS				"\n";

// Help text for command line options
const char CCD3CmdlineHelp[] =
	"Usage: ccd3comm [<switches>]"																"\n" 
	"-n --noansi"																				"\n"
		"\tTurn off ansi codes"																	"\n"
	"-b --batch [filename]"																		"\n"
		"\tExecute commands in file [filename]"													"\n"
	"-d --daemon"																				"\n"
		"\tRelease console and go to background"													"\n"
	"-i --index [device index]"																	"\n"
		"\tUse CCD3 device [device index], default = 0"											"\n"
		"\tThis is the index on the pci bus, try \"lspci\"."									"\n"
	"-a --camera [camera index]"																"\n"
		"\tUse CCD Camera [camera index], default = 8"											"\n"
		"\tValid range are 1..8"																"\n"
	"-c --config [config file]"																	"\n"
		"\tUse configuration file [config file]"												"\n"
//	"-1 --16bit"																				"\n"
//		"\t Select 16 bit data format, default"													"\n"
//	"-2 --32bit"																				"\n"
//		"\t Select 32 bit data format"															"\n"
	"-v --verbose [level]"																		"\n"
		"\tSet verbosity level [level], default = normal"										"\n"
		"\tvalid values are 0..4 or \"silent\", \"fatal\", \"error\", \"normal\" and \"debug\".""\n"
	"-V --version"																				"\n"
		"\tDisplay version information and exit"												"\n"
	"-h --help"																					"\n"
		"\tDisplay command line help and exit"													"\n";

// Option enumerations
typedef enum {
	coNoansi  = 'n',
	coBatch	  = 'b',
	coConfig  = 'c',
	coDaemon  = 'd',
	coIndex   = 'i',
	coCamera  = 'a',
//	co16bit   = '1',
//	co32bit	  = '2',
	coVerbose = 'v',
	coVersion = 'V',
	coHelp	  = 'h'	
} CCD3Options;
	
// Long option enumerations
static struct option long_options[] = {
	{"noansi",		no_argument,		0,	coNoansi	},
	{"batch",		required_argument,	0,	coBatch		},
	{"config",		required_argument,  0,  coConfig	},
	{"daemon",		no_argument,		0,  coDaemon	},
	{"index",		required_argument,	0,	coIndex		},
	{"camera",		required_argument,	0,  coCamera	},
//	{"16bit",		no_argument,		0,	co16bit		},
//	{"32bit",		no_argument,		0,	co32bit		},
	{"verbose",		required_argument,	0,	coVerbose	},
	{"version",		no_argument,		0,	coVersion	},
	{"help",		no_argument,		0,	coHelp		},
	{NULL,			0,					0,	0			}
};

// Equivalent short option string
//static char short_options[] = "nb:c:di:a:12v:Vh?";
static char short_options[] = "nb:c:di:a:v:Vh?";

// Console command enumerations
typedef enum{
	// System commands
	ciUNKNOWN = 0,
	ciCAMCMD,
	ciCAMQUE,
	ciCAMSTS,
//	ciCAMSOL,
	ciCAMNUM,
	ciFILE,
	ciFILEAUTO,
	ciFILEPATH,
	ciFILESTD,
	ciFILESAVE,
	ciFILECLOSE,
//	ciLOAD,
//	ciSHOW,
//	ciEVAL,
	ciVERB,
	ciLVERB,
	ciRSET,
	ciCLEAR,
	ciXPASET,
	ciXPAGET,
	ciEXAM,
//	ciRMS,
	ciSLEEP,
	ciIVY,
	ciKEYWORD,
	ciLOG,
	ciPREVIEW,
	ciMIRRORX,
	ciMIRRORY,
	ciROTATE,
	ciCOMBINE,
	ciSETENV,
	ciGETENV,
	ciHELP,
	ciABOUT,
	ciQUIT,
	ciEXIT,
	ciDEBUG,
	ciTEST,
	ciKEYBUF,
	ciENTER,
	ciCommandCount,
}TCommandID;

// Command specification
typedef struct {
	TCommandID ID;
	char Text[MAX_CMD_LENGTH+1];
	char Description[MAX_CMD_DESCRIPTION];
}TCommand;

// Command list
const TCommand Commands[] =
{
	{ ciUNKNOWN, 	"",				"Unknown command"										},
	{ ciCAMCMD,  	"@",			"@[NNNN] Camera command"								},
	{ ciCAMQUE,  	"?",			"?[NNNN] Camera question"								},
	{ ciCAMSTS,  	"!",			"![NNNN] Camera answer"									},
//	{ ciCAMSOL,  	"#",			"#[NNNN] [interval] Toggle solication status"			},
//	{ ciCAMNUM,  	"cam",			"cam [N] Select camera, N = 1..8"						},
	{ ciFILE,    	"file",			"file \"filename\": Set output file name"				},
	{ ciFILEAUTO,	"autosave",		"autosave [on|off], Set autogeneration of filenames"	},
	{ ciFILEPATH, 	"filepath",		"filepath [path], Set output directory"					},
	{ ciFILESTD, 	"filestd", 		"filenamestd [namestyle], set stub/style of new filenames"	},
	{ ciFILESAVE,	"save",			"save \"filename\", Save image already in buffer"		},
	{ ciFILECLOSE,	"fileclose",	"file can be closed upon end of processing"				},
//	{ ciLOAD,		"load",			"load \"filename\": Load file into buffer"				},
//	{ ciSHOW,		"show",			"show [idx]: Show image saved at position [idx]"		},
//	{ ciEVAL,		"eval",			"eval [expression]: perform calculation"				},
	{ ciVERB,    	"v",			"v [n], set verbosity level n = 0..4"					},
	{ ciLVERB,		"lv",			"lv [n], set logging level n = 0..4"					},
	{ ciRSET,    	"reset",		"RESET - Reset buffers and hardware"					},
	{ ciCLEAR,   	"clear",		"CLEAR - Clears the console display"					},
	{ ciXPASET,		"xpaset",		"xpaset [arg], set xpa command arg to ds9"				},
	{ ciXPAGET,		"xpaget",		"xpaget [arg], get xpa response from ds9"				},
//	{ ciEXAM,		"examine",  	"examine [width][height]"								},
//	{ ciRMS,		"rms",			"rms [width][height]"									},
	{ ciSLEEP,		"sleep",		"sleep [millisecs]"										},
	{ ciIVY,		"ivy",			"ivy [message], send message on ivy bus"				},
	{ ciKEYWORD,	"keyword",  	"keyword [ext][type][name][value][comment]"				},
	{ ciLOG,		"log", 			"log [message], send message to system log"				},
	{ ciPREVIEW,	"preview", 		"preview [on|off]"										},
	{ ciMIRRORX,	"mirrorx",		"mirrorx [on|off], mirror x axis on image"				},
	{ ciMIRRORY,	"mirrory",		"mirrory [on|off], mirror y axis on image"				},
	{ ciROTATE,		"rotate",		"rotate [0|90|180|270], rotate image"					},
	{ ciCOMBINE,	"combine",		"combine[on|off], combine multiple amplifiers in file"	},
	{ ciSETENV,		"setenv", 		"set environment variable"								},
	{ ciGETENV,		"getenv",		"print environment variable"							},
	{ ciHELP,    	"help",			"HELP: Display this help"								},
	{ ciABOUT,   	"about",		"About - Display program information"					},
	{ ciQUIT,    	"quit",			"QUIT: Quit this program!"								},
	{ ciEXIT,		"exit", 		"Same as \"quit\""										},
	{ ciQUIT,    	"q",			"Q:    Quit this program!"								},
	{ ciDEBUG,    	"debug",		""														},
	{ ciTEST,		"test",			""														},
	{ ciKEYBUF,		"keybuf",		""														}
};

// static singleton
cCCD3console *cCCD3console::me = NULL; 
bool cCCD3console::reload = false;

void DmyConCallback(HSUBSCRIPTION hSubscription, char* data, void* user);
void DmyDefCallback(HSUBSCRIPTION hSubscription, char* data, void* user);
void DmyCamCallback(HSUBSCRIPTION hSubscription, char* data, void* user);
void DmyDrvCallback(HSUBSCRIPTION hSubscription, char* data, void* user);
void DmyEngineCallback(HSUBSCRIPTION hSubscription, char* data, void* user);
void DmyIvyCallback(IvyClientPtr app, void* data, int argc, char** argv);
void signal_handler(int signum);


///////////////////////////////////////////////////////////////////////////////
// Constructor

cCCD3console::cCCD3console(int argc, char** argv)
{
	bool mirror_x, mirror_y;
	char filepath[MAX_PATH];
	char det_layout[MAX_ARRAY_FORMAT_LENGTH];
	char rotate[MAX_PATH];
	int block_size;
	//bool wait_debug = 1;

	if( me ) {
		throw ECCD3("Only one explicit instance of this class is allowed");
	}
	me = this;
	reload = false;

    signal(SIGINT, signal_handler);
    signal(SIGHUP, signal_handler);

	DoQuit = false;
	daemon_mode = false;
	rx_ok = true;
	tx_ok = true;
	
	config_filename[0] = '\0';
	
	event_handler_start = 0;
	cmd_executing = 0;
	cmd_executing_verbosity = L_NORMAL;
	
	ini_file = NULL;
	ivy = NULL;
	ds9 = NULL;

	time (&start_time);

	cmd_history_idx = 0;
	cmd_history = new cFifo(MAX_CMD_HISTORY, MAX_CMDLINE_LEN);
	
	batch_files = new cFilo(MAX_BATCH_FILES, sizeof(TBatchfile));

	ParseOptions(argc, argv);

	if( DoQuit ) return;

	// If no config file has been specified, use .[application name]	
	if( !strlen(config_filename) ){
		find_configfile(config_filename, argc, argv, (char*)"ccd3");
	}
	
	InitIniFile();
	InitLog();

	if( daemon_mode && daemonize() ){
		return;
	}

	InitConsole();	

	// Write Program Header
	PRINT(L_NORMAL, CCD3ProgramHeader);
	PRINT(L_DEBUG, "Using configuration file \"%s\"\n", config_filename);

	InitIvy();

	ini_file->ReadString(INI_DET_SECTION, INI_DET_LAYOUT, INI_DET_DEFAULT_LAYOUT, det_layout);
	Array.parse_layout(det_layout);

	block_size = ini_file->ReadInteger(INI_APP_SECTION, INI_APP_BLOCKSIZE, INI_APP_DEFAULT_BLOCKSIZE);
	Engine = new cCCD3engine(&Array, block_size);
	InitPriority();

	Engine->SubscribeDefault(DmyDefCallback, this, 0);
	hError = Engine->Subscribe(CAM_ERROR, DmyCamCallback, this);
	hDrv  = Engine->Subscribe(DRV_ANSWER, DmyDrvCallback, this);
	hBrek = Engine->Subscribe("!brek", DmyCamCallback, this);
	hSint = Engine->Subscribe("!sint", DmyCamCallback, this);
	hExp = Engine->Subscribe(ENGINE_EXPOSE, DmyEngineCallback, this);
	hReadout = Engine->Subscribe(ENGINE_READOUT, DmyEngineCallback, this);
	hFileclose = Engine->Subscribe(ENGINE_FILECLOSE, DmyEngineCallback, this);
	hEngineError = Engine->Subscribe(ENGINE_ERROR, DmyEngineCallback, this);

	Engine->AllowFileClose(ini_file->ReadBool(INI_FILE_SECTION, INI_FILE_ALLOWCLOSE, INI_FILE_DEFAULT_ALLOWCLOSE));
	date_shift = ini_file->ReadInteger(INI_FILE_SECTION, INI_FILE_DATE_SHIFT, INI_FILE_DEFAULT_DATE_SHIFT);

	ini_file->ReadString(INI_SCRIPT_SECTION, INI_SCRIPT_DIR, INI_SCRIPT_DEFAULT_DIR, script_dir);

	mirror_x = ini_file->ReadBool(INI_DET_SECTION, INI_DET_MIRRORX, INI_DET_DEFAULT_MIRRORX);
	mirror_y = ini_file->ReadBool(INI_DET_SECTION, INI_DET_MIRRORY, INI_DET_DEFAULT_MIRRORY);
	Engine->set_mirror_xy(mirror_x, mirror_y);

	ini_file->ReadString(INI_DET_SECTION, INI_DET_ROTATE, INI_DET_DEFAULT_ROTATE, rotate);
	if( !strcmp( rotate, "0")){
		Engine->set_rotate(r0);
	} else if( !strcmp( rotate, "90") ){
		Engine->set_rotate(r90);
	} else if( !strcmp( rotate, "180") ){
		Engine->set_rotate(r180);
	} else if( !strcmp( rotate, "270") ){
		Engine->set_rotate(r270);
	} else {
		PRINT(L_ERROR, "Unsupported rotation found \"%s\"\n", rotate);
	}

	//Engine->SetDelayedFilewrite(ini_file->ReadBool(INI_FILE_SECTION, INI_FILE_DELAY, INI_FILE_DEFAULT_DELAY));

	if( ini_file->ReadBool(INI_APP_SECTION, INI_APP_PREVIEW, INI_APP_DEFAULT_PREVIEW) ){
		InitDS9(false);
	}

	Engine->SetRemoveStdComment(ini_file->ReadBool(INI_FILE_SECTION, INI_FILE_RM_FITS_COMMENT, INI_FILE_DEFAULT_RM_FITS_COMMENT));
	SetFilepath(ini_file->ReadString(INI_FILE_SECTION, INI_FILE_DIR, INI_FILE_DEFAULT_DIR, filepath));
	InitFilename();

	while(!Engine->Reset());

	ini_file->ReadString(INI_SCRIPT_SECTION, INI_SCRIPT_ONAPPSTART, INI_SCRIPT_DEFAULT_FILE, exec_on_appstart);
	ini_file->ReadString(INI_SCRIPT_SECTION, INI_SCRIPT_ONEXPOSURE, INI_SCRIPT_DEFAULT_FILE, exec_on_exposure);
	ini_file->ReadString(INI_SCRIPT_SECTION, INI_SCRIPT_ONREADOUT, INI_SCRIPT_DEFAULT_FILE, exec_on_readout);
	ini_file->ReadString(INI_SCRIPT_SECTION, INI_SCRIPT_ONFILECLOSE, INI_SCRIPT_DEFAULT_FILE, exec_on_fileclose);
	ini_file->ReadString(INI_SCRIPT_SECTION, INI_SCRIPT_ONAPPCLOSE, INI_SCRIPT_DEFAULT_FILE, exec_on_appclose);

	AddBatchfile(exec_on_appstart);
}

///////////////////////////////////////////////////////////////////////////////
// Destructor

cCCD3console::~cCCD3console(void)
{

	CloseDS9();

	if( Engine ){
		delete Engine;
		Engine = NULL;
	}	
	
	CloseBatchfiles();
	delete batch_files;
	batch_files = NULL;

	CloseIniFile();
	CloseIvy();

	delete cmd_history;
	cmd_history = NULL;
	
    CloseLog();
	CloseConsole();
		
	me = NULL;
}

///////////////////////////////////////////////////////////////////////////////
// Initialize .ini file
void cCCD3console::InitIniFile(void)
{	
	ini_file = new TIniFile(config_filename);	
}

///////////////////////////////////////////////////////////////////////////////
// Close .ini file
void cCCD3console::CloseIniFile(void)
{
	if( ini_file ){
		delete ini_file;
		ini_file = NULL;
	}	
}

///////////////////////////////////////////////////////////////////////////////
// Initialize IVY bus
void cCCD3console::InitIvy(void)
{
	char IvyNameStr[256];
	char IvyNetStr[256];
	char IvyEnableStr[256];
	IVY_MSG msg;

	ini_file->ReadString(INI_IVY_SECTION, INI_IVY_ENABLE, INI_IVY_DEFAULT_ENABLE, IvyEnableStr);
	
	EnableIvy = !strcmp( IvyEnableStr, "1");
	if( !EnableIvy){			
		EnableIvy = !strcasecmp(IvyEnableStr, "true");
	}
	
	if( !EnableIvy ){
		PRINT(MAKE_FLAG(ccDebug, ccNormal), "ivy bus not enabled\n");
		return;
	}

	ini_file->ReadString(INI_IVY_SECTION, INI_IVY_NET, INI_IVY_DEFAULT_NET, IvyNetStr);
	ini_file->ReadString(INI_IVY_SECTION, INI_IVY_NAME, INI_IVY_DEFAULT_NAME, IvyNameStr);

	PRINT(MAKE_FLAG(ccDebug, ccNormal), "Initializing ivy bus\n");
	ivy = new cCCD3ivy(IvyNameStr, IvyNetStr);

	if( 0 > pipe(ivy_pipe) ){
		PRINT(L_ERROR, "Unable to create ivy pipe\n");
	}
	
	if( 0 > fcntl(ivy_pipe[0], F_SETFL, O_NONBLOCK)){
		PRINT(L_ERROR, "Unable to set options on ivy pipe\n");
	}

	PRINT(MAKE_FLAG(ccDebug, ccNormal), "Loading ivy message schema\n");
	for(int ivy_idx=1; ivy_idx < ivy_msg_count; ivy_idx++){
		
		//IvyMessages[ivy_idx] = DEFAULT_IVY_MSG[ivy_idx];
		msg = DEFAULT_IVY_MSG[ivy_idx];

		if( ini_file->ReadString(INI_IVY_SECTION, msg.IniToken, msg.IniToken, msg.IvyToken) ){
			if(!strlen(msg.IvyToken)){
				PRINT(L_DEBUG, "Disabling ivy msg \"%s\"\n", msg.IniToken);
			} else {
				PRINT(L_DEBUG, "Enabling ivy msg: %s = %s\n", msg.IniToken, msg.IvyToken);
			}
		} else {
			strcpy(msg.IvyToken, "");
			PRINT(L_DEBUG, "Missing definition of ivy msg \"%s\"\n", msg.IniToken);
		}
		IvyMessages[ivy_idx] = msg;
	}	

	PRINT(MAKE_FLAG(ccDebug, ccNormal), "Subscribing all ivy messages\n");
	ivy_id = ivy->Subscribe(DmyIvyCallback, this, "(%s.*)", IvyNameStr);

	ivy->Run( IVY_MSG(ivy_application_start) );
}

///////////////////////////////////////////////////////////////////////////////
// Close IVY bus

void cCCD3console::CloseIvy(void)
{
	if( ivy ){
		//PRINT(MAKE_FLAG(ccDebug, ccNormal), "closing ivy bus\n");
		IvySend(ivy_application_stop);
		//ivy->Unsubscribe(ivy_id);
		delete ivy;	
		ivy = NULL;
	}
}

///////////////////////////////////////////////////////////////////////////////
//
void cCCD3console::InitDS9(bool a_remote)
{
	if( Engine->Busy() ){
		PRINT(L_ERROR, "Preview can only be set during idle\n");
	} else {
		try {

			ds9 = ds9 ? ds9 : new ds9_comm(a_remote);
			Engine->SetPreview(ds9);

		} catch(ds9_comm::e_ds9_comm &ex){
			PRINT(L_ERROR, "%s\n", ex.what());
			CloseDS9();
		}
	}
}

///////////////////////////////////////////////////////////////////////////////
//
void cCCD3console::CloseDS9(void)
{
	if( ds9 ){
		if( Engine ){
			Engine->SetPreview(NULL);
		}
		delete ds9;
		ds9 = NULL;
	}
}

///////////////////////////////////////////////////////////////////////////////
// Add static keywords from config file to fits
/*
void cCCD3console::AddStaticKeywords(void)
{
	char keynames[MAX_STATIC_FITSKEYS][MAX_KEY_LEN];
	char keyval[MAX_VAL_LEN];
	char keytype[] = "TSTRING";
	memset(keynames, 0, sizeof(keynames));
	ini_file->ReadSectionKeys(INI_HEADER_SECTION, keynames);
	for(int n=0; strlen(keynames[n]); n++){
		ini_file->ReadString(INI_HEADER_SECTION, keynames[n], "", keyval);
		Engine->WriteKeyword("%s %s \"%s\"", keytype, keynames[n], keyval);
	}

	memset(keynames, 0, sizeof(keynames));
	ini_file->ReadSectionKeys(INI_EXTENSION_SECTION, keynames);
	for(int n=0; strlen(keynames[n]); n++){
		ini_file->ReadString(INI_EXTENSION_SECTION, keynames[n], "", keyval);
		Engine->WriteKeyword("%d %s %s \"%s\"", EXT_HDR, keytype, keynames[n], keyval);
	}
}
*/
///////////////////////////////////////////////////////////////////////////////
// Initialize batch file 0

bool cCCD3console::AddBatchfile(char* batch_filename, char* args)
{
	TBatchfile Batchfile;
	char filename[MAX_PATH];

	if( !strlen(batch_filename) ){
		return false;
	}

	if( !strchr(batch_filename, '/') ){
		sprintf(filename, "%s%s", script_dir, batch_filename);
	} else {
		strcpy(filename, batch_filename);
	}

	if( batch_files->isfull()){
		PRINT(L_ERROR, "Batchfile queue depth reached!\n");
		return false;
	} else {
		strcpy(Batchfile.filename, filename);
		strcpy(Batchfile.args, args);
		Batchfile.file = fopen(Batchfile.filename, "r");

		if( !Batchfile.file ){
			PRINT(L_ERROR, "Unable to open \"%s\"\n", Batchfile.filename);
			return false;
		} else {
			batch_files->put(&Batchfile);
			return true;
		}
	}	
}

///////////////////////////////////////////////////////////////////////////////
// Close current batch file
void cCCD3console::CloseBatchfile(void)
{
	TBatchfile Batchfile;
	batch_files->get(&Batchfile);
	fclose(Batchfile.file);

	if( batch_files->size() < event_handler_start){
		event_handler_start = 0;
	}
}

///////////////////////////////////////////////////////////////////////////////
// Close all batch files

void cCCD3console::CloseBatchfiles(void)
{
	while(batch_files->size()){
		CloseBatchfile();
	}
}

///////////////////////////////////////////////////////////////////////////////
// Read filename/content convention from ini file 
void cCCD3console::InitFilename(void)
{	
	char ini_name_style[MAX_PATH];
	bool combine;
	bool file_geometry;
	combine = ini_file->ReadBool(INI_FILE_SECTION, INI_FILE_COMBINE, INI_FILE_DEFAULT_COMBINE);
	Engine->SetCombine(combine);

	file_geometry = ini_file->ReadBool(INI_FILE_SECTION, INI_FILE_USE_GEOMETRY, INI_FILE_DEFAULT_USE_GEOMETRY);
	Engine->SetFileGeometry(file_geometry);

	ini_file->ReadString(INI_FILE_SECTION, INI_FILE_PREFIX, INI_FILE_DEFAULT_PREFIX, prefix);
	ini_file->ReadString(INI_FILE_SECTION, INI_FILE_NAMESTYLE, INI_FILE_DEFAULT_NAMESTYLE, ini_name_style);
	autosave = ini_file->ReadBool(INI_FILE_SECTION, INI_FILE_AUTO, INI_FILE_DEFAULT_AUTO);

	if( !strcasecmp(ini_name_style, "NOT")){
		namestyle = nsNOT;
		IvySend(ivy_file_std, "NOT");
	} else if ( !strcasecmp(ini_name_style, "DEFAULT")){
		namestyle = nsDefault;
		IvySend(ivy_file_std, "DEFAULT");
	} else {
		namestyle = nsCustom;
		strcpy(filestd, ini_name_style);
		IvySend(ivy_file_std, filestd);
	}
}

///////////////////////////////////////////////////////////////////////////////
// Parse command line options 

void cCCD3console::ParseOptions(int argc, char** argv)
{
	int c=0;
	int	 itmp;
	char tmp[256];

	opterr = 0;

	while ( c != EOF  && !DoQuit) {

		int option_index = 0;

		c = getopt_long (argc, argv, short_options, long_options, &option_index);

		switch (c) {
		case    EOF      	:	break;
		
		case 	coNoansi 	:	enable_ansi(false);
								PRINT(MAKE_FLAG(ccDebug, ccNormal), "Disabling ANSI codes\n");
								break;								
								
		case	coBatch		:	if( 1 != sscanf(optarg, "%s", tmp) )
									throw EInvalidArg("Could not parse batch file (%s)", optarg);
								
								AddBatchfile(tmp);
								break;
								
		case	coConfig	:	if( 1 != sscanf(optarg, "%s", config_filename) )
									throw EInvalidArg("Could not parse config file (%s)", optarg);

								PRINT(MAKE_FLAG(ccDebug, ccNormal), "Using config file : %s\n", config_filename);
								break;									

		case	coDaemon	:	daemon_mode = true;
								break;
											
		case	coIndex		:	if( 1 != sscanf(optarg, "%d", &itmp))									
									throw EInvalidArg("Could not parse device index (%s)", optarg);

								PRINT(MAKE_FLAG(ccDebug, ccNormal), "Selecting device index %d\n", itmp);
								Engine->SelectDevice(itmp);
								break;
								
		case	coCamera	:	if( 1 != sscanf(optarg, "%d", &itmp))
									throw EInvalidArg("Could not parse camera index (%s)", optarg);

								PRINT(MAKE_FLAG(ccDebug, ccNormal), "Selecting camera %d\n", itmp);
								Engine->SelectCam(itmp);
								break;
								
		case	coVerbose	: 	if( 1 == sscanf(optarg, "%d", &itmp)){
									LOG->set_print_verbosity((ccd3Verbosity)itmp);
								} else if( 1 == sscanf(optarg, "%s", tmp)){
									LOG->set_print_verbosity(tmp);
								} else {
									throw EInvalidArg("Invalid argument found: \"%s\"", optarg);
								}

								PRINT(L_NORMAL, "Verbosity level is set to %s\n", VERBOSITY_STRINGS[LOG->get_print_verbosity()]);
								break;

		case	coVersion 	: 	PRINT(L_ALWAYS, "%s%s", CCD3ProgramHeader, CCD3ProgramInfo);
								Quit();								
								break;
																   
		case	coHelp 		:	PRINT(L_ALWAYS, CCD3CmdlineHelp);
								Quit(); 
								break;
		
		case	'?'			:	break;
								//throw EUnknownArg("Unknown argument found: 0%o", optopt); 

		case	':'			:	throw EMissingArg("Missing a mandatory argument to \"%s\"", long_options[option_index].name);
		
		case	0			:	PRINT(L_ERROR, "How did I end up here .. please inform (jja@astro.ku.dk)???\n");
								break;
								
        default				:	throw EInvalidArg("Invalid option found: 0%o ??\n", c);
		}
	} // while()

	if ( optind < argc && !DoQuit) {
		throw EUnknownArg("Unknown argument found on command line: \"%s\"", argv[optind]); 
	}
}

///////////////////////////////////////////////////////////////////////////////
// Send a message on ivy bus  
void cCCD3console::IvySend(IVY_MSG_IDX ivy_idx, const char* Str, ...)
{
	char buf[256] = "";
	va_list arg;

	if( !ivy ) return;

	va_start (arg, Str);
	vsprintf(buf, Str, arg);
	va_end (arg);
	
	if( ivy_idx == ivy_none ){
		ivy->Send(buf);
	} else if (strlen(IVY_MSG(ivy_idx))) {
		if( strlen(buf))
			ivy->Send("%s %s", IVY_MSG(ivy_idx), buf);
		else
			ivy->Send(IVY_MSG(ivy_idx));
	}
	
}

///////////////////////////////////////////////////////////////////////////////
// Execute command line 
// if "wait", wait for process to terminate  

#define MAX_ARG_LEN 100
#define MAX_ARG_CNT 20
void cCCD3console::Execute(char* command_line, char* args, bool wait_child)
{
	//pid_t pid;
	int res;
	char command[MAX_PATH];
	if( !strchr(command_line, '/') ){
		sprintf(command, "%s%s %s", script_dir, command_line, args);
	} else {
		sprintf(command, "%s %s", command_line, args);
	}
	
	res = system(command);
	if( res ){
		PRINT(L_ERROR, "Subprocess failed with exit status %d\n", res);
	}
}

///////////////////////////////////////////////////////////////////////////////
#define FITS_OK( code) 	\
	if( code ){ \
		PRINT(MAKE_FLAG(ccDebug, ccError), "Fits operation failed with message: %s\n", fits_report_error( stdout, code ));\
	}

/*int cCCD3console::LoadFile(char* filename)
{
	int status=0;
	int naxis = 0;
	int bitpix;
	cCCD3image** tmpimages;
	long fpixel[2] = {1,1};
	long naxes[2] = {0,0};

	fits_open_image(&fits, filename, READWRITE, &status);
	fits_report_error( stdout, status );
	
	fits_get_img_type(fits, &bitpix, &status);
	fits_report_error( stdout, status );

	fits_get_img_type(fits, &bitpix, &status);
	fits_report_error( stdout, status );

	fits_get_img_param(fits, 2, &bitpix, &naxis, naxes, &status);
	fits_report_error( stdout, status );

	if( naxis != 2){
		PRINT(ccError, "Image with %d dimensions found!\n", naxis);
		PRINT(ccError, "Only 2-dimensional images are supported in this version!\n");
		return -1;
	}
	
	tmpimages = new cCCD3image*[img_cnt + 1];		
	tmpimages[img_cnt] = new cCCD3image(naxes[0], naxes[1]);		
	
	//fits_read_pix(fits, bitpix, (long int*)Engine->mptr, naxes[0] * naxes[1], NULL, NULL, 0, &status);  
	fits_read_pix(fits, TULONG, fpixel, naxes[0] * naxes[1], NULL, (long int*)tmpimages[img_cnt]->get_base(), 0, &status);  
	fits_report_error( stdout, status );
	
	fits_close_file(fits, &status);
	fits_report_error( stdout, status );

	if( img_cnt && images ) {
		memcpy(tmpimages, images, img_cnt * sizeof(cCCD3image*));
		delete[] images;
	}
	
	images = tmpimages; 
	
	img_cnt++;
	return img_cnt - 1;
}*/


///////////////////////////////////////////////////////////////////////////////
// Background calling process 

void child_handler(int signum)
{
	PRINT(L_DEBUG, "Child signal = %d\n", signum);

    switch(signum) {

    case SIGALRM:	CON->Quit();
    				break;

    case SIGUSR1: 	CON->Quit();
    				break;

    case SIGTERM:	CON->Quit();
    				break;
    default:
    	break;
    }
}


bool cCCD3console::daemonize(void)
{
   	char run_as_user[256] = "";

    PRINT(L_DEBUG, "Daemonizing\n" );

    pid_t pid, sid;//, parent;

    /* Fork off the parent process */
	PRINT(L_DEBUG, "Forking daemon\n");
    pid = fork();

    if (pid < 0) {
        PRINT(MAKE_FLAG(ccFatal, ccFatal), "Unable to fork child daemon, code=%d (%s)\n", errno, strerror(errno) );
        throw ECCD3("Unable to fork daemon", errno);
    }

    /* If we got a good PID, then we can exit the parent process. */
    if (pid > 0) {
    	PRINT(MAKE_FLAG(ccDebug, ccNormal), "Forked daemon pid=%d\n", pid);
		Quit();
        return true;
    }

    //bool wait_debugger = true;
   	//while(wait_debugger);

    PRINT(MAKE_FLAG(ccDebug, ccNormal), "Running as daemon pid=%d\n", getpid());
    /* At this point we are executing as the child process */

    ini_file->ReadString(INI_APP_SECTION, INI_APP_UID, INI_APP_DEFAULT_UID, run_as_user);

	if( strlen(run_as_user) ){
        struct passwd *pw = getpwnam(run_as_user);
        __uid_t my_uid = geteuid();
        if ( pw ) {
        	if( pw->pw_uid != my_uid ){
				PRINT(MAKE_FLAG(ccDebug, ccNormal), "setting user to %s\n", run_as_user );

				if(0 > setuid( pw->pw_uid )){
					PRINT(L_FATAL, "Failed setting user to %s (%s)\n", run_as_user, strerror(errno) );
					throw ECCD3("Failed setting user to %s (%s)", run_as_user, strerror(errno) );
				}
        	}

        } else {
            PRINT(L_FATAL, "Unknown user set? \"%s\" (%s)\n", run_as_user, strerror(errno) );
        	throw ECCD3("Unknown user set? \"%s\" (%s)\n", run_as_user, strerror(errno) );
        }
	}

    //parent = getppid();

    //signal(SIGCHLD, child_handler);
    signal(SIGUSR1, child_handler);
    signal(SIGALRM, child_handler);
    signal(SIGTERM, child_handler);
    signal(SIGTSTP, SIG_IGN); /* Various TTY signals */
    signal(SIGTTOU, SIG_IGN);
    signal(SIGTTIN, SIG_IGN);
    signal(SIGHUP,  SIG_IGN); /* Ignore hangup signal */

    /* Change the file mode mask */
    umask(0);

    /* Create a new SID for the child process */
    sid = setsid();
    if (sid < 0) {		// Process db
        PRINT(L_FATAL, "unable to create new session, code %d (%s)\n", errno, strerror(errno) );
        throw ECCD3("unable to create new session, code %d (%s)", errno, strerror(errno) );
    }

    /* Change the current working directory.  This prevents the current
       directory from being locked; hence not being able to remove it. */
    if ((chdir("/")) < 0) {
        PRINT(L_FATAL, "unable to change directory to %s, code %d (%s)\n", "/", errno, strerror(errno) );
        throw ECCD3("unable to change directory to %s, code %d (%s)", "/", errno, strerror(errno) );
    }

    /* Redirect standard files */
	close(STDIN_FILENO);
	close(STDOUT_FILENO);
	close(STDERR_FILENO);
	return false;
}

///////////////////////////////////////////////////////////////////////////////
// Reset console to a known state

void cCCD3console::InitConsole(void)
{
	bool use_ansi;
	
	strcpy(keybuf, "");
	//keyboard_init();
	
	use_ansi = ini_file->ReadBool(INI_APP_SECTION, INI_APP_ANSI, INI_APP_DEFAULT_ANSI);
	PRINT(L_ANSI, enable_ansi(use_ansi));
	PRINT(L_ANSI, clrscr());
	PRINT(L_ANSI, gotoxy(0,0));
}

///////////////////////////////////////////////////////////////////////////////
// Deinitialize console

void cCCD3console::CloseConsole(void)
{
	//keyboard_close();
}

///////////////////////////////////////////////////////////////////////////////
// Initialize logging class
void cCCD3console::InitLog(void)
{
	char str_logfile[MAX_PATH];
	char log_ident[MAX_PATH];
	char str_facility[256];
	
	ini_file->ReadString(INI_LOG_SECTION, INI_LOG_FILE, INI_LOG_DEFAULT_FILE, str_logfile);
	
	if( !strcasecmp(str_logfile, INI_LOG_SYSLOG_VAL )){
		// Syslog is selected
		ini_file->ReadString(INI_LOG_SECTION, INI_LOG_IDENT, INI_LOG_DEFAULT_IDENT, log_ident);
		ini_file->ReadString(INI_LOG_SECTION, INI_LOG_FACILITY, INI_LOG_DEFAULT_FACILITY, str_facility);
		new cCCD3log(log_ident, str_facility);
	} else {
		// Logfile is selected
		new cCCD3log(str_logfile);
	}

/*#ifdef DEBUG
	LOG->set_print_verbosity(ccDebug);
	LOG->set_log_verbosity(ccDebug);
#else
	LOG->set_print_verbosity(ccNormal);
	LOG->set_log_verbosity(ccNormal);
#endif*/


}

///////////////////////////////////////////////////////////////////////////////
// Deinitialize logging class
void cCCD3console::CloseLog(void)
{
	delete cCCD3log::instance();
}

///////////////////////////////////////////////////////////////////////////////
// Set thread priorities
void cCCD3console::InitPriority(void)
{
	Engine->SetRealtime( ini_file->ReadBool(INI_APP_SECTION, INI_APP_REALTIME, INI_APP_DEFAULT_REALTIME));
}

///////////////////////////////////////////////////////////////////////////////
//
bool cCCD3console::StringIsTrue(char* str)
{
	return !strcasecmp(str, "on") || !strcasecmp(str, "1") || !strcasecmp(str, "true");
}

///////////////////////////////////////////////////////////////////////////////
//
bool cCCD3console::StringIsFalse(char* str)
{
	return !strcasecmp(str, "off") || !strcasecmp(str, "0") || !strcasecmp(str, "false");
}

///////////////////////////////////////////////////////////////////////////////
//
bool cCCD3console::StringIsBool(char* str)
{
	return StringIsTrue(str) || StringIsFalse(str);
}

///////////////////////////////////////////////////////////////////////////////
// Return a single command line
char* cCCD3console::GetConsoleCommand(char* buf)
{
	static int key_idx = 0;
	char* nl = NULL;
	char* cr = NULL;
	int delimiters = 0;
	
	if( key_idx >= MAX_CMDLINE_LEN ){
		PRINT(L_ERROR, "Commmand too long ...\n");
		key_idx = 0;
		return NULL;
	}
		
	read(STDIN_FILENO, &keybuf[key_idx], 1);
	keybuf[++key_idx] = '\0';

	cmd_executing_verbosity = L_ALWAYS;
	PRINT(cmd_executing_verbosity, "%c", keybuf[key_idx-1]);
	nl = strchr(keybuf, '\n');
	cr = strchr(keybuf, '\r');

	if( !nl && !cr ){
		return NULL;
	}

	// Command will be executed

	delimiters = 0;

	if( nl ) {
		*nl = '\0';
		delimiters++;
	}

	if( cr ){
		*cr = '\0';
		delimiters++;
	}

	strcpy(buf, keybuf);
	key_idx -= strlen(buf) + delimiters;
	if( key_idx ) {
		memmove(keybuf, &keybuf[strlen(buf) + delimiters], key_idx);
	}
	//}

	// Save command in key buffer
	if( (int)strlen(buf) ) { // Don't put CR or LF into command history
		if( !cmd_history->put(buf)){
			cmd_history->get(NULL);
			if( !cmd_history->put(buf) ){
				PRINT(L_ERROR, "Command history buffer could not be cleared????\n");
			}
		}
		cmd_history_idx = 0;
	}

	return buf;
}

///////////////////////////////////////////////////////////////////////////////
// Returns next command in batch file

char* cCCD3console::GetBatchCommand(char* buf)
{
	bool eof = false;
	char* ch = NULL;
	int arg_idx = 0;
	int batch_idx = 0;
	char* arg_ptr;
	char arg[MAX_PATH];
	char buf2[MAX_PATH];
	TBatchfile Batchfile;

	// Prioritize batch commands, if present
 	if( batch_files->size() ){
		do {
			batch_files->peek(&Batchfile);

			// Read a line from file		
			do {
				// Read a character
				while( 1 != fread(&batchbuf[batch_idx++], 1, 1, Batchfile.file) ){

					eof = feof(Batchfile.file);

					if( eof ) {

						if( batch_idx > 1){
							batchbuf[batch_idx-1] = '\n';
							break;
						}

						CloseBatchfile();
						return NULL;

					} else { 
						throw ECCD3("failed reading batch file!");
					}
				}

				if( batch_idx && !IS_ASCII(batchbuf[batch_idx-1])){
					PRINT(L_ERROR, "The file \"%s\" does not look like a ccd3 batchfile?\n", Batchfile.filename);
			    	//PRINT(L_NORMAL, CCD3CmdPrompt);
					CloseBatchfile();
					if( batch_files->size()){
						batch_files->peek(&Batchfile);
					} else {
						return NULL;
					}
				}

			} while( batchbuf[batch_idx - 1] != '\n' && batch_files->size());

			ch = batchbuf;

			// Handle read line
			// Remove possible spaces
			while(*ch == ' ' || *ch == '\t') ch++;

			batchbuf[batch_idx-1] = 0;
			batch_idx = 0;

			// Handle possible arguments
			ch = batchbuf;
			do{
				ch = strchr(ch, '$');
				if( ch ){
					*ch = '\0';
					ch++;
					if( 1 == sscanf(ch, "%d", &arg_idx) ) {
						// find arg #arg_idx in Batchfile.args
						arg_ptr = Batchfile.args;
						if( 0 == arg_idx ){
							arg_ptr = Batchfile.filename;
						} else {
							for(int n=1; n < arg_idx; n++){
								arg_ptr = strchr(arg_ptr, ' ');
								if( !arg_ptr ){
									break;
								}
								while(*arg_ptr == ' '){
									arg_ptr++;
								}
							}
						}
						// Merge arg_ptr into ch
						if( arg_ptr ){
							sscanf(arg_ptr, "%s", arg);
							ch++;
							strcpy(buf2, ch);
							strcat(batchbuf, arg);
							strcat(batchbuf, buf2);
						}

					}
				}
			} while( ch );

			strcpy(buf, batchbuf);
			cmd_executing_verbosity = L_DEBUG;
			PRINT(cmd_executing_verbosity, "%s\n", buf);
			return buf;

		} while( &batchbuf[batch_idx] != ch );
		
	} // if ( batch_files->size() )
	PRINT(L_ERROR, "Returning NULL from GetBatchCommand()\n");
	return NULL;
}

///////////////////////////////////////////////////////////////////////////////
// Returns next command available on ivy_pipe

char* cCCD3console::GetIvyCommand(char* buf)
{
	static int ivy_idx = 0;
	int res = 0;
	char* c_ptr;
	
	while( read(ivy_pipe[0], &ivybuf[ivy_idx], 1) > 0) {
		if( ivybuf[ivy_idx] == '\n')
			break;

		if(++ivy_idx > IVY_BUF_LENGTH){
			PRINT(L_ERROR, "ivy buffer overflow\n");
			break;
		}
	}

	// Assume complete command received (?)
	ivybuf[ivy_idx] = '\0';
	ivy_idx = 0;
	
	res = strncmp(ivybuf, ivy->Name(), strlen(ivy->Name()));
	
	// Is this for us at all?
	if( !res ){
		c_ptr = &ivybuf[strlen(ivy->Name())+1];
		res = strncasecmp(IVY_MSG(ivy_console_command), c_ptr, strlen(IVY_MSG(ivy_console_command)));
		
		if( !res ){
			// Handle ivy console command
			c_ptr += strlen(IVY_MSG(ivy_console_command));
			while(*c_ptr == ' ')c_ptr++;
			strcpy(buf, c_ptr);
			cmd_executing_verbosity = L_DEBUG;
			PRINT(cmd_executing_verbosity, "%s\n", buf);
			return buf;
		}

	}

	return NULL; 	
}

///////////////////////////////////////////////////////////////////////////////
// Return next command if available

char* cCCD3console::GetCommand(char* buf)
{
	int files[3];
	TBatchfile Batchfile;
	int batch_idx = -1;
	int pipe_idx  = -1;
	int con_idx   = -1;
	int file_cnt = 0;
	int res;
	char* c_res = NULL;

	buf[0] = '\0';

	while( cmd_executing ){

		try{
			res = Engine->Wait_IO(false);
		} catch(cCCD3engine::ECCD3Engine &ex){
			throw;
		}

	}

	Prompt(cmd_executing_verbosity);

	do {
		file_cnt = 0;
		batch_idx = -1;
		pipe_idx = -1;
		con_idx = -1;

		// Only ask for more input, when all replies have been received
		if( batch_files->size() && (!Engine->Busy() || (event_handler_start && batch_files->size() >= event_handler_start)) ) {
			batch_files->peek(&Batchfile);
			files[file_cnt] = fileno(Batchfile.file);
			batch_idx = file_cnt++;
		}

		if( ivy ) {
			files[file_cnt] = ivy_pipe[0];
			pipe_idx = file_cnt++;
		}

		if( !daemon_mode ){
			files[file_cnt] = STDIN_FILENO;
			con_idx = file_cnt++;
		}

		try {
			res = Engine->Wait_IO(files, file_cnt, !Engine->Busy());
		} catch(cCCD3engine::ECCD3Engine &ex){
			throw;
		}


		if( res < 0 ) {

			PRINT(L_FATAL, "Failed waiting on I/O (%d)?\n", errno);
			Quit();
			return NULL;

		} else if( res == batch_idx ) {

			c_res = GetBatchCommand(buf);
			if( !c_res && DoQuit){
				return NULL;
			}

		} else if( res == pipe_idx ) {

			c_res = GetIvyCommand(buf);

		} else if( res == con_idx ) {

			c_res = GetConsoleCommand(buf);

		}
	} while ( !c_res && !DoQuit);

	while(buf[0] == ' ' || buf[0] == '\t'){
		memmove(buf, &buf[1], strlen(buf));
	}
	return c_res;
}

///////////////////////////////////////////////////////////////////////////////
// Handle backspace

int cCCD3console::HandleBackspace(char* buf, int idx)
{
		
	buf[idx--] = '\0'; //remove BS char

	if(idx){
		buf[idx--] = '\0';
		PRINT(L_ANSI, "%s%s", backspace(), clrlineright());
	}
	
	return idx;
}

///////////////////////////////////////////////////////////////////////////////
// Handle or discard received escape sequences

int cCCD3console::HandleEscapeSequence(char* buf, int idx)
{
	char tmp[MAX_CMDLINE_LEN];
	char* esc;
	//int x,y;
	int cnt = 0;

	// is any escape present in string?
	if( !(esc = strchr(keybuf, ESC)) ){
		return idx;
	}

	// is this a complete escape sequence?
	if( idx < (esc-buf)+3 ){
		return idx;
	}

	if( esc[1] != '['){
		return idx - 3;
	}

	
	switch(esc[2]){
		case 'A': // Up
					cnt = 3;
					cmd_history_idx++;
					if( cmd_history_idx <= cmd_history->size() ){

						if( cmd_history->peek(tmp, 1, cmd_history->size()- cmd_history_idx) ){
							// Discard preceding characters
							for(int n=0; n < esc-buf; n++){
								PRINT(L_ANSI, "%s%s", backspace(), clrlineright());
							}
							//PRINT(L_ANSI, "%s%s%s%s", clrline(), startofline(), CCD3CmdPrompt, tmp);
							PRINT(L_ALWAYS, "%s", tmp);
							idx = strlen(tmp);
							cnt = 0;
							strcpy(buf, tmp);
						} else {
							PRINT(L_ERROR, "Failed fetching command history\n");
						}
					} else {
						cmd_history_idx--;
					}
					break;

		case 'B': // Down
					cnt = 3;
					if( !cmd_history_idx ) break;

					cmd_history_idx--;
					if( cmd_history_idx && cmd_history_idx <= cmd_history->size()){
						if( cmd_history->peek(tmp, 1, cmd_history->size()- cmd_history_idx) ){
							// Discard preceding characters
							for(int n=0; n < esc-buf; n++){
								PRINT(L_ANSI, "%s%s", backspace(), clrlineright());
							}
							//PRINT(L_ANSI, "%s%s%s%s", clrline(), startofline(), CCD3CmdPrompt, tmp);
							PRINT(L_ALWAYS, "%s", tmp);
							idx = strlen(tmp);
							cnt = 0;
							strcpy(buf, tmp);
						} else {
							PRINT(L_ERROR, "Failed fetching command history\n");
							break;
						}
					} else {
						for(int n=0; n < esc-buf; n++){
							PRINT(L_ANSI, "%s%s", backspace(), clrlineright());
						}
						strcpy(buf, "");
						cnt = 0;
						idx = 0;
						cmd_history_idx=0;
					}

					break;
		case 'C': // Right
					//PRINT(L_NORMAL, "Right\n");
					cnt = 3;
					break;
		case 'D': // Left
					//PRINT(L_NORMAL, "Left\n");
					cnt = 3;
					break;
		/*case '[': // Cursor position report
					if(2 == sscanf(&buf[3], "%d:%dR", &y, &x)){
						PRINT(L_ANSI, "x=%d, y=%d\n", x, y);
					} else {
						PRINT(L_ERROR, "Failed parsing cursor position\n");
					}*/
		default	:   // Jump over unhandled escape sequence, find terminating character
					//for(cnt = 3; keybuf[cnt] < '@' || keybuf[cnt] > '~'; cnt++);
					cnt = 3;
					break;
	} // switch
	
	//memmove(buf, &buf[cnt], idx - cnt);
	return idx - cnt;
}

///////////////////////////////////////////////////////////////////////////////
// Print command line prompth to console
void cCCD3console::Prompt(void)
{
	PRINT(cmd_executing_verbosity, CCD3CmdPrompt);
}

///////////////////////////////////////////////////////////////////////////////
//
void cCCD3console::Prompt(ccd3Verbosity Verb)
{
	PRINT(Verb, CCD3CmdPrompt);
}
///////////////////////////////////////////////////////////////////////////////
// Print online help to console

void cCCD3console::PrintHelp(void)
{
	PRINT(L_NORMAL, CCD3ProgramHeader);
	
	PRINT(L_NORMAL, "CCD3 Command console usage:\n");
	
	for(int n=1; n <= ciEXIT; n++){
		if( strlen(Commands[n].Text) && strlen(Commands[n].Description) ){
			PRINT(L_ALWAYS, "%10s\t%s\n", Commands[n].Text, Commands[n].Description);
		}
	}	
	
}

///////////////////////////////////////////////////////////////////////////////
// Print command line help to console

void cCCD3console::PrintCmdlineHelp(void)
{
	PRINT(L_ALWAYS, CCD3ProgramHeader);
	PRINT(L_ALWAYS, CCD3CmdlineHelp);
}

		
///////////////////////////////////////////////////////////////////////////////
		
/*void cCCD3console::HandleRMS(char* buf)
{
	int res;
	static int width = 0;
	static int height = 0;
	unsigned long* tmp;
	unsigned long pos1;//, pos2;
 	cCCD3image* image = NULL;


	res = sscanf(buf, "rms %d %d", &width, &height);

	switch( res ) {
		// If width and height are specified, this is the first bias				   	
		case	2: 	tmp = new unsigned long[width * height];
					pos1 = GetDS9Data(tmp, width, height);
					break;

		case	0:
//		case   -1:  PRINT(ccNormal, "Select first corner of box...\n");
//					pos1 = GetDS9Pos();
//					PRINT(ccNormal, "Select second corner of box...\n");
//					pos2 = GetDS9Pos();
//
//					// Check geometry
//
//					break;
			
		default	 :	PRINT(L_ERROR, CCD3CmdInvalid);
					return;
	}

	image = new cCCD3image(width, height, tmp);
   	delete[] tmp;												
	
	PRINT(L_NORMAL, "Data properties of box(%dx%d) centered on %d:%d\n", width, height, pos1 >> 16, pos1 & 0xFFFF);
	PRINT(L_NORMAL, "Max      = %u\n", image->max_value());
	PRINT(L_NORMAL, "Min      = %u\n", image->min_value());
	PRINT(L_NORMAL, "Range    = %u\n", image->max_value() - image->min_value());
	PRINT(L_NORMAL, "Average  = %.1f\n", image->average());
	PRINT(L_NORMAL, "Median   = %.1f\n", image->mid());
	PRINT(L_NORMAL, "Variance = %.2f rms\n", image->rms());
	PRINT(L_NORMAL, "Dynamic  = %.2f db\n", 20 * log10(image->max_value() - image->min_value()));
	delete image;
}*/

///////////////////////////////////////////////////////////////////////////////

/*void cCCD3console::ShowStoredImage(int idx)
{
	unsigned* from_base;
	unsigned* to_base;
	int element_size, width, height;
	if( idx < 0 || idx >= img_cnt ){
		PRINT(ccError, "Sorry, no image found on position %d\n", idx);
	}
	
	Engine->SetPreview( true );
	
	Engine->xpa->set("frame new");
	Engine->xpa->set("frame show");
	
	from_base = (unsigned*)images[idx]->get_base();
	to_base   = (unsigned*)Engine->shm->Mem;
	
	element_size = images[idx]->get_element_size();
	width = images[idx]->get_width();
	height = images[idx]->get_height();
	images[idx]->calc_stat();
		
	memcpy(to_base, from_base, width * height * element_size);
	
	Engine->xpa->set("shm array shmid %d [xdim=%lu,ydim=%lu,bitpix=32]", Engine->shm->getid(), images[idx]->get_width(), images[idx]->get_height());
	Engine->xpa->set("scale limits %d %d", images[idx]->min_value(), images[idx]->max_value());	
	Engine->xpa->set("scale mode minmax");
	Engine->xpa->set("zoom to fit");	
	Engine->xpa->set("update now");
}*/

///////////////////////////////////////////////////////////////////////////////

void cCCD3console::Evaluate(char* buf){
	// + - * / rms
	// fft 
}

///////////////////////////////////////////////////////////////////////////////
//
void cCCD3console::ShowMatrice(unsigned long* matrice, unsigned xsiz, unsigned ysiz, unsigned pos)
{
	unsigned n;
	unsigned long max_x=0, min_x=0xFFFFFFFF, max_y=0, min_y=0xFFFFFFFF, val, x, y;

	PRINT(L_NORMAL, "Array at point (%d,%d):\n", pos >> 16, pos & 0xFFFF);
	for(n=0; n < xsiz * ysiz; n++){
			//PRINT(ccNormal,"0x%04X:0x%04X ", matrice[n] >> 16, matrice[n] & 0xFFFF);
			PRINT(L_NORMAL, "%u:%u ", matrice[n] >> 16, matrice[n] & 0xFFFF);
			//PRINT(ccNormal,"%u ", matrice[n]);
			max_x = max(max_x, (matrice[n] & 0xFFFF));
			min_x = min(min_x, (matrice[n] & 0xFFFF));
			max_y = max(max_y, matrice[n] >> 16);
			min_y = min(min_y, matrice[n] >> 16);
	}

	PRINT(L_NORMAL, "\n\n");
	PRINT(L_NORMAL, "max_x = %d\n", max_x);
	PRINT(L_NORMAL, "min_x = %d\n", min_x);
	PRINT(L_NORMAL, "max_y = %d\n", max_y);
	PRINT(L_NORMAL, "min_y = %d\n", min_y);
	for(y = min_y; y <= max_y; y++){
		for(x = min_x; x <= max_x; x++){
			val = y << 16 | x;
			for(n=0; n < (xsiz * ysiz); n++) if (val == matrice[n]) break;
			if( n < (xsiz*ysiz) ){
				PRINT(L_NORMAL, "%d ", n);
			} else {
				PRINT(L_NORMAL, "x ");
			}
		}
		PRINT(L_NORMAL, "\n");
	}

	delete[] matrice;
}

///////////////////////////////////////////////////////////////////////////////
// Run loop

int cCCD3console::Run(void){
	
	TCommandID MatchId = ciUNKNOWN;
	char img_filename[MAX_PATH] = "";
	char tmp_filepath[MAX_PATH] = "";
	char cmd_buf[4*BUFFER_SIZE] = "";
	char tmp[MAX_PATH] = "";
	char* ptr = NULL;
	char* ptr2 = NULL;
	char* ptr3 = NULL;
	int itmp, itmp2, n;
	unsigned utmp;
	bool btmp;
	unsigned long* matrice;
	t_rotation rotate;

	try {

		while( !DoQuit || event_handler_start ){

			while ( GetCommand(cmd_buf) ){

				//IvySend(ivy_console_command, cmd_buf); // Report command

				// Remove possible comments
				ptr3 = cmd_buf;
				do {
					ptr = strstr(ptr3, "#");

					if( !ptr ){
						ptr = strstr(ptr3, "//");
					}

					if( !ptr ){
						ptr = strstr(ptr3, ";");
					}

					if( ptr ){
						ptr2 = strstr(ptr3, "\"");
						ptr3 = ptr2 ? strstr(&ptr2[1], "\"") : NULL;

						if(  (ptr2 && ptr2 < ptr) && (ptr3 && ptr3 > ptr)){
							// comment character was enclosed in "" string
							ptr3 = &ptr3[1]; // Move past \" character
						} else {
							*ptr = '\0';
							ptr3 = cmd_buf;
						}
					}

				} while( ptr );

				while( strnlen(cmd_buf, 100) > 0 && (cmd_buf[strnlen(cmd_buf, 100)-1] == ' ' || cmd_buf[strnlen(cmd_buf, 100)-1] == '\t')){
					cmd_buf[strnlen(cmd_buf,100)-1] = '\0';
				}

				// Still any characters left after comment was removed?
				if( strlen(cmd_buf)){
					break;
				}
			} // while (GetCommand...
			
			if( DoQuit ){
				continue;
			}

			MatchId = ciUNKNOWN;
			MatchId = cmd_buf[0] == CAM_COMMAND_PREFIX	? ciCAMCMD : MatchId;
			MatchId = cmd_buf[0] == CAM_QUESTION_PREFIX ? ciCAMQUE : MatchId;
			MatchId = cmd_buf[0] == CAM_ANSWER_PREFIX   ? ciCAMSTS : MatchId;
			//MatchId = cmd_buf[0] == CAM_UNSOL_PREFIX	? ciCAMSOL : MatchId;

			if(!strlen(cmd_buf)) MatchId = ciENTER;

			// Search for token if not already found
			for( n = 1; n <= ciCommandCount && MatchId == ciUNKNOWN; n++){
				if( sscanf(cmd_buf, "%s", tmp)){
					if( !strcasecmp(tmp, Commands[n].Text)){
						MatchId = Commands[n].ID;
					}
				}
			}

			switch(MatchId){
					case ciCAMCMD:
						cmd_executing++;
						Engine->CommandCam(&cmd_buf[1], DmyConCallback, this, 1);	//Send command ... skip prefix
						break;

					case ciCAMQUE:
						cmd_executing++;
						Engine->QueryCam(&cmd_buf[1], DmyConCallback, this, 1);		//Send command ... skip prefix
						break;

					case ciCAMSTS:
						PRINT(L_ERROR, "Sorry! issuing camera status information is the sole priviledge of the camera\n");
						PRINT(L_ERROR, "Try another command or press \"help\"\n");
						break;

					case ciCAMNUM:
						if( sscanf(cmd_buf, "%*s %d", &itmp) != 1 ){
							PRINT(L_ERROR, CCD3CmdInvalid);
							break;
						}
						//Engine->SelectCam(itmp);
						PRINT(L_ERROR, "Sorry! This command is not available yet\n");
						break;

					case ciFILE:
						tmp[0] = 0;
						sscanf(cmd_buf, "%*s %s", tmp);

						if( strlen(tmp) ){

							btmp = tmp[0] == '!';
							strcpy(img_filename, &tmp[btmp ? 1 : 0]);

							ptr = strrchr(img_filename, '/');
							if( ptr ){
								*ptr = 0;
								strcpy(tmp_filepath, img_filename);
								strcat(tmp_filepath, "/");
								strcpy(img_filename, ++ptr);
							} else {
								strcpy(tmp_filepath, img_filepath);
							}

							OpenNextFile(tmp_filepath, img_filename, btmp);
							break;
						}

						PRINT(L_ERROR, CCD3CmdInvalid);
						//PRINT(cmd_executing_verbosity, "File closed\n");
						//IvySend(ivy_file_name);
						//Engine->CloseFile();

						break;

					/*case ciFILESAVE:
						if( sscanf(cmd_buf, "%*s %s", tmp) == 1){
							btmp = tmp[0] == '!';
							strcpy(img_filename, &tmp[btmp ? 1 : 0]);

							ptr = strrchr(img_filename, '/');
							if( ptr ){
								*ptr = 0;
								strcpy(tmp_filepath, img_filename);
								strcat(tmp_filepath, "/");
								strcpy(img_filename, ++ptr);
							} else {
								strcpy(tmp_filepath, img_filepath);
							}
							sprintf(tmp, "%s%s", tmp_filepath, img_filename);

							if( !Engine->SaveBuffer(tmp) ){
								PRINT(L_ERROR, "Failed saving buffer .. sorry!\n");
								IvySend(ivy_application_error, "Failed saving buffer");
								break;
							}
						} else {
							PRINT(L_ERROR, CCD3CmdInvalid);
						}

						break;
					*/
					case ciFILECLOSE:
						if( sscanf(cmd_buf, "%*s %s", tmp) == 1){

							if( StringIsBool(tmp)){
								Engine->AllowFileClose( StringIsTrue(tmp) );
								break;
							}

							PRINT(L_ERROR, CCD3CmdInvalid);

						} else {
							PRINT(cmd_executing_verbosity, "fileclose %s\n", Engine->isAllowFileClose() ? "on" : "off");
						}
						break;

					case ciFILEAUTO:
						if( sscanf(cmd_buf, "%*s %s", tmp) == 1){

							if( StringIsBool(tmp) ){
								autosave = StringIsTrue(tmp);
							} else {
								PRINT(L_ERROR, CCD3CmdInvalid);
								break;
							}
						}

						PRINT(cmd_executing_verbosity, "Autosave turned %s\n", autosave ? "on" : "off");
						IvySend(ivy_file_auto, "%d", autosave ? 1 : 0);

						break;

					case ciFILEPATH:
						if( sscanf(cmd_buf, "%*s %s", tmp_filepath)  == 1){
							SetFilepath(tmp_filepath);
						}
						break;

					case ciFILESTD:
						if( sscanf(cmd_buf, "%*s %s", tmp) == 1){

							if( !strcasecmp(tmp, "NOT")){
								namestyle = nsNOT;
								PRINT(cmd_executing_verbosity, "NOT namestyle set\n");
								IvySend(ivy_file_std, "NOT");
								break;
							}

							if ( !strcasecmp(tmp, "DEFAULT")){
								namestyle = nsDefault;
								PRINT(cmd_executing_verbosity, "Default CCD3 namestyle set\n");
								IvySend(ivy_file_std, "DEFAULT");
								break;
							}

							if ( !strcasecmp(tmp, "config")) {
								InitFilename();
								PRINT(cmd_executing_verbosity, "namestyle set according to config\n", tmp);
								break;
							}

							namestyle = nsCustom;
							ptr = strrchr(tmp, '/');
							if( ptr ){
								PRINT(L_ERROR, "filestd can't contain a path!");
								break;
							}

							ptr = strstr(&tmp[strlen(tmp) - strlen(".fits")], ".fits");
							if( ptr ){
								*ptr = '\0';
							}
							strcpy(filestd, tmp);
							PRINT(cmd_executing_verbosity, "Custom namestyle set \"%s\"\n", tmp);
							IvySend(ivy_file_std, tmp);
							break;
						}

						// Set default file standard according to config file
						InitFilename();
						PRINT(cmd_executing_verbosity, "namestyle set according to config\n", tmp);
						break;


					/*case	ciLOAD		:	if( sscanf(cmd_buf, "%*s %s", img_filename) != 1){
																			PRINT(ccError, CCD3CmdInvalid);
																			break;
																	}
																	if( strlen(img_filename) ){
																			itmp = LoadFile(img_filename);
																			if( itmp >= 0 ){
																					PRINT(ccNormal, "Image in \"%s\" stored on position %d\n", img_filename, itmp);
																			} else {
																					PRINT(ccNormal, "Failed loading image\n");
																			}
																	} else {
																			PRINT(ccNormal, "Unexpected condition reached\n");
																			break;
																	}
																	break;*/

					/*case	ciSHOW		:	if( sscanf(cmd_buf, "%*s %d", &itmp) != 1){
																			PRINT(ccError, CCD3CmdInvalid);
																			break;
																	}
																	ShowStoredImage(itmp);
																	break;*/

					/*case	ciEVAL		:	Evaluate(cmd_buf);
																	break;*/

					case ciVERB:
						if( sscanf(cmd_buf, "%*s %s", tmp) == 1 ){
							if( !LOG->set_print_verbosity(tmp) ){
								PRINT(L_ERROR, "Failed setting verbosity level\n");
								IvySend(ivy_application_error, "Failed setting verbosity level");
								break;
							}
						}

						PRINT(cmd_executing_verbosity, "Verbosity level is set to %s\n", VERBOSITY_STRINGS[LOG->get_print_verbosity()]);
						break;

					case ciLVERB:
						if( sscanf(cmd_buf, "%*s %s", tmp) == 1){
							if( !LOG->set_log_verbosity(tmp) ){
								PRINT(L_ERROR, "Failed setting logging level\n");
								IvySend(ivy_application_error, "Failed setting logging level");
								break;
							}
						}
						PRINT(cmd_executing_verbosity, "Logging level is set to %s\n", VERBOSITY_STRINGS[LOG->get_log_verbosity()]);
						break;

					case ciXPASET:
						if( !ds9 ){
							PRINT(L_ERROR, "Preview not enabled\n");
							break;
						}

						if( !(ptr = strstr(cmd_buf, " ")) ){
							PRINT(L_ERROR, "No xpa args? (%s)\n", cmd_buf);
							break;
						}

						ptr++;
						if( !ds9->xpa()->set(ptr)){
							PRINT(cmd_executing_verbosity, "%s\n", "No xpa received replied? Disabling preview!");
							CloseDS9();
						}

						break;

					case ciXPAGET:
						if( !ds9 ){
							PRINT(L_ERROR, "Preview not enabled\n");
							break;
						}

						if( !(ptr = strstr(cmd_buf, " ")) ){
							PRINT(L_ERROR, "No xpa args? (%s)\n", cmd_buf);
							break;
						}
						ptr++;

						if( ds9->xpa()->get(&ptr, 1, ptr) ){
							ptr2 = strchr(ptr, '\n');
							if( ptr2 ){
								*ptr2 = '\0';
							}
							PRINT(cmd_executing_verbosity, "%s\n", ptr);
						} else {
							PRINT(cmd_executing_verbosity, "%s\n", "No response received? Disabling preview!");
							CloseDS9();
						}
						/*try {
							Engine->Preview()->get(&ptr, 1, ptr);
							ptr2 = strchr(ptr, '\n');
							if( ptr2 ){
								*ptr2 = '\0';
							}

							PRINT(cmd_executing_verbosity, "%s\n", ptr);
						} catch( ... ){
		::Run					PRINT(cmd_executing_verbosity, "Failed command \"%s\"", cmd_buf);
						}*/

						break;

					case ciEXAM:
						if( !ds9 ){
							PRINT(L_ERROR, "Preview not enabled\n");
							break;
						}

						if( sscanf(cmd_buf, "%*s %d %d", &itmp, &itmp2) != 2 ){
							PRINT(L_ERROR, CCD3CmdInvalid);
							break;
						}

						matrice = new unsigned long[itmp * itmp2];

						utmp = ds9->Examine(matrice, itmp, itmp2);
						ShowMatrice(matrice, itmp, itmp2, utmp);
						delete[] matrice;
						break;

/*					case ciRMS:
						HandleRMS(cmd_buf);
						break;*/

					case ciIVY:
						if( !ivy ){
							PRINT(L_ERROR, "IVY connection not enabled!\n");
							break;
						}

						ptr = strchr(cmd_buf, ' ');
						while(*ptr == ' ')ptr++;
						IvySend(ivy_none, ptr);

						break;

					case ciSLEEP:
						if( sscanf(cmd_buf, "%*s %d", &itmp) != 1 ){
							PRINT(L_ERROR, CCD3CmdInvalid);
							break;
						}
						Engine->Sleep(itmp*1000);
						break;

					case ciKEYWORD:
						ptr = strchr(cmd_buf, ' ');
						while(*ptr == ' ')ptr++;

						try {
							Engine->WriteKeyword(ptr);
						} catch(common_exception &ex){
							PRINT(L_ERROR, "Failed writing keyword with message \"%s\"\n", ex.what());
							IvySend(ivy_application_error, CCD3CmdUnknown);
						}
						break;

					case ciLOG:
						ptr = strchr(cmd_buf, ' ');
						while(*ptr == ' ')ptr++;
						LOGMSG(ptr);
						break;

					case ciPREVIEW:
						ptr = strstr(cmd_buf, " ");

						if( ptr ){
							while( *ptr == ' ') ptr++;

							if( StringIsTrue(ptr) ){
								InitDS9(false);
								break;
							} else if( StringIsFalse(ptr)){
								CloseDS9();
								break;
							} else if( !strcasecmp(ptr, "remote")){
								InitDS9(true);
								break;
							}
						}

						PRINT(L_ERROR, CCD3CmdInvalid);
						IvySend(ivy_application_error, CCD3CmdUnknown);
						break;

					case ciMIRRORX:
						ptr = strstr(cmd_buf, " ");

						if( ptr ){
							while( *ptr == ' ' || *ptr == '\t') ptr++;

							if( StringIsBool(ptr) ){
								Engine->set_mirror_x( StringIsTrue(ptr) );
							} else {
								PRINT(L_ERROR, CCD3CmdInvalid);
								IvySend(ivy_application_error, CCD3CmdUnknown);
								break;
							}
						}

						PRINT(cmd_executing_verbosity, "mirrorx %s\n", Array.get_mirror_x() ? "on" : "off");
						break;

					case ciMIRRORY:
						ptr = strstr(cmd_buf, " ");
						if( ptr ){
							while( *ptr == ' ' ) ptr++;

							if( StringIsBool(ptr) ){
								Engine->set_mirror_y( StringIsTrue(ptr) );
							} else {
								PRINT(cmd_executing_verbosity, CCD3CmdInvalid);
								IvySend(ivy_application_error, CCD3CmdUnknown);
								break;
							}

						}

						PRINT(cmd_executing_verbosity, "mirrory %s\n", Array.get_mirror_y() ? "on" : "off");
						break;

					case ciROTATE:
						ptr = strstr(cmd_buf, " ");
						if( ptr ){
							while( *ptr == ' ' ) ptr++;

							if( !strcasecmp(ptr, "0") ){
								Engine->set_rotate(r0);
							} else if( !strcasecmp(ptr, "90") ){
								Engine->set_rotate(r90);
							} else if( !strcasecmp(ptr, "180") ){
								Engine->set_rotate(r180);
							} else if( !strcasecmp(ptr, "270") ){
								Engine->set_rotate(r270);
							} else {
								PRINT(L_ERROR, CCD3CmdInvalid);
								IvySend(ivy_application_error, CCD3CmdUnknown);
								break;
							}
						}

						rotate = Array.get_rotation();
						switch ( rotate ){
						case r0:
							PRINT(cmd_executing_verbosity, "rotate off\n"); break;
						case r90:
							PRINT(cmd_executing_verbosity, "rotate 90\n"); break;
						case r180:
							PRINT(cmd_executing_verbosity, "rotate 180\n"); break;
						case r270:
							PRINT(cmd_executing_verbosity, "rotate 270\n"); break;
						default:
							PRINT(L_ERROR, "rotate unknown??\n");
							IvySend(ivy_application_error, CCD3CmdUnknown);
							break;
						}
						break;

					case ciCOMBINE:
						ptr = strstr(cmd_buf, " ");
						if( ptr ){
							while(*ptr == ' ') ptr++;

							if( StringIsBool(ptr) ){
								Engine->SetCombine( StringIsTrue(ptr) );
							} else {
								PRINT(L_ERROR, CCD3CmdInvalid);
								break;
							}
						}

						PRINT(cmd_executing_verbosity, "combine %s\n", Engine->GetCombine() ? "on" : "off");
						break;

					case ciSETENV:
						ptr = strstr(cmd_buf, " ");
						if( ptr ){

							while(*ptr == ' ') ptr++;

							ptr2 = strstr(ptr, " ");


							if( ptr2 ){
								*ptr2++ = '\0';
								while(*ptr2 == ' ') ptr2++;
								setenv(ptr, ptr2, 1);
							} else {
								PRINT(cmd_executing_verbosity, CCD3CmdInvalid);
								IvySend(ivy_application_error, CCD3CmdUnknown);
							}
						}

						//PRINT(cmd_executing_verbosity, "Display = \"%s\"\n", getenv("DISPLAY"));
						break;

					case ciGETENV:
						ptr = strstr(cmd_buf, " ");
						if( ptr ){
							while(*ptr == ' ') ptr++;
							PRINT(cmd_executing_verbosity, "%s\n", getenv(ptr));
						} else {
							PRINT(cmd_executing_verbosity, CCD3CmdInvalid);
							IvySend(ivy_application_error, CCD3CmdUnknown);
						}
						break;

					case ciRSET:
						Engine->Reset();
						break;

					case ciHELP:
						PrintHelp();
						break;

					case ciEXIT:
					case ciQUIT:
						Quit();
						break;

					case ciCLEAR:
						clrscr();
						gotoxy(0,0);
						break;

					case ciABOUT:
						PRINT(cmd_executing_verbosity, "\n%s%s", CCD3ProgramHeader, CCD3ProgramInfo);
						break;

					case ciDEBUG:
						// Output debug counters
						Engine->ShowDebug();
						break;

					case ciTEST:
						ptr = strstr(cmd_buf, " ");
						itmp = 0;
						strcpy(tmp, "");
						if( ptr ){
							while( *ptr == ' ' ) ptr++;

							if( !strncasecmp( ptr, "mem block", strlen("mem block")) ) {
								sscanf(ptr, "%*s %*s %d", &itmp);
								Engine->TestMemBlock(itmp);
								break;
							}

							if( !strncasecmp( ptr, "mem single", strlen("mem single")) ) {
								sscanf(ptr, "%*s %*s %d", &itmp);
								Engine->TestMemSingle(itmp);
								break;
							}

							if( !strncasecmp( ptr, "pattern", strlen("pattern")) ){
								if( 1 == sscanf(ptr, "%*s %d", &itmp)){
									try{
										Engine->SetTestPattern(itmp);
									} catch(common_exception &ex){
										PRINT(cmd_executing_verbosity, "%s\n", ex.what());
									}
									break;
								}
							}

							if( !strncasecmp( ptr, "skipoffload", strlen("skipoffload")) ){
								sscanf(ptr, "%*s %s", tmp);
								if( strlen(tmp) && StringIsBool(tmp)){
									Engine->SetTestOffload(StringIsTrue(tmp));
									break;
								}
							}

							if( !strncasecmp( ptr, "subscriptions", strlen("subscriptions")) ){
								Engine->ShowCallback();
								break;
							}
						}
						PRINT(cmd_executing_verbosity, "Hands off!! ..if you had any business with this command, you would know how to use it!\n");
						IvySend(ivy_application_error, CCD3CmdUnknown);
						//Engine->ShowCallback();
						//Engine->TestMemSingle();
						break;

					case ciKEYBUF:
						itmp = cmd_history->size();
						ptr = new char[itmp * MAX_CMDLINE_LEN];
						cmd_history->peek(ptr, itmp);
						ptr2 = ptr;
						PRINT(cmd_executing_verbosity, "keybuf:\n");
						for(n=0; n < itmp; n++){
							PRINT(cmd_executing_verbosity, "%s\n", ptr2);
							ptr2 += MAX_CMDLINE_LEN;
						}
						delete[] ptr;
						break;

					case ciENTER:
						break;

					case ciUNKNOWN:
						if( !HandleUnknownCommand(cmd_buf) ){
							PRINT(cmd_executing_verbosity, CCD3CmdInvalid);
							IvySend(ivy_application_error, CCD3CmdUnknown);
						}
						break;

					default:
						PRINT(L_ERROR, CCD3CmdUnknown);
						IvySend(ivy_application_error, CCD3CmdUnknown);
						break;
			} // switch()
		} // while

		PRINT(L_NORMAL, "bye..\n");
		return 0;

	} catch (common_exception &ex){
		//delete this;
		throw ex;
	}

	return 0;
} // Run()

///////////////////////////////////////////////////////////////////////////////

void cCCD3console::Quit(void)
{
	AddBatchfile(exec_on_appclose);
	event_handler_start = batch_files->size();
	DoQuit = true;
	if( Engine ){
		Engine->Quit();
	}
}

///////////////////////////////////////////////////////////////////////////////
// Handle an unknown command which could be a batch or script command
int cCCD3console::HandleUnknownCommand(char* cmd)
{
	char buf[MAX_PATH];
	char line[MAX_PATH];
	char args[MAX_PATH] = "";
	FILE* file;
	char* res;
	char* cmd_ptr = cmd;
	char* arg_ptr;
	// Search script dir for command
	while(*cmd_ptr == ' ') cmd_ptr++;

	arg_ptr = strchr(cmd_ptr, ' ');
	if( arg_ptr ){
		*arg_ptr = '\0';
		arg_ptr++;
		strcpy(args, arg_ptr);
	} else {
		args[0] = '\0';
	}

	if( !strchr(cmd_ptr, '/') ){
		sprintf(buf, "%s%s", script_dir, cmd_ptr);
	} else {
		strcpy(buf, cmd_ptr);
	}

	file = fopen(buf,"r");
	if( !file ){
		return 0;
	}

	res = fgets(line, MAX_PATH, file);
	fclose(file);

	if( !res)
		return 0;//NULL;

	if( !strncmp(line, "#!", 2) ){
		// execute shell script
        Execute(buf, args, true);
	} else {
		// execute batch
		AddBatchfile(buf, args);
	}
	return 1;
}


///////////////////////////////////////////////////////////////////////////////
//

void cCCD3console::OpenNextFile(char* path, char* name, bool overwrite)
{
	char img_filename[MAX_PATH];
	char full_filename[MAX_PATH];
	char* my_path = path && strlen(path) ? path : img_filepath;

	if( !CheckPath(my_path) ){
		return;
	}

	if(name && strlen(name)){
		strcpy(img_filename, name);
	} else {
		GetFilename(my_path, img_filename);
	}

	sprintf(full_filename, "%s%s%s", overwrite ? "!":"", my_path, img_filename);
	Engine->OpenFile(full_filename);

	IvySend(ivy_file_path, my_path);
	IvySend(ivy_file_name, img_filename);
	PRINT(cmd_executing_verbosity, "Filename set to %s\n", img_filename);
}

///////////////////////////////////////////////////////////////////////////////
//
bool cCCD3console::CheckPath(char* path){
	bool path_ok = false;
	struct stat S;
	uid_t uid;
	gid_t gid;

	uid = getuid();
	gid = getgid();
	stat(path, &S);

	if ( !uid || (( uid == S.st_uid ) && ( ( S.st_mode & 0600 ) == 0600 )) ){
		path_ok = true;
	}

	if ( ( gid == S.st_gid ) && ( ( S.st_mode & 0060 ) == 0060 ) ){
		path_ok = true ;
	}

	if ( ( S.st_mode & 0006 ) == 0006 ){
		path_ok = true;
	}

	if( !path_ok ){
		PRINT(L_ERROR, "Invalid path! (\"%s\")\n", path);
		IvySend(ivy_application_error, "Invalid path");
	}

	return path_ok;
}

///////////////////////////////////////////////////////////////////////////////
//
void cCCD3console::SetFilepath(char* path)
{

	if( CheckPath(path) ){
		strcpy(img_filepath, path);

		if( img_filepath[strlen(img_filepath)-1] != '/'){
			strcat(img_filepath, "/");
		}

		PRINT(MAKE_FLAG(ccDebug,  ccNormal), "Output directory set to %s\n", img_filepath);
		IvySend(ivy_file_path, img_filepath);

	}
}

///////////////////////////////////////////////////////////////////////////////
//
void cCCD3console::GetFilename(const char* path, char* name)
{
	switch( namestyle ){
	case nsNOT:
		GetNOTFilename(path, name);
		break;
	case nsDefault:
		GetCCD3Filename(path, name);
		break;
	case nsCustom:
		GetCustomFilename(path, name);
		break;
	default:
		throw ECCD3("Invalid namestyle?");
	}
}

///////////////////////////////////////////////////////////////////////////////
// Return next file number in path within the defined pre/post strings

int cCCD3console::GetNextFileno(const char* path, const char* pre, const char* post){
	char latest_file[MAX_PATH] = "";
	DIR* p_dir;
	int fileno = 0;
	size_t pre_len = strlen(pre);
	size_t post_len = strlen(post);
	struct dirent* p_entry = NULL;

	p_dir = opendir(path);
	if( !p_dir )
		throw ECCD3("Failed opening directory: \"%s\" with err=%d\n", path, errno);

	while( (p_entry = readdir(p_dir)) ){
		// Check length
		if( strlen(p_entry->d_name) != pre_len + post_len + 4 )
			continue;
		// Check prefix
		if( strncmp(pre, p_entry->d_name, pre_len) )
			continue;
		// Check postfix
		if( strncmp(post, &p_entry->d_name[strlen(p_entry->d_name) - post_len], post_len))
			continue;

		if( strcmp(latest_file, p_entry->d_name) < 0){
			strcpy(latest_file, p_entry->d_name);
		}
	}

	closedir(p_dir);

	if( strlen(latest_file) ){
		sscanf(&latest_file[strlen(pre)], "%04d", &fileno);
	}

	return fileno + 1;

}

///////////////////////////////////////////////////////////////////////////////
// Return a filename in buf, according to NOT standard

void cCCD3console::GetNOTFilename(const char* path, char* name)
{
	struct tm *TM;
	time_t Tt = start_time;
	char pre[MAX_PATH];
	int fileno;

	TM = gmtime(&Tt);

	if( TM->tm_hour < date_shift){
		Tt -= date_shift*60*60;
		TM = gmtime(&Tt);
		//Tt += 12*60*60;
	}

	sprintf(pre, "%s%c%c%c%c",	prefix,
								'a' + TM->tm_year - 91,
								'a' + TM->tm_mon,
								'0' + (TM->tm_mday / 10),
								'0' + (TM->tm_mday % 10));

	sprintf(name, "%s%04d%s", pre, 0 , DEFAULT_FITS_EXTENSION);
	fileno = GetNextFileno(path, pre, DEFAULT_FITS_EXTENSION);
	sprintf(name, "%s%04d%s", pre, fileno, DEFAULT_FITS_EXTENSION);
}

///////////////////////////////////////////////////////////////////////////////
// Return default ccd3 filename

void cCCD3console::GetCCD3Filename(const char* path, char* name)
{
	int fileno = GetNextFileno(path, prefix, DEFAULT_FITS_EXTENSION);
	sprintf(name, "%s%04d%s", prefix, fileno, DEFAULT_FITS_EXTENSION);
}

///////////////////////////////////////////////////////////////////////////////
// Return custom namestyle filename

void cCCD3console::GetCustomFilename(const char* path, char* name)
{
	char pre[MAX_PATH];
	int fileno;
	sprintf(pre, "%s%s", prefix, filestd);
	fileno = GetNextFileno(path, pre, DEFAULT_FITS_EXTENSION);
	sprintf(name, "%s%04d%s", pre, fileno, DEFAULT_FITS_EXTENSION);
}

///////////////////////////////////////////////////////////////////////////////
// Callback routine for Camera Command/Status messages
// This routine is called out of class execution context

void cCCD3console::ConCallback(HSUBSCRIPTION hSubscription, char* data)
{
	char response[256];
	char arg[256];

	if( cmd_executing )
		cmd_executing--;

	Engine->QueryCamResponse(hSubscription, arg, response, true);
	IvySend(ivy_console_response, "%s %s",arg, response);
	PRINT(cmd_executing_verbosity ,"%s %s\n", arg, response);
}

///////////////////////////////////////////////////////////////////////////////

void cCCD3console::CamCallback(HSUBSCRIPTION hSubscription, char* data)
{

	if( hSubscription == hError ){
		if( cmd_executing )
			cmd_executing--;

		IvySend(ivy_cam_error, data);
		PRINT(L_ERROR,"%s\n", data);
		cmd_executing_verbosity = L_ERROR;
	    return;
	}

	if( hSubscription == hBrek ){
		CloseBatchfiles();
		return;
	}

	if( hSubscription == hSint ){

		Engine->AllowFileClose(ini_file->ReadBool(INI_FILE_SECTION, INI_FILE_ALLOWCLOSE, INI_FILE_DEFAULT_ALLOWCLOSE));

		if( !strlen(Engine->Filename()) ){

			if( !autosave ){

				cmd_executing_verbosity = L_ERROR;
				PRINT(L_ERROR, "WARNING: No file has been set, data will *NOT* be saved!!\n");
				IvySend(ivy_file_name, "");
			} else {
				OpenNextFile();
			}
		}
		Engine->StartExposure();
		return;
	}

	cmd_executing_verbosity = L_ERROR;
	PRINT(L_ERROR, "\nUnknown subscription found in callback?\n");
}

///////////////////////////////////////////////////////////////////////////////

void cCCD3console::DrvCallback(HSUBSCRIPTION hSubscription, char* data)
{
	if( hSubscription == hDrv ){
		if( strstr(data, DRV_RX) ){
			int new_rx_ok;

			if( 1 != sscanf(data, "%*s %*s %d", &new_rx_ok) ){
				PRINT(L_ERROR, "Failed parsing driver message: \"%s\"\n", data);
				return;
			}

			if( new_rx_ok != rx_ok ){
				rx_ok = new_rx_ok;
				if( rx_ok ){
					//IvySend(ivy_comm_ok, "Rx fiber OK");
					PRINT(L_NORMAL, "Rx fiber up\n");
				} else {
					//IvySend(ivy_comm_error, "Communication error, Rx fiber down!");
					PRINT(L_ERROR, "\nNetwork error, Rx fiber down!\n");
					cmd_executing = false;
				}
			}
		}

		if( strstr(data, DRV_TX) ){
			int new_tx_ok;

			if( 1 != sscanf(data, "%*s %*s %d", &new_tx_ok) ){
				PRINT(L_ERROR, "Failed parsing driver message: \"%s\"\n", data);
				return;
			}

			if( new_tx_ok != tx_ok ){
				tx_ok = new_tx_ok;
				if( tx_ok ){
					//IvySend(ivy_comm_ok, "Tx fiber up");
					PRINT(L_NORMAL, "Tx fiber up\n");
					cmd_executing = false;
				} else {
					//IvySend(ivy_comm_error, "Communication error, Tx fiber down!");
					PRINT(L_ERROR, "\nNetwork error, Tx fiber down!\n");
					cmd_executing = false;
				}
			}
		}

		return;
	}

	cmd_executing_verbosity = L_ERROR;
	PRINT(L_ERROR, "\nUnknown subscription found in callback?\n");
}

///////////////////////////////////////////////////////////////////////////////

void cCCD3console::DefCallback(HSUBSCRIPTION hSubscription, char* data)
{
#ifdef DEBUG
	PRINT(L_DEBUG ,"%s\n", data);
    if( !cmd_executing ){
    	PRINT(L_DEBUG, CCD3CmdPrompt);
	}
#endif
}

///////////////////////////////////////////////////////////////////////////////

void cCCD3console::IvyCallback(IvyClientPtr app, int argc, char** argv)
{
	size_t res;
	for(int n=0; n < argc; n++){
		res = write( ivy_pipe[1], argv[n], strlen(argv[n]));
		res = write( ivy_pipe[1], "\n", 1);
	}
	if( !res ){
	    PRINT(L_ERROR, "\nFailed writing ivy pipe?\n");
	}
}

///////////////////////////////////////////////////////////////////////////////

void cCCD3console::EngineCallback(HSUBSCRIPTION hSubscription, char* data)
{
	if( hSubscription == hExp ){
		if( !AddBatchfile(exec_on_exposure) ){
			return;
		}
	} else if( hSubscription == hReadout ){
		if( !AddBatchfile(exec_on_readout) ){
			return;
		}
	} else if( hSubscription == hFileclose ){
		if( !AddBatchfile(exec_on_fileclose) ){
			return;
		}
	} else if( hSubscription == hEngineError ){
		if( !AddBatchfile(exec_on_error, data) ){
			return;
		}
	} else {
		PRINT(L_DEBUG, "Unknown callback encountered?\n");
		return;
		// what to do?
	}
	event_handler_start = batch_files->size();
}

///////////////////////////////////////////////////////////////////////////////
// Dummy callback routines, map's into corresponding routines in class

void DmyConCallback(HSUBSCRIPTION hSubscription, char* data, void* user)
{
	cCCD3console* parent = (cCCD3console*)user;
	parent->ConCallback(hSubscription, data);
}

///////////////////////////////////////////////////////////////////////////////

void DmyDefCallback(HSUBSCRIPTION hSubscription, char* data, void* user)
{
	cCCD3console* parent = (cCCD3console*)user;
	parent->DefCallback(hSubscription, data);
}

///////////////////////////////////////////////////////////////////////////////

void DmyIvyCallback(IvyClientPtr app, void* data, int argc, char** argv)
{
	cCCD3console* parent = (cCCD3console*)data;
	parent->IvyCallback(app, argc, argv);
}

///////////////////////////////////////////////////////////////////////////////

void DmyCamCallback(HSUBSCRIPTION hSubscription, char* data, void* user)
{
	cCCD3console* parent = (cCCD3console*)user;
	parent->CamCallback(hSubscription, data);
}

///////////////////////////////////////////////////////////////////////////////

void DmyDrvCallback(HSUBSCRIPTION hSubscription, char* data, void* user)
{
	cCCD3console* parent = (cCCD3console*)user;
	parent->DrvCallback(hSubscription, data);
}

///////////////////////////////////////////////////////////////////////////////

void DmyEngineCallback(HSUBSCRIPTION hSubscription, char* data, void* user)
{
	cCCD3console* parent = (cCCD3console*)user;
	parent->EngineCallback(hSubscription, data);
}

///////////////////////////////////////////////////////////////////////////////

void signal_handler(int signum){
	switch( signum ){
    case SIGINT:
    	break;
    case SIGTERM:
    	break;
    case SIGQUIT:
    	break;
    case SIGHUP:
    	cCCD3console::DoReload();
    	break;
    default:
    	PRINT(L_DEBUG, "Unknown signal (%d)?\n", signum);
    	break;
	}
	CON->Quit();
}

///////////////////////////////////////////////////////////////////////////////
// EOF
