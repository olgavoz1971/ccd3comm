/*
 *  Copyright (c) 2006 Copenhagen University Astronomical Observatory
 *  All possible rights reserved
 *	Filename:	
 *  Abstract:	
 *  Author:		Jeppe Jønch Andersen (jja@astro.ku.dk)
 *  Revision:
 *  Remarks:
 */
 
#include "ccd3_shm.h"

cCCD3mem::cCCD3mem(int size, bool FailExists) : TIpc(size, FailExists)
{
	Mem = (unsigned int*)getmem();
}

///////////////////////////////////////////////////////////////////////////////
// EOF
