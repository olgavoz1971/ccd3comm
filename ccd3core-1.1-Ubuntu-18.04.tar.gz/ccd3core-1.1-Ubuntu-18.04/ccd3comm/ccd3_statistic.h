/*
 * ccd3_statistic.h
 *
 *  Created on: Apr 6, 2011
 *      Author: root
 */

#ifndef CCD3_STATISTIC_H_
#define CCD3_STATISTIC_H_

#include "ccd3_processor.h"

class cCCD3statistic_processor : public cCCD3processor
{
protected:
	unsigned period;
	unsigned minval;
	unsigned maxval;
	unsigned null_val;
	double average;
	double deviation;
	void UpdateStatistics(int from, int to);
	virtual int process(int pix_from, int pix_cnt);

public:
	cCCD3statistic_processor(cCCD3processor* a_src_class, unsigned a_null_val, unsigned a_period, int a_blocksize);
	virtual unsigned get_min(void){ return minval == UINT_MAX ? 0 : minval; };
	virtual unsigned get_max(void){ return maxval; };
	virtual double get_average(void){ return average; };
	virtual double get_deviation(void){ return deviation; };
};

#endif /* CCD3_STATISTIC_PROCESSOR_H_ */
