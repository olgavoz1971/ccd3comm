/*
 * ccd3offload_fits.h
 *
 *  Created on: Dec 11, 2009
 *      Author: jja
 */

#ifndef CCD3FITS_PROCESSOR_H_
#define CCD3FITS_PROCESSOR_H_

#include <fitsio.h>
#include "ccd3_descrambler.h"

#define MAIN_HDR ((int)0)
#define ALL_HDR	 ((int)255)
#define EXT_HDR  ((int)254)

typedef struct{
	int type;
	char type_str[32];
	int b_size;
}fits_header_type;

const fits_header_type header_types[] = {
//	{TBIT, 	   "TBIT",		sizeof(char)	},
//	{TBYTE,    "TBYTE",		sizeof(char)	},
//	{TSBYTE,   "TSBYTE",	sizeof(char)	},
	{TLOGICAL, "TLOGICAL",	sizeof(int)		},
	{TSTRING,  "TSTRING",	256				},
	{TUSHORT,  "TUSHORT",	sizeof(short)	},
	{TSHORT,   "TSHORT",	sizeof(short)	},
	{TUINT,    "TUINT",		sizeof(int)		},
	{TINT,     "TINT",		sizeof(int)		},
	{TULONG,   "TULONG",	sizeof(long)	},
	{TLONG,    "TLONG",		sizeof(long)	},
	{TFLOAT,	"TFLOAT",	sizeof(float)	},
	{TDOUBLE,	"TDOUBLE",	sizeof(double)	},
};

const int header_type_count = 10;
#define MAX_FITS_VALUE_SIZE 256
#define FITS_NULL_VALUE -1

typedef struct {
	unsigned extension;
	int type;
	char key[256];
	char* value[MAX_FITS_VALUE_SIZE]; 	// I really would have preferred to allocate this field dynamically, but valgrind complains ??
										// so for now, it allocated statically to the largest possible size.
	char comment[256];
} fits_keyword;

/*class cCCD3offload_fits_info : public cCCD3offload_info
{
	public:
		char filename[MAX_PATH];
		int status;
		int xsiz;
		int ysiz;
		bool forward;
};*/

#define MAX_FITS_EXTENSIONS 16

class cCCD3fits_processor : public cCCD3pixel_processor
{
protected:
	cCCD3ArrayDescrambler* descrambler;
	char filename[MAX_PATH];
	int status;
	bool fits_std_comment;
	fitsfile* fits[MAX_FITS_EXTENSIONS + 1];  // Number of extensions + main ext
	static struct timeval t_exp_start;
	static cFifo* keywords;
	void set_keyword(fits_keyword* keyword);
	bool pre_process(void);
	int process(int from, int cnt);
	void post_process(void);
	void commit_keywords(void);
	static double get_timedate_str(struct timeval* time, char* buf);
	void init_class(void);
public:
	cCCD3fits_processor(char* a_filename, unsigned* a_src, int a_xsiz, int a_ysiz, int a_blocksize);
	cCCD3fits_processor(char* a_filename, cCCD3pixel_processor* a_src_class, int a_blocksize);
	~cCCD3fits_processor(void);
	//static bool is_valid(void) { return strlen(filename); };
	//static void end(void);
	static void exp_start(void);
	static void exp_end(int time_actual);
	static void check_fits_error(int sts);
	void set_fits_std_comment(bool new_comment);
	char* get_filename(void){ return filename; };

	static void write_key(const char* string, ...);
	static void write_key(const char* extension, const char* type, const char* key, const char* value, const char* comment);
	static void write_key(int extension, const int type,   const char* key, const void* value, const char* comment);
	static void write_key(int extension, const char* key, const bool value, const char* comment);
	static void write_key(int extension, const char* key, const int value, const char* comment);
	static void write_key(int extension, const char* key, const unsigned value, const char* comment);
	static void write_key(fits_keyword* keyword);
	typedef ePixelProcessor eFitsProcessor;
};

#endif /* CCD3OFFLOAD_FITS_H_ */
