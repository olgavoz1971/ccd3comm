#!/bin/sh

TMPFILE="tmpbatch"
CCD3COMM="/work/ccd3/software/branches/pci2-more-mem/ccd3comm/linux/ccd3comm"
XSIZ=2148
YSIZ=4102
rm dmy.fits
rm bias1.fits
rm bias2.fits
rm flat1.fits
rm flat2.fits

TSAM=50

echo @imod 0	 	>  $TMPFILE
echo @xsiz $XSIZ 	>> $TMPFILE
echo @ysiz $YSIZ 	>> $TMPFILE
#echo @read 1		>> $TMPFILE
#echo @tsam $TSAM 	>> $TMPFILE

echo @time 5 		>> $TMPFILE

echo file bias1.fits 	>> $TMPFILE
echo sint 		>> $TMPFILE

echo file bias2.fits 	>> $TMPFILE
echo sint 		>> $TMPFILE

echo @imod 1		>> $TMPFILE
echo @time 300 		>> $TMPFILE

echo file flat1.fits 	>> $TMPFILE
echo sint 		>> $TMPFILE

echo file flat2.fits 	>> $TMPFILE
echo sint 		>> $TMPFILE
echo q 			>> $TMPFILE

$CCD3COMM -b $TMPFILE
echo .run tilegain.pro | idl

exit 0

