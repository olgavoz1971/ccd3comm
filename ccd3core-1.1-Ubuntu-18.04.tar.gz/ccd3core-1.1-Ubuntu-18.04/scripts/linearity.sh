#!/bin/sh

TMPFILE="tmpbatch"
OUTFILE="data.txt"
CCD3COMM="/work/ccd3/ccd3comm/linux/ccd3comm"
XBEG=1350
YBEG=3080
XSIZ=500
YSIZ=500
TSAM=50

B1FILE=bias1.fits
B2FILE=bias2.fits
F1FILE=flat1.fits
F2FILE=flat2.fits

rm -f $OUTFILE

TIMEFROM=100
TIMETO=7000
INCREMENT=200

TIME=$TIMEFROM

echo @tsam $TSAM >  $TMPFILE
                                                              
while [ $TIME -lt $TIMETO ]; do

    rm -f $B1FILE
    rm -f $B2FILE
    rm -f $F1FILE
    rm -f $F2FILE

    echo @xbeg $XBEG	>> $TMPFILE
    echo @ybeg $YBEG	>> $TMPFILE
    echo @xsiz $XSIZ 	>> $TMPFILE
    echo @ysiz $YSIZ 	>> $TMPFILE
    echo @imod 0 	>> $TMPFILE

    echo @time 5	>> $TMPFILE

    echo file $B1FILE 	>> $TMPFILE
    echo sint 		>> $TMPFILE

    echo file $B2FILE 	>> $TMPFILE
    echo sint 		>> $TMPFILE

    echo @imod 1	>> $TMPFILE
    echo @time $TIME 	>> $TMPFILE

    echo file $F1FILE 	>> $TMPFILE
    echo sint 		>> $TMPFILE

    echo file $F2FILE 	>> $TMPFILE
    echo sint 		>> $TMPFILE
    echo q 		>> $TMPFILE

    $CCD3COMM -b $TMPFILE

    echo $TSAM $TIME $(echo .run tilegain.pro | idl) >> $OUTFILE

    rm -f $TMPFILE
    let TIME=TIME+$INCREMENT
done
exit 0

