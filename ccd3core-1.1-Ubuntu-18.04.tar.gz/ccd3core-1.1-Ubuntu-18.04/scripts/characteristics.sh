#!/bin/sh

TMPFILE="/work/noise/tmpbatch"
OUTFILE="/work/noise/data.txt"
CCD3COMM="/work/ccd3/ccd3comm/linux/ccd3comm"
IDL="/usr/local/bin/idl"
IDL_SCRIPT="/work/noise/tilegain.pro"
XBEG=1350
YBEG=3080
XSIZ=500
YSIZ=500


B1FILE=bias1.fits
B2FILE=bias2.fits
F1FILE=flat1.fits
F2FILE=flat2.fits

rm -f $OUTFILE

# iterate 30x times on TIME
TIME_FROM=100
TIMETO=4100
TIME_INCREMENT=100


#iterate 34x times on TSAM
TSAM_FROM=20
TSAM_TO=360
TSAM_INCREMENT=10

#total measurements , 30x34 = 1020

TSAM=$TSAM_FROM

while [ $TSAM -lt $TSAM_TO ]; 
do

    echo @tsam $TSAM >  $TMPFILE

    TIME=$TIME_FROM
                                                              
    while [ $TIME -lt $TIMETO ]; 
    do
        echo "********** Doing tsam=$TSAM, time=$TIME **********"

        rm -f $B1FILE
        rm -f $B2FILE
        rm -f $F1FILE
        rm -f $F2FILE

        echo @xbeg $XBEG	>> $TMPFILE
        echo @ybeg $YBEG	>> $TMPFILE
        echo @xsiz $XSIZ 	>> $TMPFILE
        echo @ysiz $YSIZ 	>> $TMPFILE
        echo @imod 0	 	>> $TMPFILE

        echo @time 5		>> $TMPFILE

        echo file $B1FILE 	>> $TMPFILE
        echo sint 		>> $TMPFILE

        echo file $B2FILE 	>> $TMPFILE
        echo sint 		>> $TMPFILE

        echo @imod 1		>> $TMPFILE
        echo @time $TIME 	>> $TMPFILE

        echo file $F1FILE 	>> $TMPFILE
        echo sint 		>> $TMPFILE

        echo file $F2FILE 	>> $TMPFILE
        echo sint 		>> $TMPFILE
        echo q 			>> $TMPFILE

        $CCD3COMM -b $TMPFILE

        echo $TSAM $TIME $(echo .run $IDL_SCRIPT | $IDL) >> $OUTFILE
        echo "********** Done tsam=$TSAM, time=$TIME **********"

        rm -f $TMPFILE
        let TIME=TIME+$TIME_INCREMENT
    done
    
    let TSAM=TSAM+$TSAM_INCREMENT
done

exit 0

