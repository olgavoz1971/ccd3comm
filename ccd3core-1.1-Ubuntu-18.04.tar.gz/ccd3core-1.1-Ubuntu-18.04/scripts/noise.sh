#!/bin/sh

TMPFILE="tmpbatch"
OUTFILE="data.txt"
CCD3COMM="/work/ccd3/software/branches/pci2-more-mem/ccd3comm/linux/ccd3comm"
XSIZ=500
YSIZ=500
XBEG=1350
YBEG=3080
TIME=300
B1FILE=bias1.fits
B2FILE=bias2.fits
F1FILE=flat1.fits
F2FILE=flat2.fits

TSAMFROM=20
TSAMTO=350
INCREMENT=10

rm -f $OUTFILE

TSAM=$TSAMFROM

echo @time $TIME > $TMPFILE

while [ $TSAM -lt $TSAMTO ]; do

    rm -f $B1FILE
    rm -f $B2FILE
    rm -f $F1FILE
    rm -f $F2FILE

    echo @imod 0 	>> $TMPFILE
    echo @xbeg $XBEG	>> $TMPFILE
    echo @ybeg $YBEG	>> $TMPFILE
    echo @xsiz $XSIZ 	>> $TMPFILE
    echo @ysiz $YSIZ 	>> $TMPFILE
    echo @tsam $TSAM 	>> $TMPFILE

    echo @time 5	>> $TMPFILE

    echo file $B1FILE 	>> $TMPFILE
    echo sint 		>> $TMPFILE

    echo file $B2FILE 	>> $TMPFILE
    echo sint 		>> $TMPFILE

    echo @imod 1	>> $TMPFILE
    echo @time $TIME 	>> $TMPFILE

    echo file $F1FILE 	>> $TMPFILE
    echo sint 		>> $TMPFILE

    echo file $F2FILE 	>> $TMPFILE
    echo sint 		>> $TMPFILE
    echo q 		>> $TMPFILE

    $CCD3COMM -b $TMPFILE

    echo $TSAM $TIME $(echo .run tilegain.pro | idl) >> $OUTFILE

    rm -f $TMPFILE
    let TSAM=TSAM+$INCREMENT
done
exit 0

