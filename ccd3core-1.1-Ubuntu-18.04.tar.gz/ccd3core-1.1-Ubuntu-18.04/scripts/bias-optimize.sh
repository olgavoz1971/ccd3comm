#!/bin/sh

TMPFILE="/work/noise/tmpbatch"
OUTFILE="/work/noise/data.txt"
CCD3COMM="/work/ccd3/ccd3comm/linux/ccd3comm"
IDL="/usr/local/bin/idl"
IDL_SCRIPT="/work/noise/tilegain.pro"
XBEG=1350
YBEG=3080
XSIZ=500
YSIZ=500


B1FILE=bias1.fits
B2FILE=bias2.fits
F1FILE=flat1.fits
F2FILE=flat2.fits

rm -f $OUTFILE

VBHA_FROM=20
VBHA_TO=24
VBHA_INCREMENT=0.1

VBHB_FROM=9
VBHB_TO=13
VBHB_INCREMENT=0.1
TIME=1000
TSAM=50

VBHA=$VBHA_FROM

#while [ $VBHA -lt $VBHA_TO ]; 
while [ `echo $VBHA $VBHA_TO|awk '{print $1 < $2}'` != 0 ] 
do

    echo @tsam $TSAM 	>  $TMPFILE
    echo @time $TIME 	>> $TMPFILE
    echo @vbha 0 $VBHA	>> $TMPFILE

    VBHB=$VBHB_FROM
                                                              
    while [ `echo $VBHB $VBHB_TO|awk '{print $1 < $2}'` != 0 ]
    do
        echo "********** Doing vbha=$VBHA, vbhb=$VBHB  **********"

        rm -f $B1FILE
        rm -f $B2FILE
        rm -f $F1FILE
        rm -f $F2FILE

	echo @vbhb 0 $VBHB	>> $TMPFILE

        echo @xbeg $XBEG	>> $TMPFILE
        echo @ybeg $YBEG	>> $TMPFILE
        echo @xsiz $XSIZ 	>> $TMPFILE
        echo @ysiz $YSIZ 	>> $TMPFILE
        echo @imod 0	 	>> $TMPFILE

        echo @time 5		>> $TMPFILE

        echo file $B1FILE 	>> $TMPFILE
        echo sint 		>> $TMPFILE

        echo file $B2FILE 	>> $TMPFILE
        echo sint 		>> $TMPFILE

        echo @imod 1		>> $TMPFILE
        echo @time $TIME 	>> $TMPFILE

        echo file $F1FILE 	>> $TMPFILE
        echo sint 		>> $TMPFILE

        echo file $F2FILE 	>> $TMPFILE
        echo sint 		>> $TMPFILE
        echo q 			>> $TMPFILE

        $CCD3COMM -b $TMPFILE

        echo $TSAM $TIME $VBHB $VBHA $(echo .run $IDL_SCRIPT | $IDL) >> $OUTFILE
        echo "********** Done vbha=$VBHA, vbhb=$VBHB **********"

        rm -f $TMPFILE
        #let VBHB=VBHB+$VBHB_INCREMENT
        VBHB=`echo $VBHB $VBHB_INCREMENT|awk '{print $1 + $2}'`
        echo Next vbhb=$VBHB
    done
    
    #let VBMA=VBHA+$VBHA_INCREMENT
    VBHA=`echo $VBHA $VBHA_INCREMENT|awk '{print $1 + $2}'`
    echo Next vbha=$VBHA
done

exit 0

